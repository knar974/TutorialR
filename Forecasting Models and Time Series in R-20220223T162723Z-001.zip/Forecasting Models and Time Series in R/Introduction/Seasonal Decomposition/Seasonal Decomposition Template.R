#libraries
#install.packages("forecast")
library(dplyr)
library(ggplot2)
library(forecast)

#load the dataset
df = read.csv("DHS_Daily_Report_2020.csv")

#Transform the Date Variable
df$Date = strptime(x = df$Date,
                   format = "%m/%d/%Y")
df$Date = as.Date(df$Date)

#Pick the variables
df = df %>% select(Date,
                   Total.Individuals.in.Shelter,
                   Easter,
                   Thanksgiving,
                   Christmas,
                   Temperature)

#Change variable name
colnames(df)[2] = "y"

#Create bubble plot
ggplot(df, aes(x = Date, y = y)) +
  geom_line() +
  xlab("Time") +
  ylab("Shelter Demand") +
  theme(text = element_text(size = 20)) +
  scale_x_date(date_labels = "%Y %b")


########################## Seasonal Decomposition ###########

#Transform Time-series Object
y = ts(data = df$y,
       start = c(2014, 1),
       frequency = 365.25)
plot.ts(y)

#Seasonality plot
ggseasonplot(x = y,
             main = "Seasonality graph")

#Additive decomposition
decomposition_additive = decompose(x = y,
                                   type = "additive")
plot(decomposition_additive)

#Seasonal decomposition
detrend_additive = decomposition_additive$x - decomposition_additive$trend
plot(detrend_additive)
deseasonal_additive = detrend_additive - decomposition_additive$seasonal
plot(deseasonal_additive)

#Exercise -> Seasonal Decomposition with multiplicative seasonality
decomposition_mul = decompose(x = y,
                              type = "multiplicative")
plot(decomposition_mul)

#Seasonal decomposition - Multiplicative
detrend_mul = decomposition_mul$x / decomposition_mul$trend
plot(detrend_mul)
deseasonal_mul = detrend_mul / decomposition_mul$seasonal
plot(deseasonal_mul)
