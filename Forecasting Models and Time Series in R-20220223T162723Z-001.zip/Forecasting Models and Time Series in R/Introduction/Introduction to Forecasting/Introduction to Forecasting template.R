#libraries
#install.packages("dplyr")
#install.packages("ggplot2")
library(dplyr)
library(ggplot2)

#load the dataset
df = read.csv("DHS_Daily_Report_2020.csv")

#Transform the Date Variable
df$Date = strptime(x = df$Date,
                   format = "%m/%d/%Y")
df$Date = as.Date(df$Date)

#Pick the variables
df = df %>% select(Date,
                   Total.Individuals.in.Shelter,
                   Easter,
                   Thanksgiving,
                   Christmas,
                   Temperature)

#Change variable name
colnames(df)[2] = "y"

#Create bubble plot
ggplot(df, aes(x = Date, y = y)) +
  geom_line() +
  xlab("Time") +
  ylab("Shelter Demand") +
  theme(text = element_text(size = 20)) +
  scale_x_date(date_labels = "%Y %b",
               limit = c(as.Date("2020-01-01"),
                         as.Date("2020-12-31")))





