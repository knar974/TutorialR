#libraries
#install.packages("tseries")
#install.packages("plotly")
#install.packages("zoo")
library(tseries)
library(plotly)
library(zoo)
library(ggplot2)

#data
bitcoin = get.hist.quote(instrument = "BTC-USD",
                         start = "2018-01-01",
                         end = "2022-01-31",
                         quote = "Close",
                         compression = "d")
ethereum = get.hist.quote(instrument = "ETH-USD",
                         start = "2018-01-01",
                         end = "2022-01-31",
                         quote = "Close",
                         compression = "d")

#Prepare the data
df = cbind(bitcoin, ethereum)
df = fortify.zoo(df)  
  
#Simple plot
ggplot(data = df, aes(x = Index, y = Close.bitcoin)) +
  geom_line() + 
  xlab("Time") + 
  ylab("Bitcoin Price")

#Changing the line color
ggplot(data = df, aes(x = Index, y = Close.bitcoin)) +
  geom_line(color = "blue") + 
  xlab("Time") + 
  ylab("Bitcoin Price")
  
#Focus on the dates
#y: year, b: month in roman letter, m: month in numbers
#a: weekdays, d: days
ggplot(data = df, aes(x = Index, y = Close.bitcoin)) +
  geom_line(color = "blue") + 
  xlab("Time") + 
  ylab("Bitcoin Price") +
  scale_x_date(date_labels = "%Y-%m",
               date_breaks = "2 months",
               limit = c(as.Date("2021-01-01"),
                         as.Date("2021-12-31")))
  
#Text at and angle  
ggplot(data = df, aes(x = Index, y = Close.bitcoin)) +
  geom_line(color = "blue") + 
  xlab("Time") + 
  ylab("Bitcoin Price") +
  scale_x_date(date_labels = "%y-%m",
               date_breaks = "6 months") +
  theme(axis.text.x = element_text(angle = 60, hjust = 1),
        axis.text.y = element_text(angle = 30, hjust = 1))

#Intercept
ggplot(data = df, aes(x = Index, y = Close.bitcoin)) +
  geom_line(color = "blue") + 
  xlab("Time") + 
  ylab("Bitcoin Price") +
  scale_x_date(date_labels = "%y-%m",
               date_breaks = "6 months") +
  theme(axis.text.x = element_text(angle = 60, hjust = 1),
        axis.text.y = element_text(angle = 30, hjust = 1)) +
  geom_hline(yintercept = 30000, color = 'orange', size = 0.5)

#Add text and change limits
ggplot(data = df, aes(x = Index, y = Close.bitcoin)) +
  geom_line(color = "blue") + 
  xlab("Time") + 
  ylab("Bitcoin Price") +
  scale_x_date(date_labels = "%y-%m",
               date_breaks = "6 months") +
  theme(axis.text.x = element_text(angle = 60, hjust = 1),
        axis.text.y = element_text(angle = 30, hjust = 1)) +
  geom_hline(yintercept = 30000, color = 'orange', size = 0.5) +
  annotate(geom = "text", x = as.Date("2021-11-10"), y = 72000,
           label = "Bitcoin Price \nat All time High") + 
  ylim(0,80000) + 
  annotate(geom = "point", x = as.Date("2021-11-10"), y = 68000,
           size = 8, shape = 21, fill = "transparent")

#exercise: for Ethereum, create a graph:
#line color is red
#date label format is yyyy-january
#date breaks = 2 months
#Period of the graph: 2021
#text angle is 45 degrees, at least one of the axis
#intercept at 1500
#Make a mark at the all time high

#Exercise solutions
ggplot(df, aes(x = Index, y = Close.ethereum)) +
  geom_line(color = "red") + 
  xlab("Time") + 
  ylab("Ethereum price in USD") +
  scale_x_date(date_labels = "%Y-%B",
               date_breaks = "2 months",
               limits = c(as.Date("2021-01-01"), 
                          as.Date("2021-12-31"))) +
  theme(axis.text = element_text(angle = 45, hjust = 1)) + 
  geom_hline(yintercept = 1500, color = "purple", size = 0.8) + 
  annotate(geom = "text", x = as.Date("2021-11-08"), y = 5200,
           label = "Ethereum price \nat all time high") + 
  ylim(0, 6000) +
  annotate(geom = "point", x = as.Date("2021-11-08"), y = 4800,
           size = 10, shape = 21, fill = "transparent")

#interactive plots
p = ggplot(df, aes(x = Index, y = Close.ethereum)) +
      geom_line(color = "red") + 
      xlab("Time") + 
      ylab("Ethereum price in USD") +
      scale_x_date(date_labels = "%Y-%B",
                   date_breaks = "2 months",
                   limits = c(as.Date("2021-01-01"), 
                              as.Date("2021-12-31"))) +
      theme(axis.text = element_text(angle = 45, hjust = 1)) + 
      geom_hline(yintercept = 1500, color = "purple", size = 0.8) + 
      annotate(geom = "text", x = as.Date("2021-11-08"), y = 5200,
               label = "Ethereum price \nat all time high") + 
      ylim(0, 6000) +
      annotate(geom = "point", x = as.Date("2021-11-08"), y = 4800,
               size = 10, shape = 21, fill = "transparent")
ggplotly(p)






