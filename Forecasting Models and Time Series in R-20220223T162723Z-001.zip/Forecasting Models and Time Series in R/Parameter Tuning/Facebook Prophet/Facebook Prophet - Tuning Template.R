#libraries
library(dplyr)
library(prophet)
library(forecast)

#load the dataset
df = read.csv("DHS_Daily_Report_2020.csv")

#Transform the Date Variable
df$Date = strptime(x = df$Date,
                   format = "%m/%d/%Y")
df$Date = as.Date(df$Date)

#Pick the variables
df = df %>% select(Date,
                   Total.Individuals.in.Shelter,
                   Easter,
                   Thanksgiving,
                   Christmas,
                   Temperature)

#Change variable name
colnames(df)[1] = "ds"
colnames(df)[2] = "y"

######################### Holidays #############

#Easter
easter_dates = subset(df, df$Easter == 1)
easter_dates = easter_dates$ds
easter = tibble(holiday = 'easter',
                ds = easter_dates,
                lower_window = -4,
                upper_window = +2)

#thanksgiving
thanksgiving_dates = subset(df, df$Thanksgiving == 1)
thanksgiving_dates = thanksgiving_dates$ds
thanksgiving = tibble(holiday = 'thanksgiving',
                      ds = thanksgiving_dates,
                      lower_window = -3,
                      upper_window = 1)

#merge holidays
holidays = bind_rows(easter, thanksgiving)

######################## Facebook Prophet Model ###########

#Prophet model
m = prophet(holidays = holidays,
            yearly.seasonality = TRUE,
            weekly.seasonality = TRUE,
            daily.seasonality = FALSE,
            seasonality.mode = 'multiplicative',
            seasonality.prior.scale = 10,
            holidays.prior.scale = 10,
            changepoint.prior.scale = 0.05)
m = add_regressor(m, 'Christmas')
m = add_regressor(m, 'Temperature')
m = fit.prophet(m, df)

######################## Cross-Validation ###########

#CV
df.cv = cross_validation(model = m,
                         horizon = 31,
                         units = 'days',
                         period = 7,
                         initial = 2300)
accuracy(df.cv$yhat, df.cv$y)


############### Parameter Tuning ###################

#Parameter grid
prophetGrid = expand.grid(changepoint_prior_scale = c(0.05, 0.1),
                          seasonality_prior_scale = c(5, 10, 15),
                          holidays_prior_scale = c(5,10),
                          seasonality.mode = c('multiplicative', 'additive'))

#Results vector
results = vector(mode = 'numeric',
                 length = nrow(prophetGrid))

#PArameter tuning
for (i in 1:nrow(prophetGrid)) {
  
  #Fetch parameters
  parameters = prophetGrid[i, ]
  
  #Build the model
  m = prophet(yearly.seasonality = TRUE,
              weekly.seasonality = TRUE,
              daily.seasonality = FALSE,
              holidays = holidays,
              seasonality.mode = parameters$seasonality.mode,
              seasonality.prior.scale = parameters$seasonality_prior_scale,
              holidays.prior.scale =  parameters$holidays_prior_scale,
              changepoint.prior.scale = parameters$changepoint_prior_scale)
  m = add_regressor(m, 'Christmas')
  m = add_regressor(m, 'Temperature')
  m = fit.prophet(m, df)
  
  #Cross-validation
  df.cv = cross_validation(model = m,
                           horizon = 31,
                           units = 'days',
                           period = 14,
                           initial = 2400)
  
  #store the results
  results[i] = accuracy(df.cv$yhat, df.cv$y)[1, 2]
  print(i)
  
  
}

prophetGrid = cbind(prophetGrid, results)
best_params = prophetGrid[prophetGrid$results == min(results), ]






