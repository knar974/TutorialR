#Libraries
library(prophet)
library(dplyr)
library(forecast)

#get the data
df = read.csv("Udemy_wikipedia_visits.csv")

#change Date format
df$Date = strptime(df$Date, format = "%m/%d/%Y")
df$Date = as.Date(df$Date)

#Change column names
colnames(df)[1] = "ds"
colnames(df)[2] = "y"

#Easter 
easter_dates = subset(df, df$Easter == 1)
easter_dates = easter_dates$ds
easter = tibble(holiday = 'easter',
                ds = easter_dates,
                lower_window = -6,
                upper_window = +3)

#Christmas
christmas_dates = subset(df, df$Christmas == 1)
christmas_dates = christmas_dates$ds
christmas = tibble(holiday = 'christmas',
                   ds = christmas_dates,
                   lower_window = -6,
                   upper_window = +3)

#Merge the holidays
holidays = bind_rows(easter, christmas)

#Prophet Model
m = prophet(yearly.seasonality = TRUE,
            weekly.seasonality = TRUE,
            daily.seasonality = FALSE,
            seasonality.mode = "multiplicative",
            holidays = holidays,
            seasonality.prior.scale = 10,
            holidays.prior.scale = 10,
            changepoint.prior.scale = 0.05)
m = add_regressor(m, 'Black.Friday')
m = fit.prophet(m, df)


################ Parameter Tuning #######################
#Parameter grid and results vector
prophetGrid = expand.grid(changepoint_prior_scale = c(0.05, 0.1, 0.15),
                          seasonality_prior_scale = c(5,10),
                          holidays_prior_scale = c(5, 10, 15),
                          seasonality.mode = c('multiplicative', 'additive'))
results = vector(mode = 'numeric',
                 length = nrow(prophetGrid))

#PArameter tuning
for (i in 1:nrow(prophetGrid)) {
  
  #Fetch the parameters
  parameters = prophetGrid[i, ]
  
  #Build the model
  m = prophet(yearly.seasonality = TRUE,
              weekly.seasonality = TRUE,
              daily.seasonality = FALSE,
              seasonality.mode = parameters$seasonality.mode,
              holidays = holidays,
              seasonality.prior.scale = parameters$seasonality_prior_scale,
              holidays.prior.scale = parameters$holidays_prior_scale,
              changepoint.prior.scale = parameters$changepoint_prior_scale)
  m = add_regressor(m, 'Black.Friday')
  m = fit.prophet(m, df)
  
  #CV
  df.cv = cross_validation(model = m,
                           horizon = 31,
                           initial = 1600,
                           period = 14,
                           units = 'days')
  
  #Results
  results[i] = accuracy(df.cv$yhat, df.cv$y)[1,2]
  print(i)
  
}

#Fetch best parameters
prophetGrid = cbind(prophetGrid, results)
best_params = prophetGrid[prophetGrid$results == min(results), ]














