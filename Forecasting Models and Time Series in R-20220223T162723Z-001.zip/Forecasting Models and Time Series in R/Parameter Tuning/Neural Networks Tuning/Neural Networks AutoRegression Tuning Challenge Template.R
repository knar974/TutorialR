#install packages
#install.packages("fpp3")

#libraries
library(fpp3)
library(forecast)

#data
data("us_change")

############# Preparations ##########################

#Numbers for Training and test
numbers = seq(from = 170, to = 194, by = 2)

#results for CR
results_cv = vector(mode = 'numeric', length(numbers))

#Parameter Grid
Grid = expand.grid(p = seq(from = 1, to = 6, by = 1),
                   P = c(1,2,3),
                   decay = c(0.05, 0.1, 0.15),
                   size = c(1,2,3,4))

#Results for tuning
results_grid = vector(mode = 'numeric', length = nrow(Grid))

############### Parameter Tuning #################

for (i in seq_len(nrow(Grid))) {
  parameters = Grid[i, ]
  print(i)
  
  for (j in 1:length(numbers)){
    print(j)
    #Training and test set
    training = us_change[1:numbers[j], ]
    test = us_change[(numbers[j]+1):(numbers[j] + 4), ]
    
    #transform training y
    training_y = ts(training$Unemployment,
                    frequency = 4)
    
    #Isolate Regressors
    training_reg = as.matrix(training[, 2:5])
    test_reg = as.matrix(test[ , 2:5])
    
    #Forecasting model
    model = nnetar(y = training_y,
                   p = parameters$p,
                   P = parameters$P,
                   size = parameters$size,
                   xreg = training_reg,
                   decay = parameters$decay)
    
    #Forecasting
    predictions = forecast(model, xreg = test_reg)
    
    #Accuracy
    results_cv[j] = accuracy(predictions$mean, 
                             test$Unemployment)[1,3]
  
  }
  #storing CV in the Grid Results
  results_grid[i] = mean(results_cv)
}

#Fetch the best parameters
Grid = cbind(Grid, results_grid)
best_params = Grid[Grid$results_grid == min(results_grid), ] 












