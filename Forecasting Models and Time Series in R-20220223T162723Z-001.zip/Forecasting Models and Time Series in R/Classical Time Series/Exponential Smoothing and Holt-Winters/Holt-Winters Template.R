#Libraries
library(dplyr)
library(ggplot2)
library(forecast)

#load the data
df = read.csv("Churrasco.csv")

#time series transformation
#frequency  = 52 if weekly, 12, if monthly, 4 for quarterly
#7 for daily or 365
y = ts(data = df$Churrasco,
       frequency = 52,
       start = c(2016, 5))

#Plotting
plot.ts(y)
ggseasonplot(y,
             polar = TRUE)

#Training and Test Set
training = window(x = y,
                  end = c(2020,47))
test = window(x = y,
              start = c(2020,48))

#Holt-Winters model
model = HoltWinters(x = training,
                    seasonal = "additive")

#Predictions
predictions = forecast(model, h = length(test))

#plotting
plot(predictions)

#Accuracy 
accuracy(predictions$mean, test)

#storing error
error_multiplicative = accuracy(predictions$mean, test)[1,2]
















