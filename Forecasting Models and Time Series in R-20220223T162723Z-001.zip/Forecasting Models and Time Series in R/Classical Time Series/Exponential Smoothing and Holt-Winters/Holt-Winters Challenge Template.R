#Get the data
#install.packages("TSA")
library(TSA)
data("airmiles")
airmiles

#library
library(forecast)
plot.ts(airmiles)
ggseasonplot(airmiles,
             polar = TRUE)


#Training and Test Set
training = window(airmiles, end = c(2004, 5))
test = window(airmiles, start = c(2004, 6))

#Holt Winters Model
model = HoltWinters(training, 
                    seasonal = "multiplicative")

#predictions
predictions = forecast(model, h = length(test))

#Accuracy
accuracy(predictions$mean, test)

#Error
RMSE_mul = 1893563
RMSE_add = 2218902



