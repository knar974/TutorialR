#libraries
#install.packages("dplyr")
#install.packages("ggplot2")
library(dplyr)
library(ggplot2)

#loading data
df = read.csv("DHS_Daily_Report_2020.csv")

#Transforming Date Variable
df$Date = strptime(df$Date, "%m/%d/%Y")
df$Date = as.Date(df$Date)

#selecting variables
df = df %>% select(Date,
                   Total.Individuals.in.Shelter,
                   Easter,
                   Thanksgiving,
                   Christmas,
                   Temperature)

#transforming Y variable
colnames(df)[2] = "y"

#Most basic bubble plot
ggplot(df, aes(x=Date, y=y)) +
  geom_line() +
  xlab("Time") +
  ylab("shelter demand") +
  theme(text = element_text(size=20)) +
  scale_x_date(date_labels = "%Y %b")

#########################################################################

#loading data
prophet = read.csv("Demand Forecasting Product/Ensemble/prophet.csv")
sarimax = read.csv("Demand Forecasting Product/Ensemble/sarimax.csv")
neural = read.csv("Demand Forecasting Product/Ensemble/neural.csv")

#################################################################

#training and test set
training <- df %>% filter(Date < '2020-12-01')
test <- df %>% filter(Date >= '2020-12-01')

#cleaning test set
test <- test[, 1:2]

#merging everything
ensemble <- cbind(test,
                  sarimax,
                  prophet,
                  neural)

#creating average forecast
ensemble <- transform(ensemble,
                      ensemble_forecast = rowMeans(ensemble[,3:ncol(ensemble)]))

#accuracy
accuracy(ensemble$ensemble_forecast, ensemble$y)

#plotting
library(tidyr)
library(ggplot2)
ensemble %>% 
  pivot_longer(-c(Date),
               names_to = "forecast", 
               values_to = "value") %>%
  ggplot(aes(x = Date, y = value)) + 
  geom_line(aes(color = forecast), size = 1) +
  theme_minimal()







