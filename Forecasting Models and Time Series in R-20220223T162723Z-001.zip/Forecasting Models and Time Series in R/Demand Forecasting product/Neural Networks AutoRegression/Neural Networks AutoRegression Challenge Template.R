#install packages
#install.packages("fpp3")

#libraries
library(fpp3)
library(forecast)

#data
data("us_change")

#Training and test set
training = us_change[1:194, ]
test = us_change[195:198, ]

#transform training y
training_y = ts(training$Unemployment,
                frequency = 4,
                start = 1970)

#plot
plot.ts(training_y)

#Isolate Regressors
training_reg = as.matrix(training[, 2:5])
test_reg = as.matrix(test[ , 2:5])

#Forecasting model
model = nnetar(y = training_y,
               p = 1,
               P = 1,
               size = 2,
               xreg = training_reg,
               decay = 0.2)

#Forecasting
predictions = forecast(model, xreg = test_reg)
plot(predictions)

#Accuracy
accuracy(predictions$mean, test$Unemployment)


















