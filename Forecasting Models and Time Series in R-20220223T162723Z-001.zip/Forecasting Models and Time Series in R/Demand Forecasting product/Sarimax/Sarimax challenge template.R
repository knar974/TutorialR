#library
library(forecast)

#get the data
df = read.csv("Churrasco.csv")

#training and test split
training = df[1:251,]
test = df[252:261,]

#Exogenous variables
train_exog = as.matrix(training[,3:5])
test_exog = as.matrix(test[,3:5])

#Time Series Object
training_y = ts(data = training$Churrasco,
                frequency = 52,
                start = c(2016,4))

#plotting
plot.ts(training_y)

#SARIMAX Model
model = auto.arima(y = training_y,
                   xreg = train_exog)
summary(model)

#forecast
forecast = forecast(model, xreg = test_exog)

#Accuracy
accuracy(forecast$mean, test$Churrasco)










