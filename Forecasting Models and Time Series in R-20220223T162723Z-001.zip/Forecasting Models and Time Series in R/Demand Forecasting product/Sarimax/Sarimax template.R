#libraries
#install.packages("dplyr")
#install.packages("ggplot2")
library(dplyr)
library(ggplot2)
library(forecast)

#load the dataset
df = read.csv("DHS_Daily_Report_2020.csv")

#Transform the Date Variable
df$Date = strptime(x = df$Date,
                   format = "%m/%d/%Y")
df$Date = as.Date(df$Date)

#Pick the variables
df = df %>% select(Date,
                   Total.Individuals.in.Shelter,
                   Easter,
                   Thanksgiving,
                   Christmas,
                   Temperature)

#Change variable name
colnames(df)[2] = "y"

#Create bubble plot
ggplot(df, aes(x = Date, y = y)) +
  geom_line() +
  xlab("Time") +
  ylab("Shelter Demand") +
  theme(text = element_text(size = 20)) +
  scale_x_date(date_labels = "%Y %b")

###################################################

#Training and Test Set
training = df %>% filter(Date < '2020-12-01')
test = df %>% filter(Date >= '2020-12-01')

#Time series object
#if daily, then 7 or 365, 12 if monthly, 52 if weekly,
#4 if quarterly
training_y = ts(data = training$y,
                frequency = 7)

#Auto-correlation plot
acf(training_y)

#Stationarity
ndiffs(x = training_y,
       test = "adf")

#Get the regressors
training_reg = as.matrix(training[,3:6])
test_reg = as.matrix(test[,3:6])

#SARIMAX model
model = auto.arima(training_y, 
                   stepwise = FALSE, 
                   approximation = FALSE,
                   xreg = training_reg)
summary(model)

#Forecasting
predictions_sarimax = forecast(model, xreg = test_reg)

#plotting
autoplot(predictions_sarimax)

#Accuracy
accuracy(predictions_sarimax$mean, test$y)

######################################

#saving forecasts
sarimax = as.data.frame(predictions_sarimax$mean)
colnames(sarimax)[1] = 'SARIMAX'
write.csv(sarimax,
          file = "Demand Forecasting Product/Ensemble/sarimax.csv",
          row.names = FALSE)












