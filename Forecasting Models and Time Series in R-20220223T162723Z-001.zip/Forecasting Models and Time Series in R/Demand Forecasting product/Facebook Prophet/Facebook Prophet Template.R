#libraries
#install.packages("dplyr")
#install.packages("ggplot2")
#install.packages("prophet")
library(dplyr)
library(ggplot2)
library(prophet)
library(forecast)

#load the dataset
df = read.csv("DHS_Daily_Report_2020.csv")

#Transform the Date Variable
df$Date = strptime(x = df$Date,
                   format = "%m/%d/%Y")
df$Date = as.Date(df$Date)

#Pick the variables
df = df %>% select(Date,
                   Total.Individuals.in.Shelter,
                   Easter,
                   Thanksgiving,
                   Christmas,
                   Temperature)

#Change variable name
colnames(df)[1] = "ds"
colnames(df)[2] = "y"

#Create bubble plot
ggplot(df, aes(x = ds, y = y)) +
  geom_line() +
  xlab("Time") +
  ylab("Shelter Demand") +
  theme(text = element_text(size = 20)) +
  scale_x_date(date_labels = "%Y %b")

######################### Holidays #############

#Easter
easter_dates = subset(df, df$Easter == 1)
easter_dates = easter_dates$ds
easter = tibble(holiday = 'easter',
                ds = easter_dates,
                lower_window = -4,
                upper_window = +2)

#thanksgiving
thanksgiving_dates = subset(df, df$Thanksgiving == 1)
thanksgiving_dates = thanksgiving_dates$ds
thanksgiving = tibble(holiday = 'thanksgiving',
                      ds = thanksgiving_dates,
                      lower_window = -3,
                      upper_window = 1)

#merge holidays
holidays = bind_rows(easter, thanksgiving)

######################### Training and Test ###############

#Training and Test Set
training = df %>% 
  filter(ds < '2020-12-01') %>%
  select(ds, y, Christmas, Temperature)
test = df %>%
  filter(ds >= '2020-12-01') %>%
  select(ds, y, Christmas, Temperature)

######################## Facebook Prophet Model ###########

#Prophet model
m = prophet(holidays = holidays,
            yearly.seasonality = TRUE,
            weekly.seasonality = TRUE,
            daily.seasonality = FALSE,
            seasonality.mode = 'multiplicative',
            seasonality.prior.scale = 10,
            holidays.prior.scale = 10,
            changepoint.prior.scale = 0.05)
m = add_regressor(m, 'Christmas')
m = add_regressor(m, 'Temperature')
m = fit.prophet(m, training)

#Regressor coefficients
regressor_coefficients(m)

#Create Future dataframe
future = make_future_dataframe(m,
                               periods = nrow(test))
future[,2:3] = df %>% select(Christmas, Temperature)

#Forecasting
forecast = predict(m, future)

#Events
forecast %>%
  select(ds, thanksgiving) %>%
  filter(abs(thanksgiving) > 0) %>%
  filter(ds > '2020-01-01')
print(easter_dates)

#visualization
plot(m, forecast)
prophet_plot_components(m, forecast)
plot(m, forecast) + add_changepoints_to_plot(m)

#Accuracy
predictions = tail(forecast$yhat, nrow(test))
accuracy(predictions, test$y)


################### Save the forecasts ####################

prophet = as.data.frame(predictions)
colnames(prophet)[1] = 'Prophet'
write.csv(prophet,
          file = "Demand Forecasting Product/Ensemble/prophet.csv",
          row.names = FALSE)  
  
  


