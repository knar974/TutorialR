#Libraries
library(prophet)
library(dplyr)
library(forecast)

#get the data
df = read.csv("Udemy_wikipedia_visits.csv")

#change Date format
df$Date = strptime(df$Date, format = "%m/%d/%Y")
df$Date = as.Date(df$Date)

#Change column names
colnames(df)[1] = "ds"
colnames(df)[2] = "y"

#Easter 
easter_dates = subset(df, df$Easter == 1)
easter_dates = easter_dates$ds
easter = tibble(holiday = 'easter',
                ds = easter_dates,
                lower_window = -6,
                upper_window = +3)

#Christmas
christmas_dates = subset(df, df$Christmas == 1)
christmas_dates = christmas_dates$ds
christmas = tibble(holiday = 'christmas',
                ds = christmas_dates,
                lower_window = -6,
                upper_window = +3)

#Merge the holidays
holidays = bind_rows(easter, christmas)

#Training and test set
training = df %>%
  filter(ds < '2020-12-01') %>%
  select(ds, y, Black.Friday)

test = df %>%
  filter(ds >= '2020-12-01') %>%
  select(ds, y, Black.Friday)

#Prophet Model
m = prophet(yearly.seasonality = TRUE,
            weekly.seasonality = TRUE,
            daily.seasonality = FALSE,
            seasonality.mode = "multiplicative",
            holidays = holidays,
            seasonality.prior.scale = 10,
            holidays.prior.scale = 10,
            changepoint.prior.scale = 0.05)
m = add_regressor(m, 'Black.Friday')
m = fit.prophet(m, training)

#coefficients
regressor_coefficients(m)

#Future Dataframe
future = make_future_dataframe(m,
                               periods = nrow(test))
future[,2] = df %>% select(Black.Friday)

#Forecasting
forecast = predict(m, future)

#Plotting
plot(m, forecast)
prophet_plot_components(m, forecast)
plot(m, forecast) + add_changepoints_to_plot(m)

#Accuracy
predictions = tail(forecast$yhat, nrow(test))
accuracy(predictions, test$y)


