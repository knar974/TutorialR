## ----cache=FALSE, echo=FALSE,include=FALSE-------------------------------
source('hooks.R', echo=TRUE)
fig.path='figures/intro-'

## ----echo=FALSE,eval=TRUE------------------------------------------------
options(continue="  ")

