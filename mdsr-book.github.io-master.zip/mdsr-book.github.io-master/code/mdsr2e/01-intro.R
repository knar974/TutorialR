## ----graunt, echo=FALSE, out.width = "49%", fig.show='hold', fig.cap="Excerpt from Graunt's bills of mortality. At left, the title page. At right, an excerpt on the plague."----
knitr::include_graphics("gfx/graunt1.png")
knitr::include_graphics("gfx/graunt2.png")

