# check version number
import imblearn
print(imblearn.__version__)