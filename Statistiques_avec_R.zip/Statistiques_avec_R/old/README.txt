De l'(in)utilit� d'un tableur : statistiques avec R

Cette ann�e, je me retrouve prof en lyc�e (Grrrr...). Pour taper les notes
de mes �l�ves, les visualiser et calculer les moyennes, j'ai tent� d'utiliser 
un tableur (gnumeric), mais devant le manque de flexibilit� de ce genre d'outil,
je me suis finalement tourn� vers un logiciel de statistiques : R.

* Gnumeric

Un tableur, c'est un logiciel qui permet de remplir des tableaux
avec des nombres, des chaines de caract�res, ou des formules.
Par exemple, on peut mettre, le nom des �l�ves dans une premi�re colonne, 
leur pr�nom dans une deuxi�me, leurs notes dans les colonnes suivantes,
et demander � l'ordinateur de faire la moyenne dans la derni�re colonne.
Autre exemple, pour les commer�ants, on peut mettre le code
d'un article dans une colonne, le prix unitaire dans une autre, le nombre
d'articles command�s dans une autre et le prix total dans une derni�re colonne ; 
il y a alors une ligne par article, plus une derni�re ligne avec le total.

De mani�re plus g�n�rale, un tableur, c'est une grosse machine � calculer, 
grosse en ce sens qu'elle permet de faire de grosses additions.

Comme tableur, j'ai choisi gnumeric.

  http://www.gnome.org/projects/gnumeric/

Mais il en existe d'autres, qui pr�sentent probablement les m�mes
fonctionnalit�s.

  http://www.openoffice.org/
  http://www.koffice.org/kspread/
  http://siag.nu/index.shtml

=screenshot1.png

On peut taper des formules simples (un seul appel de fonction)
� l'aide du cliquodrome : c'est pratique si on ne connait
pas tr�s bien le nom ou les arguments des fonctions.

=screenshot2.png

On peut aussi taper les formules directement, comme si c'�tait
du texte : pour que le tableur comprenne qu'il s'agit bien d'une formule,
il suffit de la faire commencer par le signe =. Par exemple, on 
pourra taper << =median(B1:B20) >>.

Plut�t que de taper les num�ros de cases � la main, on peut les
s�lectionner � la souris (en plein milieu de la saisie de la formule).

Attention ! 
En fran�ais, il faut s�parer les arguments de fonctions par un point-virgule
(en anglais, c'est une virgule) et utiliser une virgule dans les nombres 
d�cimaux (et pas un point comme en anglais)...
Je trouve plus simple de lancer gnumeric en anglais :

  unset `set | grep -E -a '^(LC|LANG)' | sed 's/=.*//'`
  gnumeric Seconde.gnumeric &

On peut alors faire des traitements statistiques un peu plus pouss�s que 
la moyenne. Voici quelques fonctions que je trouve utiles.

  max         Valeur maximale
  min         Valeur minimale
  median      Valeur m�diane
  percentiles

  large       k-i�me plus grande valeur
  small       k-i�me plus petite valeur
  rank        rang d'une valeur

  count       nombre de valeurs num�riques
  counta      nombre de cases

  mean        Moyenne arithm�tique
  trimmean    Moyenne apr�s avoir enlev� les valeurs les plus
              �lev�es et les plus basses.
  stdevp      D�viation standard (d'une population)

Exemple 1. Les �l�ves les plus mauvais auront droit � une s�ance 
d'"aide individuelle". Voici la huiti�me note � partir du bas.

  =small( B1:B30 ; 8 )

Voici le nombre d'�l�ves concern�s (il peut y en avoir plusieurs 
qui ont cette note-l�).

  =count( B1:B30 ) - rank( B31 ; B1:B30 ; 0 ) + 1

J'aimerais bien avoir la liste des �l�ves concern�s, mais avec gnumeric seul, 
je ne sais pas faire, du moins, pas de mani�re automatique.

Exemple 2. Pour les relev�s de notes trimestriels, je calcule les moyennes � gentillement � : 
j'enl�ve syst�matiquement la note la plus basse.

  =(sum(A1:A12)-small(A1:A12,1))/(count(A1:A12)-1)

* Griefs contre gnumeric

Je n'arrive pas � demander � gnumeric le nom des huit �l�ves les plus mauvais.

Je n'arrive pas � faire la moyenne d'un ensemble de cases non contigu�s.

Je n'arrive pas � repr�senter graphiquement les donn�es.

Je n'arrive pas � obtenir des repr�sentation graphiques non �l�mentaires 
(par exemple, l'analyse en composantes principales, avec le graphe des valeurs
propres) des donn�es.

* Utilisation conjointe de gnumeric et R, graphiques avec R

R est un logiciel de statistiques (un �quivalent gratuit, et m�me
libre, de S-plus), avec lequel on peut programmer, et donc avec lequel
je ne serai pas limit�. L'autre gros logiciel de statistiques
commercial est SAS, dont un �quivalent libre est DAP (Data Analysis
and Presentation), que je ne connais pas.

  http://www.gnu.org/software/dap/dap.html

On doit aussi pouvoir faire un peu de statistique avec Matlab et ses
clones, SciLab et Octave.

  http://www-rocq.inria.fr/scilab/
  http://www.octave.org/

Pour lancer R, c'est tr�s simple : on tape << R >>.
Et on se retrouve avec une belle interface textuelle...

  % R

  R : Copyright 2002, The R Development Core Team
  Version 1.5.1  (2002-06-17)

  R is free software and comes with ABSOLUTELY NO WARRANTY.
  You are welcome to redistribute it under certain conditions.
  Type `license()' or `licence()' for distribution details.

  R is a collaborative project with many contributors.
  Type `contributors()' for more information.

  Type `demo()' for some demos, `help()' for on-line help, or
  `help.start()' for a HTML browser interface to help.
  Type `q()' to quit R.

  > 1+1
  [1] 2
  > demo()
  > demo(graphics)

On peut aussi demander une interface graphique.

  R --gui=GNOME

= R_gnome.png

Mais revenons � Gnumeric.
Dans un premier temps, j'ai envisag� de continuer � utiliser gnumeric 
pour taper les notes et R pour faire les calculs et les dessins.

Pour cela, apr�s avoir tap� les notes, je dois sauvegarder 
le fichier au format CSV, 

=screenshot3.png
=screenshot4.png
=screenshot5.png

puis enlever les lignes ou 
colonnes dont je n'a pas besoin (celles qui contiennent des calculs 
que gnumeric est capable de faire),

  perl -p -i -e 'if(!$b){m/(,*)$/;$a=$1;$b=1}s/$a$//;exit if m/^,*$/' tmp.csv

puis charger le fichier sous R.

  ?read.table
  notes = read.table("tmp.csv", header=TRUE, sep=",", dec=".")
  notes$note
   [1]  8 15 14 16  8  5 11 16 12  6 11  7  8  4 12 14 14 13  6 11 11  1  3 14 14
  [26] 13  1 14 10 15 19  5  2 17 10

puis tracer l'histogramme des notes

  hist(notes$note)

=hist1.png

On peut aussi comparer les notes de deux devoirs

  pairs(cbind(Seconde13$C1, Seconde13$DS1))

=hist2.png

Les commandes hist et pair sont les deux seules � connaitre.
Voici n�anmoins d'autres exemples de graphiques.

  hist(notes$note, probability=TRUE, breaks=2*c(0:10))
  points(density(notes$note,bw=1), type='l')

= hist3.png

  boxplot(notes$note)

= hist4.png

  x <- notes[,3]
  y <- notes[,4]

  plot(y~x)
  abline(0,1)
  abline(lm(y ~ x))

= hist5.png

Les dessins png ont �t� r�alis�s ainsi :

  ?Devices
  ?postscript
  ?png
  png(filename="hist1.png", width=600, height=600, pointsize=12, bg="white")
  hist(note$note)
  dev.off()

Mais je trouve tr�s p�nible de devoir � chaque fois exporter le fichier 
au format csv, puis de le nettoyer : je d�cide finalement de ne plus utiliser que R.

* Les types de donn�es sous R

Avant de pouvoir programmer un peu, il est n�cessaire de 
bien comprendre les types de donn�es que manipule R.

Il y a trois valeurs bool�ennes : TRUE, FALSE et NA (Not Available).

Un vecteur (de nombres ou de chaines de caract�res : tous les �l�ments doivent
avoir le m�me type) (ici, � c � signifie � concat�ner �).

  x = c(1,2,5,3,6,3,4,0)
  n = c('foo', 'bar', 'baz')

Un facteur, c'est � peu pr�s comme un vecteur de chaines de caract�res,
mais R suppose que chaque chaine peut apparaitre plusieures fois et stocke donc
les donn�es en deux morceaux : d'une part la liste des chaines de caract�res qui
apparaissent, d'autre part le vecteur, qui ne contient plus des chaines, 
mais simplement le num�ro d'ordre de la chaine dans la liste pr�c�dente.
C'est donc ce qu'il est naturel de manipuler quand on est face � une variable 
qualitative.
On peut convertir un facteur en un vecteur de chaines de caract�res
� l'aide de la commande as.vector.

Un Data Frame, c'est une liste de vecteurs, ayant tous la m�me taille. On rappelle
que les �l�ments d'un m�me vecteur (i.e., d'une m�me colonne colonnes)
doivent tous avoir le m�me type.

  ?data.frame

Attention : si une colonne d'un Data Frame contient des chaines de caract�res,
elle est automatiquement convertie en facteur. Or, les facteurs ont tendance
� �tre convertis en vecteur num�riques, ce qui n'est pas du tout ce que l'on veut.
Il faut penser � les convertir explicitement, avec as.vector().

Les listes sont comme des vecteurs, sauf qu'elles peuvent contenir 
n'importe quel type de donn�es (nombres, chaines de caract�res, vecteurs, 
autres listes, etc.).
Je les utilise comme tables de hachage :

  h = list()
  ...
  h[["foo bar"]] = ...
  ...

La commande is.null permet de savoir si la table de hachage
contient la valeur que l'on cherche :

  if( is.null( h[[as.character(i)]] ) ){
    ...
  }

* Manipulation de vecteurs, tableaux et Data Frames

Cr�er un vecteur (� c � comme � concat�ner �) :

  c(1,3,5,2,3,4) 

Mettre le r�sultat d'un calcul dans une variable :

  x <- c(1,3,5,2,3,4) 

ou 

  x = c(1,3,5,2,3,4)

Longueur d'un vecteur :

  length(x)

Vecteur vide :

  x = vector(mode="numeric")

Ajouter un �l�ment � un vecteur :

  x = append(x, 156)

ou 

  x = c(x, 156)

Empiler plusieurs vecteurs (lignes) pour faire une matrice :

  m <- rbind(x, y, z)

Concat�ner plusieurs vecteurs (colonnes) pour faire une matrice :

  m <- cbind(x, y, z)

Cr�er un vecteur contenant les nombres de 0 � 10 :

  x <- 0:10

Tracer une fonction (une fen�tre apparait) :

  x <- (0:20)/10
  y <- x^2 +x + 1
  plot( y~x, type="l" )

Un sous-vecteur, d�fini par un vecteur d'indices :

  x[c(1,4,8,3)]

Un vecteur de bool�ens :

  x>1

Un sous-vecteur d�fini par un vecteur de bool�ens :

  x[ x>1 ]

V�rifier qu'un �l�ment d'un vecteur (ou autre) est bien d�fini :

  is.na(x[1])

Le sous-vecteur des �l�ments effectivement d�finis de x :

  x[ ! is.na(x) ]

Les op�ration bool�ennes sont !, & et | :

  x[ !is.na(x) & x>1 ]

Une ligne d'un tableau de dimension 2 :

  m[1,]

Une colonne d'un tableau de dimension 2 :

  m[,1]

Un Data Frame, c'est presque comme un tableau : les colonnes doivent
toutes avoir le m�me nombre d'�l�ments ; les colonnes sont des
vecteurs (donc les �l�ments d'une m�me colonne ont tous le m�me type,
contrairement aux listes) ; les colonnes contenant des chaines de
caract�res sont automatiquement converties en facteurs.
On peut cr�er un Data Frame 

  > data.frame(foo=c(1,2,3), bar=c('a', 'b', 'c'))
    foo bar
  1   1   a
  2   2   b
  3   3   c

ou le lire depuis un fichier CSV

  ?read.table

ou depuis l'entr�e standard

  a = scan()

Les colonnes d'un Data Frame portent un nom, que l'on peut utiliser pour
y acc�der.

  Seconde13$DS1

ou 

  Seconde12[["DS1"]]

Appliquer une fonction � chaque ligne d'un tableau (le � 1 � signifie � premi�re
dimension �, i.e., ligne) :

  apply(cbind(Seconde4$DM1, Seconde4$DS1), 1, mean)

On peut remettre le r�sultat dans un tableau :

  data.frame( nom = Seconde4$Nom,
              moyenne = apply(cbind(Seconde4$DM1, Seconde4$DS1), 1, mean)
            )

* Saisie des donn�es

Pour la saisie du nom des �l�ves et des notes, on peut utiliser le tableur int�gr� 
� R. C'est beaucoup plus rudimentaire que gnumeric, mais �a suffira.

  notes <- edit(notes)

On peut avoir besoin de changer le nom d'une colonne.

  # Liste des noms de colonnes
  attributes(notes)
  attr(notes,"names")
  attr(notes,"names")[6] = "DS2";

On peut aussi avoir besoin de r�ordonner les lignes du tableau.

  o = order(Seconde13$Nom)
  for (d in 1:length(Seconde13)) {
    Seconde13[,d] = Seconde13[,d][o]
  }

(Je ne comprends pas pourquoi j'ai �cris �a : �a n'a aucune raison de
marcher. La colonne en question est un facteur, donc la
commande order ne donnera pas le bon r�sultat.)

  o = order(as.vector(PremiereSTT$Nom))
  for (d in 1:length(PremiereSTT)) {
    PremiereSTT[,d] = PremiereSTT[,d][o]
  }

Les lignes ont un nom : je leur donne le nom des �l�ves.

  attr(Seconde13, "row.names") <- as.vector(Seconde13[,1])

(non)

* R : documentation

Le document suivant explique comment utiliser R, progressivement,
� un niveau �l�mentaire (il ne faut pas �tre effray� par les expression 
� �cart-type � ou � distribution gaussienne �, mais c'est tout).

  http://cran.r-project.org/doc/contrib/SimpleR.pdf

Le document suivant (tr�s instructif, m�me s'il est 
�crit dans une langue que je ne connais pas -- probablement
de l'espagnol), explique en d�tails quels types de graphiques on peut
r�aliser avec R. J'en conseille vivement la lecture

  http://cran.r-project.org/doc/contrib/grafi3.pdf

Le manuel de r�f�rence de R est disponible directement sous R :

  ?round

Pour les mots-clefs du langage, ou pour des commandes non alphanum�riques,
il faut mettre des guillemets.

  ?"for"
  ?"[["

Si on ne connais pas le nom de la commande :

  apropos("stem")

* R : quelques fonctions �l�mentaires

Param�tres statistiques et calculs :

  min    (notes$DS1, na.rm=T)
  max    (notes$DS1, na.rm=T)
  median (notes$DS1, na.rm=T)
  mean   (notes$DS1, na.rm=T)
  sd     (notes$DS1, na.rm=T) # Standard deviation
  rank
  sum
  length
  round

  ?fivenum
  ?quantile
  var
  mad(a) # d�viation moyenne � la m�diane (normalis�e)
  cummax # maximums cumul�s
  cummin # minimums cumul�s
  cor    # corr�lation

Affichage d'un message ou d'une variable

  print("Coucou !")

Concat�nation de chaines de caract�res

  paste("min:        ", min (x$DS1, na.rm=T)))

Ecriture dans un fichier 

  cat("\\end{document}\n", file="RESULT.tex", append=TRUE)

* R : structures de contr�le

Conditionnelle :

  if(...) {
    ...
  } else {
    ...
  }

Boucle for :

  for (i in 1:10) {
    ...
    if(...) { next }
    ...
    if(...) { break }
    ...
  }

Boucle while :

  while(...) {
    ...
  }

Boucle repeat :

  repeat {
    ...
    if(...) { break }
    ...
  }

* R : fonctions

On d�finit une fonction ainsi :

  f <- function(x) {
    x^2 + x + 1
  }

La valeur de retour est la derni�re valeur calcul�es.

On peut donner des valeurs par d�faut aux arguments.

  f <- function(x, y=3) { ... }

Lors de l'appel de la fonction, on peut utiliser le nom des arguments,
sans tenir compte de leur ordre.

  f(y=4, x=3.14)

A la fin des arguments, on peut mettre trois points de suspension,
qui repr�sentent tous les arguments que l'on n'a pas pr�cis�s, et que l'on
peut passer en argument � d'autres fonctions.

  f <- function(x, ...) {
    plot(x, ...)
  }

Les fonctions n'ont pas d'effet de bord : toutes les modifications sont locales.

La commande debug permet d'ex�cuter une fonction pas � pas.

  ?debug
  debug(f)
  f(3)
  undebug(f)

* Matrices

Une matrice :

  > m <- matrix( c(1,2,3,4), nrow=2 )
  > m
       [,1] [,2]
  [1,]    1    3
  [2,]    2    4

Le produit matriciel :

  > x <- matrix( c(6,7), nrow=2 )
  > x
       [,1]
  [1,]    6
  [2,]    7
  > m %*% x
       [,1]
  [1,]   27
  [2,]   40

Le d�terminant d'une matrice :

  > det(m)
  [1] -2

La transpos�e d'une matrice :

  > t(m)
       [,1] [,2]
  [1,]    1    2
  [2,]    3    4

Une matrice diagonale :

  > diag(c(1,2))
       [,1] [,2]
  [1,]    1    0
  [2,]    0    2

La matrice identit� (ou la matrice d'une homoth�tie) :

  > diag(1,2)
       [,1] [,2]
  [1,]    1    0
  [2,]    0    1

  > diag(rep(1,2))
       [,1] [,2]
  [1,]    1    0
  [2,]    0    1

  > diag(2)
       [,1] [,2]
  [1,]    1    0
  [2,]    0    1

On a d�j� vu les fonctions cbind et rbind pour cr�er des matrices.

  > cbind( c(1,2), c(3,4) )
       [,1] [,2]
  [1,]    1    3
  [2,]    2    4
  > rbind( c(1,3), c(2,4) )
       [,1] [,2]
  [1,]    1    3
  [2,]    2    4

La trace d'une matrice :

  > sum(diag(m))
  [1] 5

L'inverse d'une matrice :

  > solve(m)
       [,1] [,2]
  [1,]   -2  1.5
  [2,]    1 -0.5

G�n�ralement, on n'a pas besoin de l'inverse d'une matrice, mais
simplement de multiplieur par l'inverse d'une matrice : c'est plus
rapide et num�riquement plus stable.

  > solve(m, x)
       [,1]
  [1,] -1.5
  [2,]  2.5

  > solve(m) %*% x
       [,1]
  [1,] -1.5
  [2,]  2.5

Valeurs propres :

  > eigen(m)$values
  [1]  5.3722813 -0.3722813

Vecteurs propres :

  > eigen(m)$vectors
             [,1]       [,2]
  [1,] -0.5742757 -0.9093767
  [2,] -0.8369650  0.4159736

On v�rifie qu'on a effectivement diagonalis� la matrice :

  > p <- eigen(m)$vectors
  > d <- diag(eigen(m)$values)
  > p %*% d %*% solve(p)
       [,1] [,2]
  [1,]    1    3
  [2,]    2    4

C'est peut-�tre le bon moment pour rappeler les principales
d�composition d'une matrice, que l'on rencontre en alg�bre lin�aire.

La d�composition LU, ou plus pr�cis�ment PA = LDU (P: matrice de
permutation ; L, U : matrices triangulaires inf�rieure ou sup�rieure,
avec des 1 sur la diagonale ; L contient toutes les op�rations
effectu�es sur les lignes ; D : matrice des pivots) traduit le
r�sultat de l'algorithme du pivot de Gauss.

On n'en a pas r�ellement besoin, car l'algorithme du pivot de Gauss
est impl�ment� dans la commande solve, qui permet de multiplier par
l'inverse d'une matrice (sans calculer explicitement cet inverse, ce
qui serait num�riquement plus instable).

  ?solve

La d�composition de Jordan est une g�n�ralisation de la
diagonalisation (car toutes les matrices ne sont pas diagonalisables).

On n'en a pas r�ellement besoin, car si on prend une matrice au
hasard, elle est diagonalisable. 

Il y a ensuite plein de d�compositions bas�es sur la matrice t(A)*A.

La d�composition A=QR (R : triangulaire sup�rieure, Q : unitaire)
traduit l'orthonormalisation de Gram-Schmidt des colonnes de A (on
peut l'obtenir � l'aide de la d�composition LU de t(A)*A). 

  ?qr

La d�composition en valeurs singuli�res A=Q1*S*Q2 (Q1, Q2 : matrices
des vecteurs propres de A*t(A) et t(A)*A ; S : matrice diagonale des
racines carr�es des valeurs propres de A*t(A) ou t(A)*A), qui donne,
dans le cas o� A est sym�trique, sa diagonalisation dans une base
orthonormale, et qui intervient aussi dans le calcul du
pseudo-inverse. 

  ?svd

La d�composition polaire, A = QR (Q : orthogonale, R : sym�trique
d�finie positive), qui est un analogue de la d�composition polaire
d'un nombre complexe, et qui s�pare la rotation des �tirements.

A FAIRE : application � la m�thode des moindres carr�s.

  Minimiser va{ Ax - b }
  R�soudre t(A) A  x = t(A) b
  (g�n�ralement, t(A)A est inversible. Sinon, utiliser des pseudo-inverses)

A FAIRE : les diff�rentes d�compositions (rappels d'alg�bre lin�aire).

  ?svd

  SVD : �crire une matrice comme somme de matrices de rang 1, de sorte
  que les premi�res approchent � au mieux � la matrice de d�part.

  ?qr   # Lien avec les moindres carr�s

  Il y a aussi la d�composition LU


* Persistance

� la fin de chaque session, R nous demande s'il faut sauvegarder
l'environement la fois suivante : on se retrouve alors avec nos
variables et fonctions (elles sont stock�es dans un fichier dans le
r�pertoire courrant ; si on fait des plusieures choses diff�rentes
avec R, il suffit d'utiliser des r�pertoires diff�rents).

Ne pas oublier de nettoyer de temps � autres les variables du r�pertoire
courrant, � l'aide des commandes ls et rm.

  ls()
  rm(x, y, z)

On peut aussi stocker du code dans un fichier et le rappeler � l'aide
de la commande source.

  source("MonProgramme.R")

* Biblioth�ques (library) suppl�mentaires

On les trouve sur CRAN (Complete R Archive Network) 

  http://cran.r-project.org/

et on les installe ainsi :

  R CMD INSTALL vcd_0.1-3.tar.gz

Quand on constate qu'elles ne marchent pas, on peut les retirer ainsi :

  R CMD REMOVE vcd

* Programmation Orient�e Objets

Quoiqu'en dise le manuel, R n'est pas un langage orient� objet.  

+ M�thodes g�n�riques

Il y a n�anmoins un peu de polymorphisme, impl�ment� comme suit.  �
chaque objet est associ� une liste d'attributs, dont les classes
auxquelles appartient l'objet. Ainsi, si on appelle la fonction plot
avec un argument de classes "foo" et "bar", la commande va d'abord
chercher une fonction plot.foo, puis une fonction plot.bar puis enfin,
en cas d'�chec, appellera la fonction plot.defaut.  Il en va de m�me
avec la fonction print.  On peut ainsi d�finir ses propres � classes �
et surcharger les fonctions plot et print.

  > print.foo <- function (x,...) {
    print.default(x)
    print.default(min(x))
    print.default(median(x))
    print.default(max(x))
  }
  > x <- matrix( rnorm(20), nrow=4 )
  > print(x)
             [,1]       [,2]        [,3]        [,4]       [,5]
  [1,] 0.05858332 -0.3082483  1.08259617 -0.10539949 -0.3734017
  [2,] 0.23264808 -0.4763760 -0.01989608 -0.07837898  2.3640196
  [3,] 0.05239833 -0.6764430 -0.76649216  0.76078938  0.2715206
  [4,] 0.27780672 -0.5458009 -0.96929622  0.90089157  1.7325063
  > attr(x, "class") <- "foo"
  > print(x)
             [,1]       [,2]        [,3]        [,4]       [,5]
  [1,] 0.05858332 -0.3082483  1.08259617 -0.10539949 -0.3734017
  [2,] 0.23264808 -0.4763760 -0.01989608 -0.07837898  2.3640196
  [3,] 0.05239833 -0.6764430 -0.76649216  0.76078938  0.2715206
  [4,] 0.27780672 -0.5458009 -0.96929622  0.90089157  1.7325063
  attr(,"class")
  [1] "foo"
  [1] -0.9692962
  [1] 0.01625113
  [1] 2.364020

On peut aussi d�finir ses propres fonctions surchargeables ainsi :

  print <- function (x, ...) UseMethod("print")

+ Critiques

Il n'y a pas du tout d'encapsulation...

La notion centrale est celle de m�thode, et non pas celle d'objet...

+ M�thodes

Voici une autre mani�re de manipuler des objets avec R.

  A FAIRE

  library(help=methods)
  http://www.omegahat.org/RSMethods/Intro.ps  

* Graphiques

+ Commandes de base

Voici les principales commandes permettant de repr�senter des donn�es.

La commande plot permet de tracer un ensemble de points,
�ventuellement en les reliant par une ligne. C'est en fait une
fonction g�n�rique : elle se comportera diff�remment selon le type de
son argument.

La commande matplot permet de tracer plusieurs courbes en m�me temps.

La commande pairs permet de tracer plusieurs nuages de points en m�me temps.
(A FAIRE : c'est impr�cis).

La commande scatterplot permet de tracer un << nuage >> de points unidimensionnel.

La commande hist permet de tracer un histogramme.

La commande boxplot permet de tracer un (ou plusieurs) diagrammes � moustaches.

La commande contour permet de tracer des lignes de niveau.

La commande persp permet de tracer une surface.

+ Configuration

Voici quelques mani�res de configurer ces graphiques.

On peut ajouter un titre, modifier le nom des axes.

Dans ces titres, on peut mettre des symboles math�matiques.

  ?expression
  ?substitute

On peut choisir la couleur des traits, leur �paisseur, les symboles utilis�s, 
la taille de ces symboles.

  type='l'
  type='h'
  col
  lwd
  cex

Les options density en angle permettent de hachurer certaines z�nes du dessin.

On peut mettre plusieurs graphiques dans un seul dessin. Il est alors
parfois n�cessaire de modifier les marges pour pouvoir ajouter un
titre.

  op <- par(mfrow = c(2, 2), oma = c(0, 0, 2, 0))
  A FAIRE : exemple des 4 graphiques pour observer une variable.

  A FAIRE : nuage de points avec histogrammes, rugs et boxplots dans les marges.

On peut superposer plusieurs graphiques.

  points
  lines
  add=T
  segments
  text

On peut colorier des parties du dessin � l'aide de la commande polygon.

  A FAIRE : l'aire entre deux courbes.

+ Grid

Une biblioth�que de bas niveau (?) pour faire des graphiques.
C'est ce qui est utilis� par la biblioth�que lattice.

  library(help=grid)
  library(grid)
  ?Grid

A FAIRE

+ Treillis

La biblioth�que lattice, inspir�e des treillis de S-Plus, contient
tout ce qu'il faut pour personnaliser ses dessins. 

  library(help=lattice)
  library(lattice)
  ?Lattice
  ?xyplot

NON.
A FAIRE : mettre un peu plus loin.

Les treillis sont des graphiques dans lesquels on s�pare les individus
en plusieurs groupes pour faire un graphique pour chacun d'entre
eux. Cela permet d'examiner des donn�es multivari�es.

http://cm.bell-labs.com/cm/ms/departments/sia/project/trellis/

Voici quelques exemples tir�s du manuel.

  ## Tonga Trench Earthquakes
  data(quakes)
  Depth <- equal.count(quakes$depth, number=8, overlap=.1)
  xyplot(lat ~ long | Depth, data = quakes)

= R_190.png

  ## Examples with data from `Visualizing Data' (Cleveland)
  ## (obtained from Bill Cleveland's Homepage :
  ## http://cm.bell-labs.com/cm/ms/departments/sia/wsc/, also
  ## available at statlib)
  data(ethanol)
  EE <- equal.count(ethanol$E, number=9, overlap=1/4)
  ## Constructing panel functions on the fly; prepanel
  xyplot(NOx ~ C | EE, data = ethanol,
         prepanel = function(x, y) prepanel.loess(x, y, span = 1),
         xlab = "Compression Ratio", ylab = "NOx (micrograms/J)",
         panel = function(x, y) {
             panel.grid(h=-1, v= 2)
             panel.xyplot(x, y)
             panel.loess(x,y, span=1)
         },
         aspect = "xy")

= R_191.png

  ## banking
  data(sunspot)
  xyplot(sunspot ~ 1:37 ,type = "l", aspect="xy",
         scales = list(y = list(log = TRUE)),
         sub = "log scales")

= R_192.png

  data(state)
  ## user defined panel functions
  states <- data.frame(state.x77,
                       state.name = dimnames(state.x77)[[1]],
                       state.region = state.region)
  xyplot(Murder ~ Population | state.region, data = states,
         groups = as.character(state.name),
         panel = function(x, y, subscripts, groups)
         ltext(x=x, y=y, label=groups[subscripts], cex=.7, font=3))

= R_193.png

  data(barley)
  barchart(yield ~ variety | year * site, data = barley, #aspect = 2.5,
           ylab = "Barley Yield (bushels/acre)",
           scales = list(x = list(0, abbreviate = TRUE,
                         minlength = 5)))

= R_194.png

  data(singer)
  bwplot(voice.part ~ height, data=singer, xlab="Height (inches)")

= R_195.png

  dotplot(variety ~ yield | year * site, data=barley)

= R_196.png

  dotplot(variety ~ yield | site, data = barley, groups = year,
          panel = function(x, y, subscripts, ...) {
              dot.line <- trellis.par.get("dot.line")
              panel.abline(h = y, col = dot.line$col,
                           lty = dot.line$lty)
              panel.superpose(x, y, subscripts, ...)
          },
          key = list(space="right", transparent = TRUE,
                     points=list(pch=trellis.par.get("superpose.symbol")$pch[1:2],
                                 col=trellis.par.get("superpose.symbol")$col[1:2]),
                     text=list(c("1932", "1931"))),
          xlab = "Barley Yield (bushels/acre) ",
          aspect=0.5, layout = c(1,6), ylab=NULL)

= R_197.png

  stripplot(voice.part ~ jitter(height), data = singer, aspect = 1,
            jitter = TRUE, xlab = "Height (inches)")

= R_198.png

  ## Interaction Plot
  data(OrchardSprays)
  bwplot(decrease ~ treatment, OrchardSprays, groups = rowpos,
         panel = "panel.superpose",
         panel.groups = "panel.linejoin",
         xlab = "treatment",
         key = list(lines = Rows(trellis.par.get("superpose.line"),
                    c(1:7, 1)),
                    text = list(lab = as.character(unique(OrchardSprays$rowpos))),
                    columns = 4, title = "Row position"))

= R_199.png

  histogram( ~ height | voice.part, data = singer, nint = 17,
            endpoints = c(59.5, 76.5), layout = c(2,4), aspect = 1,
            xlab = "Height (inches)")

= R_200.png

  ## The following would not be possible in S-Plus
  histogram( ~ height | voice.part, data = singer,
            xlab = "Height (inches)", type = "density",
            panel = function(x, ...) {
                panel.histogram(x, ...)
                panel.mathdensity(dmath = dnorm,
                                  args = list(mean=mean(x),sd=sd(x)))
            } )

= R_201.png

  densityplot( ~ height | voice.part, data = singer, layout = c(2, 4),
              xlab = "Height (inches)", bw = 5)

= R_202.png

  A FAIRE : expliquer tout cela...

* ESS

C'est le mode statistiques d'Emacs

  A FAIRE

* Code

Voici ce que j'utilise effectivement pour faire mes moyennes.

  moyenne = function (x, ...) {
    if( any(is.na(x)) | length(x)==1 ){
      return( mean(x, na.rm=T, ...) );
    } else {
      return( ( sum(x, na.rm=F) - min(x, na.rm=F) )/(length(x)-1) );
    }
  }
  
  vectorCorrectLength <- function (v, l) { 
    # It should be a vector, and not a factor...
    v <- as.vector(v)
    for ( i in 1:l )
      v <- append(v, "")
    v[1:l]
  }
  
  appendToDataFrame <- function (df, name, v) {
    if( length(df)>0 ){
      l = max( length(df[,1]), length(v) )
      d = data.frame( vectorCorrectLength(df[,1], l) )
      if( length(df)>1 ){
        for ( i in 2:length(df) ) {
          d = data.frame( d, vectorCorrectLength(df[,i], l) )
        }
      }
      d = data.frame( d, vectorCorrectLength(v, l) )
      attr(d, "names") = c( attr(df, "names"), name )
    } else {
      d = data.frame(v)
      attr(d, "names") = c(name);
    }
    d
  }
  
  panel.hist <- function(x, ...) {
    usr <- par("usr"); on.exit(par(usr))
    par(usr = c(usr[1:2], 0, 1.5) )
    h <- hist(x, plot = FALSE)
    breaks <- h$breaks; nB <- length(breaks)
    y <- h$counts; y <- y/max(y)
    rect(breaks[-nB], 0, breaks[-1], y, ...)
  }
  
  notes <- function ( classe, pire=FALSE, devoirs=NA, ... ) {
    df = data.frame()
    nb_eleves <- length(classe[,1])
  
    if( is.na(devoirs) ){ 
      devoirs = attr(classe, "names")
      devoirs = devoirs[3:length(list)]
    }
  
    v1 = vector(mode="numeric")
    v2 = vector(mode="numeric")
    for (i in 1:length(classe[,1]) ){
      n = vector(mode="numeric");
      m = classe[i,];
      for (j in devoirs) {
        n = append(n, m[[j]])
      }
      v1 = append(v1, round(mean(n, na.rm=T), digits=2))
      v2 = append(v2, round(moyenne(n), digits=2))
    }
    names <- attr(classe, "names")
    classe = data.frame(classe, v1, v2, classement(v2))
    attr(classe, "names") <- c(names, "Moyennes", "Moyennes", "Classement")
  
    for (d in 1:length(classe[1,])) {
  
      # On regarde s'il faut garder la colonne
      garder = FALSE
      for (n in c(devoirs, "Moyennes", "Classement", "Nom", "Pr�nom")){
        if( n == attr(classe,"names")[d] )
          garder = TRUE
      }
  
      if(!garder) next
      print(paste("Processing row", d, attr(classe,"names")[d]))
  
      # On r�cup�re les valeurs pr�c�dentes
      valeurs = vector(mode="character")
      valeurs = append(valeurs, as.character(classe[,d]))
      # On calcule les moyennes, etc.
      if( attr(classe,"names")[d] == "Nom" ){
        valeurs = append(valeurs, c("Min", "Median", "Max", "Missing", "Mean", "StdDev"))
        if(pire){
          valeurs = append(valeurs, c("Eighth worst mark", "number", "names"))
        }
      } else if( attr(classe,"names")[d] != "Nom" 
                 & attr(classe,"names")[d] != "Pr�nom"
                 & attr(classe,"names")[d] != "Classement"
                ){
        print("***"); print(d); print( attr(classe,"names")[d] )
        valeurs = append(valeurs, round( min(classe[,d], na.rm=T), digits=2))
        valeurs = append(valeurs, round( median(classe[,d], na.rm=T), digits=2))
        valeurs = append(valeurs, round( max(classe[,d], na.rm=T), digits=2))
        valeurs = append(valeurs, round( length( (classe[,d])[ is.na(classe[,d]) ] ), digits=2))
        valeurs = append(valeurs, round( mean(classe[,d], na.rm=T), digits=2))
        valeurs = append(valeurs, round( sd(classe[,d], na.rm=T), digits=2))
        # Les huit notes les plus mauvaises
        if (pire) {
          notes = as.vector( classe[,d] )
          noms = as.vector( classe[,1] )
          eight = sort(notes)[8];
          valeurs = append(valeurs, eight)
          eleves = noms[ (!is.na(notes)) & (notes <= eight) ]
          valeurs = append(valeurs, paste( length(eleves), "�l�ves"))
          valeurs = append(valeurs, eleves)
        }
      }
      df = appendToDataFrame(df, attr(classe, "names")[d], valeurs)
    }
  
    affiche(df)
  
    # Graphiques
    gr=vector(mode="numeric")
    for (d in 1:length(classe[1,])) {
      garder = FALSE
      for (n in c(devoirs, "Moyennes")){
        if( n == attr(classe,"names")[d] )
          garder = TRUE
      }
      if(garder)
        gr=append(gr, d)
    }
    ## The resulting postscript file can be used by dvips -Ppfb -j0 ??????
  #  postscript(file="RESULT.eps", onefile=TRUE, family="ComputerModern")
    postscript(file="RESULT.eps", onefile=TRUE, horizontal=TRUE)
    pairs(classe[,gr], diag.panel=panel.hist,
          upper.panel=panel.smooth,
          lower.panel=panel.smooth);
    dev.off();
    cat("\\includegraphics[angle=-90]{RESULT.eps}\n", file="RESULT.tex", append=TRUE)
    cat("\\end{document}\n", file="RESULT.tex", append=TRUE)
  }
  
  affiche <- function (df) {
    print("*** Affiche")
    print(df)
    cat("\\documentclass{article}\n", file="RESULT.tex", append=FALSE)
    cat("\\usepackage[latin1]{inputenc}\n", file="RESULT.tex", append=TRUE)
    cat("\\usepackage[T1]{fontenc}\n", file="RESULT.tex", append=TRUE)
    cat("\\usepackage[a4paper,dvips,landscape=true,left=1cm,right=1cm,top=1cm,bottom=1cm,nohead,nofoot]{geometry}\n", file="RESULT.tex", append=TRUE)
    cat("\\usepackage{graphicx}\n", file="RESULT.tex", append=TRUE)
    cat("\\def\\globble\#1\{\}\n", file="RESULT.tex", append=TRUE)
    cat("\\parindent=0pt\n", file="RESULT.tex", append=TRUE)
    cat("\\pagestyle{empty}\n", file="RESULT.tex", append=TRUE)
    cat("\\usepackage{dcolumn}\n", file="RESULT.tex", append=TRUE)
    cat("\\newcolumntype{.}{D{.}{.}{2,2}}\n", file="RESULT.tex", append=TRUE)
    cat("\\begin{document}\n", file="RESULT.tex", append=TRUE)
    cat("\\begin{tabular}{|l|l|", file="RESULT.tex", append=TRUE)
    for ( i in 3:length(df) ){
      #cat(".|", file="RESULT.tex", append=TRUE)
      cat("c|", file="RESULT.tex", append=TRUE)
    }
    cat("}\n", file="RESULT.tex", append=TRUE)
    cat("\\hline\n", file="RESULT.tex", append=TRUE)
    cat("\\globble ", file="RESULT.tex", append=TRUE)
    for ( i in attr(df,"names") ){
      cat("&", file="RESULT.tex", append=TRUE)
      cat(i, file="RESULT.tex", append=TRUE)
    }
    cat("\\\\\n", file="RESULT.tex", append=TRUE)
    cat("\\hline\n", file="RESULT.tex", append=TRUE)
    for (i in 1:length( attr(df,"row.names") )) {
      if( df[i,1] == "Min" ){
        cat("\\hline\n", file="RESULT.tex", append=TRUE)
      }
      cat("\\globble ", file="RESULT.tex", append=TRUE)
      for (j in df[i,]) {
        cat("&", file="RESULT.tex", append=TRUE)
        cat(as.vector(j), file="RESULT.tex", append=TRUE)
      }
      cat("\\\\\n", file="RESULT.tex", append=TRUE)
    }
    cat("\\hline\n", file="RESULT.tex", append=TRUE)
    cat("\\end{tabular}\n\n", file="RESULT.tex", append=TRUE)
  }
  
  classement <- function (x) {
    a = sort(x)
    l = length(a)
    h = list() # hash table
    for (i in a) {
      h[[as.character(i)]] = l
      l = l-1
    }
    result = vector(mode="numeric")
    for (i in x) {
      if( is.null( h[[as.character(i)]] ) ){
        result = append(result, NA)
      } else {
        result = append(result, h[[as.character(i)]])
      }
    }
    result
  }
  
  notes(Seconde4, devoirs=c("DM1", "C1", "C2", "DS1", "DS1", "DM2"))
  notes(Seconde4, pire=TRUE, devoirs=c("DM2"))
  notes(Seconde13, devoirs=c("C1", "DM1", "DS1", "DS1", "DM2"))
  notes(PremiereSTT, devoirs=c("DM1", "DS1", "DS1", "DM2"))

  notes(Seconde4, devoirs=c("C3", "DM3", "DM4", "DS2", "DS2", "DM5"))
  notes(Seconde13, devoirs=c("C2", "DM3", "DM4", "DS2", "DS2", "DM5", 'DM6', 'C3', 'DM7'))
  notes(PremiereSTT, devoirs=c("DM3", "DS2", "DS2"))
  notes(TerminaleSTT, devoirs=c("DS2", "DS2", "DM3"))

      A FAIRE : sauvegarder les donn�es au format CSV...

* Statistique

Nous abandonnons maintenant le contexte qui nous a men� vers R
pour l'utiliser dans d'autres domaines.

+ ATTENTION 

Ce qui suit a �t� �crit par quelqu'un qui n'a aucune comp�tence 
en statistiques -- il peut y avoir d'abominables erreurs ou confusions.
(Dans toute ma scolarit�, j'ai fais des probabilit�s pendant deux heures, �
la fin d'un cours de th�orie de la mesure, en licence -- mais jamais
de statistiques).

Pour de plus amples renseignements, on peut consulter :

  http://davidmlane.com/hyperstat/index.html

A FAIRE : d'autres URLs ?


* Exemples de donn�es

Il y a plein d'exemples de donn�es qui viennent avec R et avec
lesquelles on peut jouer.

  > library('ts')
  > data(beavers)
  > ?beavers
  > summary(beaver1)
        day             time             temp           activ
   Min.   :346.0   Min.   :   0.0   Min.   :36.33   Min.   :0.00000
   1st Qu.:346.0   1st Qu.: 932.5   1st Qu.:36.76   1st Qu.:0.00000
   Median :346.0   Median :1415.0   Median :36.87   Median :0.00000
   Mean   :346.2   Mean   :1312.0   Mean   :36.86   Mean   :0.05263
   3rd Qu.:346.0   3rd Qu.:1887.5   3rd Qu.:36.96   3rd Qu.:0.00000
   Max.   :347.0   Max.   :2350.0   Max.   :37.53   Max.   :1.00000
  > beaver1$temp
    [1] 36.33 36.34 36.35 36.42 36.55 36.69 36.71 36.75 36.81 36.88 36.89 36.91
   [13] 36.85 36.89 36.89 36.67 36.50 36.74 36.77 36.76 36.78 36.82 36.89 36.99
   [25] 36.92 36.99 36.89 36.94 36.92 36.97 36.91 36.79 36.77 36.69 36.62 36.54
   [37] 36.55 36.67 36.69 36.62 36.64 36.59 36.65 36.75 36.80 36.81 36.87 36.87
   [49] 36.89 36.94 36.98 36.95 37.00 37.07 37.05 37.00 36.95 37.00 36.94 36.88
   [61] 36.93 36.98 36.97 36.85 36.92 36.99 37.01 37.10 37.09 37.02 36.96 36.84
   [73] 36.87 36.85 36.85 36.87 36.89 36.86 36.91 37.53 37.23 37.20 37.25 37.20
   [85] 37.21 37.24 37.10 37.20 37.18 36.93 36.83 36.93 36.83 36.80 36.75 36.71
   [97] 36.73 36.75 36.72 36.76 36.70 36.82 36.88 36.94 36.79 36.78 36.80 36.82
  [109] 36.84 36.86 36.88 36.93 36.97 37.15
  > plot(beaver1$temp)        # index/valeur

= R_060.png

  > hist(beaver1$temp)        # Valeur/effectif

= R_061.png

Les donn�es sont souvent stock�es dans un Data Frame : on peut
transformer les colonnes de de Data Frame en variables � l'aide de la
commade attach() (c'est le m�me principe que les espaces de nommage
(namespaces) du C++). Il ne faut pas oublier de d�tacher le Data Frame
quand on a fini de jouer avec.

  data(beavers)
  attatch(beaver1)
  hist(temp)
  ...
  detach(beaver1)

Pour regarder quelles sont les donn�es pr�sentes dans un paquetage :

  data(package='ts')

  Data sets in package `ts':

  AirPassengers           Monthly Airline Passenger Numbers 1949-1960
  austres                 Quarterly Time Series of the Number of
                          Australian Residents
  beavers                 Body Temperature Series of Two Beavers
  BJsales                 Sales Data with Leading Indicator.
  EuStockMarkets          Daily Closing Prices of Major European Stock
                          Indices, 1991-1998.
  JohnsonJohnson          Quarterly Earnings per Johnson & Johnson Share
  LakeHuron               Level of Lake Huron 1875--1972
  lh                      Luteinizing Hormone in Blood Samples
  lynx                    Annual Canadian Lynx trappings 1821--1934
  Nile                    Flow of the River Nile
  nottem                  Average Monthly Temperatures at Nottingham,
                          1920--1939
  sunspot                 Yearly Sunspot Data, 1700--1988. Monthly
                          Sunspot Data, 1749--1997.
  treering                Yearly Treering Data, -6000--1979.
  UKDriverDeaths          Road Casualties in Great Britain 1969--84
  UKLungDeaths            Monthly Deaths from Lung Diseases in the UK
  UKgas                   UK Quarterly Gas Consumption
  USAccDeaths             Accidental Deaths in the US 1973--1978
  WWWusage                Internet Usage per Minute

Les donn�es pr�sentes dans le paquetage "base" :

  Data sets in package `base':

  Formaldehyde            Determination of Formaldehyde concentration
  HairEyeColor            Hair and eye color of statistics students
  InsectSprays            Effectiveness of insect sprays
  LifeCycleSavings        Intercountry life-cycle savings data
  OrchardSprays           Potency of orchard sprays
  PlantGrowth             Results from an experiment on plant growth
  Titanic                 Survival of passengers on the Titanic
  ToothGrowth             The effect of vitamin C on tooth growth in
                          guinea pigs
  UCBAdmissions           Student admissions at UC Berkeley
  USArrests               Violent crime statistics for the USA
  USJudgeRatings          Lawyers' ratings of state judges in the US
                          Superior Court
  USPersonalExpenditure   Personal expenditure data
  VADeaths                Death rates in Virginia (1940)
  airmiles                Passenger miles on US airlines 1937-1960
  airquality              New York Air Quality Measurements
  anscombe                Anscombe's quartet of regression data
  attenu                  Joiner-Boore Attenuation Data
  attitude                Chatterjee-Price Attitude Data
  cars                    Speed and Stopping Distances for Cars
  chickwts                The Effect of Dietary Supplements on Chick
                          Weights
  co2                     Moana Loa Atmospheric CO2 Concentrations
  discoveries             Yearly Numbers of `Important' Discoveries
  esoph                   (O)esophageal Cancer Case-control study
  euro                    Conversion rates of Euro currencies
  eurodist                Distances between European Cities
  faithful                Old Faithful Geyser Data
  freeny                  Freeny's Revenue Data
  infert                  Secondary infertility matched case-control
                          study
  iris                    Edgar Anderson's Iris Data as data.frame
  iris3                   Edgar Anderson's Iris Data as 3-d array
  islands                 World Landmass Areas
  longley                 Longley's Economic Regression Data
  morley                  Michaelson-Morley Speed of Light Data
  mtcars                  Motor Trend Car Data
  nhtemp                  Yearly Average Temperatures in New Haven CT
  phones                  The Numbers of Telephones
  precip                  Average Precipitation amounts for US Cities
  presidents              Quarterly Approval Ratings for US Presidents
  pressure                Vapour Pressure of Mercury as a Function of
                          Temperature
  quakes                  Earthquake Locations and Magnitudes in the
                          Tonga Trench
  randu                   Random Numbers produced by RANDU
  rivers                  Lengths of Major Rivers in North America
  sleep                   Student's Sleep Data
  stackloss               Brownlee's Stack Loss Plant Data
  state                   US State Facts and Figures
  sunspots                Monthly Mean Relative Sunspot Numbers
  swiss                   Swiss Demographic Data
  trees                   Girth, Height and Volume for Black Cherry
                          Trees
  uspop                   Populations Recorded by the US Census
  volcano                 Topographic Information on Auckland's Maunga
                          Whau Volcano
  warpbreaks              Breaks in Yarn during Weaving
  women                   Heights and Weights of Women

Il y en a aussi beaucoup dans le paquetage MASS (Modern Applied Statistics
with S).

  data(package='MASS')

R pr�cise m�me :

  Use `data(package = .packages(all.available = TRUE))'
  to list the data sets in all *available* packages.

* Donn�es univari�es

On parle de donn�es univari�es quand il n'y a qu'une seule variable,
i.e., qu'une seule colonne dans le tableau.

+ Donn�es univari�es quantitatives

Il y a une seule liste de nombres.

  > x
   [1] 12.0  6.0 16.5 13.5 15.0  3.0 10.5  1.5 10.5  7.5 15.0  7.5 12.0 13.5  4.5
  [16] 13.5 13.5  6.0 12.0  7.5  9.0  6.0 13.5 13.5 15.0 13.5  6.0   NA 13.5  4.5

On peut r�sumer ces donn�es � l'aide de quelques nombres : 
la moyenne, le minimum, le maximum, la m�dianne (on met les nombres dans
l'ordre et on prend celui du milieu)
les quartiles (idem, mais on prend les nombres � un quard du d�but ou de la fin).

  > summary(x)
  Min. 1st Qu.  Median    Mean 3rd Qu.    Max.    NA's
  1.50    6.00   12.00   10.19   13.50   16.50    1.00

On peut aussi calculer l'�cart moyen avec la m�diane (mad) : cela
permet de mesurer la dispersion des donn�es.  G�n�ralement, on mesure
plut�t la dispersion � l'aide de l'�cart-type, (� standard deviation �
en anglais) i.e., la racine carr�e de la moyenne des carr�s de l'�cart
� la moyenne : c'est beaucoup moins naturel (et moins robuste) que
l'�cart moyen � la m�diane, mais l'�cart-type v�rifie plein de
propri�t�s th�oriques int�ressantes.

  > y = exp(rnorm(20))
  > y
   [1]  0.3044751  2.1824199  1.3674871  0.6912447 17.3900803  0.4442225
   [7]  0.2278233  4.9369640  0.4687781  0.4683544  0.5337208  0.7018454
  [13]  0.1992839  1.7690121  0.6256426  1.2275288  2.6412501  2.1512802
  [19]  0.5085903  0.3862761
  > mean(y)
  [1] 1.961314
  > sd(y)
  [1] 3.808593
  > mad(y)
  [1] 0.5816158

Je profite de l'occasion pour signaler les liens entre moyenne,
variance, m�diane et �cart moyen � la moyenne. Quand on a un ensemble
de nombres x1, x2, ... xn, on peut essayer de trouver le r�el m qui
minimise la somme

  abs(m-x1) + abs(m-x2) + ... + abs(m-xn).

C'est la m�diane. On peut aussi essayer de trouver le r�el m qui
minimise la somme 

  (m-x1)^2 + (m-x2)^2 + ... + (m-xn)^2.

C'est la moyenne. (Cette propri�t� de la moyenne s'appelle la
propri�t� des moindres carr�s.)

Au d�but, j'avais du mal � comprendre la pertinence de la variance
comme mesure de la dispersion ; la moyenne des valeurs absolues des
diff�rences avec la moyenne me semblaient plus naturelle. La
d�finition pr�c�dente de la moyenne peut servir de motivation de la
notion de variance. Il y a d'autres motivations. L'une est que c'est
facile � calculer, � la main, de mani�re incr�mentale. Une autre est
que �a intervient dans plein de r�sultats th�oriques (in�galit� de
Bienaim�-Tchebichev, etc.).

Les notions de moyenne et de variance perdent leur pertinence pour des
distributions non sym�triques ou pour des distributions avec beaucoup
de valeurs extr�mes. On utilisa alors la m�diane, l'intervalle
inter-quartile, la distance moyenne � la m�diane. (En fait, pour les
distributions non sym�triques, c'est m�me carr�ment la notion de
centre qui perd sa pertinence.)

On peut repr�senter ces donn�es � l'aide d'un disgramme de dispersion

  data(faithful)
  stripchart(faithful$eruptions)

= R_032.png

Mais celui-ci devient illisible s'il y a trop de donn�es. On peut alors 
rajouter une dimension, dans laquelle on met des nombres au hasard.

  plot(faithful$eruptions, runif(length(faithful$eruptions)))

= R_034.png
= R_038.png

  plot(faithful$eruptions, rnorm(length(faithful$eruptions)))

= R_033.png
= R_037.png

  plot(faithful$eruptions, rnorm(length(faithful$eruptions))^3)

= R_035.png

  x <- faithful$eruptions
  plot( array(x, 5*length(x)), rnorm(5*length(x)) )

= R_036.png

En fait, il y a d�j� une option de la commande stripchart
qui fait quelque chose de comparable.

  > stripchart(faithful$eruptions,method='jitter')

= R_040.png

Le � stem-and-leaf plot � est une sorte d'histogramme textuel (qui ne
me semble pas vraiment utilis� en France), dans lequel on fait figurer
les donn�es num�riques elles-m�mes. On peut le voir comme une mani�re
d'organiser une masse de chiffres, � la main.

  http://www.shodor.org/interactivate/discussions/steml.html
  http://davidmlane.com/hyperstat/A28117.html
  http://www.google.fr/search?q=stem-and-leaf&ie=UTF-8&oe=UTF-8&hl=fr&btnG=Recherche+Google&meta=

En voici un exemple

  > stem(x)

  The decimal point is at the |

   0 | 5
   2 | 0
   4 | 55
   6 | 0000555
   8 | 0
  10 | 55
  12 | 00055555555
  14 | 000
  16 | 5

On peut repr�senter graphiquement ces donn�es par des 
boites � moustaches, qui correspond aux nombres suivants :
minimum, premier quartile, m�diane, troisi�me quartile, maximum, 
(avec �ventuellement des points tr�s �loign�s ("outliers"), 
apr�s Q3+1.5*IQR ou avant Q1-1.5*IQR)).

  > x <- rnorm(200)
  > boxplot(x)

= R_001.png

L'appellation � boite � moustaches � est plus compr�hensible si on 
fait le dessin horizontalement.

  x <- rnorm(200)
  boxplot(x, horizontal=TRUE)

= R_068.png

On peut aussi 
demander un intervalle de confiance � 95% pour la m�diane

  > boxplot(x, notch=TRUE)

= R_039.png

  A FAIRE : 
  un boxplot avec des "rugs" ???
  boxplot(x)
  rug(x,side=2)
  Idem, horizontalement

Les graphes � moustaches servent � examiner les donn�es avant de leur faire subir
des traitement plus complexes, en particulier � v�rifier qu'elles sont bien sym�triques 
(ainsi, la plupart des tests statistiques supposent que les donn�es sont normale, 
et donc en particulier centr�es)

= R_067.png

et qu'il n'y a pas de points aberrants, qui pourraient provenir d'une
erreur dans la saisie des donn�es, et qui risqueraient de fausser la
suite de l'analyse statistique.

  x <- c(rnorm(30),20)
  x <- sample(x, length(x))
  boxplot( x, horizontal=T )

= R_136.png

  # autre mani�re de rep�rer les points aberrants
  plot(x-median(x), type='h', lwd=5)
 
= R_137.png

On peut aussi repr�senter ces donn�es 
par un histogramme (il faut pr�alablement r�partir les donn�es
dans des classes; mais l'ordinateur s'en charge).

  > hist(x)

= R_002.png

On peut remplacer l'histogramme par le graphe d'une fonction (si on
voit les donn�es comme une somme de masses de Dirac, il suffit de
faire la convolution avec un "noyau" bien choisi, par exemple, la
densit� de la loi gaussienne).

  hist(x, probability=TRUE)
  points(density(x,bw=1), type='l')
  curve(dnorm, add=T, col="red")

= R_003.png

  hist(faithful$eruptions, nclass=20, probability=T, col='lightblue')
  points(density(faithful$eruptions,bw=.1), , type='l', lwd=3, col='red')

= R_160.png

A FAIRE : les quatre graphiques (sur un seul dessin)
1. histogramme + courbe normale + rugs
2. boxplot
3. symetry plot + confidence intervals
4. QQplot + confidence intervals

A FAIRE : On peut aussi repr�senter les donn�es elle-m�mes, tri�es.

  plot(sort(x), pch='.')

+ Donn�es univari�es ordonn�es

On ne s'int�resse pas � la valeur num�rique, mais au classement.  On
peut traiter ces donn�es tant�t comme des donn�es quantitatives
(d'ailleurs, quand on a une variable quantitative, on peut ranger ces
valeurs dans des classes et les remplacer par leur num�ro d'ordre),
apr�s une �ventuelle transformation (de sorte que les donn�es soit
distribu�es normalement et pas uniform�ment), tant�t comme des donn�es
qualitatives (car, contrairement aux variables quantitatives, elles ne
peuvent prendre qu'un nombre fini de valeurs).

  A FAIRE : un peu plus de d�tails, d'exemples
  Exemple : petit/moyen/grand
  Quelques graphiques

+ Donn�es univari�es qualitatives

On a une liste de donn�es non num�riques (en fait, ces donn�es peuvent
�tre cod�es par des nombres, mais une diff�rence de ces nombres n'a
pas de sens : par exemple, des num�ros de d�partement ou des num�ros
de r�ponse � des questions).

  > data(HairEyeColor)
  > HairEyeColor
  , , Sex = Male

         Eye
  Hair    Brown Blue Hazel Green
    Black    32   11    10     3
    Brown    38   50    25    15
    Red      10   10     7     7
    Blond     3   30     5     8

  , , Sex = Female

         Eye
  Hair    Brown Blue Hazel Green
    Black    36    9     5     2
    Brown    81   34    29    14
    Red      16    7     7     7
    Blond     4   64     5     8

  > attributes(HairEyeColor)
  $dim
  [1] 4 4 2

  $dimnames
  $dimnames$Hair
  [1] "Black" "Brown" "Red"   "Blond"

  $dimnames$Eye
  [1] "Brown" "Blue"  "Hazel" "Green"

  $dimnames$Sex
  [1] "Male"   "Female"

  $class
  [1] "table"

C'est un exemple avec plusieures variables, on va en prendre
une seule.

  > x <- HairEyeColor[1,,1]
  > x
  Brown  Blue Hazel Green
     32    11    10     3
  > x <- apply(HairEyeColor, 2, sum)
  > x
  Brown  Blue Hazel Green
    220   215    93    64

On peut repr�senter ces donn�es par un graphe en colonnes

  barplot(x)

= R_004.png

  barplot(x, col=1, density=c(3,7,11,20), angle=c(45,-45,45,-45))

= R_153.png

en barre

  barplot(as.matrix(x), legend.text=TRUE)

= R_006.png

  barplot(as.matrix(x), horiz=TRUE, col=rainbow(length(x)), legend.text=TRUE)

= R_069.png

A FAIRE (pareto diagram)

  data(attenu)
  barplot(rev(sort(table(attenu$event))))
  # No colors
  barplot(rev(sort(table(attenu$event))), col = "white")

ou par un camembert.

  pie(x)

= R_005.png

Pour des donn�es un peu plus nombreuses, on peut utiliser la commande dotchart.

  dotchart(x)

= R_052.png

  data(islands)
  dotchart(islands)

= R_053.png

* Le zoo des distributions de probabilit�

+ Loi de Bernoulli

Tirer une pi�ce � pile ou face revient � examiner une variable
al�atoire suivant une loi de Bernoulli de param�tre 0.5. Si la pi�ce
est truqu�e et que � pile � apparait avec une probabilit� p, c'est une
loi de Bernoulli de param�tre p.

  P( X=1 ) = p
  P( X=0 ) = 1-p

+ Loi binomiale

On tire une pi�ce � pile ou face n fois et on regarde le nombre de � pile �.
Il s'agit en fait d'une somme de vaiid de Bernoulli.

On peut la simuler ainsi.

  N <- 10000
  n <- 20
  p <- .5
  x <- rep(0,N)
  for (i in 1:N) {
    x[i] <- sum(runif(n)<p)
  }
  hist(x, main="Simulation d'une loi binomiale")

= R_164.png

Voici � quoi elle ressemble.

  N <- 1000
  n <- 10
  p <- .5
  x <- rbinom(N,n,p)
  hist(x, xlim=c(min(x),max(x)), probability=T, nclass=max(x)-min(x)+1, col='lightblue',
       main='Loi binomiale, n=10, p=.5')

= R_161.png

  N <- 100000
  n <- 100
  p <- .5
  x <- rbinom(N,n,p)
  hist(x, xlim=c(min(x),max(x)), probability=T, nclass=max(x)-min(x)+1, col='lightblue',
       main='Loi binomiale, n=100, p=.5')

= R_162.png

  p <- .9
  x <- rbinom(N,n,p)
  hist(x, xlim=c(min(x),max(x)), probability=T, nclass=max(x)-min(x)+1, col='lightblue',
       main='Loi binomiale, n=100, p=.8')

= R_163.png
  
  A FAIRE : superposer la loi normale � ces graphiques.
  A FAIRE : v"rifier que les param�tres sont bien les suivants.
  curve(dnorm(x,mean=n/2,sd=sqrt(n/4)), add=T, col='red')

C'est aussi la loi qu'on rencontre lors d'un �chantillonage avec
remise (quand on tire des boules dans une urne, et qu'on remet la
boule dans l'urne avant de tirer la suivante).

+ Loi hyperg�om�trique

C'est la loi qu'on rencontre lors d'un �chantillonage sans remise. 

On la rencontre par exemple en �cologie, quand on cherche � d�nombrer
les individus d'une esp�ce. On capture des animaux, r�guli�rement, et
on les marque (par exemple avec des bagues). Au bout d'un moment, une
partie de la population est bagu�e (on connait son effectif), l'autre
pas. Lors de nouvelles captures, on a un certain nombre d'animaux
marqu�s et un certain nombre d'animaux non marqu�s : ces nombres vont
nous aider � d�terminer la taille de la population. 

Voyons ce que cela donne sur un exemple, � l'aide d'une simulation.
On tire 5 boules d'une urne qui en contient 15 blanches et 5 rouges, 
et on compte le nombre de boules blanches.

A FAIRE : simulation

A FAIRE : distribution


+ Loi de Poisson

La loi qui d�crit le nombre de clients qui arrivent dans une file d'attente
pendant une unit� de temps. Ou le nombre de fautes dans un texte.

  P( X=k ) = e^(-mu) * mu^k / k!

+ Loi uniforme discr�te

+ Loi g�om�trique

C'est la loi du nombre d'essais avant une r�ussite lors d'une suite
d'�preuves de Bernoulli.

+ Loi binomiale n�gative

C'est la loi du nombre d'�checs avant k r�ussites lors d'une suite
d'�preuves de Bernoulli.

+ Loi multinomiale

C'est l'�quivalent de la loi binomiale, mais cette fois-ci,
les exp�riences ont plusieurs r�sultats possibles.

  P( (X1,X2,...,Xn)=(k1,k2,...,kn) ) = m! p1^k1 ... pn^kn / (k1! ... kn!)

+ Loi uniforme continue

+ Loi exponentielle

A FAIRE

+ Loi normale

Loi normale standard (de moyenne 0 et de variance 1)

  f(x) = exp( -x^2/2 ) / sqrt( 2 pi )

On en d�duit la loi normale de moyenne mu et de variance sigma^2 par
une transformation affine :

  f(x) = exp( -( (x-mu) / sigma )^2 /2 ) / sqrt( 2 pi sigma )

A FAIRE : Parler de la loi des grands nombres

+ Loi du Chi2 � un degr� de libert�

C'est la loi de X^2, si X est une va suivant une loi normale standard.

+ Loi du Chi^2 � n degr�s de libert�

C'est la loi de X1^2+...+Xn^2, o� les Xi sont des vaiid normales standard.

+ Autres lois

La loi B�ta, la loi Gamma, la loi du T de Student, la loi du F de Fisher.

A FAIRE : parler de la famille exponentielle, qui intervient dans
certains r�sultats th�oriques (lesquels ?) et dans le mod�le lin�aire
g�n�ralis�.

* Simulations

+ Probabilit� et fr�quence limite

On tire � pile ou face 1000 fois et on regarde comment �volue
la fr�quence de � pile �. On constate qu'elle � tend � vers 0.5.

  n <- 1000
  x <- runif(n)
  x <- x>.5
  x <- cumsum(x)/(1:n)
  plot(x, ylim=c(0,1), type="l")
  
= R_064.png

Idem, sur une �chelle logarithmique

  plot(x, ylim=c(0,1), type="l", log="x")

= R_065.png

+ Exemple

Simulation de 20 s�ries de 10 tirages al�atoires d'une variable normale.

  N <- 10
  n <- 20
  x <- rnorm(n*N)
  y <- rep(1:n, N)
  boxplot(x ~ y)

= R_041.png

  par( mfrow = c(4,5) )
  for (i in 1:n) {
    hist(x[ y==i ])
  }

= R_042.png

Maintenant, 20 s�ries de 100 tirages.

= R_043.png
= R_044.png

20 s�ries de 3 tirages ; on met en �vidence les s�ries pour lesquelles
la moyenne r�elle n'est pas entre les valeurs extr�mes.

  N <- 3
  n <- 20
  x <- rnorm(n*N)
  y <- rep(1:n, N)
  m <- matrix(x, nrow=N, byrow=T)
  c <- apply(m,2,min)>0 | apply(m,2,max)<0
  boxplot(x ~ y, col=c(0,6)[1+c])

= R_070.png

Echantillons gaussiens de taille de plus en plus grande.

  x <- rnorm(10+100+1000+10000+100000)
  y <- c( rep(5,10), rep(4,100), rep(3,1000), rep(2,10000), rep(1,100000))
  boxplot(x~y, horizontal=T, axes=F)
  axis(1)
  axis(2, 1:5, c(10,100,1000,10000,100000) )

= R_071.png

+ Loi de Benford

Si on prend des donn�es num�riques << r�elles >>, leur premier chiffre
suit une loi de Benford.

  x <- 1:9
  y <- log(1+1/x)/log(10)
  plot(y~x, type="h")

= R_051.png

V�rifions-le � l'aide de donn�es boursi�res.
Commen�ons par r�cup�rer des cours de bourse
et des volumes �chang�s de quelques 130 titres.

  rm A
  for i in AB C DE FI JN OR S TZ
  do
    GET 'http://fr.finance.yahoo.com/q?s=@SRD_'$i'.PA&f=snlcvi' >> A
  done
  perl -n -l -e 'm#e.gif[^>]*>([0-9,]+)<# && print$1' A | 
    perl -p -e 's/\.//g; s/,/./g' > Cours.txt
  perl -n -l -e 'm#.*>([0-9.]*?)</font.*Graphique# && print "$1"' A | 
    perl -p -e 's/\.//g' > Volume.txt

R�cup�rons les donn�es sous R

  a <- read.table("Cours.txt")
  a <- a[a>0]
  a <- as.vector(a)
  a <- floor(a*10^-floor(log(a)/log(10)))
  hist(a, probability=T)
  points((x+.5), y, type='h', col='red', lwd=3)
  chisq.test(table(factor(a)), p=y) # p-value = 0.06

= R_151.png

  a <- read.table("Volume.txt")
  a <- a[a>0]
  a <- as.vector(a)
  a <- floor(a*10^-floor(log(a)/log(10)))
  hist(a, probability=T)
  points((x+.5), y, type='h', col='red', lwd=3)
  chisq.test(table(factor(a)), p=y) # p-value = 0.85

= R_152.png

Voici une justification th�orique de ce fait :

  http://www.math-info.univ-paris5.fr/smel/articles/benford/cadre_benford.html

+ Variable normale multidimentionnelle dont on pr�cise la matrice des covariances

On se donne deux vaiid normales X et Y de moyenne 0 et de variance 1
et on essaye de trouver a, b et c de sorte que (aX, bY+cX) ait la bonne variance.

A FAIRE : est-ce toujours normal ?

  > rnorm2 <- function(n, mean=c(0,0), cov=c(1,1,0)) {
      a <- sqrt(cov[1])
      c <- cov[3]/a
      b <- sqrt(cov[2]-c^2)
      x <- rnorm(n)
      y <- rnorm(n)
      print(a); print(b); print(c);
      cbind( mean[1]+a*x, mean[2]+b*y+c*x )
    }
  > cov(rnorm2(10000, cov=c(1,5,2)))
  [1] 1
  [1] 1
  [1] 2
           [,1]     [,2]
  [1,] 1.015107 2.034396
  [2,] 2.034396 5.069416

Voir aussi

  library(help=mvtnorm)

A FAIRE

Voir aussi :

  library(MASS)
  ?mvrnorm

+ Estimateurs biais� et non biais�s de la variance

On consid�re 5 tirages al�atoires ind�pendants suivant une loi normale
de moyenne 1 et d'�cart-type 1.

En r�p�tant cette exp�rience 10000 fois, on obtient (une approximation de)
l'esp�rance de la moyenne empirique : elle est � peu pr�s �gale � la moyenne vraie 
(ici, 0).

  x <- vector()
  for(i in 1:10000){
    x <- append(x, mean(rnorm(5)))
  }
  mean(x)

  [1] 9.98948e-05

Si on fait pareil avec la variance empirique, on constate que son esp�rance
est sensiblement diff�rente de la variance r�elle (on obtient 0.8 au lieu de 1) : 
on dit que la variance empirique est un estimateur biais�
de la variance.

  n <- 5
  x <- vector()
  for(i in 1:10000){
    t <- rnorm(n)
    t <- t - mean(t)
    t <- t*t
    x <- append(x, sum(t)/n)
  }
  mean(x)

  [1] 0.806307

Pour avoir un estimateur non biais�, il suffit de remplacer le � n � dans la
d�finition de la variance par n-1 (c'est ce que l'on appelle la variance 
de l'�chantillon, par opposition � la variance de la population).

  n <- 5
  y <- vector()
  for(i in 1:10000){
    t <- rnorm(n)
    t <- t - mean(t)
    t <- t*t
    y <- append(y, sum(t)/(n-1))
  }
  mean(y)

  [1] 1.000129

Une autre mani�re d'obtenir un estimateur non biais� consiste �
utiliser la moyenne vraie au lieu de la moyenne empirique (c'est
peu r�aliste, car dans les situations concr�tes, on connait
rarement la moyenne vraie).

  n <- 5
  z <- vector()
  for(i in 1:10000){
    t <- rnorm(n)
    t <- t - 0
    t <- t*t
    z <- append(z, sum(t)/n)
  }
  mean(x)

  [1] 1.001210

On peut comparer graphiquement ces trois estimateurs de la variance.

  boxplot(x,y,z)

= R_054.png

  plot(density(x))
  points(density(y), type="l", col="red")
  points(density(z), type="l", col="blue")

= R_055.png

  par( mfrow = c(3,1) )
  hist(x, xlim=c(0,5), breaks=20)
  hist(y, xlim=c(0,5), breaks=20)
  hist(z, xlim=c(0,5), breaks=20)

= R_056.png

Ou plut�t leur racine carr�e (c'est plus sym�trique).

  x <- sqrt(x)
  y <- sqrt(x)
  z <- sqrt(z)
  boxplot(x,y,z)

= R_057.png

  plot(density(x))
  points(density(y), type="l", col="red")
  points(density(z), type="l", col="blue")

= R_058.png

  par( mfrow = c(3,1) )
  hist(x, xlim=c(0,5), breaks=20)
  hist(y, xlim=c(0,5), breaks=20)
  hist(z, xlim=c(0,5), breaks=20)

= R_059.png
 
+ Divers

  plot(sort(runif(100)))
  for (i in 1:1000) {
    lines( sort(runif(100)) )
  }

= R_062.png

On peut tracer les bornes sup et inf de ces choses-l�.

  n <- 1000
  m <- 200
  a <- matrix( runif(n*m), c(n,m) )
  b <- apply(a, 1, sort)
  c <- apply(b, 1, range)
  plot( c[1,], type="l" )
  lines( c[2,] )

  n <- 10
  m <- 200
  a <- matrix( runif(n*m), c(n,m) )
  b <- apply(a, 1, sort)
  c <- apply(b, 1, range)
  lines( c[1,] )
  lines( c[2,] )

= R_063.png

* Echantillons et tests statistiques

Tr�s souvent, la s�rie statistique que l'on �tudie n'est pas
la population enti�re mais juste un �chantillon. On peut facilement calculer
les param�tres (moyenne, �cart-type) de l'�chantillon, mais ce sont juste des
approximations des param�tres de la population : comment mesurer l'exactitude de cette 
approximation ?

+ Exemples

Voici quelques exemples concrets de cette situation.

Un industriel doit choisir une vari�t� de Ma�s. Il sera destin� � la
consommation animale et on cherche la vari�t� qui contient le plus de
prot�ines possible : il faut conna�tre pr�cis�ment la teneur moyenne
en prot�ines (non pas de l'�chantillon, mais bien de la population).

Un industriel doit choisir une vari�t� de Ma�s. Il sera destin� �
la consommation humaine et, pour des raisons de conditionnement, on
veut que tous les �pis aient la m�me taille ; on cherche donc � avoir
l'�cart-type le plus petit possible.

+ Mod�lisation d'une exp�rience statistique

En termes simples : on tire au hasard des individus dans une population 
et on mesure chez les variables statistiques qui nous int�ressent (taille
de l'�pi de ma�s, teneur en prot�ines, etc.)

En termes plus math�matiques : on consid�re X1, X2, ... Xn des variables al�atoires 
ind�pendantes identiquement distribu�es (vaiid). � l'aide des valeurs que ces variables
prennent en un point de l'univers, on tente d'obtenir des informations sur la loi
qu'elles suivent (par exemple, on s'attend � ce que (X1+...+Xn)/n soit
une approximation de l'esp�rance de cette loi : est-ce bien le cas ? en quel sens ?
comment appr�cier la qualit� de cette approximation ?).

+ Un peu de vocabulaire...

+ Estimateur

On consid�re une exp�rience statistique, i.e., on consid�re des vaiid
X1,...Xn ; on suppose qu'on connait la forme de la loi, mais pas tous ses
� param�tres � (par exemple, on sait que c'est une loi normale, mais on ne connait
pas l'esp�rance, ou pas l'�cart-type). Un estimateur est une fonction de X1,...,Xn
qui donne une approximation de ces param�tres (si on voit les variables al�atoires
X1,...Xn comme des applications  Om�ga ---> R, un estimateur est une variable al�atoire
obtenue en composant (X1,...,Xn) avec une application R^n ----> R).
Par exemple, (X1+...+Xn)/n est un estimateur de l'esp�rance.

+ Estimateur sans biais 

C'est un estimateur dont l'esp�rance est effectivement
la valeur du param�tre. 
Par exemple la moyenne empirique (X1+...+Xn)/n est un estimateur sans biais de l'esp�rance.
Par contre, le calcul montre que 
l'�cart-type empirique est un estimateur avec biais de l'�cart-type (mais si on prend
la m�me formule avec � n-1 � au d�nominateur � la place de � n �, ou avec l'esp�rance 
vrai � la place de la moyenne empirique, on obtient un estimateur sans biais : voir 
les exemples de la partie � simulation � ci-dessus).

Il y a plein de notions autres que le biais qui mesurent la qualit�
d'un estimateur ou d'une suite d'estimateurs. Par exemple, on dit
qu'un estimateur est consistant si, quand on augmente la taille de
l'�chantillon, il tend, en probabilit�, vers la valeur r�elle du
param�tre. Ainsi, la loi faible des grands nombres affirme que la
moyenne empirique est un estimateur coh�rent de la moyenne.

+ M�thode du maximum de vraissemblance (MLE : Maximum Likelihood Estimators)

C'est une m�thode pour trouver un estimateur (on ne sait pas s'il
v�rifira de � bonnes � propri�t�s, en particulier il sera souvent
biais�, mais c'est d�j� un bon d�part).  Elle consiste � regarder pour
quelle valeur du param�tre on a le plus de chance d'obtenir le
r�sultat qu'on a observ�.

Par exemple, cherchons, avec cette m�thode, un estimateur de la moyenne
d'une variable suivant une loi normale de variance 1 � l'aide d'un �chantillon
de 5 individus (dans cet exemple, on obtient en fait la moyenne empirique).

  # Choix de la moyenne
  m <- runif(1, min=-1, max=1)
  # Les n individus
  n <- 5
  v <- rnorm(n, mean=m)
  # Calcul de la densit�
  N <- 1000
  l <- seq(-2,2, length=N)
  y <- vector()
  for (i in l) {
    y <- append(y, prod(dnorm(v,mean=i)))
  }
  plot(y~l, type='l')
  # Moyenne r�elle
  points(m, prod(dnorm(v,mean=m)), lwd=3)
  # Moyenne empirique
  points(mean(v), prod(dnorm(v,mean=mean(v))), col='red', lwd=3)

= R_108.png

+ M�thode des moments (MME : Method of Moments Estimation)

C'est une autre m�thode pour obtenir un estimateur. S'il n'y a qu'un
seul param�tre, on le choisit de sorte que le premier moment (i.e., le
moyenne) de la variable co�ncide avec sa valeur empirique. S'il y a k
param�tres, on les choisit de sorte que les k premiers moments
co�ncident avec leur valeur empirique. (Comme pour la m�thode du
maximum de vraissemblance, on ne connait rien, a priori, de la qualit�
de l'estimateur obtenu -- il est m�me souvent biaise.)

A FAIRE : Take the faithful data and tray and fit them to a sum of
gaussians.  (Do the exact computations by hand, or use
mupad. Alternatively, solve the system numerically.)

+ In�galit� de Cramer-Rao

L'in�galit� de Cramer-Rao nous dit qu'on ne peut pas trouver des
estimateurs arbitrairement bons (plus pr�cis�ment, il donne une borne
inf�rieure pour la variance d'un estimateur non born�).

+ Statistique suffisante

La premi�re �tape pour construire un estimateur le meilleur possible
consiste � remplacer les donn�es X1,X2,...,Xn par un (ou plusieurs)
nombre(s) qui contienne autant d'information : on dit que ce nombre
est une statistique suffisante. Plus pr�cis�ment, si

  P( (X1,X2,...,Xn) \in U | t(X1,...,Xn) = c )

ne d�pend que de U et c mais pas du param�tre que l'on cherche, on dit
que t est une statistique suffisante. On dispose d'un crit�re simple 
(le th�or�me de factorisation de Neyman) pour reconnaitre une
statistique suffisante. Plus pr�cis�ment, on cherche une statistique
suffisante minimale, i.e., dont les lignes de niveau soient les plus
grandes possibles. 

+ BUE (Best Unbiaised Estimators, aka UMVUE, Uniformly Minimum Variance Unbiased Estimator)

Estimateurs non biais�s dont la variance est la plus faible possible
(de sorte que l'in�galit� de Cramer-Rao devienne une �galit�).
Je n'ai pas vraiment compris comment on les obtient.

  A FAIRE : comprendre

+ Test statistique 

On cherche � r�pondre � une question du genre � le tabac augmente-t-il
le risque de cancer ? �, � la proximit� d'une usine de retraitement de
d�chets radioactifs augmente-t-elle le risque de leuc�mie ? �, � la
moyenne de la population dont est extraite cet �chantillon de moyenne
empirique 0.02 est-elle nulle ? �.

D�taillons l'exemple du probl�me � ces deux �chantillons
proviennent-ils de la m�me population (plus pr�cis�ment : ce deux
populations de m�me moyenne) ? �. 

On consid�re une premi�re population, pour laquelle on observe une
variable statistique (de distribution normale), � partir d'un
�chantillon.  On fait pareil avec une deuxi�me population, pour
laquelle on observe une variable (normale, de m�me moyenne) et un
deuxi�me �chantillon.

On peut alors calculer la loi de la variable :

  estimation de la moyenne dans le premier �chantillon - estimation dans le second

Si on mesure une certaine valeur de cette diff�rence, on peut calculer
la probabilit� qu'il y avait d'obtenir une diff�rence aussi importante.
Si 

  P( diff�rence > diff�rence observ�e ) < alpha,

on rejette l'hypoth�se � les deux moyennes sont �gales �, avec un 
risque d'erreur �gal � alpha.

On prendra garde que ce r�sultat n'est pas certain : 
il peut y avoir deux types d'erreurs, on peut dire � tors que les moyennes
sont diff�rentes ou dire � tors que les moyennes sont �gales.

On prendra aussi garde que ces tests ne sont valables que sous certaines
conditions (normalit�, �quivariance, etc.).

En toute rigueur, on ne consid�re pas une seule hypoth�se, mais 
deux : par exemple � les moyennes sont �gales � et � les moyennes sont diff�rentes � ; 
ou alors � les moyennes sont �gales � et � la premi�re moyenne est plus grande �, 
ou encore � les moyennes sont �gales � et � la premi�re est plus petite �.
On utilisera l'un des deux derniers couples d'hypoth�ses si l'une des moyenne
est plus grande que l'autre et si on a un embryon d'explication plausible pour cela.

Les tests statistiques ne vont jamais dire << l'hypoth�se est vraie
>>. Ils vont se limiter � rejeter ou � ne pas rejeter l'hypoth�se.
(C'est tr�s semblable au d�veloppement de la science tel qu'expliqu�
par K. Popper : on ne d�montre jamais que quelque chose est vrai, on
se contente d'essayer sans cesse de d�montrer que c'est faux, et
d'�chouer.)

+ Hypoth�ses H0 (nulle) et H1 (alternative)

On consid�re alors deux hypoth�ses : l'hypoth�se nulle H0, � il n'y a
aucun effet � (par exemple, � le tabac n'augmente pas le risque de
cancer �, � la proximit� d'une usine n'augmente pas le risque de
leuc�mie �) ; l'hypoth�se alternative H1, � il y a un effet � (par
exemple, � le tabac augmente les risques de cancer �).  L'hypoth�se
alternative peut �tre sym�trique (� le tabac a un effet sur le risque
de cancer � : il l'augmente ou il le diminue) ou non (� le tabac
augmente le risque de cancer �).  Choisir une hypoth�se alternative
non sym�trique signifie donc que l'on rejette a priori la moiti� de
l'hypoth�se : il peut s'agir d'un pr�jug�, il convient donc de bien
r�fl�chir avant de choisir une hypoth�se alternative non sym�trique.

On appelle parfois H0 l'hypoth�se conservative, car c'est l'hypoth�se
qu'on conserve si le r�sultat du test n'est pas clair.

+ Erreur de type I 

Rejeter � tors l'hypoth�se nulle (i.e., dire � il n'y a 
un effet � ou � il n'y a une diff�rence � et se tromper).

Par exemple, si la variable suit une loi normale, on s'attend �
obtenir des valeurs << au milieu >> de la courbe en cloche. Si on
obtient des valeurs trop �loign�es, on rejettera (parfois � tors)
l'hypoth�se nulle. Le risque d'erreur de type I correspond donc �
l'aire de la partie en rouge sur la figure suivante.

  colorie <- function (x, y1, y2, N=1000, ...) {
    for (t in (0:N)/N) {
      lines(x, t*y1+(1-t)*y2, ...)
    }
  }
  # Non, il y a d�j� une fonction qui fait �a...
  colorie <- function (x, y1, y2, ...) {
    polygon( c(x, x[length(x):1]), c(y1, y2[length(y2):1]), ... )
  }
  x <- seq(-6,6, length=100)
  y <- dnorm(x)
  plot(y~x, type='l')
  i = x<qnorm(.025)
  colorie(x[i],y[i],rep(0,sum(i)) ,col='red')
  i = x>qnorm(.975)
  colorie(x[i],y[i],rep(0,sum(i)) ,col='red')
  lines(y~x)

= R_148.png

+ p-valeur 

Probabilit�, (si l'hypoth�se nulle est vraie), d'obtenir un r�sultat au moins
aussi extr�me. C'est la probabilit� de commettre une erreur de type I.

+ Erreur de type II 

Accepter � tors l'hypoth�se nulle (i.e., dire � il y a un 
effet � ou � il y a une diff�rence � et se tromper).

En toute rigueur, ce n'est pas une erreur, car on ne doit jamais dire
<< H0 est vraie >>, mais juste << on ne rejette pas H0 >>. Ce n'est
pas une erreur, mais une occasion rat�e.

Le risque d'erreur de type II, c'est l'aire de la partie rouge dans le
dessin suivant. La coube en cloche du milieu, c'est la distribution
pr�vue par l'hypoth�se nulle, l'autre courbe, c'est la distribution
effectivement suivie par l'�chantillon.

  x <- seq(-6,6, length=1000)
  y <- dnorm(x)
  plot(y~x, type='l')
  y2 <- dnorm(x-.5)
  lines(y2~x)
  i <- x>qnorm(.025) & x<qnorm(.975)
  colorie(x[i],y2[i],rep(0,sum(i)), col='red')
  segments( qnorm(.025),0,qnorm(.025),dnorm(qnorm(.025)), col='red' )
  segments( qnorm(.975),0,qnorm(.975),dnorm(qnorm(.975)), col='red' )
  lines(y~x)
  lines(y2~x)

= R_149.png

Si les deux courbes sont suffisemment �loign�es, le risque d'erreur de
type II est beaucoup plus faible.

= R_150.png

+ Puissance

Par d�finition, la puissance d'un test, c'est 

  1 - P( erreur de type II ).

G�n�ralement, la puissance n'est pas un nombre mais une fonction.
l'hypoth�se nulle est souvent de la forme H0 : << mu = mu0 >> et
l'hypoth�se alternative de la forme H1: << mu diff�rent de mu0 >>.  La
puissance va d�pendre de la valeur r�elle de mu : si mu est proche de
mu0, le risque d'erreur est grand est la puissance failble, par
contre, si mu et mu0 sont tr�s diff�rents, le risque d'erreur est plus
faible et la puissance plus �lev�e.

A FAIRE : quelle valeur donner � la puissance ?

+ Hypoth�se simple

On dit qu'une hypoth�se est simple si elle implique
une connaissance compl�te de la loi suivie par les v.a.. Par exemple,
si on cherche la moyenne d'une v.a. dont on sait qu'elle est normale
de variance 1, l'hypoth�se H0 : � la moyenne est nulle � est
simple. Par contre, si on ne connait pas la variance, cette hypoth�se
H0 n'est pas simple. Autre exemple : on observe un �chantillon
statistique et on sait qu'il provient soit d'une population 1 (d�crite
par une v.a. normale de moyenne 3 et de variance 2), soit d'une
population 2 (d�crite par une v.a. normale de moyenne 1 et de variance
1) ; les hypoth�ses H0 : � l'�chantillon provient de la population 1 �
et H1 : � l'�chantillon provient de la population 2 � sont toutes deux
simples.

+ Hypoth�se composite 

Une hypoth�se qui n'est pas simple. Tr�s
souvent, les hypoth�ses alternatives (H1) sont composites.

+ Intervalle de confiance

On sait qu'une variable al�atoire suit une loi d'une certaine forme,
que l'on ne connait pas enti�rement, par exemple, une loi normale de
variance 1 dont on ne connait pas la moyenne. 

On pourrait s'attendre � ce qu'un (article ind�fini : il y en a plein)
intervalle de confiance � 95% pour la moyenne soit un intervalle dans
lequel on a 95% de chances de trouver la moyenne si on a observ� cet
�chantillon. A priori, �a n'est pas �a [voir quand m�me quelques
paragraphes plus bas], car pour mod�liser une telle situation, on
aurait besoin de connaitre la loi suivie par les moyennes, or, dans
les situations concr�tes, cela n'a pas de sens (la moyenne n'est pas
titr�e au hasard : soit elle est nulle, soit elle ne l'est pas, mais
elle n'est pas al�atoire).

Retournons le probl�me : pour toute valeur m de la moyenne, on peut
trouver un intervalle I(m) (pour fixer les id�es, prenons des
intervalles centr�s sur m) dans lequel la moyenne empirique a 95% de
chances de se trouver. Si on observe une certaine moyenne empirique,
l'intervalle de confiance � 95% sur la moyenne est l'ensemble des m
tels que la moyenne empirique soit dans l'intervalle I(m).

Tentons de v�rifier, � l'aide d'une simulation, la fausset� de la
premi�re interpr�tation (ici, on utilise le test T de Student pour
obtenir un intervalle de confiance � 95% de la moyenne).

  # Taille des �chantillons
  n <- 100
  # Nombre de points de la courbe
  N <- 1000
  v <- vector()
  for (i in 1:N) {
    m <- runif(1)
    x <- m+rnorm(n)
    int <- t.test(x)$conf.int
    v <- append(v, int[1]<m & m<int[2])
  }
  sum(v)/N

On trouve 0.95. Donc, a post�riori, la premi�re interpr�tation est
quand m�me correcte (on peut m�me essayer avec d'autres
distributions).  En fait, c'est tr�s facile � d�montrer : il suffit de
remarquer que dire que la moyenne empirique est dans un certain
intervalle centr� sur la moyenne r�elle revient � dire que la moyenne
r�elle est dans un certain intervalle autour de la moyenne empirique.

Une erreur courrante consiste � croire que la p-valeur est la
probabilit� que H0 soit vraie : ce n'est pas du tout �a. C'est la
probabilit� d'obtenir des r�sultats au moins aussi extr�mes si H0 est
vraie.

+ UMP (Uniform Most Powerful) tests

On aimerait bien fixer la puissance d'un test, de la m�me mani�re
qu'on fixe son niveau. Mais
il y a un probl�me : la puissance n'est pas un nombre, mais une
fonction, qui d�pend de l'hypoth�se simple dans H1.

On dit qu'un test est UMP si, pour toute hypoth�se simple dans H1, il
poss�de la plus grande puissance parmi tous les tests de niveau alpha.

+ Test non param�trique

La plupart du temps, les tests statistiques supposent que les variables sont normales.
Les tests non param�triques ne font pas ce genre d'hypoth�se.

A FAIRE : donner des exemples de tests param�triques / non param�triques.

+ Robustesse

On dit qu'un test (param�trique) est robuste s'il donne toujours des
r�sultats corrects quand ses hypoth�ses ne sont plus v�rifi�es.

+ R�sistance

On dit qu'un param�tre statistique est r�sistant s'il est peu
d�pendant des valeurs extr�mes. Par exemple, la moyenne n'est pas
r�sistante, contrairement � la m�diane.

  > x <- rnorm(10)
  > mean(x)
  [1] -0.08964153
  > mean(c(x,10^10))
  [1] 909090909
  > median(x)
  [1] -0.2234618
  > median(c(x,10^10))
  [1] -0.1949206

+ Trois mani�res de faire des tests statistiques

1. On peut chercher un param�tre de la loi d�crivant la population :
on utilise alors un estimateur. Si possible, on en prendra un qui soit
non biais� et dont la variance soit la plus faible possible. (Si on
n'y arrive pas, en particulier si la variable �tudi�e n'est pas
normale, on pourra utiliser respectivement les m�thodes du Jackknife
et du Bootstrap, que nous pr�senterons plus tard.)

2. On peut chercher un intervalle dans lequel se trouve ce param�tre : 
on construit alors un intervalle de confiance.

3. On peut chercher � savoir si ce param�tre a une valeur pr�d�finie :
on effectue alors un test.

+ Critiques des tests statistiques

Une p-valeur �lev�e peut signifier deux choses : soit l'hypoth�se
nulle est tr�s fausse, soit elle ne l'est qu'un peu mais l'�chantillon
est suffisemment grand pour qu'on s'en apper�oive. Dans le second cas,
on a une diff�rence statistiquement notable entre l'hypoth�se nulle et
la r�alit�, mais, partiquement, cette diff�rence est n�gligeable.

+ Th�orie de la d�cision

Parmi tous les tests possibles, on en cherche un pour lequel les risques
d'erreur de type I et II soient les plus bas possibles. Parmi les tests qui 
ne sont pas perfectibles (que l'on ne peut pas modifier pour en obtenir un 
pour lequel le risque d'erreur de type I soit le m�me et le risque d'erreur de 
type II plus bas (ou le contraire)), il n'existe pas de moyen de 
choisir LE meilleur (mais la th�orie de la d�cision permet �
chacun de choisir parmi ces tests celui qui convient le mieux �
son propre gout du risque). G�n�ralement, on fixe une borne sup�rieure pour la
probabilit� d'une erreur de type I (alpha) et on minimise le risque d'erreur de type II.

A FAIRE : r�f�rence du livre sur la th�orie de la d�cision.

* Le zoo des tests statistiques

La plupart des fonctions R qui effectuent des tests statistiques
sont dans � ctest � (classical tests).

  library(help="ctest")

+ Lecture du r�sultat de ces tests

On s'attendrait � ce que les fonctions de R qui effectuent
ces tests nous disent � hypoth�se rejet�e � ou � hypoth�se non rejet�e � -- 
mais non. L'utilisateur doit savoir interpr�ter lui-m�me les r�sultats,
avec �ventuellement un certain esprit critique.

Le r�sultat des tests est essentiellement un nombre, la � p-valeur �.
C'est la probabilit� d'obtenir un r�sultat au moins aussi extr�me.
S'il est proche de 1, on ne rejette pas l'hypoth�se, s'il est proche de
0, on peut la rejeter.  Plus pr�cis�ment, si on veut un risque
d'erreur de alpha % (par exemple, 5%), on ne rejette pas l'hypoth�se si
p>alpha/100 (par exemple, p>.05) et on la rejette sinon.

Par exemple, 

  > x <- rnorm(200)
  > t.test(x)

        One Sample t-test

  data:  x
  t = 3.1091, df = 199, p-value = 0.002152
  alternative hypothesis: true mean is not equal to 0
  95 percent confidence interval:
   0.07855896 0.35102887
  sample estimates:
  mean of x
  0.2147939

Si on rejette l'hypoth�se (ici : � la moyenne est nulle �), 
on aura tors avec une probabilit� de 0.002152, soit 2 fois sur mille.

On retrouve cela � l'aide de simulations : dans 95% des cas, on a p>.05

  p <- c()
  for (i in 1:1000) {
    x <- rnorm(200)
    p <- append(p, t.test(x)$p.value)
  }
  hist(p)

= R_029.png

  p <- sort(p)
  p[950]
  p[50]
  x <- 1:1000
  plot(p ~ x)

= R_030.png

Il s'agissait ici du risque d'erreur de type I (rejeter � tors
l'hypoth�se nulle).  Examinons maintenant le risque d'erreur de type
II (accepter � tors l'hypoth�se nulle).  Ce risque d�pend de la
moyenne (que l'on ne connait pas) : si la moyenne est proche de z�ro,
ce risque est grand, si est est �loign�e, il est plus faible.

  # Taille de chaque �chantillon
  n <- 10
  # Nombre de simulations � effectuer pour avoir une bonne
  # approximation de la probabilit�
  m <- 1000
  # Nombre de points pour tracer la courbe
  k <- 50
  # Valeur maximale de la moyenne
  M <- 2
  r <- vector()
  for (j in M*(0:k)/k) {
    res <- 0
    for (i in 1:m) {
      x <- rnorm(10, mean=j)
      if( t.test(x)$p.value > .05 ){
        res <- res + 1
      }
    }
    r <- append(r, res/m)
  }
  rr <- M*(0:k)/k
  plot(r~rr, type="l")

  # Courbe th�orique 
  A FAIRE !!!
  (pour l'instant, j'ai la courbe th�orique d'un test de Z)
  r2 <- function (p,q,conf,x) {
    p(q(1-conf/2)-x) - p(q(conf/2)-x)
  }
  f <- function(x) {
    p <- function (t) { pnorm(t, sd=1/sqrt(10)) }
    q <- function (t) { qnorm(t, sd=1/sqrt(10)) }
    r2(p,q,.05,x)
  }
  f <- function(x) {
    p <- function (t) { pt(t, 100) }
    q <- function (t) { qt(t, 100) }
    r2(p,q,.05,x)
  }
  curve( f(x) , add=T, col="green" )
 
= R_066.png

On peut aussi repr�senter graphiquement la r�partition des p-valeurs
pour une valeur donn�e de la moyenne.

A FAIRE : expliquer ce que je fais (en me relisant, je ne comprends
pas...)  (commencer par mettre un titre au graphique, et des noms plus
explicites aux axes.)

  N <- 10000
  x <- 100*(1:N)/N
  plot( x/100 ~ x, type='l', xlab="(%)", ylab="p-value" )
  for (m in c(0, .05, .1, .15, .2)) {
    p <- c()
    for (i in 1:N) {
      x <- m+rnorm(200)
      p <- append(p, t.test(x)$p.value)
    }
    p <- sort(p)
    x <- 100*(1:N)/N
    lines(p ~ x, type='l')
  }
  abline(.05, 0)

= R_091.png

Le manuel donne cet exemple, assez troublant, qui explique pourquoi R
ne donne pas un r�sultat tranch� � hypoth�se rejet�e � ou � hypoth�se
non rejet�e �.  Si on regarde les donn�es � l'oeil nu, on peut
affirmer sans grand risque que les moyennes sont tr�s
distinctes. Pourtant, la p-valeur est tr�s �lev�e et conduit � ne pas
rejeter l'hypoth�se nulle (les moyennes sont �gales). Le probl�me,
c'est la taille de l'intervalle de confiance, qui est �norme. Il faut
donc bien regarder les donn�es et bien lire le r�sultat.  (Cet exemple
pr�sente d'autres probl�mes : pour appliquer un test T de Student sur
les moyennes, il faut que les �chantillons soient normaux,
�quivariants et ind�pendants -- �a n'a pas l'air d'�tre le cas).

  > x <- 1:10
  > y <- c(7:20, 200)
  > boxplot(x,y, horizontal=T)

= R_101.png

  > boxplot(x,y, log="x", horizontal=T)

= R_102.png

  > t.test(x, y)

        Welch Two Sample t-test

  data:  x and y
  t = -1.6329, df = 14.165, p-value = 0.1245
  alternative hypothesis: true difference in means is not equal to 0
  95 percent confidence interval:
   -47.242900   6.376233
  sample estimates:
  mean of x mean of y
    5.50000  25.93333

Par contre, si on enl�ve la valeur 200, on obtient un r�sultat plus
conforme � l'intuition. 

  > t.test(1:10,y=c(7:20))

        Welch Two Sample t-test

  data:  1:10 and c(7:20)
  t = -5.4349, df = 21.982, p-value = 1.855e-05
  alternative hypothesis: true difference in means is not equal to 0
  95 percent confidence interval:
   -11.052802  -4.947198
  sample estimates:
  mean of x mean of y
        5.5      13.5

+ ATTENTION

La plupart de ces tests ne sont valables que pour des distributions
normales.  S'il y a plusieurs �chantillons, on demande qussi qu'ils
aient la m�me variance.

+ Le test T de Student

Il s'agit de trouver la moyenne d'un �chantillon.

  ?t.test

Conditions d'application : la variable est normale (sinon, on peut
utiliser le test U de Wilcoxon).

Nous avons d�j� donn� un exemple quelques lignes plus haut.

Voici la th�orie.

L'hypoth�se nulle est H0 : � la moyenne r�elle est m �, 
l'hypoth�se alternative est H1 : � la moyenne r�elle n'est pas m �.
On calcule la quantit� 

  T = ( moyenne empirique - m ) / ( �cart-type empirique de l'�chantillon / sqrt(n) )

(attention, on prend l'�cart-type
de l'�chantillon (celui avec n-1), pas de la population (celui avec n) -- R utilise
uniquement le premier)
et on rejette H0 si 

  abs( T ) > t_{n-1} ^{-1} ( 1 - alpha/2 )

o� T_{n-1} est la loi T de Student � n-1 degr�s de libert�.
(Si on observe des vaiid normales, T suit effectivement cette loi de Student : 
on peut d'ailleur d�finir la loi de Student ainsi.)

Voici le graphe des densit�s des lois de Student.
On constate que pour n grand, on se rapproche d'une loi normale.

  curve(dnorm(x), from=-5, to=5, add=F, col="yellow", lwd=2)  
  curve(dt(x,100), from=-5, to=5, add=F, col="black")  
  curve(dt(x,5),  from=-5, to=5, add=T, col="red")  
  curve(dt(x,2),  from=-5, to=5, add=T, col="green")  
  curve(dt(x,1),  from=-5, to=5, add=T, col="blue")  

=R_007.png

Voyons maintenant comment mettre cela en pratique, � la main.

On part d'un �chantillon de population normale, dont on calcule la moyenne.

  > x <- rnorm(200)
  > m <- mean(x)
  > m
  [1] 0.05875323

On cherche maintenant un intervalle, centr� autour de cette moyenne 
empirique, dans lequel on ait 95% de chances de trouver la moyenne r�elle
(qui est 0).

  x <- rnorm(100)
  n <- length(x)
  m <- mean(x)
  m
  alpha <- .05
  m + sd(x)/sqrt(n)*qt(alpha/2, df=n-1, lower.tail=T)
  m + sd(x)/sqrt(n)*qt(alpha/2, df=n-1, lower.tail=F)

On obtient [m - 0.19, m + 0.19].

La fonction t.test nous donne un r�sultat comparable.

  > t.test(x, mu=0, conf.level=0.95)

        One Sample t-test

  data:  x
  t = 0.214, df = 99, p-value = 0.831
  alternative hypothesis: true mean is not equal to 0
  95 percent confidence interval:
   -0.1987368  0.2467923
  sample estimates:
   mean of x
  0.02402775

On peut aussi v�rifier cela exp�rimentalement, � l'aide de simulations.

  > m = c()
  > for (i in 1:10000) {
  +   m <- append(m, mean(rnorm(100)) )
  + }
  > m <- sort(m)
  > m[250]
  [1] -0.1982188
  > m[9750]
  [1] 0.1999646

L'intervalle est donc [-0.20, +0.20] : on retrouve approximativement
le r�sultat th�orique (l'approximation est grossi�re, comme toujours
pour les m�thodes de type Mont�-Carlo).

On peut aussi repr�senter graphiquement une telle simulation.
On voit que la moyenne r�elle est parfois en dehors de l'intervalle de
confiance.

  N <- 50
  n <- 5
  v <- matrix(c(0,0),nrow=2)
  for (i in 1:N) {
    x <- rnorm(n)
    v <- cbind(v, t.test(x)$conf.int)
  }
  v <- v[,2:(N+1)]
  plot(apply(v,2,mean), ylim=c(min(v),max(v)))
  abline(0,0)
  c <- apply(v,2,min)>0 | apply(v,2,max)<0
  segments(1:N,v[1,],1:N,v[2,], col=c+1, lwd=3)

=R_103.png

+ Robustesse du test T de Student

Faisons une simulation pour voir ce qui se passe si on tente de faire
un test de Student avec des donn�es non normales (dans une telle
situation, on devrait utiliser un test U de Wilcoxon).

  > N <- 1000
  > n <- 3
  > v <- vector()
  > for (i in 1:N) {
      x <- runif(n, min=-1, max=1)
      v <- append(v, t.test(x)$p.value)
    }
  > sum(v>.05)/N
  [1] 0.932
  
Maintenant avec des donn�es normales.

  > N <- 1000
  > n <- 3
  > v <- vector()
  > for (i in 1:N) {
      x <- rnorm(n, sd=1/sqrt(3))
      v <- append(v, t.test(x)$p.value)
    }
  > sum(v>.05)/N
  [1] 0.952

Par cons�quent, la p-valeur est fausse si la variable n'est plus
normale : quand on croit rejeter l'hypoth�se en avec un risque
d'erreur de type I de 5%, le risque est en fait (pour une distribution
uniforme) de 7%.

Regardons maintenant ce qui se passe avec l'intervalle de confiance :
on devrait �tre dedans dans 95% des cas.

  > N <- 1000
  > n <- 3
  > v <- vector()
  > for (i in 1:N) {
      x <- runif(n, min=-1, max=1)
      r <- t.test(x)$conf.int
      v <- append(v, r[1]<0 & r[2]>0)
    }
  > sum(v)/N
  [1] 0.919

  > N <- 1000
  > n <- 100
  > v <- vector()
  > for (i in 1:N) {
      x <- rnorm(n, sd=1/sqrt(3))
      r <- t.test(x)$conf.int
      v <- append(v, r[1]<0 & r[2]>0)
    }
  > sum(v)/N
  [1] 0.947

on est dans l'intervalle de confiance dans 92% des cas, au lieu de 95%.

Par contre, avec des �chantillons assez grands, l'erreur devient n�gligeable.

  > N <- 1000
  > n <- 100
  > v <- vector()
  > for (i in 1:N) {
      x <- runif(n, min=-1, max=1)
      v <- append(v, t.test(x)$p.value)
    }
  > sum(v>.05)/N
  [1] 0.947

  > N <- 1000
  > n <- 100
  > v <- vector()
  > for (i in 1:N) {
      x <- runif(n, min=-1, max=1)
      r <- t.test(x)$conf.int
      v <- append(v, r[1]<0 & r[2]>0)
    }
  > sum(v)/N
  [1] 0.945

On pourra retenir que le test de Student est robuste : si les donn�es
ne sont pas normales, la p-valeur et le diam�tre de l'intervalle de
confiance sont sous-estim�s, mais pas trop.

+ Test de Z

C'est comme le test de Student, mais cette fois-ci, on connait la
valeur exacte de la variance : on n'utilise donc plus la distribution
T de Student, mais simplement la distribution normale (souvent not�e
Z).

Dans la pratique, quand on ne connait pas la valeur exacte de la
moyenne, on ne connait g�n�ralement pas non plus la valeur exacte de
la variance -- ce test a donc une utilit� pratique assez limit�e.

Pour les gros �chantillons, la loi du T de Student est bien approch�e
par la loi normale, on peut donc faire un test de Z au lieu d'un test
de T (mais comme c'est de toute mani�re l'ordinateur qui fait les
calculs � notre place...)

+ Test de Student : comparaison de la moyenne de deux �chantillons

On a maintenant deux �chantillons dont on aimerait savoir s'ils
viennent de la m�me population ; et plus particuli�rement s'ils ont la
m�me moyenne.

On suppose ici que les lois sont normales de m�me variance (on peut
utiliser un test F pour s'en assurer). Si ces conditions ne sont pas
v�rifi�es, on peut utiliser un test U de Wilcoxon.

Si les deux �chantillons sont de taille n (�a marche aussi si les
�chantillons sont de tailles diff�rentes, mais la formule est beaucoup
plus compliqu�e), on montre que la quantit�

  t = diff�rence des moyennes / sqrt( (somme des variances)/n )

suit une loi de Student � 2n-2 degr�s de libert�.

On rejette l'hypoth�se � les moyennes sont �gales � si 

  abs(t) > abs( t(alpha, 2n-2) )

Conditions d'application : �quivariance (les deux �chantillons ont la m�me
variance, ce que l'on v�rifie avec un test F), ind�pendance des deux �chantillons
(ce n'est pas toujours le cas : par exemple, on peut vouloir comparer la
longueur de l'hum�rus droit et de l'hum�rus gauche chez des individus ; 
pour se ramener � des choses ind�pendantes, on va consid�rer la diff�rence de 
longueur entre les deux os).

On pourrait le faire � la main, comme plus haut, mais il y a d�j� une
fonction.

  ?t.test
  > x <- rnorm(100)
  > y <- rnorm(100)
  > t.test(x,y)

        Welch Two Sample t-test

  data:  x and y
  t = -1.3393, df = 197.725, p-value = 0.182
  alternative hypothesis: true difference in means is not equal to 0
  95 percent confidence interval:
   -0.46324980  0.08851724
  sample estimates:
    mean of x   mean of y
  -0.03608115  0.15128514

  > t.test(x, y, alternative="greater")

        Welch Two Sample t-test

  data:  x and y
  t = -1.3393, df = 197.725, p-value = 0.909
  alternative hypothesis: true difference in means is greater than 0
  95 percent confidence interval:
   -0.4185611        Inf
  sample estimates:
    mean of x   mean of y
  -0.03608115  0.15128514

Voici l'exemple du manuel : l'�tude de l'efficacit� d'un
somnif�re.

  > data(sleep)
  > plot(extra ~ group, data = sleep)

  > t.test(extra ~ group, data = sleep)
        Welch Two Sample t-test

  data:  extra by group
  t = -1.8608, df = 17.776, p-value = 0.0794
  alternative hypothesis: true difference in means is not equal to 0
  95 percent confidence interval:
   -3.3654832  0.2054832
  sample estimates:
  mean in group 1 mean in group 2
             0.75            2.33

Ici, comme la p-valeur est sup�rieure � 5%, on concluerait que le
somnif�re a des effets non significatifs.  N�anmoins, si on travaille
pour le laboratoire qui le fabrique, on voudra une conclusion
diff�rente. On peut l'obtenir en changenant l'hypoth�se alternative,
qui devient � le somnif�re augmente le temps de sommeil
�. (Normalement, on doit choisir l'hypoth�se alternative avant de
faire l'exp�rience, et ce choix doit �tre appuy� par des faits
ext�rieurs � l'exp�rience : constater que dans cette exp�rience la
moyenne empirique d'un �chantillon est plus grande ne suffit pas.)

  > t.test(extra ~ group, data = sleep, alternative="less")

        Welch Two Sample t-test

  data:  extra by group
  t = -1.8608, df = 17.776, p-value = 0.0397
  alternative hypothesis: true difference in means is less than 0
  95 percent confidence interval:
         -Inf -0.1066185
  sample estimates:
  mean in group 1 mean in group 2
             0.75            2.33

Si on a plus de deux �chantillons, on peut faire une analyse de la
variance. Si on a deux �chantillons non normaux, on peut faire un test
U de Wilcoxon. Si on a plus de deux �chantillon, non normaux, on peut
faire une analyse de la variance non param�trique, i.e., un test de
Kruskal--Wallis.

+ Robustesse du test T de Student

Pour comparer des moyennes avec un test T de Student, il faut que les
�chantillons proviennent de populations normales de m�me
variance. Regardons ce qui se passe avec des �chantillons normaux non
�quivariants.

  N <- 1000
  n <- 10
  v <- 100
  a <- NULL
  b <- NULL
  for (i in 1:N) {
    x <- rnorm(n)
    y <- rnorm(n, 0, v)
    a <- append(a, t.test(x,y)$p.value)
    b <- append(b, t.test(x/var(x), y/var(y))$p.value)
  }
  plot(sort(a), type='l', col="green")
  points(sort(b), type="l", col="red")
  abline(0,1/N)
 
=R_124.png 

Nous avons vu plus haut que les donn�es devaient �tre normales pour
pouvoir leur appliquer le test T de Student, mais qu'il se comportait
quand m�me relativement bien avec des donn�es normales.  Nous pouvons
maintenant affirmer que l'hypoth�se d'�quivariance est carr�ment
inutile (attention : je ne sais pas si elle est inutile pour le test T
de Student en g�n�ral ou simplement pour le test T de Student tel
qu'il est impl�ment� dans R).

+ Plusieurs mani�res de comparer des moyennes

Il existe plusieurs mani�res de comparer deux moyennes.

  data(sleep)
  plot(extra ~ group, data=sleep)

A l'aide d'un test de Student, si on suppose que les donn�es sont normales.

  > t.test(extra ~ group, data=sleep)

        Welch Two Sample t-test

  data:  extra by group
  t = -1.8608, df = 17.776, p-value = 0.0794
  alternative hypothesis: true difference in means is not equal to 0
  95 percent confidence interval:
   -3.3654832  0.2054832
  sample estimates:
  mean in group 1 mean in group 2
             0.75            2.33

A l'aide d'un test de Wilcoxon, si on ne sait pas que les donn�es sont
normales, on si on soup�onne qu'elles ne le sont pas.

  > wilcox.test(extra ~ group, data=sleep)

        Wilcoxon rank sum test with continuity correction

  data:  extra by group
  W = 25.5, p-value = 0.06933
  alternative hypothesis: true mu is not equal to 0

  Warning message:
  Cannot compute exact p-value with ties in: wilcox.test.default(x = c(0.7, -1.6,

A l'aide d'une analyse de la variance (nous expliquerons plus loin ce que c'est).

  > anova(lm(extra ~ group, data=sleep))
  Analysis of Variance Table

  Response: extra
            Df Sum Sq Mean Sq F value  Pr(>F)
  group      1 12.482  12.482  3.4626 0.07919 .
  Residuals 18 64.886   3.605
  ---
  Signif. codes:  0 `***' 0.001 `**' 0.01 `*' 0.05 `.' 0.1 ` ' 1

A l'aide d'une analyse de la variance non param�trique, i.e., un test
de Kruskal--Wallis.

  > kruskal.test(extra ~ group, data=sleep)

        Kruskal-Wallis rank sum test

  data:  extra by group
  Kruskal-Wallis chi-squared = 3.4378, df = 1, p-value = 0.06372

Voici les r�sultats.

  M�thode                  p-valeur

  Test T de Student        0.0794
  Test de Wilcoxon         0.06933
  Analyse de la variance   0.07919
  Test de Kruskal--Wallis  0.06372

+ Le Chi^2 et le calcul de la variance

On cherche la variance la variance d'un �chantillon (on ne connait pas
la moyenne de la population).

Voici la th�orie.

L'hypoth�se nulle est H0 : � la variance r�elle est v �, 
l'hypoth�se alternative est � la variance r�elle n'est pas v �.
On calcule la quantit� 

  Chi2 = (n-1) * (variance empirique) / v

et on rejette l'hypoth�se H0 si 

    Chi2 > Chi2_{n-1} ^{-1} ( 1 - alpha/2 )
  ou 
    Chi2 < Chi2_{n-1} ^{-1} ( alpha/2 )

o� Chi2_{n-1} est la loi du Chi2 � n-1 degr�s de libert�.

Voici le graphe de la densit� du Chi2, selon le nombre de degr�s de libert�.

  curve(dchisq(x,2),  from=0, to=5, add=F, col="red")  
  curve(dchisq(x,1),  from=0, to=5, add=T, col="black")  
  curve(dchisq(x,3),  from=0, to=5, add=T, col="green")  
  curve(dchisq(x,4),  from=0, to=5, add=T, col="blue")  
  curve(dchisq(x,5),  from=0, to=5, add=T, col="black")  
  curve(dchisq(x,6),  from=0, to=5, add=T, col="black")  
  curve(dchisq(x,7),  from=0, to=5, add=T, col="black")  
  curve(dchisq(x,8),  from=0, to=5, add=T, col="black")  
  curve(dchisq(x,9),  from=0, to=5, add=T, col="black")  
  curve(dchisq(x,10), from=0, to=5, add=T, col="black")  

= R_008.png

Voici comment on peut obtenir � la main un intervalle de
confiance pour l'�cart-type.

  alpha <- .05
  x <- rnorm(200)
  n <- length(x)
  v = var(x)
  sd(x)
  sqrt( (n-1)*v / qchisq(alpha/2, df=n-1, lower.tail=F) )
  sqrt( (n-1)*v / qchisq(alpha/2, df=n-1, lower.tail=T) )

On obtient [0.91, 1.11].

On peut v�rifier cela par la simulation : 

  v <- c(0)
  for (i in 1:10000) {
    v <- append(v, var(rnorm(200)) )
  }
  v <- sort(v)
  sqrt(v[250])
  sqrt(v[9750])

On obtient l'intervalle [0.90, 1.10].

Avec des �chantillons plus petits, on obtient une estimation
moins fiable : l'intervalle est [0.68, 1.32].

  v <- c(0)
  for (i in 1:10000) {
    v <- append(v, var(rnorm(20)) )
  }
  v <- sort(v)
  sqrt(v[250])
  sqrt(v[9750])

Je n'ai pas trouv� de fonction R qui fasse �a.

  A FAIRE 

+ Loi de Fisher (test F) et comparaison de la variance de deux �chantillons

Il s'agit de savoir si deux �chantillon proviennent de deux populations
ayant ou non la m�me variance (on ne tient pas compte de la moyenne).

C'est comme pour la comparaison des moyennes, mais ici, on prend
le quotient des variances.

On utilise par exemple ce test avant un test t de Student (comparaison des moyennes),
car l'�quivariance en est une condition d'application.

Voici l'exemple avec lequel nous avons illustr� le test de Student : 
il est effectivement vraissemblable que les variances sont �gales.

  ?var.test
  > var.test( sleep[,1] [sleep[,2]==1], sleep[,1] [sleep[,2]==2] )

        F test to compare two variances

  data:  sleep[, 1][sleep[, 2] == 1] and sleep[, 1][sleep[, 2] == 2]
  F = 0.7983, num df = 9, denom df = 9, p-value = 0.7427
  alternative hypothesis: true ratio of variances is not equal to 1
  95 percent confidence interval:
   0.198297 3.214123
  sample estimates:
  ratio of variances
           0.7983426

Voici la th�orie.

L'hypoth�se nulle est H0 : � les deux populations ont la m�me variance �,
l'hypoth�se alternative est H1 : � les deux populations n'ont pas la m�me variance �.
On calcule la quantit� 

  F = (variance empirique du premier �chantillon) / (variance empirique du deuxi�me)

et on rejette H0 si 

    F < F _{n1-1, n2-2} ^{-1} ( alpha/2 )
  ou
    F > F _{n1-1, n2-2} ^{-1} ( 1 - alpha/2 )

o� F est la loi de Fisher.

Dans la pratique, 
on calcule le quotient F des deux variances (en mettant la plus grande au num�rateur),
et on rejette l'hypoth�se d'�galit� des variances si 

  F > F(alpha/2, n1-1, n2-1)

o� n1 et n2 sont les effectifs des �chantillons.

Voici un exemple, � la main :

  > x <- rnorm(100, 0, 1)
  > y <- rnorm(100, 0, 2)
  > f <- var(y)/var(x)
  > f
  [1] 5.232247
  > qf(alpha/2, 99, 99)
  [1] 0.6728417
  > f > qf(alpha/2, 99, 99)
  [1] TRUE

A FAIRE : comprendre :

  # Exemple du manuel
  x <- rnorm(50, mean = 0, sd = 2)
  y <- rnorm(30, mean = 1, sd = 1)
  var.test(x, y)                  # Do x and y have the same variance?
  var.test(lm(x ~ 1), lm(y ~ 1))  # The same.

Si on a plus de deux �chantillons, on peut utiliser le test de
Bartlett. Si on a deux �chantillons non normaux, on peut utiliser les
tests non param�triques d'Ansari ou de Mood. Si on a plus de deux
�chantillons non normaux, on peut utiliser le test de Fligner

  ?bartlett.test
  ?ansari.test
  ?mood.test
  ?fligner.test

* Le zoo des tests statistiques (suite)

A FAIRE : RELIRE (et r��crire) CETTE PARTIE

+ Le test du Chi^2 (comparaison de distributions)

Il s'agit de v�rifier que deux �chantillons proviennent de la m�me population,
ou qu'un �chantillon provient d'une population suivant une loi donn�e.

  ?chisq.test

Consid�rons par exemple la situation suivante : on mesure deux variables 
qualitatives, chacune � deux valeurs, sur un �chantillon. Dans la population compl�te, 
on observe les quatre classes dans les proportions 
10%, 20%, 60%, 10%. 

         A    B   total
  A     10   20   30
  B     60   10   70
  total 70   30   100

On peut obtenir un �chantillon ainsi.

  foo <- function (N) {
    x <- runif(N)
    aa <- x<.1
    ab <- !aa & x<.3
    ba <- !aa & !ab & x<.90
    bb <- !aa & !ab & !ba
    matrix( c( sum(aa),sum(ab),sum(ba),sum(bb) ), nrow=2)
  }

  A FAIRE : ce n'est pas tr�s bien programm�...
  Utiliser la fonction "sample"
  x <- sample( c(rep(0,3),rep(1,7)), 10, replace=T )
  y <- sample( c(0,1), 10, replace=T )
  > table(x,y)
     y
  x   0 1
    0 2 0
    1 6 2

(suite)

  N <- 10
  x <- foo(N)
  y <- foo(N)
  chisq.test(as.vector(x),as.vector(y))

On peut faire un graphe des p-valeurs, qui nous confirme que 95% du temps
elles sont au dessus de 0.05. Si on obtient une p-valeur inf�rieure
� 0.05, on dira que les �chantillons proviennent de populations diff�rentes,
sinon, on dira qu'ils proviennent de la m�me.

  A FAIRE : COMPRENDRE
  (ce n'est PAS DU TOUT le genre de graphe que je m'attendais � obtenir)

  v <- vector()
  for (i in 1:1000) {
    N <- 5
    x <- as.vector(foo(N))
    y <- as.vector(foo(N))
    v <- append(v, chisq.test(x,y, simulate.p.value=T)$p.value)
  }
  plot(sort(v))

= R_072.png

  ...
  N <- 100
  ...

= R_073.png

  ...
  N <- 5
  v <- append(v, chisq.test(x,y)$p.value)
  ...

= R_074.png

  ...
  N <- 100
  v <- append(v, chisq.test(x,y)$p.value)
  ...

= R_075.png

  A FAIRE
  exemple 1 : avec deux �chantillons
  exemple 2 : avec un �chantillon et une loi donn�e a priori
  exemple 3 : avec un �chantillon, et on teste l'�quiprobabilit�.

Remarque : Ce test est con�u pour des variables qualitatives.

A FAIRE (A COMPRENDRE) : la distance du chi2.

+ Test de Fisher : ind�pendance de deux variables qualitatives

Il s'agit de v�rifier que deux variables qualitatives, donn�es par une
table de contingence, sont ind�pendantes.

Je reprend le m�me exemple que plus haut (deux variablea qualitatives,
chacune avec deux modalit�s, les quatre classes correspondantes sont
affect�es des probabilit�s
10%, 20%, 60%, 10%.

         A    B   total
  A     10   20   30
  B     60   10   70
  total 70   30   100

Si les variables �taient ind�pendantes, les proportions s'obtiendraient
en multipliant les proportions marginales.

         A    B   total
  A     21    9   30
  B     79   21   70
  total 70   30   100

  A FAIRE : utiliser un test du Chi2 pour comparer un �chantillon de
  la premi�re population avec les proportions en cas d'ind�pendance.
  (on remplacera les proportions marginales th�oriques (que l'on ne
  connait pas) par les proportions marginales exp�rimentales)

  foo <- function (N) {
    x <- runif(N)
    aa <- x<.1
    ab <- !aa & x<.3
    ba <- !aa & !ab & x<.90
    bb <- !aa & !ab & !ba
    matrix( c( sum(aa),sum(ab),sum(ba),sum(bb) ), nrow=2)
  }

Pour un �chantillon de taille suffisante, on voit ais�ment
que les variables ne sont pas ind�pendantes.

  > fisher.test( foo(100) )

        Fisher's Exact Test for Count Data

  data:  foo(100)
  p-value = 2.888e-07
  alternative hypothesis: true odds ratio is not equal to 1
  95 percent confidence interval:
   0.02284534 0.23726078
  sample estimates:
  odds ratio
  0.07754446

A FAIRE : graphique

Par contre, sur un �chantillon de taille plus petite, c'est beaucoup
moins clair.

  > fisher.test( foo(10) )

        Fisher's Exact Test for Count Data

  data:  foo(10)
  p-value = 1
  alternative hypothesis: true odds ratio is not equal to 1
  95 percent confidence interval:
    0.003660373 39.142615141
  sample estimates:
  odds ratio
   0.3779644

A FAIRE : graphique

A FAIRE : le test du Chi2 ne permet-il pas de faire la m�me chose ???
Si, mais le test du Chi2 n'est qu'une approximation : la variable
qu'on �tudie ne suit qu'asymptotiquement une loi du Chi2. 

* Le zoo des test statistiques : tests non param�triques

A FAIRE : remettre un peu d'ordre dans (et compl�ter) tout cela.

+ Test U de Wilcoxon : comparaison de deux "moyennes"

Il s'agit d'un test non param�trique : on ne connait rien sur la loi
suivie par les donn�es, en particulier, on pense qu'elle n'est pas
normale (sinon, on prendrait le test du T de Student, qui est plus
puissant).

On prend les deux �chantillons, on les met ensemble et on met le tout dans l'ordre.
On regarde ensuite si les �l�ments des deux �chantillons sont � bien m�lang�s �
ou au contraire si les �l�ments d'un �chantillon sont plut�t au d�but alors 
que ceux de l'autre sont plut�t � la fin.

L'hypoth�se que l'on teste est ici � P(X1_i > X2_i) = 0.5 �.

En supposant les �chantillons d�j� tri�s, on calcule

  U1 = nombre de couples (i,j) tels que X1_i>X2_j
       + (1/2) * nombre de couples (i,j) tels que X1_i=X2_j
  U2 = nombre de couples (i,j) tels que X1_j>X2_i
       + (1/2) * nombre de couples (i,j) tels que X1_i=X2_j
  U = min(U1,U2)

Autre m�thode de calcul :

  Mettre tous les �l�ments dans l'ordre et leur assigner un rang
  R1 = somme des rangs du premier �chantillon
  R2 = somme des rangs du deuxi�me �chantillon
  U2 = n1*n2 + n1(n1+1)/2 - R1
  U1 = n1*n2 + n2(n2+1)/2 - R2
  U = min(U1, U2)

Voici l'exemple de la page de manuel (ici, on a des raisons de penser que
x>y).

  help.search("wilcoxon")
  ?wilcox.test
  > x <- c(1.83,  0.50,  1.62,  2.48, 1.68, 1.88, 1.55, 3.06, 1.30)
  > y <- c(0.878, 0.647, 0.598, 2.05, 1.06, 1.29, 1.06, 3.14, 1.29)
  > wilcox.test(x, y, paired = TRUE, alternative = "greater", conf.level=.95, conf.int=T)

        Wilcoxon signed rank test

  data:  x and y
  V = 40, p-value = 0.01953
  alternative hypothesis: true mu is greater than 0
  95 percent confidence interval:
   0.175   Inf
  sample estimates:
  (pseudo)median
          0.46

V�rifions sur un exemple que le test reste valable pour des
distributions non normales.

  N <- 1000
  n <- 4
  v <- vector()
  w <- vector()
  for (i in 1:N) {
    x <- runif(n, min=-10, max=-9) + runif(n, min=9, max=10)
    v <- append(v, wilcox.test(x)$p.value)
    w <- append(w, t.test(x)$p.value)
  }
  sum(v>.05)/N
  sum(w>.05)/N

On obtient 1 et 0.93 : on commet moins d'erreurs avec le test U de
Wilcoxon, mais sa puissance est moindre, i.e., on laisse passer plein
d'occasions de rejeter l'hypoth�se nulle :

  # Probabilit� de rejet d'une hypoth�se fausse (=puissance)
  N <- 1000
  n <- 5
  v <- vector()
  w <- vector()
  for (i in 1:N) {
    x <- runif(n, min=0, max=1)
    v <- append(v, wilcox.test(x)$p.value)
    w <- append(w, t.test(x)$p.value)
  }
  sum(v<.05)/N
  sum(w<.05)/N

On obtient 0 (la puissance du test est alors nulle : il ne rejette
jamais l'hypoth�se nulle -- si on a un �chantillon tr�s petit et si on
ne sait rien sur la loi, on ne peut pas dire grand-chose) contre 0.84

Prenons une loi plus �loign�e de la normale.

  # Probabilit� de rejet d'une hypoth�se fausse (=puissance)
  N <- 1000
  n <- 5
  v <- vector()
  w <- vector()
  for (i in 1:N) {
    x <- runif(n, min=-10, max=-9) + runif(n, min=9, max=10)
    v <- append(v, wilcox.test(x)$p.value)
    w <- append(w, t.test(x)$p.value)
  }
  sum(v<.05)/N
  sum(w<.05)/N

On obtient 0 et 0.05. Pour n=10, on obtiendrait 0.05 dans les deux cas.

Regardons maintenant l'intervalle de confiance.

  N <- 1000
  n <- 3
  v <- vector()
  w <- vector()
  for (i in 1:N) {
    x <- runif(n, min=-10, max=-9) + runif(n, min=9, max=10)
    r <- wilcox.test(x, conf.int=T)$conf.int
    v <- append(v, r[1]<0 & r[2]>0)
    r <- t.test(x)$conf.int
    w <- append(w, r[1]<0 & r[2]>0)
  }
  sum(v)/N
  sum(w)/N

On obtient 0.75 contre 0.93.

  A FAIRE 

  Je ne comprends pas : comme le test U est non-param�trique, il
  devrait donner des intervalles de confiance plus grands, et donc se
  tromper moins souvent.

  L'intervalle de confiance du test de Wilcoxon est trois fois plus
  petit que celui du test T de Student.

  On retiendra de cette comparaison des tests de Wilcoxon et de
  Student que le test de Student est robuste (i.e., quand ses
  conditions d'application ne sont pas v�rifi�es, il marche quand m�me
  assez bien).

+ Test de Wilcoxon (A FAIRE : fusionner avec le paragraphe pr�c�dent)A

Il s'agit de v�rifier que l'�chantillon provient d'une population �
sym�trique �, i.e., il s'agit d'un test sur la m�dianne (et plus
particuli�rement sur la pseudo-m�diane, i.e., la m�diane de (U+V)/2 o�
U et V sont des vaiid suivant la m�me lois que l'�chantillon).

  ?wilcox.test

A FAIRE : regarder si les exemples suivants sont pertinents.

L'exemple suivant regarde si la variable est sym�trique
autour de sa moyenne.

  > x <- rnorm(100)^2
  > x <- x - mean(x)
  > wilcox.test(x)

        Wilcoxon signed rank test with continuity correction

  data:  x
  V = 1723, p-value = 0.005855
  alternative hypothesis: true mu is not equal to 0

L'exemple suivant regarde si la variable est sym�trique
autour de sa m�diane.

  > x <- x - median(x)
  > wilcox.test(x)

        Wilcoxon signed rank test with continuity correction

  data:  x
  V = 3360.5, p-value = 0.004092
  alternative hypothesis: true mu is not equal to 0

Si on a plus de deux �chantillons, on peut utiliser le test de 
Kruskal-Wallis.

  ?kruskal.test

+ Test de Kolmogorov-Smirnov (comparaison de distributions)

Il s'agit de voir si deux variables (quantitatives) 
suivent la m�me loi.

  > ks.test( rnorm(100), 1+rnorm(100) )

        Two-sample Kolmogorov-Smirnov test

  data:  rnorm(100) and 1 + rnorm(100)
  D = 0.43, p-value = 1.866e-08
  alternative hypothesis: two.sided

  > ks.test( rnorm(100), rnorm(100) )

        Two-sample Kolmogorov-Smirnov test

  data:  rnorm(100) and rnorm(100)
  D = 0.11, p-value = 0.5806
  alternative hypothesis: two.sided

  > ks.test( rnorm(100), 2*rnorm(100) )

        Two-sample Kolmogorov-Smirnov test

  data:  rnorm(100) and 2 * rnorm(100)
  D = 0.19, p-value = 0.0541
  alternative hypothesis: two.sided

* Comment se ramener � des distributions normales ?

Il n'est pas toujours possible ou (raisonnable) de se ramener � une
distribution normale : il arrive par exemple que la distribution
pr�sente plusieurs pics...

+ Nettoyage des donn�es

Pour analyser les donn�es, il faut pr�alablement les v�rifier
(s'assurer qu'il n'y a pas d'erreurs, ni de donn�es incoh�rentes : a
priori ces erreurs sont rares, donc on les voit facilement, par
exemple avec des boutes � moustaches ou d'autres repr�sentations
graphiques) et �ventuellement les remplacer par des donn�es plus
sym�triques.

En effet, beaucoup de traitements statistiques (par exemple : le calcul de
la moyenne) sont tr�s sensibles � des donn�es (rares) qui s'�loignent
beaucoup de la � norme �, � des situations non sym�triques et �
des distributions avec des � queues �paisses � (beaucoup de donn�es qui
s'�loignent de la norme).

+ Comment v�rifier qu'une distribution est sym�trique ?

� l'aide d'une boite � moustaches ou � l'aide d'un test U de Wilcoxon, comme nous
l'avons d�j� vu plus haut.

On peut aussi le faire graphiquement. Si les donn�es sont exactement
sym�triques autour de la m�diane, � chaque point au dessus de la
moyenne correspond un point au dessous, � la m�me distance. 

  symetry.plot <- function (x,...) {
    x <- x[ !is.na(x) ]
    x <- sort(x)
    x <- abs(x - median(x))
    n <- length(x)
    nn <- ceiling(n/2)
    plot( x[n:(n-nn+1)] ~ x[1:nn] ,
          xlab='Distance below median',
          ylab='Distance above median', 
          ...)    
  }
  symetry.plot(rnorm(100))
  abline(0,1)  

= R_203.png

  symetry.plot(exp(rnorm(100)))
  abline(0,1)  

= R_204.png

Plus l'�chantillon contient de points, plus le graphe est proche de la
droite. On voit ici qu'avec une centaine de points, on peut quand m�me
en �tre assez loin.

  symetry.plot( rnorm(100) )
  abline(0,1)  
  for (i in 1:100) {
    x <- sort(rnorm(100))
    x <- abs(x - median(x))
    n <- length(x)
    nn <- ceiling(n/2)
    points( x[n:(n-nn+1)] ~ x[1:nn] )
  }

= R_205.png

  symetry.plot( exp(rnorm(100)) )
  abline(0,1)  
  for (i in 1:100) {
    x <- sort(exp(rnorm(100)))
    x <- abs(x - median(x))
    n <- length(x)
    nn <- ceiling(n/2)
    points( x[n:(n-nn+1)] ~ x[1:nn] )
  }

= R_206.png

Voici l'intervalle de confiance (exp�rimental) � 95% autour de cette
droite, pour un �chantillon de taille 100 d'une distribution normale
standard.

  A FAIRE : des "intervalles de confiance" autour de la droite...

+ Comment v�rifier qu'une distribution est normale ?

Une premi�re solution consiste � faire un test de Shapiro.

  ?shapiro.test

  > shapiro.test(rnorm(100))

        Shapiro-Wilk normality test

  data:  rnorm(100)
  W = 0.9809, p-value = 0.1564

  > shapiro.test(rnorm(100)^2)

        Shapiro-Wilk normality test

  data:  rnorm(100)^2
  W = 0.6976, p-value = 4.74e-13

Le test de Kolmogorov--Smirnov est plus g�n�ral : il marche avec des
distributions autres que la distribution normale , et permet aussi de
savoir si deux �chantillons sont distribu�s suivant la m�me loi.

  ?ks.test

Une seconde m�thode consiste � utiliser un QQplot : on calcule les
quantiles de la distribution, puis les quantiles d'une distribution
normale, et on trace l'un en fonction de l'autre.

  ?qqnorm

  y <- rnorm(100)
  qqnorm(y)
  qqline(y)

= R_076.png

  y <- rnorm(100)^2
  qqnorm(y)
  qqline(y)

= R_077.png

A FAIRE : la droite s'appelle la droite de Henri.

A FAIRE : v�rifier qu'elle s'appelle bien ainsi.

Voici d'autres exemples de QQplot.

  y <- exp(rnorm(100))
  qqnorm(y, main='(1) Loi log-normale'); qqline(y, col='red')

= R_139.png

  y <- rnorm(100)^2
  qqnorm(y, ylim=c(-2,2), main="(2) Carr� d'une va suivant une loi normale")
  qqline(y, col='red')

= R_140.png

  y <- -exp(rnorm(100))
  qqnorm(y, ylim=c(-2,2), main="(3) Oppos� d'une v.a. suivant une loi log-normale")
  qqline(y, col='red')

= R_141.png

  y <- runif(100, min=-1, max=1)
  qqnorm(y, ylim=c(-2,2), main='(4) Loi uniforme'); qqline(y, col='red')

= R_142.png

  y <- rnorm(10000)^3
  qqnorm(y, ylim=c(-2,2), main="(5) Cube d'une v.a. suivant une loi normale")
  qqline(y, col='red')

= R_143.png

On peut lire ces graphiques de la mani�re suivante.

a. Si la loi est plus concentr�e qu'une loi normale � gauche de la
moyenne, la partie gauche du graphe se trouve au dessus de la droite
(exemples 1, 2 et 4 ci-dessus).

b. Si la loi est moins concentr�e qu'une loi normale � gauche de la
moyenne, la partie gauche du graphe se trouve en dessous de la droite
(exemple 3 ci-dessus).

c. Si la loi est plus concentr�e qu'une loi normale � droite de la
moyenne, la partie droite du graphe se trouve en dessous de la droite
(exemples 3 et 4 ci-dessus).

d. Si la loi est moins concentr�e qu'une loi normale � droite de la
moyenne, la partie droite du graphe se trouve au dessus de la droite
(exemples 1 et 2 ci-dessus).

L'exemple 5 ci-dessus s'interpr�te donc ainsi : la distribution est
sym�trique ; � gauche de 0, pr�s de 0, elle est plus concentr�e qu'une
loi normale ; � gauche de 0, loin de 0, elle est moins concentr�e
qu'une loi normale ; � droite de 0, c'est pareil.

  x <- seq(from=0, to=2, length=100)
  y <- exp(x)-1
  plot( y~x, type='l', xlim=c(-2,2), ylim=c(-2,2), col='red')
  lines( x~y, type='l', col='green')
  x <- -x
  y <- -y
  lines( y~x, type='l', col='blue', )
  lines( x~y, type='l', col='cyan')
  abline(0,1)
  legend( -2, 2,
          c( "loi moins concentr�e que la normale � droite",  
             "loi plus concentr�e que la normale � droite",
             "loi moins concentr�e que la normale � gauche",
             "loi plus concentr�e que la normale � gauche"
           ),
          lwd=1,
          col=c("red", "green", "blue", "cyan")
        )

= R_145.png

e. Si la distribution est << plus d�centr�e vers la gauche qu'avec une
loi normale >> (plus pr�cis�ment, si la m�diane est inf�rieure � la
moyenne des premier et troisi�me quartiles) , alors la courbe passe en
dessous de la droite au centre du graphique (exemples 1 et 2
ci-dessus).

f. Si << plus d�centr�e vers la droite qu'avec une loi normale >>
(plus pr�cis�ment, si la m�diane est sup�rieure � la moyenne des
premier et troisi�me quartiles) , alors la courbe passe au dessus de
la droite au centre du graphique (exemple 3 ci-dessus).

g. Si la distribution est sym�trique (plus pr�cis�ment : si la m�diane
est au milieu des premier et trois�me quartiles), alors la courbe
coupe la droite au centre du dessin (exemples 4 et 5 ci-dessus).

  op <- par()
  layout( matrix( c(2,0,1,1), 2, 2, byrow=T ),
          c(1,1), c(1,3),
        )
  # Le graphique
  n <- 100
  y <- rnorm(n)
  x <- qnorm(ppoints(n))[order(order(y))]
  par(mar=c(5.1,4.1,0,2.1))
  plot( y~x, col="blue" )
  y1 <- scale( rnorm(n)^2 )
  x <- qnorm(ppoints(n))[order(order(y1))]
  lines(y1~x, type="p", col="red")
  y2 <- scale( -rnorm(n)^2 )
  x <- qnorm(ppoints(n))[order(order(y2))]
  lines(y2~x, type="p", col="green")
  abline(0,1)

  # La l�gende
  # Quelqu'un sait-il comment superposer des graphiques ?
  # Je parviens uniquement � les juxtaposer...
  # (normalement, c'est le param�tre graphique "fig", mais �a ne marche pas...)
  par(bty='n', ann=F)
  g <- seq(0,1, length=10)
  e <- g^2
  f <- sqrt(g)
  h <- c( rep(1,length(e)), rep(2,length(f)), rep(3,length(g)) )
  par(mar=c(0,4.1,0,0))
  boxplot( c(e,f,g) ~ h, horizontal=T, 
           border=c("red", "green", "blue"),
           xaxt='n',
           yaxt='n', 
           )
  par(op)

A FAIRE : centrer la l�gende

= R_146.png

A FAIRE : d'autres exemples.
(ou changer le titres des premiers exemples)

  Heavy tails, high and low outliers
  Light tails, no outliers
  Positive skew, high outliers
  Negative skew, low outliers
  Granularity
  Two peaks, central gap.

On peut r�aliser un QQplot � la main, en reprenant sa d�finition
donn�e plus haut.

  y <- rnorm(100)^2
  y <- scale(x)
  y <- sort(x)
  x <- qnorm( seq(0,1,length=length(y)) )
  plot(y~x)
  abline(0,1)

Regardons comment la fonction qqnorm est programm�e.

  > qqnorm
  function (y, ...)
  UseMethod("qqnorm")

  > help.search("qqnorm")
  Help files with alias or title matching `qqnorm',
  type `help(FOO, package = PKG)' to inspect entry `FOO(PKG) TITLE':
  qqnorm(base)            Quantile-Quantile Plots
  qqnorm.gls(nlme)        Normal Plot of Residuals from a gls Object
  qqnorm.lme(nlme)        Normal Plot of Residuals or Random Effects
                          from an lme Object

  > qqnorm.default
  function (y, ylim, main = "Normal Q-Q Plot", xlab = "Theoretical Quantiles",
      ylab = "Sample Quantiles", plot.it = TRUE, ...)
  {
    y <- y[!is.na(y)]
    if (0 == (n <- length(y)))
      stop("y is empty")
    if (missing(ylim))
      ylim <- range(y)
    x <- qnorm(ppoints(n))[order(order(y))]
    if (plot.it)
      plot(x, y, main = main, xlab = xlab, ylab = ylab, ylim = ylim,
            ...)
    invisible(list(x = x, y = y))
  }

On peut faire la m�me chose pour comparer avec d'autres distributions.

  qq <- function (y, ylim, quantiles=qnorm,
      main = "Q-Q Plot", xlab = "Theoretical Quantiles",
      ylab = "Sample Quantiles", plot.it = TRUE, ...)
  {
    y <- y[!is.na(y)]
    if (0 == (n <- length(y)))
      stop("y is empty")
    if (missing(ylim))
      ylim <- range(y)
    x <- quantiles(ppoints(n))[order(order(y))]
    if (plot.it)
      plot(x, y, main = main, xlab = xlab, ylab = ylab, ylim = ylim,
            ...)
    # From qqline
    y <- quantile(y, c(0.25, 0.75))
    x <- quantiles(c(0.25, 0.75))
    slope <- diff(y)/diff(x)
    int <- y[1] - slope * x[1]
    abline(int, slope, ...)
    invisible(list(x = x, y = y))
  }

  y <- runif(100)
  qq(y, quantiles=qunif)

= R_138.png

(Les diff�rentes interpr�tations du qqplot restent valables, mais les
points e, f et g ne renseignent plus sur la sym�trie de la
distribution, mais comparent cette sym�trie avec celle de la loi de
r�f�rence, qui n'est pas n�cessairement sym�trique.)

A FAIRE : � l'aide de simulations (ou de calculs th�oriques), ajouter
des intervalles de confiance sur le QQplot.

+ Transformations : racine carr�e, logarithme

Certaines donn�es ne sont pas normales, mais on peut souvent
s'y ramener par des transformations, comme prendre la racine carr�e
ou le logarithme.

On prend la racine carr�e si la distribution ressemble �
une distribution normale un peu des�quilibr�e

= R_014.png

par exemple 

= R_011.png
= R_012.png

On applique le logarithme quand la distribution ressemble � une distribution
lognormale

= R_013.png

par exemple 

= R_009.png
= R_010.png

A FAIRE : choisir une transformation en s'aidant du test de Shapiro.

A FAIRE

  ?boxcox

  (Donne la meilleure valeur de lambda pour que y = a x^lambda + b ???)

  data(trees)
  boxcox(Volume ~ log(Height) + log(Girth), data = trees,
         lambda = seq(-0.25, 0.25, length = 10))
  data(quine)
  boxcox(Days+1 ~ Eth*Sex*Age*Lrn, data = quine,
         lambda = seq(-0.05, 0.45, len = 20))

  Transforming non-normal data into normal data. The box.cox.powers
  function in the car package does unconditional univariate and
  multivariate Box-Cox transformations.
  (Cette biblioth�que n'est pas install�e...)

* Que faire si les donn�es ne sont vraiment pas normales ?

A FAIRE : exemple (des distributions � 2 pics, par exemple faithful, 
les premi�res notes de mes �l�ves, ou une somme de deux distributions normales).

  x <- c( 2+rnorm(100), 6+rnorm(100) )
  hist(x)

+ M�thodes non param�triques

Nous avons vu certains tests non param�triques : rappelons-les.

Pour la moyenne, on peut remplacer le test T de Student par le test U
de Wincoxon.  Dans le cas de plus de deux �chantillons, on peut
remplacer l'analyse de la variance par le test de Kruskal--Wallis.

Pour la variance, on peut remplacer le test F de Fisher ou celui de
Bartlett par les tests d'Ansari, Mood ou Fligner.

+ Comparaison de moyennes � l'aide de permutations

On se donne deux �chantillons de taille n, et on veut savoir si
leur moyennes sont significativement diff�rentes.
Pour cela, on commence par calculer les moyennes et leur diff�rences.
Ensuite on recommence, mais en prenant deux �chantillons 
de taille n au hasard dans nos 2n valeurs. Et on continue jusqu'� avoir une
bonne estimation de la distribution de ces diff�rences. Ensuite, on
regarde o� notre diff�rence initiale se trouve dans cette distribution : 
on rejette l'hypoth�se d'�galit� si elle semble trop marginale.

Condition d'application : �quivariance (i.e., les deux �chantillons ont
la m�me variance, ce que l'on v�rifie � l'aide d'un test de F).

A FAIRE : comment appelle-t-on cela en anglais ? resampling ???

A FAIRE : un exemple pratique
(reprendre les donn�es du T-test ?)

+ Jackknife

Les estimateurs que l'on obtient � l'aide de la m�thode du maximum de
vraissemblance (MLE) sont souvent biais�s. L'algorithme Jackknife, que
voici, permet de transformer un tel estimateur U en un estimateur moins
biais�.

Diviser l'�chantillon en N �chantillons de m�me taille (par exemple,
de taille 1) et calculer l'estimation Ui du param�tre. On pose alors 

  J = N U - (N-1)/N * (U1 + U2 + ... + Un)

Par exemple, si on lui donne la formule de la variance de la
population (avec n, au d�nominateur : c'est un estimateur biais�)
comme estimateur de la variance, il nous ressort la variance de
l'�chantillon (avec n-1 au d�nominateur : il n'est plus biais�).

A FAIRE : � v�rifier

  A FAIRE
  library(boot)
  ?jack.after.boot

+ M�thode de Mont�-Carlo et bootstrap

Quand on ne connait pas du tout la loi d'une population, et si on a un
�chantillon, on peut utiliser cet �chantillon pour faire des
simulations concernant cette loi, tout simplement en faisant des
tirages au hasard dans cet �chantillon. C'est ce qu'on appelle la
m�thode de Monte-Carlo.

On peut l'utiliser pour comparer des estimateurs d'un param�tre de la
loi, et ainsi choisir celui qui a la variance la plus faible.

  A FAIRE

  library(boot)
  ?boot


A FAIRE : 

  utiliser le bootstrap pour :
  estimer la variance d'un estimateur
  calculer un intervalle de confiance
  faire des tests et calculer des p-valeurs

+ Courbe d'influence

On dispose d'un estimateur U d'un param�tre u d'une loi F(u). Le
probl�me, c'est qu'on ne connait pas exactement la loi F. Pour juger
de la robustesse de l'estimateur, on regarde comment il varie si on
modifie F en un point. Plus pr�cis�ment, on calcule 

                  U( (1-h) F + h 1x ) - U(F)
  w(x) =   lim   ----------------------------
         h -> 0              h

o� 1x est la mesure de Dirac en x.

  A FAIRE : exemple de la moyenne

  A FAIRE : exemple de la variance

  A FAIRE : exemple de la corr�lation (en dimension 2)
  ?contour
  ?persp

* Repr�sentation graphique de donn�es bivari�es (ou multivari�es)

+ Donn�es bivari�es quantitatives et r�gression

On a cette fois-ci deux s�ries de nombres, en parall�le : on peut les repr�senter
dans un tableau � deux colonnes, chaque ligne du tableau (chaque couple de valeurs)
correspond � un individu.

On peut repr�senter ces donn�es dans le plan (nuage de points, � scatter plot �
en anglais) :

  plot(y ~ x)

= R_015.png

A FAIRE : 
ajouter un boxplot dans les marges, sans les outliers
ainsi qu'un histogramme avec des rugs.

Voici un exemple plus concret.

  > data(cars)
  > cars
     speed dist
  1      4    2
  2      4   10
  3      7    4
  ...
  47    24   92
  48    24   93
  49    24  120
  50    25   85
  > plot(cars, xlab = "Speed (mph)", ylab = "Stopping distance (ft)", las = 1)
  > title(main = "cars data")

= R_079.png

On peut tenter d'approcher ces donn�es par une droite

Voici tout d'abord l'approximation au sens des moindres carr�s (ou �
r�gression lin�aire � : voir plus loin pour de plus amples d�tails) :
on cherche � minimiser la somme des carr�s des distances (mesur�es
verticalement) entre la droite et les points. 

  plot(y~x)
  abline(lm(y~x))

= R_016.png

  plot(cars)
  abline(lm(cars$dist ~ cars$speed))

�a n'est pas sym�trique : si on intervertit les variables, on obtient
quelque chose de diff�rent (mais les deux droites passent par le
centre de gravit� du nuage).

  plot(cars)
  r <- lm(cars$dist ~ cars$speed)
  abline(r, col='red')
  r <- lm(cars$speed ~ cars$dist)
  a <- r$coefficients[1] # Intercept
  b <- r$coefficients[2] # slope
  abline(-a/b , 1/b, col="blue")

= R_080.png

Dans un cas, on cherche � minimiser la somme des carr�s des distances
entre la droite et les points, mesur�es verticalement, dans l'autre,
on mesure ces distances horizontalement. Il s'agit de de mani�res � raisonnables �
mais diff�rentes de mesurer la distance entre un nuage de points et une droite.
C'est pourqhoi on obtient des r�sultats diff�rents.

  plot(cars)
  r <- lm(cars$dist ~ cars$speed)
  abline(r, col='red')
  segments(cars$speed, cars$dist, cars$speed, r$fitted.values,col="red")

= R_084.png

  plot(cars)
  r <- lm(cars$speed ~ cars$dist)
  a <- r$coefficients[1] # Intercept
  b <- r$coefficients[2] # slope
  abline(-a/b , 1/b, col="blue")
  segments(cars$speed, cars$dist, r$fitted.values, cars$dist, col="blue")

= R_085.png

La fonction lowess permet d'avoir une courbe non n�cessairement rectiligne.

  plot(cars, xlab = "Speed (mph)", ylab = "Stopping distance (ft)",
       las = 1)
  lines(lowess(cars$speed, cars$dist, f = 2/3, iter = 3), col = "red")
  title(main = "cars data")

= R_081.png

Dans ce cas pr�cis, on s'attend plut�t � ce que la distance d�pende
lin�airement du carr� de la vitesse (ou que ce soit un polyn�me de
degr� 2).

  y <- cars$dist
  x <- cars$speed
  x2 <- x^2
  # Affine
  r <- lm( y ~ x2 )
  plot( y~x )
  yp <- predict(r)
  o = order(x)
  lines( yp[o] ~ x[o], col="red" )
  # Lin�aire
  rr <- lm( y ~ -1 + x2 )
  yp <- predict(rr)
  lines( yp[o] ~ x[o], col="green" )
  # Polyn�me de degr� 2
  rr <- lm( y ~ poly(x,2) )
  yp <- predict(rr)
  lines( yp[o] ~ x[o], col="blue" )

= R_147.png

Il y a une autre mani�re raisonnable de mesurer la distance entre un
nuage de points et une droite : la somme des carr�s des distances
entre les points et la droite, mesur�es orthogonalement � la
droite. C'est ce qu'on appelle l'ACP (Analyse en Composantes
Principales), et cette fois-ci, c'est sym�trique.  (nous y reviendrons
plus en d�tail un peu plus loin).

  plot(cars)
  r <- lm(cars$dist ~ cars$speed)
  abline(r, col='red')
  r <- lm(cars$speed ~ cars$dist)
  a <- r$coefficients[1] # Intercept
  b <- r$coefficients[2] # slope
  abline(-a/b , 1/b, col="blue")
  r <- princomp(cars)
  b <- r$loadings[2,1] / r$loadings[1,1]
  a <- r$center[2] - b * r$center[1]
  abline(a,b)

= R_082.png

Voici une situation dans laquelle les trois droites devraient �tre
distinctes.

  x <- rnorm(100)
  y <- x + rnorm(100)
  plot(y~x)
  r <- lm(y~x)
  abline(r, col='red')
  r <- lm(x ~ y)
  a <- r$coefficients[1] # Intercept
  b <- r$coefficients[2] # slope
  abline(-a/b , 1/b, col="blue")
  r <- princomp(cbind(x,y))
  b <- r$loadings[2,1] / r$loadings[1,1]
  a <- r$center[2] - b * r$center[1]
  abline(a,b)

= R_083.png

  x <- rnorm(100)
  y <- x + rnorm(100)
  plot(y~x, xlim=c(-4,4), ylim=c(-4,4) )
  r <- princomp(cbind(x,y))
  b <- r$loadings[2,1] / r$loadings[1,1]
  a <- r$center[2] - b * r$center[1]
  abline(a,b)
  # Matrice de changement de base
  u <- r$loadings
  # Projection sur le premier axe
  p <- matrix( c(1,0,0,0), nrow=2 )
  X <- rbind(x,y)
  X <- r$center + solve(u, p %*% u %*% (X - r$center))
  segments( x, y, X[1,], X[2,] )

= R_086.png

Le coefficient de corr�lation (sans unit�, entre -1 et 1),
permet de voir s'il est facile d'approcher
les donn�es par une droite.
Dans les exemples suivants, le coefficient de corr�lation passe
progressivement de 1 � -1.

= R_017.png
= R_018.png
= R_019.png
= R_031.png
= R_020.png
= R_021.png

Dans certaines situations, il y a clairement un lien entre les deux variables,
mais il n'est pas affine : on peut alors regarder s'il n'y a pas un lien lin�aire,
non pas entre les donn�es, mais entre leur rangs (c'est la corr�lation de Spearman).
(Il faut quand m�me que le lien entre les deux variables soit monotone.)

  > b = (0:100)/100
  > c = b^2
  > cor(b,c)
  [1] 0.9676503

= R_022.png

  > cor(rank(b),rank(c))
  [1] 1

+ Donn�es multivari�es quantitatives

La commande pairs produit un tableau de graphiques comme les pr�c�dents.

  A FAIRE : prendre un exemple de donn�es (autres que celui du manuel, iris).

  pairs(...)

  A FAIRE : graphique

On peut configurer le graphique, en mettant d'autres choses dans les
cases.

  panel.hist <- function(x, ...) {
    usr <- par("usr"); on.exit(par(usr))
    par(usr = c(usr[1:2], 0, 1.5) )
    h <- hist(x, plot = FALSE)
    breaks <- h$breaks; nB <- length(breaks)
    y <- h$counts; y <- y/max(y)
    rect(breaks[-nB], 0, breaks[-1], y, ...)
  }
  pairs(donn�es,
        diag.panel=panel.hist,
        upper.panel=panel.smooth,
        lower.panel=panel.smooth);

  A FAIRE : graphique

A FAIRE : ajouter les coefficients de corr�lation (et aussi les R^2
sur la diagonale).

+ Donn�es bivari�es qualitative/quantitative

L'une des variable est qualitative, l'autre quantitative.
On peut faire une boite � moustaches par valeur de la variable qualitative
(ici, on compare l'efficacit� de diff�rents insecticides).

  data(InsectSprays)
  boxplot(count ~ spray, data = InsectSprays,
          xlab = "Type of spray", ylab = "Insect count",
          main = "InsectSprays data", varwidth = TRUE, col = "lightgray")

= R_045.png

  stripchart(InsectSprays$count ~ InsectSprays$spray, method='jitter')

= R_046.png

On aimerait faire un � stripchart � avec diff�rentes couleurs 
pour distinguer les diff�rences, un peu comme on sait faire 
en dimensions sup�rieures.

  data(iris)
  plot(iris[1:4], pch=21, bg=c("red", "green", "blue")[codes(iris$Species)])

= R_047.png

Le probl�me, c'est que la commande stripchart n'accepte
pas cet argument � bg �. On fait donc la m�me chose � la main.
(On ne voit rien...)

  a <- InsectSprays$count
  b <- rnorm(length(a))
  plot(b~a, pch=21, 
       bg=c("red", "green", "blue", "cyan", "yellow", "black")
            [codes(InsectSprays$spray)])

= R_048.png

  a <- as.vector(t(iris[1]))
  b <- rnorm(length(a))
  plot(b~a, pch=21, bg=c("red", "green", "blue")[codes(iris$Species)])

= R_049.png

On peut calculer un � rapport de corr�lation � : si X est la variable
qualitative et Y la variable quantitative, on peut �crire la variance
de Y comme somme d'une � variance expliqu�e par � et d'une � variance
r�siduelle � ; le rapport de corr�lation est la racine (parfois on
prend la racine, parfois non...)  du quotient de la variance expliqu�e
et de la variance de Y.

  > aov( count ~ spray, data = InsectSprays )
  Call:
     aov(formula = r)

  Terms:
                     spray Residuals
  Sum of Squares  2668.833  1015.167
  Deg. of Freedom        5        66

  Residual standard error: 3.921902
  Estimated effects may be unbalanced

Ici, la variance expliqu�e est 2669, la variance r�siduelle est 1015.
Le rapport de corr�lation est donc 

  > s <- summary(aov( count ~ spray, data = InsectSprays ))[[1]][,2]
  > s[2]/(s[1]+s[2])
  [1] 0.275561


ou, si on prend la racine carr�e,

  > sqrt(s[2]/(s[1]+s[2])
  [1] 0.524939

On r�sume cela en disant que le type d'insecticide explique 70% de la
variance du nombre d'insectes.

  A FAIRE : v�rifier que c'est bien �a.

+ Donn�es bivari�es qualitatives
 
On peut repr�senter ces donn�es sous forme d'un tableau,
les lignes repr�sentant les diff�rentes valeurs de la premi�re variable, 
les colonnes celles de la seconde, les cases du tableau contiennent les effectifs.

On peut remplacer les lignes par les � profils-lignes �, i.e., des fr�quences 
marginales (on peut aussi faire �a avec les colonnes). On peut ensuite repr�senter
chaque ligne par une barre.

  > data(HairEyeColor)
  > a <- as.table( apply(HairEyeColor, c(1,2), sum) )
  > a
         Eye
  Hair    Brown Blue Hazel Green
    Black    68   20    15     5
    Brown   119   84    54    29
    Red      26   17    14    14
    Blond     7   94    10    16
  > barplot(a, legend.text = attr(a, "dimnames")$Hair)

= R_024.png

  > barplot(a, beside=TRUE, legend.text = attr(a, "dimnames")$Hair)

= R_026.png

  > barplot(t(a), legend.text = attr(a, "dimnames")$Eye))

= R_025.png

  > barplot(t(a), beside=TRUE, legend.text = attr(a, "dimnames")$Eye)

= R_027.png

  > plot(a)

= R_028.png

  > plot(t(a))

= R_050.png

On peut repr�senter chaque ligne du tableau par une courbe (l'axe des
abscisses est alors utilis� pour l'autre variable qualitative et l'axe
vertical repr�sente les effectifs).

  a <-  apply(HairEyeColor, c(1,2), sum)
  n <- dim(a)[1]
  plot( a[1,], ylim=c(0,max(a)), type='l' )
  for (i in 1:n) {
    lines( a[i,], col=i+1 )
  }
  legend(1+(n-1)/2, max(a), 
         legend=names(a[1,]),
         lty=1, 
         col=1+(1:n), 
        )
  A FAIRE : se d�barasser des nombres sur l'axe des abscisses
  A FAIRE : le graphe dans l'autre sens.

  A FAIRE : effacer le paragraphe pr�c�dent...

+ Donn�es multivari�es qualitatives

  data(HairEyeColor)
  a <- apply(HairEyeColor, c(1,2) , sum)
  qualplot <- function (a) {
    matplot( row(a), a, type='l', axes=F,
             col = 1:dim(a)[2]+1,
             lty = 1:dim(a)[2],
             xlab=names(dimnames(a))[1], ylab=names(dimnames(a))[2] )
    axis(1, 1:dim(a)[1], row.names(a))
    axis(2)
    legend(1, max(a), row.names(t(a)),
           lwd=1, col=1:dim(a)[2]+1, lty=1:dim(a)[2])
  }
  qualplots <- function (a) {
    op = par(ask=T)
    qualplot(a)
    qualplot(t(a))
    par(op)
  }
  qualplots(a)

= R_154.png
= R_155.png

On peut pr�alablement modifier le tableau pour que les effectifs
marginaux soient �gaux. (A FAIRE : �a porte un nom ???)

  qualplotfreq <- function (a) {
    a <- t( t(a) / apply(a,2,sum) )
    qualplot(a)
  }
  qualplotsfreq <- function (a) {
    op = par(ask=T)
    qualplotfreq(a)
    qualplotfreq(t(a))
    par(op)
  }
  qualplotsfreq(a)

= R_156.png
= R_157.png

A FAIRE : un autre exemple, avec moins de valeurs, pour montrer comment
lire ce genre de graphique.

Si les variables n'ont que deux valeurs, on peut aussi utiliser la commande 
fourfoldplot.

  ?fourfoldplot

  A FAIRE

On peut voir si les deux variables sont li�es ou non 
� l'aide du coefficient de Tschuprow (s'il est proche de 0, elles ne sont 
pas li�es, s'il est proche de 1, elles le sont).

  A FAIRE : avec R ?????

+ Deux variables quantitatives, une variable qualitative

On repr�sente les diff�rentes valeurs de la variable qualitative par
des symboles ou des couleurs diff�rentes.

  A FAIRE

+ Donn�es multivari�es : toutes les variables sauf une ou deux sont qualitatives.

Quand on a juste une variable qualitative et une variable
quantitative, on peut faire des graphes � moustaches.  Avec deux
variables qualitatives et une variable quantitative, ce n'est plus
lisible, car les graphes � moustaches se superposent mal.

  a <- rnorm(10)
  b <- 1+ rnorm(10)
  c <- 1+ rnorm(10)
  d <- rnorm(10)
  x <- c(a,b,c,d)
  y <- factor(c( rep("A",20), rep("B",20)))
  z <- factor(c( rep("U",10), rep("V",20), rep("U",10) ))
  op = par(mfrow=c(2,2))
  plot(x~y)
  plot(x~z)
  plot(x[z=="U"] ~ y[z=="U"], border="red", ylim=c(min(x),max(x)))
  plot(x[z=="V"] ~ y[z=="V"], border="blue", add=T)
  plot(x[y=="A"] ~ z[y=="A"], border="red", ylim=c(min(x),max(x)))
  plot(x[y=="B"] ~ z[y=="B"], border="blue", add=T)
  par(op)

= R_168.png

On peut juste les mettres c�te � c�te (si les variables n'ont que deux
valeurs, comme ici, �a reste lisible).

  l <- rep("",length(x))
  for (i in 1:length(x)){
    l[i] <- paste(y[i],z[i])
  }
  l <- factor(l)
  boxplot(x~l)

= R_171.png

Par contre, au lieu de superposer des graphes � moustaches, on peut superposer
des courbes correspondant � la moyenne des �chantillons.

  # l est une liste � deux �l�ments
  myplot1 <- function (x, l, ...) {
    t <- tapply(x,l,mean)
    l1 <- levels(l[[1]])
    l2 <- levels(l[[2]])
    matplot(t,
            type='l', lty=1, col=1:length(l2),
            axes=F, ...)
    axis(1, 1:2, l1)
    axis(2)
    lim <- par("usr")
    legend(lim[1] + .05*(lim[2]-lim[1]), lim[4],
           l2, lwd=1, lty=1, col=1:length(l2) )
  }
  op <- par(mfrow=c(1,2))
  myplot1( x, list(y,z), ylim=c(0,2) )
  myplot1( x, list(z,y), ylim=c(0,2) )
  par(op)


= R_169.png

Si le dessin n'est pas trop charg�, on peut tenter de l'enrichir en
faisant figurer, en pointill�s, les quartiles et les valeurs extr�mes
de chaque �chantillon.

  # l est une liste � deux �l�ments
  myplot3 <- function (x, l, ...) {
    l1 <- levels(l[[1]])
    l2 <- levels(l[[2]])
    t0 <- tapply(x,l,min)
    t1 <- tapply(x,l,function(x)quantile(x,.25))
    t2 <- tapply(x,l,median)
    t3 <- tapply(x,l,function(x)quantile(x,.75))
    t4 <- tapply(x,l,max)
    matplot(cbind(t0,t1,t2,t3,t4),
            type='l', 
            lty=c(rep(3,length(l2)), rep(2,length(l2)), 
                  rep(1,length(l2)), rep(2,length(l2)),
                  rep(3,length(l2)) ),
            col=1:length(l2),
            axes=F, ...)
    axis(1, 1:2, l1)
    axis(2)
    lim <- par("usr")
    legend(lim[1] + .05*(lim[2]-lim[1]), lim[4],
           l2, lwd=1, lty=1, col=1:length(l2) )
  }
  op <- par(mfrow=c(1,2))
  myplot3( x, list(y,z) )
  myplot3( x, list(z,y) )
  par(op)

= R_170.png

Voici un exemple concret.

  A FAIRE

+ Graphe en coordonn�es barycentriques (ternary plot)

On dispose de trois variables quantitatives (tr�s souvent, des
pourcentages, en chimie).

  library(MASS)
  ?Skye
  data(Skye)

  ternary <- function(X, pch = par("pch"), lcex = 1,
                      add = FALSE, ord = 1:3, ...)
  {
    X <- as.matrix(X)
    if(any(X) < 0) stop("X must be non-negative")
    s <- drop(X %*% rep(1, ncol(X)))
    if(any(s<=0)) stop("each row of X must have a positive sum")
    if(max(abs(s-1)) > 1e-6) {
      warning("row(s) of X will be rescaled")
      X <- X / s
    }
    X <- X[, ord]
    s3 <- sqrt(1/3)
    if(!add)
    {
      oldpty <- par("pty")
      on.exit(par(pty=oldpty))
      par(pty="s")
      plot(c(-s3, s3), c(0.5-s3, 0.5+s3), type="n", axes=FALSE,
           xlab="", ylab="")
      polygon(c(0, -s3, s3), c(1, 0, 0), density=0)
      lab <- NULL
      if(!is.null(dn <- dimnames(X))) lab <- dn[[2]]
      if(length(lab) < 3) lab <- as.character(1:3)
      eps <- 0.05 * lcex
      text(c(0, s3+eps*0.7, -s3-eps*0.7),
           c(1+eps, -0.1*eps, -0.1*eps), lab, cex=lcex)
    }
    points((X[,2] - X[,3])*s3, X[,1], ...)
  }

  ternary(Skye/100, ord=c(1,3,2))

= R_165.png

Ici, les lignes du tableau ont une somme �gale � 100.

  > sum( apply(Skye,1,sum) != 100 )
  [1] 0

Voici une autre mani�re de les tracer, d'apr�s
http://finzi.psych.upenn.edu/R/Rhelp01/archive/1000.html

  tri <-
  function(a, f, m, symb = 2, grid = F, ...)
  {
    ta <- paste(substitute(a))
    tf <- paste(substitute(f))
    tm <- paste(substitute(m))

    tot <- 100/(a + f +m)
    b <- f * tot
    y <- b * .878
    x <- m * tot + b/2
    par(pty = "s")
    oldcol <- par("col")
    plot(x, y, axes = F, xlab = "", ylab = "", 
         xlim = c(-10, 110), ylim= c(-10, 110), type = "n", ...)
    points(x,y,pch=symb)
    par(col = oldcol)
    trigrid(grid)
    text(-5, -5, ta)
    text(105, -5, tm)
    text(50, 93, tf)
    par(pty = "m")
    invisible()
  }

  trigrid  <-
  function(grid = F)
  {
    lines(c(0, 50, 100, 0), c(0, 87.8, 0, 0)) #draw frame
    if(!grid) {
      for(i in 1:4 * 20) {
        lines(c(i, i - 1), c(0, 2 * .878)) #side a-c (base)
        lines(c(i, i + 1), c(0, 2 * .878))
        T.j <- i/2 #side a-b (left)
        lines(c(T.j, T.j + 2), c(i * .878, i * .878))
        lines(c(T.j, T.j + 1), c(i * .878, (i - 2) * .878))
        T.j <- 100 - i/2 #side b-c (right)
        lines(c(T.j, T.j - 2), c(i * .878, i * .878))
        lines(c(T.j, T.j - 1), c(i * .878, (i - 2) * .878))
      }
    } else {
      for(i in 1:4 * 20) {
        # draw dotted grid
        lines(c(i, i/2), c(0, i * .878), lty = 4, col = 3)
        lines(c(i, (50 + i/2)), c(0, .878 * (100 - i)), lty = 4, col = 3)
        lines(c(i/2, (100 - i/2)), c(i * .878, i * .878), lty = 4, col = 3)
      }
      par(lty = 1, col = 1)
    }
  }

  # some random data in three variables
  c1<- runif(5, 10, 20)
  c2<- runif(5, 1, 5)
  c3 <- runif(5, 15, 25)
  # basic plot
  tri(c1,c2,c3)

= R_166.png

  # plot with different symbols and a grid
  tri(c1,c2,c3, symb=7, grid=T) 

= R_167.png

C'est un bon exercice d'�crire soi-m�me sa propre fonction.
Ici, je rajoute des couleurs.

  A FAIRE

+ Graphiques �toil�s (star plots)

Si on dispose de beaucoup de variables (une demi-douzaine, quantitatives)
et peu d'individus (une dizaine), on peut faire des graphiques �toil�s.

  data(mtcars)
  stars(mtcars[, 1:7], key.loc = c(14, 2),
        main = "Motor Trend Cars : stars(*, full = F)", full = FALSE)

= R_104.png

  stars(mtcars[, 1:7], key.loc = c(14, 1.5),
        main = "Motor Trend Cars : full stars()",flip.labels=FALSE)

= R_105.png

  palette(rainbow(12, s = 0.6, v = 0.75))
  stars(mtcars[, 1:7], len = 0.8, key.loc = c(12, 1.5),
        main = "Motor Trend Cars", draw.segments = TRUE)

= R_106.png

  stars(mtcars[, 1:7], locations = c(0,0), radius = FALSE,
        key.loc=c(0,0), main="Motor Trend Cars", lty = 2)

= R_107.png

* Repr�sentation graphique de donn�es multivari�es (statistique multidimensionnelle)

Il y a deux types de m�thodes en statistique multidimensionnelle : les
m�thodes factorielles, qui consistent � projeter le nuage de points
sur un sous-espace, en perdant le moins d'information possible ; les
m�thodes de classification, qui tentent de regrouper les points.

Les m�thodes factorielles regroupent trois techniques fondamentales :
l'analyse en composantes principales, l'analyse des correspondances
(variables qualitatives, repr�sent�es par un tableau de contingences)
et l'analyse des correspondances multiples.

+ Donn�es multivari�es : variables quantitatives (analyse en composantes principales)

Une premi�re mani�re de voir l'ACP, c'est comme un analogue de la m�thode
des moindres carr�s pour trouver une droite qui passe � au plus proche � 
d'un nuage de points. Mais alors que la m�thode des moindres carr�s
est asym�trique (les deux dimensions jouent des r�les compl�tement diff�rents, 
et elles ne sont donc pas interchangeables), l'ACP est sym�trique.
On commence par translater les donn�es pour que le point
moyen du nuage de points soit � l'origine. Ensuite, on essaye d'effectuer une rotation
pour que l'�cart-type des premi�res coordonn�es soit le plus grand possible : cela
revient � diagonaliser la matrice des covariances (c'est une matrice sym�trique
r�elle (elle est m�me positive), elle est donc diagonalisable dans une base orthonormale),
en commen�ant par les vecteurs propres les plus grands
Le premier axe des nouvelles coordonn�es correspond � une approximation du nuage
de point par un sous-espace de dimension un ; si on veut une approximation 
par un sous-espace de dimension k, on prend les k premiers vecteurs propres.

Cela permet de r�duire la dimension de l'espace des variables en 
gardant le sous-espace � le plus caract�ristique �.

Pour choisir la dimension de ce sous-espace, on regarde
(graphiquement) les valeurs propres, et on s'arr�te quand elles se
mettent � d�croitre rapidement (si elles d�croissent tr�s lentement,
on est mal).

Voici une seconde mani�re de voir l'ACP. On mod�lise les donn�es sous la forme 
X = Y + E, o� X repr�sente les donn�es dont on dispose (dans un espace de dimension n), 
Y est une variable al�atoire � valeur dans sous-espace de dimension k, et E
est un terme d'erreur, une variable al�atoire � valeur dans l'espace de dimension n.
Le but du jeu est de retrouver l'espace de dimension k.

On peut aussi voir l'ACP comme un jeu sur un tableau de nombres (en
fait, c'est tr�s pertinent : on attrape ainsi l'analyse des
correspondances). Ainsi, on peut faire jouer le m�me r�le aux lignes
et aux colonnes : d'un c�t�, on cherche les similitudes ou les
diff�rences entre les individus, de l'autre, les similitudes ou les
diff�rences entre les variables. (On a donc deux matrices a
diagonaliser, mais il suffit d'en diagonaliser une : elles ont les
m�mes valeurs-propres non nulles et les vecteurs propres de l'une ce
d�duisent de ceux de l'autre.) On s'arrange pour que les variables
soient centr�es norm�es.  Les points correspondant aux variables sont
alors sur une sph�re de rayon unit�. Leur projection forme le � cercle
des corr�lations �.  On peut repr�senter les points-variables au
milieu des points-individus : ces premiers sont alors les projections
sur le plan des axes de coordonn�es.

Apr�s avoir effectu� l'ACP, on peut ajouter des individus sur le
dessin (groupe t�moin, ou individus fictifs � repr�sentatifs � de
certaines classes d'individus). Dualement, on peut aussi ajouter des
variables (g�n�ralement � des fins explicatives). Si ces variables
sont qualitatives (on dit parfois � nominales �), on rajoute en fait
un � individu moyen � pour chacune des valeur de cette variable.  (Les
anglophones appellent �a un � biplot � car on repr�sente sur un m�me
graphique les individus (en noir) et les variables (en rouge).)

  library(help=mva)
  library(mva)
  data(USArrests)
  p <- princomp(USArrests)
  biplot(p)

= R_087.png

Voici les valeurs propres. On constate qu'il y a une chute brutale :
cela signifie que l'analyse en composantes principales est pertinente
et qu'on peut se limiter aux vecteurs propres dont les valeurs propres
sont �lev�es (ici : le premier, on aurait donc m�me pu faire un dessin
en dimension 1).

  plot(p)

= R_088.png

Voici maintenant un exemple o� l'analyse en composantes principales n'est
pas pertinente (les notes de mes �l�ves).

  # Copy-pasted with the help of the "deparse" command:
  #   cat( deparse(x), file='foobar')
  notes <- matrix( c(15, NA, 7, 15, 11, 7, 7, 8, 11, 11, 13, 6, 14, 19, 9,
      8, 6, NA, 7, 14, 11, 13, 16, 10, 18, 7, 7, NA, 11, NA, NA, 6,
      15, 5, 11, 7, 3, NA, 3, 1, 10, 1, 1, 18, 13, 2, 2, 0, 7, 9, 13,
      NA, 19, 0, 17, 8, 2, 9, 2, 5, 12, 0, 8, 12, 8, 4, 8, 0, 5, 5.5,
      1, 12, 4, 13, 5, 11, 6, 0, 7, 8, 11, 9, 9, 9, 14, 8, 5, 8, 5, 5,
      12, 6, 16.5, 13.5, 15, 3, 10.5, 1.5, 10.5, 9, 15, 7.5, 12, 13.5,
      4.5, 13.5, 13.5, 6, 12, 7.5, 9, 6, 13.5, 13.5, 15, 13.5, 6, NA,
      13.5, 4.5, 14, NA, 14, 14, 14, 8, 16, NA, 6, 6, 12, NA, 7, 15,
      13, 17, 18, 5, 14, 17, 17, 13, NA, NA, 16, 14, 18, 13, 17, 17,
      8, 4, 16, 16, 16, 10, 15, 8, 10, 13, 12, 14, 8, 19, 7, 7, 9, 8,
      15, 16, 8, 7, 12, 5, 11, 17, 13, 13, 7, 12, 15, 8, 17, 16, 16,
      6, 7, 11, 15, 15, 19, 12, 15, 16, 13, 19, 14, 4, 13, 13, 19, 11,
      15, 7, 20, 16, 10, 12, 16, 14, 0, 0, 11, 9, 4, 10, 0, 0, 5, 11,
      12, 7, 12, 17, NA, 6, 6, 9, 7, 0, 7, NA, 15, 3, 20, 11, 10, 13,
      0, 0, 6, 1, 5, 6, 5, 4, 2, 0, 8, 9, NA, 0, 11, 11, 0, 7, 0, NA,
      NA, 7, 0, NA, NA, 6, 9, 6, 4, 5, 4, 3 ),
    nrow=30)
  notes <- data.frame(notes)
  # Ce ne sont pas les vrais noms
  row.names(notes) <- c("Anouilh", "Balzac", "Camus", "Dostoievski",
                        "Eschyle", "F�nelon", "Giraudoux", "Hom�re",
                        "Ionesco", "Jarry", "Kant", "La Fontaine",
                        "Marivaux", "Nerval", "Ossian", "Platon",
                        "Quevedo", "Racine", "Shakespeare", "T�rence",
                        "Updike", "Voltaire", "Whitman", "X", "Yourcenar",
                        "Zola", "27", "28", "29", "30")
  attr(notes, "names") <- c("C1", "DM1", "C2", "DS1", "DM2", "C3", "DM3", 
                            "DM4", "DS2")
  notes <- as.matrix(notes)
  notes <- t(t(notes) - apply(notes, 2, mean, na.rm=T))
  # Get rid of NAs
  notes[ is.na(notes) ] <- 0
  # plots
  plot(princomp(notes))

= R_089.png

  biplot(princomp(notes))

= R_090.png

Dans la figure pr�c�dente, les anciens vecteurs de base ont �t�
repr�sent�s en rouge. On les repr�sente parfois sur un dessin isol�s,
dans un cercle, le cercle des corr�lations (ce sont ces vecteurs
unitaires, ils sont donc sur la sph�re de rayon 1 : le cercle des
corr�lations est la projection de cette sph�re).

Voici un autre exemple : on peut utiliser l'ACP pour classer les
textes d'un corpus : les lignes du tableau (les individus) sont les
textes, les colonnes les mots de vocabulaire, les valeurs dans le
tableau sont le nombre d'occurrence du mot dans le texte. Comme la
dimension de l'espace (i.e., le nombre de colonnes) est tr�s grande
(quelques milliers), il n'est pas tr�s commode de calculer la matrice
des covariances et encore moins de la diagonaliser : on peut n�anmoins
r�aliser l'ACP, de mani�re approch�e, � l'aide de r�seaux de neurones.

  A FAIRE : URL ???

Nous avons ici donn� la m�me importance � chaque note et � chaque
individu. On aurait pu donner plus d'importance � certaines (les notes
des devoirs en classe) (au lieu de prendre les notes de chaque devoir
dans une mati�re donn�e, on peut prendre les moyennes dans chaque
mati�re, et les affecter des coefficients du bac) : c'est le m�me
algorithme, il suffit de munir l'espace d'une m�trique refl�tant ces
diff�rences d'importance.

+ Donn�es multivari�es quantitatives : analyse en composantes robustes

On peut remplacer les variables par leur rang. Mais alors, les
variables suivent une distribution uniforme, et le traitement usuel
(avec des carr�s partout) donne trop d'importance aux valeurs
extr�mes. On peut alors faire une transformation pour se ramener � une
distribution normale.

+ Donn�es multivari�es quantitatives : aggr�gation autour des centres mobiles 

On choisit au hasard k points, les centres, et on r�partit l'ensemble
des donn�es en k classes, en mettant un point dans la m�me classe que
le centre dont il est le plus proche. On remplace chaque centre par le
centre de gravit� de sa classe. Et on it�re.

Cette m�thode pr�sente un l�ger probl�me : le r�sultat d�pend des
premiers centre mobiles choisis...

La m�thode des K-moyennes (k-means) est assez proche.

  x <- rbind(matrix(rnorm(100, sd = 0.3), ncol = 2),
             matrix(rnorm(100, mean = 1, sd = 0.3), ncol = 2))
  cl <- kmeans(x, 2, 20)
  plot(x, col = cl$cluster, pch=3, lwd=1)
  points(cl$centers, col = 1:2, pch = 7, lwd=3)
  segments( x[cl$cluster==1,][,1], x[cl$cluster==1,][,2], 
            cl$centers[1,1], cl$centers[1,2])
  segments( x[cl$cluster==2,][,1], x[cl$cluster==2,][,2], 
            cl$centers[2,1], cl$centers[2,2], 
            col=2)

  A FAIRE : mettre le nombre d'amas en param�tre

= R_092.png

  (A FAIRE : dessiner le diagramme de Voronoi correspondant
   -- mais il n'y a pas de fonction pr�d�finie pour faire �a...)
  (Attention : c'est un diagramme de Voronoi dans R^n, mais on ne
  peut repr�senter q'une projection dans le plan...

Voici ce que �a donne avec mes notes.

  cl <- kmeans(notes, 6, 20)
  plot(notes, col = cl$cluster, pch=3, lwd=3)
  points(cl$centers, col = 1:6, pch=7, lwd=3)

= R_110.png

Ce n'est pas du tout ce que l'on veut : il a fait le dessin dans
le plan engendr� par les deux premiers axes de coordonn�es, au lieu de prendre
le premier plan factoriel.

  n <- 6
  cl <- kmeans(notes, n, 20)
  p <- princomp(notes)
  u <- p$loadings
  x <- (t(u) %*% t(notes))[1:2,]
  x <- t(x)
  plot(x, col=cl$cluster, pch=3, lwd=3)
  c <- (t(u) %*% t(cl$center))[1:2,]
  c <- t(c)
  points(c, col = 1:n, pch=7, lwd=3)
  for (i in 1:n) {
    print(paste("Cluster", i))
    for (j in (1:length(notes[,1]))[cl$cluster==i]) {
      print(paste("Point", j))
      segments( x[j,1], x[j,2], c[i,1], c[i,2], col=i )
    }
  }

= R_111.png

  text( x[,1], x[,2], attr(x, "dimnames")[[1]] )

= R_112.png

En fait, la commande clusplot fait d�j� des choses comparables.
On lui donne le r�sultat d'une des commandes suivantes.

  pam    partitionning around medoids
  clara  other partitionning, well-suited for large data sets
  daisy  dissimilarity matrix: qualitative or quantative variables
  dist   dissimilarity matrix: quantitative variables only
  fanny  fuzzy clustering

Voici quelques exemples de r�sultats.

  clusplot( notes, pam(notes, 6)$clustering )

= R_113.png

  clusplot( notes, pam(notes, 2)$clustering )

= R_114.png

  clusplot( daisy(notes), pam(notes,2)$clustering, diss=T )

= R_115.png

  clusplot( daisy(notes), pam(notes,6)$clustering, diss=T )

= R_116.png

  clusplot(fanny(notes,2))

= R_117.png

  clusplot(fanny(notes,10))

= R_118.png

+ Donn�es multivari�es quantitatives : classification hi�rarchique (dendogramme)

On r�partit les points en n classes (un point par classe). On cherche
les deux classes les plus proches (on prend par exemple la distance
entre leurs centres de gravit� -- mais on peut �tre un peu plus
subtil) et on les aggr�ge. On se retrouve avec une classe de moins. On
it�re.  On repr�sente le r�sultat sous forme d'un dendogramme.

  data(USArrests)
  hc <- hclust(dist(USArrests), "ave")
  plot(hc)

= R_093.png

  plot(hc, hang = -1)

= R_094.png

A FAIRE : comprendre ce qui suit.

  ## Do the same with centroid clustering and squared Euclidean distance,
  ## cut the tree into ten clusters and reconstruct the upper part of the
  ## tree from the cluster centers.
  hc <- hclust(dist(USArrests)^2, "cen")
  memb <- cutree(hc, k = 10)
  cent <- NULL
  for(k in 1:10){
    cent <- rbind(cent, colMeans(USArrests[memb == k, , drop = FALSE]))
  }
  hc1 <- hclust(dist(cent)^2, method = "cen", members = table(memb))
  opar <- par(mfrow = c(1, 2))
  plot(hc,  labels = FALSE, hang = -1, main = "Original Tree")

= R_095.png

  plot(hc1, labels = FALSE, hang = -1, main = "Re-start from 10 clusters")

= R_096.png

Voici ce que �a donne avec les notes de mes �l�ves.

  plot(hclust(dist(notes)))

= R_097.png

  p <- princomp(notes)
  u <- p$loadings
  x <- (t(u) %*% t(notes))[1:2,]
  x <- t(x)
  plot(x, col="red")
  c <- hclust(dist(notes))$merge
  y <- NULL
  n <- NULL
  for (i in (1:(length(notes[,1])-1))) {
    print(paste("Step", i))
    if( c[i,1]>0 ){
      a <- y[ c[i,1], ]
      a.n <- n[ c[i,1] ]
    } else {
      a <- x[ -c[i,1], ]
      a.n <- 1
    }
    if( c[i,2]>0 ){
      b <- y[ c[i,2], ]
      b.n <- n[ c[i,2] ]
    } else {
      b <- x[ -c[i,2], ]
      b.n <- 1
    }
    n <- append(n, a.n+b.n)
    m <- ( a.n * a + b.n * b )/( a.n + b.n )
    y <- rbind(y, m)
    segments( m[1], m[2], a[1], a[2], col="red" )
    segments( m[1], m[2], b[1], b[2], col="red" )
    if( i> length(notes[,1])-1-6 ){
      op=par(ps=30)
      text( m[1], m[2], paste(length(notes[,1])-i), col="red" )
      par(op)
    }
  }
  text( x[,1], x[,2], attr(x, "dimnames")[[1]] )

= R_109.png  

A FAIRE : un graphique avec diff�rentes couleurs selon les branches de l'arbre.
(un premier graphique avec juste deux couleurs, le suivant avec trois, etc.)

A FAIRE : 

  ?mclust
  (not installed)

+ classification and regression trees (CART)

A FAIRE

  library(help=rpart)


+ Donn�es multivari�es quantitatives (fin)

La m�thode des centres mobiles est tr�s rapide, et bien adapt�e aux
donn�es volumineuses, mais non d�terministe, tout le contraire de la
classification hi�rarchique. C'est pourquoi on utilise souvent un
algorithme mixte (hybrid clustering) : on commence par utiliser la
m�thode des centres mobiles pour obtenir quelques dizaines ou
centaines de classes, on utilise ensuite la classification
hi�rarchique pour regrouper ces classes et choisir le nombre de
classes. Finalement, on rafine (on applique � nouveau la m�thode des
centres mobiles, avec les classes que l'on vient d'obtenir).

  A FAIRE : sous R ???

A FAIRE : indice d'agr�gation.

+ Donn�es multivari�es quantitatives avec une variable qualitative (analyse factorielle discriminante)

La variable qualitative peut �tre � le patient a-t-il eu un infarctus
? � et les variables quantitatives diff�rents facteurs de risque
potentiels (tension art�rielle, nombre de calories ing�r�es par jour,
exercice physique, poids, etc.) : on essaye alors de d�terminer quels
sont les facteurs de risque les plus importants, i.e., quelles
variables d�terminent le mieux la variable qualitative.  On peut aussi
utiliser l'AFD de mani�re pr�dictive , i.e., r�pondre � la question �
la patient aura-t-il un infarctus ? �.

Le principe est � peu pr�s le m�me que dans le cas bidimensionnel �voqu� plus haut, 
et on se ram�ne � une ACP.

A FAIRE : comprendre
A FAIRE : terminer d'expliquer
A FAIRE : un exemple, avec R.


+ Donn�es multivari�es qualitatives : analyse factorielle des correspondances simples

L'analyse des correspondances s'int�resse aux tableaux de contingence,
i.e., aux variables qualitatives. Pla�ons-nous dans la cas de deux
variables. On commence par transformer le
tableau en deux tableaux : celui des profils-lignes (la somme des
�l�ments de chaque ligne �gale 1 (ou 100%)) et celui des profils-colonnes.
Si les deux variables sont ind�pendantes, on a f(i,j)=f(i,*)f(*,j). On
utilise alors le test du Chi2 de Pearson (??? A FAIRE ???) pour
comparer les distributions de f(i,j) et de f(i,*)f(*,j).

D'un point de vue technique, l'analyse des correspondances ressemble
beaucoup � l'analse des composantes principales. Il s'agit de
repr�senter graphiquement les points correspondant aux diff�rentes
lignes du tableau (resp, les colonnes), de mani�re � avoir un nuage de
points les plus espac�s possibles (i.e., en maximisant la
variance). On proc�de donc exactement comme pour l'ACP, � ceci pr�s
qu'on ne mesure pas les distances avec la m�trique canonique, mais �
l'aide de la � distance du chi2 �, 

A FAIRE

Analyse des correspondances

  library(MASS)
  data(HairEyeColor)
  x <- HairEyeColor[,,1]+HairEyeColor[,,2]
  biplot(corresp(x, nf = 2))

= R_098.png

  biplot(corresp(t(x), nf = 2))

= R_099.png

  A FAIRE : ajouter des points correspondant aux autres variables
  (un point � hommes � et un point � femmes �)

+ Donn�es multivari�es qualitatives : analyse des composantes multiples

L'analyse des correspondances simples s'int�ressait � deux variables
statistiques qualitatives ; l'analyse des correspondances multiples
s'int�resse � plusieurs variables qualitatives.
Les donn�es ne sont g�n�ralement pas repr�sent�es par une matrice (ou
plut�t une hypermatrice) de contingence, car cette matrice aurait un
nombre d'�l�ments vraiment �norme, et la plupart ce ces �l�ments
seraient nuls.

A FAIRE : principe ???

Voici tout d'abord l'exemple du manuel.

  library(MASS)
  data(farms)
  farms.mca <- mca(farms, abbrev=TRUE)
  farms.mca
  plot(farms.mca)

= R_100.png

Reprenons l'exemple de la couleur des yeux et de cheveux des �tudiants
: comme les donn�es sont sous forme d'une hypermatrice, il faut
pr�alablement les transformer.

  Pour HairEyeColor, il faut transformer les donn�es...
  A FAIRE

  A FAIRE : expliquer aussi comment ajouter des variables
  (qualitatives ou quantitatives, sur un tel graphique). 
  Utiliser :
  ?predict.mca

A FAIRE :

  library(MASS)
  ?lda

+ Analyse canonique 

Etude (g�n�rale) de la liaison entre deux groupes de
variables. R�gression multiple, analyse de la variance, analyse de la
covariance, analyse discriminante,
analyse des correspondances en sont des cas particuliers.  Plus
pr�cis�ment, il s'agit de trouver une combinaison lin�aire des
variables du premier groupe ainsi qu'une combinaison lin�aire du
second de mani�re � maximiser leur corr�lation.

* Vocabulaire de la r�gression et de l'analyse de la variance

+ R�gression

Tentative de pr�diction d'une variable statistique en fonction
d'autres variables. Il s'agit donc d'�tudier le lien entre plusieurs
variables statistiques, mais de mani�re asym�trique : certaines
variables sont pr�dictives, d'autres pas.

+ R�gression multiple 

Etude de la liaison entre un groupe de variables (g�n�ralement
quantitatives) et une variable quantitative. Il s'agit plus
pr�cis�ment de pr�dire les valeurs de cette variable. On cherche �
�crire la variable � pr�dire comme une combinaison lin�aire des autres
variables. Pour tenter de simplifier le mod�le ainsi obtenu, en se
d�barassant des variables pr�dictives non n�cessaires, on s'amuse �
faire plein de tests statistiques du genre "H0 : tel coefficient est
nul".

+ R�gression r�gularis�e 

R�gression sur les composantes principales (et non pas sur l'espace
tout entier). De mani�re g�n�rale, c'est une bonne id�e de tenter de
se limiter � un nombre r�duit de variables.

+ Analyse de la variance 

Etude de la liaison entre un groupe de variables qualitatives et une
variable quantitative, dont on veut pr�dire les valeurs. Plus
pr�cis�ment, on cherche � �crire (dans le cas de deux variables u et
v).

  y = qqch qui d�pend de la valeur de u 
      + qqch qui d�pend de la valeur de v
      + qqch qui d�pend de la valeur de (u,v)
      + bruit

On �value les diff�rents coefficients qui apparaissent dans 
cette �criture et on fait plein de tests pour regarder si certains 
des coefficients sont nuls (par exemple, les coefficients qui correspondent
aux valeurs de (u,v), et qui correspondent � une interaction entre u et v).

+ Analyse de la covariance 

Etude de la liaison entre un groupe de variables (en partie
qualitatives, en partie quantitatives) et une variable
quantitative. On proc�de comme pour l'analyse de la variance, toujours
avec plein de tests.

+ Analyse discriminante 

Etude de la liaison entre un groupe de
variables et une variable qualitative.

A FAIRE

+ Analyse des correspondances 

Etude de la liaison entre des variables qualitatives (nous en avons
parl� plus haut).

+ Mod�le lin�aire (ou r�gression lin�aire)

On cherche � �crire une variable y comme combinaison 
lin�aire d'autres variables x1, x2,... xn :

  E(y) = a0 + a1 x1 + a2 x2 + ... + an xn.

Cela revient en fait � �crire 

  y = a0 + a1 x1 + a2 x2 + ... + an xn + bruit

o� << bruit >> est un terme d'erreur (g�n�ralement normal, d'esp�rance
nulle).

Le mod�le lin�aire regroupe la r�gression multiple, l'analyse de la
variance, l'analyse de la covariance.

+ Mod�le lin�aire g�n�ralis� 

Cette fois-ci, on �crit plut�t

  g( E(y) ) = a0 + a1 x1 + a2 x2 + ... + an xn

o� g est une certaine fonction. De plus, y ne suit pas n�cessairement
une loi normale, mais simplement une loi de la famille exponentielle
(par exemple, normale, binomiale, Poisson, gamma). Pour trouver la
valeur des param�tres, on utilise la m�thode du maximum de
vraissemblance (dans le cas d'une loi normale, on retombe sur les
moindres carr�s).

C'est en particulier ce que l'on utilise si Y est qualitative.  Dans
ce cas, on peut chercher P(y=0) ; mais comme une probabilit� est
toujours comprise entre 0 et 1, on n'arrivera pas � l'exprimer comme
combinaison lin�aire de variables quantitatives auxquelles on ajoute
du bruit. On applique alors � cette probabilit� une bijection g entre
l'intervalle [0;1] et la droite r�elle (on dit que g est un lien).  On
essaye alors d'exprimer g(P(y=0)) comme combinaison lin�aire des
variables pr�dictives.

+ Lien

La fonction g, dans la d�finition du mod�le lin�aire g�n�ralis�,
s'appelle un lien. Il a souvent une forme sigmo�dale.

+ Fonction logistique

C'est un exemple de lien.

                    p
  logit(p) = log -------
                  1 - p

On peut donc �crire

                            P(gagner)
  logit( P(gagner) ) = log -----------.
                            P(perdre)

Le quotient P(gagner)/P(perdre) s'appelle la cote (vous avez surement
d�j� entendu l'expression << la cote est � ... contre 1 >>).

Voici le graphe de cette fonction.

  x <- seq(0,1, length=100)
  x <- x[2:(length(x)-1)]
  logit <- function (t) {
    log( t / (1-t) )
  }
  plot(logit(x) ~ x, type='l')

= R_188.png

+ Fonction probit

C'est un autre exemple de lien : c'est la fonction inverse de la
fonction de r�partition de la loi normale standard.

  curve(logit(x), col='blue', add=F)
  curve(qnorm(x), col='red', add=T)
  a <- par("usr")
  legend( a[1], a[4], c("logit","probit"), col=c("blue","red"), lty=1)

= R_189.png

+ Mod�le de variables latentes

On suppose ici que les variables observ�es sont des combinaisons
lin�aires de "facteurs" (variables non observ�es, en nombre
plus r�duit). Cela revient en fait � faire une analyse en composantes
principales.

+ Analyse factorielle discriminante

   A FAIRE

Il s'agit de pr�dire la valeur d'une variables
qualitative, i.e., de mettre les individus dans des classes.
(Par exemple : aide au diagnostic m�dical, 
reconnaissance des mauvais payeurs par une banque, etc.)
On cherche des "fonctions lin�aires discirminantes (des combinaisons
lin�aires dea variables, qui maximisent la variance interclasse et minimisent
la variance intraclasse)

+ R�seaux de neurones

Ils rendent � peu pr�s les m�mes services que l'analyse discriminante.

A FAIRE

+ Mod�les log-lin�aires

On �tudie les liaisons entre des variables qualitatives,
sans qu'une variable joue un r�le particulier
(il n'y a pas de variable � pr�voir).
Les donn�es sont repr�sent�es par un tableau de contingence.
On commence par formuler une hypoth�se sur ce tableau, qui donne
un certain mod�le et certaines valeurs pour les fr�quences. Par
exemple, s'il y a deux variables, si on suppose qu'elles sont
ind�pendantes, le mod�le implique que 

  t(i,j) = t(i,*) t(*,j)

On utilise alors un test du Chi2 pour comparer cette distribution
avec celle effectivement observ�e. Ce mod�le peut s'�crire sous forme
lin�aire

  ln t(i,j) = a1(i) + a2(j).

S'il ne convient pas, on peut essayer de rajouter un terme 
traduisant l'interaction entre les deux variables.

  ln t(i,j) = a1(i) + a2(j) + a12(i,j)

Plus g�n�ralement, on pourra essayer

  ln t(i,j,k) = a0 + a1(i) + a2(j) + a3(k) 
                + a12(i,j) + a13(i,k) + a23(j,k)
                + a123(i,j).

Ici encore, on pourrait s'amuser � faire plein de tests pour
regarder si certains de ces coefficients sont nuls. Mais g�n�ralement, 
on commence par essayer les mod�les les plus simples, et
on les complexifie au fur et � mesure : on s'arr�te quand 
le mod�le convient.

Le mod�le log-lin�aire est pertinent si on a peu de variables (pas plus
de 5 : sinon, on pr�f�rera l'analyse des correspondances) 
et beaucoup d'individus.

+ R�gression logistique

C'est un cas particulier du mod�le lin�aire g�n�ralis�, 
dans lequel le lien est la fonction logit.

On cherche � relier des variables qualitatives x1, x2,..., xn et une
variable qualitative y qui prend deux valeurs (on parle de variable
binaire ou dichotomoque). Pn cherche � estimer la probabilit�

  pi(x) = P ( y=1 | x ).

on consid�re le mod�le 

  logit pi(x) = a0 + a1 x1 + ... + an xn

o�

  logit(t) = ln( t/(1-t) ).

Comme d'habitude, on estime les coefficients � l'aide de
la m�thode du maximum de vraissemblance et on fait plein de tests
du genre "H0: a_i = 0".

+ A FAIRE

division de l'ensemble des donn�es en deux : apprentissage et test.

Vocabulaire : predictor, input, independant variable ; response,
output, dependant variable ; quantitative, categorical, discrete.

* R�gression et analyse de la variance (Anova)

+ R�gression

On s'int�resse � la pr�diction d'une variable statistique Y
� l'aide d'une autre variable X, toutes deux quantitatives.

La courbe de r�gression de Y sur X est la fonction f qui minimise

  E( Y - f(X) )^2.

On peut l'obtenir ainsi :

  f(x) = E[ Y | X=x ].

Voici quelques mani�res d'approcher la r�gression.

A FAIRE : moyenne mobile

A FAIRE : moyenne mobile pond�r�e par un noyau

  library(modreg)
  ?ksmooth
  La documentation nous dit :
  Better kernel smoothers are available in other packages.
  (sans pr�ciser o�)

A FAIRE : r�gression en bandes.

Le principe est simple : on d�coupe les valeurs de Y en plusieurs
morceaux (disons 5), on prend le centre (m�diane) de chacun de ces
nuages de points, et on les relie. Cela permet de voir si une
r�gression lin�aire est une bonne id�e ou si un mod�le non lin�aire
est pr�f�rable.

A FAIRE : lowess

  ?lowess
  data(quakes)
  plot(lat~long, data=quakes)
  lines(lowess(quakes$long, quakes$lat), col='red')

= R_207.png

A FAIRE : loess

  library(modreg)
  ?loess
  ?scatter.smooth


N�anmoins, on se limite g�n�ralement � une fonction qui a une forme
relativement simple, comme une fonction affine (ou un polyn�me). On
cherche alors � minimiser

  E( Y - (aX+b) )^2.

Dans la pratique, on utilise un �chantillon pour estimer les valeurs
des param�tres a et b (�a marche bien m�me si X n'est pas al�atoire,
par exemple, si elle est fix�e par l'exp�rimentateur).

Il s'agit simplement de trouver les valeurs de a et b qui minimisent
la somme des (Yi - (a Xi + b))^2 : il suffit de regarder quand les
d�riv�es partielles par rapport � a et b s'annullent.

  > lm(lat~long, data=quakes)

  Call:
  lm(formula = lat ~ long, data = quakes)

  Coefficients:
  (Intercept)         long
      33.5615      -0.3020

Si on veut plus de d�tails :

  > summary(lm(lat~long, data=quakes))

  Call:
  lm(formula = lat ~ long, data = quakes)

  Residuals:
      Min      1Q  Median      3Q     Max
  -19.084  -2.723   0.868   3.319   7.810

  Coefficients:
              Estimate Std. Error t value Pr(>|t|)
  (Intercept) 33.56151    4.38533   7.653 4.61e-14 ***
  long        -0.30204    0.02442 -12.367  < 2e-16 ***
  ---
  Signif. codes:  0 `***' 0.001 `**' 0.01 `*' 0.05 `.' 0.1 ` ' 1

  Residual standard error: 4.685 on 998 degrees of freedom
  Multiple R-Squared: 0.1329,     Adjusted R-squared: 0.132
  F-statistic:   153 on 1 and 998 DF,  p-value: < 2.2e-16

On peut ensuite faire des tests sur a et b (qui ont des distributions
normales), ou chercher des intervalles de confiance (soit de a et b,

  A FAIRE On peut chercher des intervalles de confiance pour un
  param�tre isol� -- on obtient un segment -- ou pour plusieurs
  param�tres en m�me temps -- on obtient un ellipso�de plein : si on
  peut le tracer, il apporte plus d'information. On parle alors de
  r�gion de confiance.
  (prendre un exemple dans lequel l'ellipse est en biais)
  library(ellipse)
  g <- lm(y~x1+x2+x3)
  plot(ellipse(g,c(2,3)),type="l",xlim=c(-1,0))
  points(0,0)
  points(g$coef[2],g$coef[3],pch=18)
  abline(v=c(-0.461-2.01*0.145,-0.461+2.01*0.145),lty=2)
  abline(h=c(-1.69-2.01*1.08,-1.69+2.01*1.08),lty=2)


soit de aX+b (bande de confiance), soit de E[Y|X=x] (bande de
pr�diction)).

  x <- runif(20)
  y <- 1-2*x+.1*rnorm(20)
  res <- lm(y~x)
  plot(y~x)
  new <- data.frame( x=seq(0,1,length=21) )
  p <- predict(res, new)
  points( p ~ new$x, type='l' )
  p <- predict(res, new, interval='confidence')
  points( p[,2] ~ new$x, type='l', col="green" )
  points( p[,3] ~ new$x, type='l', col="green" )
  p <- predict(res, new, interval='prediction')
  points( p[,2] ~ new$x, type='l', col="red" )
  points( p[,3] ~ new$x, type='l', col="red" )

= R_126.png

Voici d'autres mani�res de repr�senter les intervalles de confiance et
de pr�diction.

  N <- 100
  n <- 20
  x <- runif(N, min=-1, max=1)
  y <- 1 - 2*x + rnorm(N, sd=abs(x))
  res <- lm(y~x)
  plot(y~x)
  x0 <- seq(-1,1,length=n)
  new <- data.frame( x=x0 )
  p <- predict(res, new)
  points( p ~ x0, type='l' )
  p <- predict(res, new, interval='prediction')
  segments( x0, p[,2], x0, p[,3], col='red')
  p <- predict(res, new, interval='confidence')
  segments( x0, p[,2], x0, p[,3], col='green', lwd=3 )

= R_178.png

  mySegments <- function(a,b,c,d,...) {
    u <- par('usr')
    e <- (u[2]-u[1])/100
    segments(a,b,c,d,...)
    segments(a+e,b,a-e,b,...)
    segments(c+e,d,c-e,d,...)
  }
  plot(y~x)
  p <- predict(res, new)
  points( p ~ x0, type='l' )
  p <- predict(res, new, interval='prediction')
  mySegments( x0, p[,2], x0, p[,3], col='red')
  p <- predict(res, new, interval='confidence')
  mySegments( x0, p[,2], x0, p[,3], col='green', lwd=3 )

= R_179.png

A FAIRE : lire et comprendre le code suivant.

file:///home/zoonek/spool/WWW/DOC/R/www.r-project.org/nocvs/mail/r-help/2002/0680.html

It must be from the gregmisc package.

  plotCI <- function (x, y = NULL, uiw, liw = uiw, aui=NULL, ali=aui,
                       err="y", ylim=NULL, sfrac = 0.01, gap=0, add=FALSE,
                       col=par("col"), lwd=par("lwd"), slty=par("lty"), xlab=NULL,
                       ylab=NULL, ...) {
   ## originally from Bill Venables, R-list
     if (is.list(x)) {
       y <- x$y
       x <- x$x
     }
     if (is.null(y)) {
       if (is.null(x))
         stop("both x and y NULL")
       y <- as.numeric(x)
       x <- seq(along = x)
     }
     if (missing(xlab)) xlab <- deparse(substitute(x))
     if (missing(ylab)) ylab <- deparse(substitute(y))
     if (missing(uiw)) { ## absolute limits
       ui <- aui
       li <- ali
     }
     else { ## relative limits
       if (err=="y") z <- y else z <- x
       ui <- z + uiw
       li <- z - liw
     }
     if (is.null(ylim)) ylim <- range(c(y, ui, li), na.rm=TRUE)
     if (add) {
       points(x, y, col=col, lwd=lwd, ...)
     } else {
       plot(x, y, ylim = ylim, col=col, lwd=lwd, xlab=xlab, ylab=ylab, ...)
     }
     if (gap==TRUE) gap <- 0.01 ## default gap size
     ul <- c(li, ui)
     if (err=="y") {
       gap <- rep(gap,length(x))*diff(par("usr")[3:4])
   # smidge <- diff(par("usr")[1:2]) * sfrac
       smidge <- par("fin")[1] * sfrac
   # segments(x , li, x, pmax(y-gap,li), col=col, lwd=lwd, lty=slty)
   # segments(x , ui, x, pmin(y+gap,ui), col=col, lwd=lwd, lty=slty)
       arrows(x , li, x, pmax(y-gap,li), col=col, lwd=lwd, lty=slty, angle=90, length=smidge, code=1)
       arrows(x , ui, x, pmin(y+gap,ui), col=col, lwd=lwd, lty=slty, angle=90, length=smidge, code=1)
       ## horizontal segments
   # x2 <- c(x, x)
   # segments(x2 - smidge, ul, x2 + smidge, ul, col=col, lwd=lwd)
     }
     else if (err=="x") {
       gap <- rep(gap,length(x))*diff(par("usr")[1:2])
       smidge <- par("fin")[2] * sfrac
   # smidge <- diff(par("usr")[3:4]) * sfrac
       arrows(li, y, pmax(x-gap,li), y, col=col, lwd=lwd, lty=slty, angle=90, length=smidge, code=1)
       arrows(ui, y, pmin(x+gap,ui), y, col=col, lwd=lwd, lty=slty, angle=90, length=smidge, code=1)
       ## vertical segments
   # y2 <- c(y, y)
   # segments(ul, y2 - smidge, ul, y2 + smidge, col=col, lwd=lwd)
     }
     invisible(list(x = x, y = y))
   }
    
  
+ Exemples

Tir�s du manuel, voici quatre exemples de donn�es, tr�s diff�rentes,
qui donnent la m�me droite de r�gression.

  data(anscombe)
  ff <- y ~ x
  op <- par(mfrow=c(2,2), mar=.1+c(4,4,1,1), oma= c(0,0,2,0))
  for(i in 1:4) {
    ff[2:3] <- lapply(paste(c("y","x"), i, sep=""), as.name)
    ## or   ff[[2]] <- as.name(paste("y", i, sep=""))
    ##      ff[[3]] <- as.name(paste("x", i, sep=""))
    assign(paste("lm.",i,sep=""), lmi <- lm(ff, data= anscombe))
    #print(anova(lmi))
  }
  for(i in 1:4) {
    ff[2:3] <- lapply(paste(c("y","x"), i, sep=""), as.name)
    plot(ff, data =anscombe, col="red", pch=21, bg = "orange", cex = 1.2,
         xlim=c(3,19), ylim=c(3,13))
    abline(get(paste("lm.",i,sep="")), col="blue")
  }
  mtext("Anscombe's 4 Regression data sets", outer = TRUE, cex=1.5)
  par(op)

= R_180.png

+ Graphiques pour explorer une r�gression

Quelques graphiques permettent de distinguer les quatre cas pr�c�dents
et de corriger le mod�le (ou les donn�es), si n�cessaire.

  data(longley)
  plot(Employed ~ GNP, data=longley)
  r <- lm(Employed ~ GNP, data=longley)
  abline(r)

= R_186.png

  op <- par(mfrow=c(2,2))
  plot(r)
  par(op)

= R_187.png

Le premier graphique repr�sente les r�sidus en fonction des valeurs
pr�dites. Les r�sidus sont sens�s ne pas d�pendre de la valeur
pr�dite. Dans l'exemple suivant, on voit que leur variance augmente
(on peut le v�rifier, par exemple en coupant l'�chantillon au milieu
et en comparant les variances de ces deux nouveaux �chantillons, �
l'aide d'un test statistique). Si la variance augmente, tout ce que
l'on peut faire avec la r�gression (calcul de variance, d'intervalles
de confiance ou de pr�diction, tests statistique, etc.) n'est plus
valable.

  data(crabs)
  plot(FL~RW, data=crabs)

= R_184.png

  plot(lm(FL~RW, data=crabs), which=1)

= R_185.png

  n <- length(crabs$RW)
  m <- ceiling(n/2)
  o <- order(crabs$RW)
  r <- lm(FL~RW, data=crabs)
  x <- r$residuals[o[1:m]]
  y <- r$residuals[o[(m+1):n]]
  var.test(y,x) # p-value = 1e-4

  A FAIRE : un exemple o� les r�sidus sont distribu�s selon une courbe
  A FAIRE un exemple avec un point isol� (une grande valeur de X).

Le second graphique est un QQPlot des r�sidus, permettant de v�rifier
s'ils sont distribu�s normalement.

  plot(r, which=2)
  A FAIRE : trouver un exemple o� les r�sidus ne sont pas normaux.
  Donner deux graphiques : r�sidus ~ valeur pr�dite et qqplot

Le troisi�me (scale-location plot, ou spread-location plot)
repr�sente la racine carr�e de la valeur absolue des
r�sidus normalis�s.

  plot(r, which=3)
  A FAIRE : prendre le m�me exemple qu'en 1.

Pr�sent� comme �a, il n'offre pas beaucoup plus d'information que le
premier. Mais on peut lui ajouter une << r�gression en bande >> (ou un
autre type de r�gression) qui permet de d�tecter l'h�t�rosc�dasticit�
(i.e., qui permet de d�tecter que la variance n'est pas constante).

  A FAIRE

Les distances de Cook des diff�rents points : pour chaque point, on
effectue la r�gr�ssion avec et sans le point, et on regarde la
diff�rence.

  plot(r, which=4)
  A FAIRE : trouver un exemple avec une erreur.
  (les �lections am�ricaines ???)

  On peut aussi faire des histogrammes, boxplot, qqplot pour examiner ces
  distances de Cook.
  A FAIRE

  A FAIRE :
  ?lm.influence
  example(influence.measures)

  A FAIRE : plot(y~x) avec des points plus gros pour les individus les
  plus influents.  (en dimensions sup�rieures, on peut commencer par
  se d�barasser de toutes les variables pr�dictives sauf une).

Les r�sidus forment une variable statistique comme une autre,
que l'on peut examiner comme n'importe quelle autre variable.

  A FAIRE : les quatre graphiques
  1. histogramme + courbe normale + rugs
  2. boxplot
  3. Sym�trie
  4. qqplot

Ces graphiques restent valables en dimensions sup�rieures.  Voici
l'exemple du manuel (on pr�dit une variable � partir de quatre
autres).

  data(LifeCycleSavings)
  plot(LifeCycleSavings)

= R_181.png

  op <- par(mfrow = c(2, 2), oma = c(0, 0, 2, 0))
  plot(lm.SR <- lm(sr ~ pop15 + pop75 + dpi + ddpi, data = LifeCycleSavings))
  par(op)

= R_182.png

  ## 4 plots on 1 page; allow room for printing model formula in outer margin:
  op <- par(mfrow = c(2, 2), oma = c(0, 0, 2, 0))
  #plot(lm.SR)
  #plot(lm.SR, id.n = NULL)               # no id's
  #plot(lm.SR, id.n = 5, labels.id = NULL)# 5 id numbers
  plot(lm.SR, panel = panel.smooth)
  ## Gives a smoother curve
  #plot(lm.SR, panel = function(x,y) panel.smooth(x, y, span = 1))
  par(op)

= R_183.png

A FAIRE : comment v�rifie-t-on l'absence de corr�lation entre les r�sidus ???

+ Probl�mes possibles avec les r�sidus

A FAIRE

H�t�rosc�dasticit� (i.e., la variance des r�sidus varie)

  x <- runif(100)
  y <- 1 - 2*x + .3*x*rnorm(100)
  plot(y~x)
  abline(lm(y~x), col='red')

= R_208.png

  plot( lm(y~x), which=1 )

= R_209.png

Curvilin�arit�

  x <- runif(100, -1, 1)
  y <- 1-x+x^2+.3*rnorm(100)
  plot(y~x)
  abline(lm(y~x), col='red')

= R_213.png

  plot( lm(y~x), panel = panel.smooth, which=1 )

= R_214.png

Non normalit�

  x <- runif(100)
  y <- 1 - 2*x + .3*exp(rnorm(100)-1)
  plot(y~x)
  abline(lm(y~x), col='red')

= R_210.png

  plot( lm(y~x), which=1 )
 
= R_211.png

  plot( lm(y~x), which=2 )

= R_212.png

Points isol�s : il peuvent avoir une importance d�mesur�e sur les
r�sultats de la r�gression.

  A FAIRE

Autocorr�lation

  A FAIRE (mais on en reparlera plus loin, avec les s�ries temporelles
  et les corr�logrammes)
  L'autocorr�lation est fr�quente avec les s�ries temporelles ou les donn�es
  g�ographiques, mais assez rare avec des �chantillons al�atoires.
  Il faut que les donn�es soient ordonn�es ou au moins qu'on ait une
  notion de proximit� entre les individus.
  On peut tester l'autocorr�lation (plus r�cis�ment, la corr�lation entre
  X(i) et X(i-1)) � l'aide d'un test de Durbin--Watson.

Ces probl�mes peuvent invalider les tests T ou F que l'on faut sur les
coefficients de la r�gression.

+ R�sidus

A FAIRE : standardized and studentized residuals

+ Influence

Il existe diff�rentes mesures de l'influence d'un point sur une r�gression.

  leverage: the ith diagonal element of the Hat matrix
  H = X (X' X)^-1 X'
  \hat Y = H Y
  It is between 1/n and 1.
  If it is under .2, it is safe.
  (It measures the unusualness of the X-values)
  Comment traduit-on ? 
  Effet de levier ???
  Ca permet de voir s'il y a des erreurs dans la mesure de X.
  (Mais il peut aussi y avoir des erreurs dans la mesure de Y).

  Cook distance
  Influencial point if D>1 or D>4/n

  Rescaled Cook distance (for plots)
  D* = (99/4) * D(D+1)^2 + 1 if D<1
  D* = 100 if D>1
  Between 0 and 100

  ?ls.diag

A FAIRE : expliquer ces diff�rentes mesures.

A FAIRE : un graphique Y~X, avec la droite de r�gression, et des
points d'autant plus gros qu'ils sont influents.

  # Avec la distance de Cook
  x <- rnorm(20)
  y <- 1 + x + rnorm(20)
  x <- c(x,10)
  y <- c(y,1)
  r <- lm(y~x)
  d <- cooks.distance(r)
  d <- (99/4)*d*(d+1)^2 + 1
  d[d>100] <- 100
  d[d<20] <- 20
  d <- d/20
  plot( y~x, cex=d )
  abline(r)
  abline(coef(line(x,y)), col='red')
  abline(lm(y[1:20]~x[1:20]),col='blue')
  
  ?lm.influence
  influence.measure(r)
  Voir aussi : `dfbetas', `dffits', `covratio', `cooks.distance', `lm'.

    Functions `rstandard' and `rstudent' give the standardized and
     Studentized residuals respectively. (These re-normalize the
     residuals to have unit variance, using an overall and
     leave-one-out measure of the error variance respectively.)


A FAIRE : idem mais sur le graphe des r�sidus.

A FAIRE : idem, mais avec 3 variables Y, X1, X2.
On se ram�ne d'abord � des graphes Y~X1 sans l'influence de X2, etc.

+ Multicolin�arit�

Le coefficient de corr�lation entre deux variables permet de voir si
elles sont colin�aires. Mais on peut aussi avoir des relations entre
plus de deux variables, du genre X3 = X1 + X2. Pour les d�tecter, on
peut faire une r�gression de Xk par rapport aux autres Xi et regarder
R^2.

  A FAIRE : exemple

Au lieu de regarder les R^2, on peut regarder la matrice des
corr�lations entre les coefficients estim�s.

  A FAIRE : exemple

Pour r�soudre ce probl�me, on peut enlever les variables superflues
(mais se posent alors des probl�mes d'interpr�tation). On peut aussi
demander plus de donn�es (les probl�mes de multicolin�arit� sont
fr�quents quand on a beaucoup de variables et peu d'individus).

Il existe des m�thodes de r�gression peu sensibles � la
multicolin�arit�.

  A FAIRE : ridge regression
  (biaised but lower variance)
  J.O. Rawlings, Applied Regression Analysis : A Research Tool (1988)

+ Transformation des donn�es

Avant de faire une r�gression, c'est probablement une bonne id�e de se
ramener � des variables � peu pr�s normales. Cela permet, par exemple,
de se d�barasser des valeurs extr�mes, qui peuvent avoir une tr�s
grande importantce sur le r�sultat de la r�gression. Dans beaucoup de
cas, �a permet aussi de se d�barasser des probl�mes concernant les
r�sidus, comme l'h�t�rosc�dasticit�.

A FAIRE : � la main

On peut aussi faire cela � l'aide de la fonction boxcox.

  x <- exp( rnorm(100) )
  y <- 1 + 2*x + .3*rnorm(100)
  y <- y^1.3
  boxcox(y~x)

= R_215.png

Voici une comparaison des donn�es initiales et des donn�es transform�es.

  bc <- boxcox(y ~ x, plotit=F)
  a <- bc$x[ order(bc$y, decreasing=T)[1] ]
  op <- par( mfcol=c(1,2) )
  plot( y~x )
  plot( y^a ~ x )
  par(op)

= R_219.png

Voici des exemples plus concrets.

  data(trees)
  plot(trees)

= R_216.png

  boxcox(Volume ~ Girth, data = trees)

= R_217.png

  boxcox(Volume ~ log(Height) + log(Girth), data = trees )

= R_218.png

+ The four transformation plots

(how to ensure symetry, equal spread, straightness, additive structure)

(a power plot which is a straight line with slope m suggests a power transformation whose exponent is 1-m.)

1. Transformation for equal spread.
(Location/spread plot)
 Deux variables, une quantitative, une
qualitative. Cela revient � r�partir les individus dans diff�rentes
classes. On repr�sente log(IQR) en fonction de log(median).

2. Transformation plot for symetry.
(xU+xL)/2-M en fonction de ((xU-M)^2+(M-xL)^2)/(4M),
o� M est la m�diane et xU, xL des quartiles (inf�rieurs et sup�rieurs).

3. Transformation plot for straightness.  y-My-C(x-Mx) en fonction de
C^2(x-Mx)^2/(2My) o� Mx, My sont les m�dianes de x et y, C pente de la
r�gression (que l'on ne connait pas).

4. Transformation for additivity (diagnostic plot).
Two-way table.
Par des DL, on remarque que si y_ij^p = m + a_i + b_j, 
alors y_ij = D + A_j + B_j + (1-p) A_i A_i / D.
On trace donc 
y_ij-(m+a_i+b_j) en fonction de a_i b_j / m 
o� y_ij=m+a_i+b_j est un un mod�le additif (qui ne convient donc pas).

+ R�gression et sommes de carr�s

Quand on �crit les r�sultats d'une r�gression ou d'une analyse de la
variance, on se retrouve souvent avec un tableau rempli de << sommes
de carr�s >>.

RSS (Residual Sum of Squares) : c'est la quantit� que l'on cherche �
minimiser lors de la r�gression. On dispose d'une variable pr�dictive,
X, et on cherche � pr�dire les valeurs d'une autre variable, Y. On
�crit

  hat Yi = b0 + b1 Xi

et on cherche les valeurs de b0 et b1 qui minimisent

  RSS = Somme( (Yi - hat Yi)^2 ).

TSS (Total sum of squares) : c'est la quantit� qu'on cherche �
minimiser lorsqu'on d�finit la moyenne de Y.

  TSS = Somme( (Yi - bar Y)^2 )

ESS (Explained Sum of Squares) : c'est la diff�rence entre les valeurs
pr�c�dentes.

  ESS = Somme( ( hat Yi - bar Y )^2 )

R-square : c'est le coefficient de d�termination. Plus il est proche
de 1, plus la r�gression explique les variations de Y.

  R^2 = ESS/TSS.

A FAIRE : interpr�tation graphique de R^2.  Les donn�es sont r�parties
autour d'une bande de hauteur RSS autour de la droite de r�gression,
alors que la hauteur du dessin est TSS. On a alors R^2=1-RSS/TSS.
(Cette interpr�tation n'est plus valable pour un mod�le lin�aire (non
affine). Et dans ce cas, ce n'est peut-�tre pas une tr�s bonne id�e de
calculer R^2.)

+ Lecture du r�sultat d'une r�gression

Voici trois mani�res d'afficher les r�sultats d'une r�gression.

  x <- rnorm(100)
  y <- 1 + 2*x + .3*rnorm(100)

A l'aide de la commande print, qui donne simplement les coefficients.

  > lm(y~x)

  Call:
  lm(formula = y ~ x)

  Coefficients:
  (Intercept)            x
        0.987        1.964

A l'aide de la commande anova. On nous donne alors les sommes de
carr�s, leur moyenne (on les divise par le nombre de degr�s de
libert�), leur quotient (F value), et la probabilit� que leur quotient
soit aussi �lev� si le coefficient directeur de la droite est nul
(c'est donc la p-valeur d'un test dont l'hypoth�se nulle est
l'annulation de ce coefficient directeur).

  > anova(lm(y~x))
  Analysis of Variance Table

  Response: y
            Df Sum Sq Mean Sq F value    Pr(>F)
  x          1 386.97  386.97    4747 < 2.2e-16 ***
  Residuals 98   7.99    0.08
  ---
  Signif. codes:  0 `***' 0.001 `**' 0.01 `*' 0.05 `.' 0.1 ` ' 1

La commande summary fournit une troisi�me mani�re de pr�senter le
r�sultat d'une r�gression. On a les m�mes informations que
pr�c�demment (les coefficients de la r�gression et la p-valeur pour le
test F). On a en plus les quartiles des r�sidus (mais il vaut
peut-�tre mieux les observer � l'aide de graphiques), l'erreur
standard sur les coefficients, un test de Student sur l'annulation de
ces coefficients (ici, les p-valeurs sont tr�s faibles, ils sont bien
tous deux non nuls) et le coefficient de d�termination (R-squared : s'il
est proche de 1, les deux variables sont effectivement li�es).

  > summary(lm(y~x))

  Call:
  lm(formula = y ~ x)

  Residuals:
       Min       1Q   Median       3Q      Max
  -0.84692 -0.24891  0.02781  0.20486  0.60522

  Coefficients:
              Estimate Std. Error t value Pr(>|t|)
  (Intercept)  0.98706    0.02856   34.56   <2e-16 ***
  x            1.96405    0.02851   68.90   <2e-16 ***
  ---
  Signif. codes:  0 `***' 0.001 `**' 0.01 `*' 0.05 `.' 0.1 ` ' 1

  Residual standard error: 0.2855 on 98 degrees of freedom
  Multiple R-Squared: 0.9798,     Adjusted R-squared: 0.9796
  F-statistic:  4747 on 1 and 98 DF,  p-value: < 2.2e-16

+ Tests d'hypoth�se sur une r�gression lin�aire

Nous venons de voir que la commande summary permettait de faire (ou
d'afficher les r�sultats d') un test T de Student sur les
coefficients.

Dans le m�me exemple, on peut regarder si le coefficient constant est
1. (Quand on �crit une formule pour d�crire un mod�le, certaines
op�rations sont interpr�t�es diff�remment (en particulier * et ^) :
pour �tre s�r qu'elles seront interpr�t�es comme des op�rations
arithm�tiques sur les variables, on peut les entourer de I(...). Ici,
�a n'est pas n�cessaire.)

  > summary(lm(I(y-1)~x))

  Call:
  lm(formula = I(y - 1) ~ x)

  Residuals:
       Min       1Q   Median       3Q      Max
  -0.84692 -0.24891  0.02781  0.20486  0.60522

  Coefficients:
              Estimate Std. Error t value Pr(>|t|)
  (Intercept) -0.01294    0.02856  -0.453    0.651
  x            1.96405    0.02851  68.898   <2e-16 ***
  ---
  Signif. codes:  0 `***' 0.001 `**' 0.01 `*' 0.05 `.' 0.1 ` ' 1

  Residual standard error: 0.2855 on 98 degrees of freedom
  Multiple R-Squared: 0.9798,     Adjusted R-squared: 0.9796
  F-statistic:  4747 on 1 and 98 DF,  p-value: < 2.2e-16

Sous l'hypoth�se que ce coefficient est 1, regardons si le coefficient
directer est nul.

  > summary(lm(I(y-1)~0+x))

  Call:
  lm(formula = I(y - 1) ~ 0 + x)

  Residuals:
       Min       1Q   Median       3Q      Max
  -0.85962 -0.26189  0.01480  0.19184  0.59227

  Coefficients:
    Estimate Std. Error t value Pr(>|t|)
  x  1.96378    0.02839   69.18   <2e-16 ***
  ---
  Signif. codes:  0 `***' 0.001 `**' 0.01 `*' 0.05 `.' 0.1 ` ' 1

  Residual standard error: 0.2844 on 99 degrees of freedom
  Multiple R-Squared: 0.9797,     Adjusted R-squared: 0.9795
  F-statistic:  4786 on 1 and 99 DF,  p-value: < 2.2e-16

Regardons s'il est �gal � deux.

  > summary(lm(I(y-1-2*x)~0+x))

  Call:
  lm(formula = I(y - 1 - 2 * x) ~ 0 + x)

  Residuals:
       Min       1Q   Median       3Q      Max
  -0.85962 -0.26189  0.01480  0.19184  0.59227

  Coefficients:
    Estimate Std. Error t value Pr(>|t|)
  x -0.03622    0.02839  -1.276    0.205

  Residual standard error: 0.2844 on 99 degrees of freedom
  Multiple R-Squared: 0.01618,    Adjusted R-squared: 0.006244
  F-statistic: 1.628 on 1 and 99 DF,  p-value: 0.2049

  A FAIRE :
  More generally, I believe linear.hypothesis in the package `car' can
  be used:
  linear.hypothesis(lm(y~x), matrix(c(0,1), 1, 2), 1)
  ...
  The linear.hypothesis function in the car package will test any
  linear hypothesis. But the standard summary output for a linear
  model gives you the coefficient, its standard error, and the
  residual df, so why not just compute your own t, and use pt to get
  the p-value?  

Remarque (� mettre un peu plus loin, quand on parlera d'analyse de la
variance) : on peut voir le calcul de la moyenne d'un �chantillon
comme un cas particulier de la r�gression, dans lequel on cherche �
�crire Y = b.

+ Comparaison de mod�les

Lors d'une r�gression multiple, on s'efforce de prendre le moins de
variables possibles. On est ainsi amen� � comparer des mod�les : par
exemple, comparer un mod�le avec plein de variables et un autre avec
moins de variables.

La commande anova permet d'effectuer ce genre de comparaison.

  data(trees)
  r1 <- lm(Volume ~ Girth, data=trees)
  r2 <- lm(Volume ~ Girth + Height, data=trees)
  anova(r1,r2)

Le r�sultat, 

  Analysis of Variance Table

  Model 1: Volume ~ Girth
  Model 2: Volume ~ Girth + Height
    Res.Df    RSS Df Sum of Sq      F  Pr(>F)
  1     29 524.30
  2     28 421.92  1    102.38 6.7943 0.01449 *
  ---
  Signif. codes:  0 `***' 0.001 `**' 0.01 `*' 0.05 `.' 0.1 ` ' 1

nous dit que les deux mod�les sont sensiblement diff�rents avec un
risque d'erreur inf�rieur � 2%.

Voici d'autres exemples.

  x1 <- rnorm(100)
  x2 <- rnorm(100)
  x3 <- rnorm(100)
  b <- .1* rnorm(100)

  y <- 1 + x1 + x2 + x3 + b 
  r1 <- lm( y ~ x1 )
  r2 <- lm( y ~ x1 + x2 + x3 )
  anova(r1,r2) # p-valeur = 2e-16

  y <- 1 + x1
  r1 <- lm( y ~ x1 )
  r2 <- lm( y ~ x1 + x2 + x3 )
  anova(r1,r2) # p-valeur = 0.25

  y <- 1 + x1 + .02*x2 - .02*x3 + b
  r1 <- lm( y ~ x1 )
  r2 <- lm( y ~ x1 + x2 + x3 )
  anova(r1,r2) # p-valeur = 0.10

Si, lors de la comparaison de deux mod�les, on trouve une p-valeur
importante, i.e., si les deux mod�les ne sont pas significativement
diff�rents, on peut abandonnera le plus complexe pour retenir le plus
simple.

+ D�finition de l'Anova

A FAIRE
Comparaison de mod�les.  Expliquer comment les pr�sentations
pr�c�dentes de l'anova rentrent dans ce cadre.

+ Les risques de la r�gression multiple

Lors d'une r�gression multiple, on s'efforce de prendre le moins de
variables pr�dictives possibles, tout en ayant une pr�diction
correcte. Pour choisir ou �liminer des variables, on peut �tre tent� de
faire plein de tests statistiques.

C'est une mauvaise id�e.

En effet, � chaque test, on a un certain risque de commettre une
erreur -- et ces risques d'erreur s'accumulent.

(N�anmoins, on le fait souvent. On peut soit partir d'un mod�le sans
aucune variable, ajouter la variable Xi qui a la plus forte
corr�lation avec Y, puis ajouter successivement les variables qui
procurent la plus grande augmentation de R^2, en s'arr�tant lorsqu'on
atteint une F-vameur pr�alablement fix�e ; soit partir d'un mod�le
avec toutes les variables, et retirer successivement celles qui
r�duisent le moins R^2, en s'arr�tant lorsqu'on atteint une F-valeur
pr�alablement fix�e.)

+ Graphiques pour la r�gression multiple

On a une variable d�pendante Y et deux variables ind�pendantes X1 et X2. 
On peut �tudier l'effet de X1 sur Y apr�s s'�tre d�barass� de l'effet de X2. 
Pour cela, on fait une r�gression de Y sur X2, une r�gression de X1 sur X2, et
on trace les r�sidus de la premi�re en fonction de ceus de la seconde.

  A FAIRE


+ R�gression curvilin�aire

On fait une transformation des variables, ou on rajoute d'autres
variables obtenues � partir des variables, et on fait une r�gression
(lin�aire) sur tout �a.

On peut par exemple faire une r�gression de la forme 

  log(Y) ~ X + X^2 + sin(X)

A FAIRE : exemple

A FAIRE : r�gression polyn�miale

+ R�gression non lin�aire

On peut aussi avoir des mod�les vraiment non lin�aires.

  Croissance ou d�croissance exponentielle
  Y = a e^(bX) + bruit

  Exponentielle n�gative
  Y = a(1-e^(bX)) + bruit

  Exponentielle double
  Y = u/(u-v) * (e^(-vX) - e^(-uX)) + bruit

  Croissance sigmo�de
  Y = a/( 1+ce^(-bX) ) + bruit

  Sigmo�de moins sym�trique
  Y = a exp( -ce^(-bX) ) + bruit

A FAIRE : graphe de ces fonctions

Pour effectuer ces r�gressions, on utilise toujours les moindres
carr�s, mais on se retrouve avec un syst�me non lin�aire, qui l'on
r�sout de mani�re approch�e (par exemple, par la m�thode de
Newton--Raphson).

  A FAIRE : sous R

  library(help=nls)
  library(nls)

  A FAIRE

Je crois qu'on peut proc�der ainsi. 
D�finir une fonction f(x,p), o� x est la variable et p un vecteur contenant les
param�tres. (On l'utilisera ainsi : f(x,c(a,b,c)).)

  library(nls)
  f <- function (x,p) {
    ...
  }
  r <- nls( y ~ f(x,c(a,b,c)), start=c(a=1, b=-3.14, c=0) )
  summary(r)
  lines(x, f(x,r$m$getAllPars()))



  library(help=nlme)
  library(nlme)

  A FAIRE

+ R�gression non lin�aire

A FAIRE : relire

  A FAIRE :
  lm( y ~ x + I(x^2) )

  Quand on d�finit un mod�le � l'aide d'une telle formule, le
  caract�re ^ a un sens pr�cis (ainsi, (a+b+c)^2 signifie
  a+b+c+a:b+a:c+b:c). Si on rajoute I(...), il est bien interpr�t�
  comme un carr�. On a le m�me probl�me avec les caract�res + et *.

R�gression non lin�aire

  x <- runif(100,-2,2)
  y <- x^2+.2*rnorm(100)
  plot(y~x)
  r <- lm( y ~ poly(x,2) )
  points( predict(r) ~ x, pch=3, col='red')
  # Pour tracer la courbe, il faut mettre les points dans l'ordre
  o = order(x)
  points( predict(r)[o] ~ x[o], type='l', col='red')

  A FAIRE : je constate que les coefficients qui devraient �tre nuls ne le sont pas.
  Enlever les points dont la distance de Cook est la plus grande
  et regarder si alors certains coefficients sont suceptibles d'�tre nuls.

A FAIRE

  lm( 1/y ~ x )

R�gression non lin�aire

  library(ts)
  data(beavers)
  y <- beaver1$temp
  x <- 1:length(y)
  plot(y~x)
  for (i in 1:10) {
    r <- lm( y ~ poly(x,i) )
    lines( predict(r), type="l", col=i )
  }
  summary(r)
 
= R_134.png

  plot(y~x)
  r <- lm( y ~ poly(x,5) )
  lines(predict(r), type="l", col="red")
  x2 <- x^2
  x5 <- x^5
  r <- lm(y~x+x2+x5)
  lines(predict(r), type="l", col="blue")

= R_135.png

  A FAIRE
  Dans cet exemple, pourquoi obtient-t-on des valeurs diff�rentes
  en cherchant un polyn�me et en cherchant une somme de mon�mes ?

  data(beavers)
  y <- beaver1$temp
  x <- 1:length(y)
  x2 <- x^2
  x3 <- x^3
  x4 <- x^4
  x5 <- x^5
  summary(lm(y~x+x2+x3+x4+x5))
  summary(lm(y ~ poly(x,5))

+ Application de la r�gression � un probl�me de classification

On dispose de trois variables, deux quantitatives, X1 et X2, et une
qualitative, Y, � deux valeurs, que l'on cherche � pr�dire.

  n <- 10
  N <- 10
  s <- .3
  m1 <- rnorm(n, c(0,0))
  a <- rnorm(2*N*n, m1, sd=s)
  m2 <- rnorm(n, c(1,1))
  b <- rnorm(2*N*n, m2, sd=s)
  x1 <- c( a[2*(1:(N*n))], b[2*(1:(N*n))] )
  x2 <- c( a[2*(1:(N*n))-1], b[2*(1:(N*n))-1] )
  y <- c(rep(0,N*n), rep(1,N*n))
  plot( x1, x2, col=c('red','blue')[1+y] )

= R_172.png

On peut consid�rer la variable qualitative comme une variable
num�rique, � deux valeurs, 0 et 1, et proc�der � un r�gression
lin�aire par rapport aux deux autres. On otient une expression du
genre

  Y = b0 + b1 X1 + x2 X2.

On peut alors s�parer le plan (X1,X2) en deux, le long de la droite 
d'�quation b0 + b1 X1 + x2 X2 = 1/2.

  r <- lm(y~x1+x2)
  abline( (.5-coef(r)[1])/coef(r)[3], -coef(r)[2]/coef(r)[3] )

= R_173.png

+ Application de la r�gression curvilin�aire � un probl�me de classification

La situation est la m�me que pr�c�demment, mais on fait une r�gression
de Y par rapport aux variables X1, X2, X1X2, X1^2, X2^2. 

  A FAIRE
  J'ai besoin d'une fonction pour tracer des c�niques

= R_174.png

+ Autre mani�re de r�soudre un probl�me de classification : la m�thode des plus proches voisins

La situation est encore la m�me que pr�c�demment. Cette fois-ci, pour
trouver la valeur de Y � l'aide de celles de X1 et X2, on va regarder
les 10 points de l'�chantillon les plus proches de (X1,X2), faire la
moyenne des valeurs de Y correspondantes et arrondir � 0 ou 1.

  M <- 100
  d <- function (a,b, N=10) {
    mean( y[ order( (x1-a)^2 + (x2-b)^2 )[1:N] ] )
  }
  myOuter <- function (x,y,f) {
    r <- matrix(nrow=length(x), ncol=length(y))
    for (i in 1:length(x)) {
      for (j in 1:length(y)) {
        r[i,j] <- f(x[i],y[j])
      }
    }
    r
  }
  cx1 <- seq(from=min(x1), to=max(x1), length=M)
  cx2 <- seq(from=min(x2), to=max(x2), length=M)
  contour(cx1, cx2, myOuter(cx1,cx2,d), levels=.5, add=T)

= R_175.png

Voici une autre situation, dans laquelle cette m�thode se r�v�le plus
pertinente que la pr�c�dente.

  n <- 20
  N <- 10
  s <- .1
  m1 <- rnorm(n, c(0,0))
  a <- rnorm(2*N*n, m1, sd=s)
  m2 <- rnorm(n, c(0,0))
  b <- rnorm(2*N*n, m2, sd=s)
  x1 <- c( a[2*(1:(N*n))], b[2*(1:(N*n))] )
  x2 <- c( a[2*(1:(N*n))-1], b[2*(1:(N*n))-1] )
  y <- c(rep(0,N*n), rep(1,N*n))
  plot( x1, x2, col=c('red','blue')[1+y] )
  M <- 100
  cx1 <- seq(from=min(x1), to=max(x1), length=M)
  cx2 <- seq(from=min(x2), to=max(x2), length=M)
  #text(outer(cx1,rep(1,length(cx2))),
  #     outer(rep(1,length(cx1)), cx2),
  #     as.character(myOuter(cx1,cx2,d)))
  contour(cx1, cx2, myOuter(cx1,cx2,d), levels=.5, add=T)

= R_176.png

Comparons avec ce qu'on obtient en faisant varier le nombre de voisins.

  plot( x1, x2, col=c('red','blue')[1+y] )
  v <- c(3,10,50)
  for (i in 1:length(v)) {
    contour(cx1, cx2, 
            myOuter(cx1,cx2, function(a,b){d(a,b,v[i])}), 
            levels=.5, add=T, drawlabels=F, col=i+1)
  }
  legend(min(x1),max(x2),as.character(v),col=1+(1:length(v)), lty=1)

= R_177.png

On constate qu'il ne faut pas prendre trop de points.
    
Dans le cas o� on ne prend pas les 10 points les plus proches mais
simplement le point le plus proche, on obtient un diagramme de
Vorono�.

  http://www.perlmonks.org/index.pl?node_id=189941

= perl_voronoi3.png

Il existe des variantes de cette m�thode : au lieu de faire la moyenne
sur les 10 voisins les plus proches, on peut prendre tous les points,
mais en les pond�rant selon leur distance (une telle pond�ration
s'appelle un noyau) ; au lieu de prendre la distance euclidienne, on
peut prendre une distance qui donne plus d'importance � certaines
coordonn�es ; etc.

+ R�gression robuste

A FAIRE

M-estimateurs : bas�s sur la m�thode du maximum de vraissemblance (MLE)

R-estimateurs : bas�s sur le rang (�a ne marche pas tr�s bien, en fait).

L-estimateurs : bas�s sur les quantiles (par exemple, la moyenne
tronqu�e (en anglais "trimmed mean" -- je ne sais pas si ma traduction
est correcte)).

W-estimateurs : Moindres carr�s pond�r�s (WLS: Weighted Least Squares)

WLS (Weighted Least Squares).
On calcule la r�gression et les r�sidus,on assigne � chaque individu
un poids, d'autant plus faible que le r�sidus est grand, et on fait
une nouvelle r�gression.

IRLS (Iteratively Reweighted Least Squares).
Comme pr�c�demment, mais on it�re jusqu'� ce que �a se stabilise.

  A FAIRE : sous R
  C'est la commande glm...

  x <- rnorm(20)
  y <- 1 - x + rnorm(20)
  x <- c(x,10)
  y <- c(y,1)
  plot(y~x)
  abline(lm(y~x))
  r <- glm(y~x, trace=T, epsilon=1e-14)
  abline(r, col='red')
  ???? C'est pareil

  Autre commande :
  rlm     Fit a linear model by robust regression using an M estimator.
  library(MASS)
  ?rlm
  x <- rnorm(20)
  y <- 1 + x + rnorm(20)
  x <- c(x,10)
  y <- c(y,1)
  plot(y~x)
  abline(lm(y~x))
  r <- rlm(y~x, trace=T, epsilon=1e-14)
  abline(r, col='red')
  abline(lm(y[1:20]~x[1:20]),col='blue')
  Ca ne parche pas...
  
  library(eda)
  ?line
  x <- rnorm(20)
  y <- 1 + x + rnorm(20)
  x <- c(x,10)
  y <- c(y,1)
  plot(y~x)
  abline(lm(y~x))
  abline(lm(y[1:20]~x[1:20]),col='blue')
  abline(coef(line(x,y)), col='red')
  CA MARCHE

  r <- lm(y~x)
  i <- lm.influence(r)
  c <- cooks.distance(r)
  
  Voir aussi : `dfbetas', `dffits', `covratio', `cooks.distance', `lm'.

  library(help=lqs)
  library(lqs)
  ...

  A FAIRE : 
  plot(y~x)
  panel.smooth(x,y)

Utilisation de l'estimation robuste.  On fait une r�gression classique
et une r�gression robuste.  Si les deux diff�rent, c'est mauvais
signe...  On trace le graphe des poids en fonction des r�sidus : c'est
sur une courbe en forme de cloche, sur laquelle on voit bien les
points influents (leur poids est faible). On essayer alors de faire
une nouvelle r�gression (� la fois classique et robuste) sans ces
points. Si le r�sultat diff�re, c'est mauvais signe.

  A FAIRE : exemple

+ Probl�matique de l'anova simple : comparaison de trois moyennes

Il s'agit d'un test de comparaison des moyennes, exactement comme le test T de Student, 
mais avec un nombre quelconque d'�chantillons (et pas seulement deux).

Conditions d'application : les �chantillons sont normaux et de m�me variance.

On peut aussi reformuler les choses ainsi : on dispose de deux
variables, X et Y, la variable Y est quantitative (c'est la quantit�
dont la moyenne nous int�resse) et la variable X est qualitative (elle
nous donne le num�ro de l'�chantillon). On essaye de voir si Y d�pend
de X (i.e., on essaye de faire une r�gression de Y en fonction de X).

Simulation :

  N <- 10
  a <- rnorm(N)
  b <- rnorm(N)
  c <- rnorm(N)
  d <- rnorm(N)
  df <- data.frame( y=c(a,b,c,d), x=factor(c(rep(1,N),rep(2,N),rep(3,N),rep(4,N))) )
  plot( y ~ x, data=df )

= R_128.png

  plot(density(df$y,bw=1), xlim=c(-6,6), ylim=c(0,.5), type='l')
  points(density(a,bw=1), type='l', col='red')
  points(density(b,bw=1), type='l', col='green')
  points(density(c,bw=1), type='l', col='blue')
  points(density(d,bw=1), type='l', col='yellow')

= R_129.png

+ Motivation de l'ANOVA simple

Le graphique ci-dessous repr�sente la valeur d'une variable
statistique sur trois �chantillons. On cherche � savoir si ces trois
�chantillons proviennent de la m�me population. Pour cela, on regarde
la moyenne de notre variable statistique. Ces trois moyennes sont
diff�rentes, mais ces diff�rences sont-elles suffisemment importantes
pour �tre statistiquement significatives ? On constate que les
diff�rences entre les moyennes sont relativement importantes par
rapport � la << largeur >> des courbes en cloche, qui ne se
chevauchent presque pas. Pour cette raison, on rejettera l'hypoth�se
<< les moyennes sont identiques >>.

  curve( dnorm(x-2), from=-6, to=6, col='red' )
  curve( dnorm(x+2), add=T, col='green')
  curve( dnorm(x+2+.2), add=T, col='blue')
  curve( dnorm(x+2-.3), add=T, col='yellow')
  x <- c(2, -2, -2.2, -1.7)
  segments( x, c(0,0,0,0), x, rep(dnorm(0),4), col=c('red', 'green', 'blue', 'yellow') )
       
= R_131.png

C'est tout le contraire dans la figure suivante. Bien que les moyennes
des �chantillons soient exactement les m�mes que dans le cas
pr�c�dent, les diff�rences entre ces moyennes sont relativement
petites par rapport � la largeur des courbes en cloche, qui se
recoupent beaucoup. Pour cette raison, on ne rejettera pas l'hypoth�se
<< les moyennes sont �gales >>.

  s <- 3
  curve( dnorm(x-2, sd=s), from=-6, to=6, col='red' )
  curve( dnorm(x+2, sd=s), add=T, col='green')
  curve( dnorm(x+2+.2, sd=s), add=T, col='blue')
  curve( dnorm(x+2-.3, sd=s), add=T, col='yellow')
  x <- c(2, -2, -2.2, -1.7)
  segments( x, c(0,0,0,0), x, rep(dnorm(0, sd=s),4), 
            col=c('red', 'green', 'blue', 'yellow') )

= R_132.png

Pour quantifier ces raisonnements qualitatifs et graphiques, il nous
faut une mesure de la largeur des courbes en cloche : on pourrait
prendre la variance de chaque �chantillon, mais comme on pr�f�re
n'avoir qu'un seul nombre, on prendra la moyenne de ces variances (si
les trois �chantillons proviennent de la m�me population, on obtient
un estimateur sans biais de la variance de la population). Il nous
faut aussi une mesure de la dispersion des moyennes : on pourrait
prendre la variance des moyennes, mais pour comparer avec l'estimateur
pr�c�dent, on va la transformer en un estimateur de la variance de la
population, en la multipliant par la taille des �chantillons. 

Finalement, on est amen� � consid�rer le quotient
(n d�signe la taille de chaque �chantillon)

       n * (variance des moyennes)
  F = -----------------------------
          moyenne des variances

Si F >> 1, on rejette l'hypoth�se d'�galit� des moyennes, si F est
petit, on ne la rejette pas. C'est donc un test asym�trique. On
d�montre que si les moyennes sont �gales, l'esp�rance de F est 1 ; si
elles sont diff�rentes, l'esp�rance est plus grande que 1. Il arrive
bien s�r que F<1 : dans ce cas on ne rejette pas l'hypoth�se.

Ce quotient, F, suit une loi de F � ********* et ********* degr�s de
libert�.  Voici le graphe de la fonction de distribution de ces lois.
Quand le premier param�tre cro�t, le maximum se d�place vers le bas �
droite, quand le second cro�t, il se d�place vers le haut.

  curve( df(x, 2, 2), from=0, to=4, ylim=c(0,1) )
  curve( df(x, 2, 10), add=T, col='red' )
  curve( df(x, 4, 2),  add=T, col='green' )
  curve( df(x, 4, 6),  add=T, col='green' )
  curve( df(x, 4, 10), add=T, col='green' )
  curve( df(x, 4, 20), add=T, col='green' )
  curve( df(x, 6, 2),  add=T, col='blue' )
  curve( df(x, 6, 6),  add=T, col='blue' )
  curve( df(x, 6, 10), add=T, col='blue' )
  curve( df(x, 6, 20), add=T, col='blue' )
  
= R_133.png

+ Autre motivation de l'anova

A FAIRE : variance = variance expliqu�e + variance r�siduelle

+ Exemple d'ANOVA simple, � la main

On pourrait suivre textuellement la d�finition.

  n <- 10
  a <- rnorm(n)
  b <- rnorm(n)
  c <- rnorm(n)
  d <- 1+rnorm(n)
  sx2 <- var(c( mean(a), mean(b), mean(c), mean(d) ))
  sp2 <- mean(c( var(a), var(b), var(c), var(d) ))
  MSbetween <- n * sx2
  dlbetween <- 4-1
  MSwithin <- sp2
  dlwithin <- 4*(n-1)
  F <- MSbetween / MSwithin

On trouve :

  >   F
  [1] 5.137807

Mais g�n�ralement, on fait les calculs diff�remment, en se rappelant
que la variance peur se calculer � l'aide de sommes de carr�s :

  Var(X) = E[ (X-EX)^2 ]
         = E[X^2] - (EX)^2

On pr�sente alors les calculs ainsi.

  # La somme des valeurs
  sa <- sum(a)
  sb <- sum(b)
  sc <- sum(c)
  sd <- sum(d)
  s <- sa + sb + sc + sd
  # La somme des carr�s
  ssa <- sum(a^2)
  ssb <- sum(b^2)
  ssc <- sum(c^2)
  ssd <- sum(d^2)
  ss <- ssa + ssb + ssc + ssd
  # Les valeurs qui nous int�ressent
  # SS = Sum of Squares
  # MS = Mean Square
  # effect = between = variance expliqu�e
  SSeffect <- (sa^2/n + sb^2/n + sc^2/n + sd^2/n) - s^2/(4*n)
  dleffect <- 4-1
  MSeffect <- SSeffect/dleffect
  SStotal <- ss - s^2/(4*n) # ????
  # error = within = residuals = variance r�siduelle
  SSerror = SStotal - SSeffect
  dlerror <- 4*(n-1)
  MSerror <- SSerror/dlerror
  F <- MSeffect / MSerror
 
  res <- matrix( nrow=3, ncol=5 )
  rownames(res) <- c("Effect", "Error", "Total")
  colnames(res) <- c("SS", "df", "MS", "F", "p-value")
  res[,1] <- c(SSeffect, SSerror, SStotal)
  res[,2] <- c(dleffect, dlerror, dleffect+dlerror)
  res[,3] <- c(MSeffect, MSerror, NA)
  res[,4] <- c(F, NA, NA)
  res[,5] <- c(1-pf(F,dleffect,dlerror), NA, NA)
  print(res, na.print="")

On obtient :

               SS df        MS        F    p-value
  Effect 15.18513  3 5.0617083 5.137807 0.00463538
  Error  35.46678 36 0.9851884
  Total  50.65191 39

+ Exemple d'ANOVA simple, � la main

A FAIRE : EFFACER ???

Sous ce nom trompeur se cachent des tests statitiques pour comparer
plusieurs moyennes (et pas seulement deux, comme avec le test T de
Student). On parle d'<< analyse de la variance >> car on compare ces
moyennes en regardant la moyenne des variances de chaque �chantillon
et la variance des moyennes des �chantillons. Si les �chantillons
proviennent de la m�me population, on obtient le m�me r�sultat (� un
facteur pr�s).

Prenons un exemple, et traitons-le en entier � la main : les trois
�chantillons suivants proviennent-ils du m�me �chantillon ?

  a <- c(47, 53, 49, 50, 46)
  b <- c(55, 54, 58, 61, 52)
  c <- c(54, 50, 51, 51, 49)

  boxplot(list(a,b,c))

= R_125.png

On calcule la variance des moyennes et la moyenne des variances.

  vm <- var(c(mean(a),mean(b),mean(c)))
  mv <- mean(var(a),var(b),var(c))

On regarde leur quotient.

  res <- vm/mv

On trouve 1.733333, que l'on compare avec ce que l'on devrait obtenir.

  N <- 10000
  n <- 5
  x <- NULL
  for (i in 1:N) {
    a <- rnorm(n)
    b <- rnorm(n)
    c <- rnorm(n)
    vm <- var(c(mean(a),mean(b),mean(c)))
    mv <- mean(var(a),var(b),var(c))
    x <- append(x, vm/mv)
  }
  x <- sort(x)
  plot(x ~ seq(0,1,length=length(x)), log="y", type="l")
  p <- sum(x>res)/length(x)
  p
  points(1-p,res, pch=4, lwd=3, col="red")

  A FAIRE : il me semble qu'on devrait �tre toujours du m�me 
  c�t� de 1, or ce n'est pas le cas. Pourquoi ????????????????
  Parce que je n'ai pas renormalis� comme il faut...
  Il aurait fallu renormaliser par 
    x <- append(x, vm/mv)
  mais �a ne marche pas pour autant...
  Ca devrait �tre toujours au dessus de 1, mais plus d'une fois sur deux,
  c'est en dessous.

On trouve 0.0341 et on rejette l'hypoth�se 
H0 : << les trois �chantillons ont la m�me moyenne >>
avec un risque d'erreur de 5%.

  A FAIRE : trouver comment R est capable de faire �a tout seul.

Remarque : voici une autre mani�re de justifier ces calculs.  On peut
montrer que la variance totale (de la r�union des trois �chantillons)
est la somme de la variance des moyennes (aussi appel�e variance
inter-classes) et de la moyennes des variances (aussi appel�e variance
intra-classes) ; il est donc naturel de consid�rer leur quotient.

Remarque : on peut formuler les choses diff�remment.  On a �tudi� des
donn�es statistiques bivari�es, la premi�re variable �tant qualitative
(� trois valeurs, 1, 2 et 3), la deuxi�me quantitative. Plus
pr�cis�ment, on a cherch� � savoir si la variable quantitative
d�pendait de l'autre.

A FAIRE : idem avec deux conditions.

A FAIRE : idem avec deux variables qualitatives et une table de contingence.

A FAIRE : r�gression et ANOVA

+ Exemple d'ANOVA simple, avec R

On comprend maintenant un peu mieux le r�sultat donn� par R :

  >   df <- data.frame(y=c(a,b,c,d), x=factor(c(rep(1,n),rep(2,n),rep(3,n),rep(4,n))))
  >   anova(lm(y~x,data=df))
  Analysis of Variance Table

  Response: y
            Df Sum Sq Mean Sq F value   Pr(>F)
  x          3 15.185   5.062  5.1378 0.004635 **
  Residuals 36 35.467   0.985
  ---
  Signif. codes:  0 `***' 0.001 `**' 0.01 `*' 0.05 `.' 0.1 ` ' 1

Le seul nombre qui nous int�resse, c'est la p-valeur : ici, on peut
rejeter l'hypoth�se << les quatre moyennes sont �gales >> avec un
risque d'erreur inf�rieur � 1%.

+ Le rapport de corr�lation

On d�finit le rapport de corr�lation comme le quotient 

  >   SSerror/SStotal
  [1] 0.7002063

On dit alors que << 70% de la variation est expliqu�e par la variable
explicative >>. (A FAIRE : v�rifier que j'ai bien parl� de variable
explicative plus haut)

  A FAIRE : j'ai l'impression que c'est le contraire : 70% de la
  variance n'est pas expliqu�e par la variable explicative.

  doit <- function (s) {
    n <- 100
    a <- rnorm(n, sd=s)
    b <- 1+rnorm(n, sd=s)
    y <- c(a,b)
    x <- factor(c( rep(1,n), rep(2,n) ))
    s <- summary(aov(y~x))[[1]][,2]
    s[2]/(s[1]+s[2])
  }
  doit(1)  # 0.78
  doit(.1) # 0.04

+ Tests post-hoc

Si l'analyse de la variance nous a dit que les moyennes n'�taient pas �gales, 
il faut encore savoir lesquelles sont diff�rentes.

A FAIRE :

  This is usually known as `multiple comparisons', and there is not
  much in R. There are

  1) Function Tukey in package Devore5
  2) pairwise.t.test and friends in package ctest, including p.adjust.

  but as S-PLUS users keep pointing out, multicomp there has much more.

A FAIRE : comprendre les diff�rences (s'il y en a) entre les 
tests suivants.

  Test t de Student : d�j� vu.

  Test de Bonferroni : c'est le test T de Student, mais comme
  estimateur de la variance on prend celui obtenu � l'aide de tous les
  �chantillons.

  Test de Tukey : on regarde le quotient de la valeur absolue de la
  diff�rence des moyennes par l'erreur standard (sqrt(MSerror/n)) de
  cette diff�rence

  HSD de Tukey

  LSD de Fisher (Least Significant Difference) : on fait des tests de
  Student en prenant l'estimation de la variance obtenue � l'aide de
  toute la population. (Il y a alors N-k degr�s de libert�, o� N est
  la somme des effectifs des �chantillons et k le nombre
  d'�chantillons.)

  A FAIRE

+ Th�or�me de Gauss--Markov

Les estimateurs obtenus � l'aide des moindres carr�s sont les
meilleurs estimateurs lin�aires non biais�s (BLUE: Best Linear
Unbiaised Estimators).

N�anmoins, certains estimateurs biais�s ont une variance moindre et
sont donc tr�s int�ressants.

De plus, certains estimateurs non lin�aires robustes sont plus
efficaces pour des distributions non normales.

+ Anova non param�trique

L'analyse de la variance suppose que les variables sont normales et
�quivariantes. Si ce n'est pas le cas, on peut la remplacer par le
test de Kruskal et Wallis.

  A FAIRE : exemple (trouver des donn�es concr�tes)

  A FAIRE : sur un exemple (�ventuellement construit), montrer qu'on
  obtient un r�sultat diff�rent avec l'ANOVA param�trique et non param�trique.

+ Lien avec la r�gression

On peut pr�senter les calculs que l'on fait dans une r�gression
lin�aire dans un tableau d'analyse de variance.  Et le principe des
calculs est en fait le m�me : on cherche � exprimer la variance de Y
comme somme de la variance d'une expression lin�aire en X et d'une
variance r�siduelle, en minimisant cette variance r�siduelle.

  x <- runif(10)
  y <- 1 + x + .2*rnorm(10)
  anova(lm(y~x))

La table d'analyse de variance nous dit qu'effectivement, Y d�pend de
X (avec un risque d'erreur inf�rieur � 1%).

  Analysis of Variance Table

  Response: y
            Df  Sum Sq Mean Sq F value   Pr(>F)
  x          1 0.85633 0.85633  20.258 0.002000 **
  Residuals  8 0.33817 0.04227

Ca marche toujours avec plusieurs variables.

  x <- runif(10)
  y <- runif(10)
  z <- 1 + x - y + .2*rnorm(10)
  anova(lm(z~x+y))

La table d'analyse de variance nous dit que z d�pend de x et de y, 
avec un risque d'erreur inf�rieur � 1%.

  Analysis of Variance Table

  Response: z
            Df  Sum Sq Mean Sq F value    Pr(>F)
  x          1 2.33719 2.33719  45.294 0.0002699 ***
  y          1 0.73721 0.73721  14.287 0.0068940 **
  Residuals  7 0.36120 0.05160

On peut remarquer que le r�sultat d�pend de l'ordre des param�tres.

  >   anova(lm(z~y+x))
  Analysis of Variance Table

  Response: z
            Df  Sum Sq Mean Sq F value   Pr(>F)
  y          1 2.42444 2.42444  46.985 0.000241 ***
  x          1 0.64996 0.64996  12.596 0.009355 **
  Residuals  7 0.36120 0.05160

Dans certains cas on peut m�me avoir des r�sultats contradictoires :
selon l'ordre des variables ind�pendantes, on peut tant�t trouver que
z d�pend de x, tant�t qu'il n'en d�pend pas.

  > x <- runif(10)
  > y <- runif(10)
  > z <- 1 + x + 5*y + .2*rnorm(10)

  > anova(lm(z~x+y))
  Analysis of Variance Table
  Response: z
            Df Sum Sq Mean Sq  F value    Pr(>F)
  x          1 0.0104  0.0104   0.1402    0.7192
  y          1 7.5763  7.5763 102.1495 1.994e-05 ***
  Residuals  7 0.5192  0.0742

  > anova(lm(z~y+x))
  Analysis of Variance Table
  Response: z
            Df Sum Sq Mean Sq F value    Pr(>F)
  y          1 7.1666  7.1666  96.626 2.395e-05 ***
  x          1 0.4201  0.4201   5.664   0.04889 *
  Residuals  7 0.5192  0.0742

+ Anova between et within

A FAIRE : URL de rpsych.html

A FAIRE : mettre deux pr�sentations diff�rentes de l'anova within,
l'une avec mon exemple construit, l'autre avec un exemple r�el.

Consid�rons les trois variables statistiques suivantes.

  n <- 100
  s <- .1
  x <- rnorm(n)
  y <- x + s*(1+rnorm(n))
  z <- x - s*(1+rnorm(n))
  pairs(data.frame(x,y,z))

  a <- c(x,y,z)
  b <- factor(c(rep(1,n),rep(2,n),rep(3,n)))
  plot(a~b)

= R_158.png

On se demande si les moyennes de ces trois groupes sont sensiblement
diff�rentes.

  > anova(lm(a~b))
  Analysis of Variance Table

  Response: a
             Df Sum Sq Mean Sq F value Pr(>F)
  b           2   1.88    0.94  0.8489 0.4289
  Residuals 297 328.59    1.11

Elles ne le sont pas.

N�anmoins, on remarque que l'on a presque toujours y>x>z.

  plot( y ~ x, col='red' )
  points( z ~ x, col='blue' )
  abline(0,1)

= R_159.png

L'analyse de la variance peut nous aider � le voir : on va s�parer les
variations dues � la variable b des variations dues � l'individu sur
lequel on mesure les variables x, y et z. On fait cela en ajoutant un
terme d'erreur, dans lequel on pr�cise qu'il faut s�parer la
variance en plusieurs morceaux.

  individu <- factor(c(1:n,1:n,1:n))
  summary(aov( a ~ b + Error(individu + individu:b) ))

Il y a clairement un effet :

  Error: individu
            Df Sum Sq Mean Sq F value Pr(>F)
  Residuals 99 327.31    3.31

  Error: individu:b
             Df  Sum Sq Mean Sq F value    Pr(>F)
  b           2 1.87838 0.93919  144.97 < 2.2e-16 ***
  Residuals 198 1.28272 0.00648

On peut tenter de quantifier cet effet.

  > summary(lm(y~x))
  Call:
  lm(formula = y ~ x)

  Residuals:
       Min       1Q   Median       3Q      Max
  -0.24493 -0.05885  0.01002  0.05184  0.20581

  Coefficients:
              Estimate Std. Error t value Pr(>|t|)
  (Intercept) 0.097914   0.009393   10.42   <2e-16 ***
  x           0.996981   0.008895  112.09   <2e-16 ***
  ---
  Signif. codes:  0 `***' 0.001 `**' 0.01 `*' 0.05 `.' 0.1 ` ' 1

  Residual standard error: 0.09319 on 98 degrees of freedom
  Multiple R-Squared: 0.9923,     Adjusted R-squared: 0.9922
  F-statistic: 1.256e+04 on 1 and 98 DF,  p-value: < 2.2e-16

A FAIRE : un intervalle de confiance sur l'ordonn�es � l'origine sous
l'hypoth�se que la pente est exactement 1.

A FAIRE : dire qu'il est tr�s important de bien �crire les termes d'erreur.

A FAIRE : autres exemples de termes d'erreur :

  summary(aov(rt ~ deg * noise + Error(subj / (deg + noise)), data=MD497.df))
  summary(aov(rt ~ drug, data = Stv.df)) # Completely randomized
  summary(aov(rt ~ drug + Error(subj/drug), data = Stv.df)) # anova within subjects

  # gp is a between-subject factor, drug and dose are within-subject:
  summary(aov(effect ~ gp * drug * dose + Error(subj), data=Ela.uni)) # Incorrect
  summary(aov(effect ~ gp * drug * dose + Error(subj/(dose+drug)), data=Ela.uni))

A FAIRE : regarder les d�monstrations

  demo("lm.glm")

+ Pourquoi y a-t-il deux fonctions pour l'ANOVA ?

  aov(...)
  anova(lm(...))
  summary(aov(...))
  summary(lm(...))
  lm(...)
  glm(...)
  etc.

  La fonction glm n'est-elle pas plus g�n�rale que la fonction lm ?
  Ne peut-on donc pas oublier la fonction gml pour se limiter � la fonction glm ???

  logistic regression:
    glm with family=binomial

  log-linear model:
    glm with family=poisson

  (Thus, the "family argument specifies the link function)

A FAIRE

+ mavova ????

A FAIRE

Apparently an alternative to the aov function.

+ L'anova est un cas particulier de la r�gression

One-way anova

Anova avec une seule variable qualitative. 

On peut la pr�senter ainsi. Si la variable qualitative a K valeurs, on
la code avec K-1 variables dont les valeurs sont 0 et 1. On fait
ensuite une r�gression.

  A FAIRE : exemple et comparaison avec l'anova "directe".

Two-way Anova

Anova avec deux variables qualitatives.

On peut la pr�senter comme pr�c�demment, en rempla�ant les variables
qualitatives par plusieurs variables quantitatibes dont les seules
valeurs sont 0 et 1.

  A FAIRE : exemple et comparaison avec l'anova "directe".

On peut proc�der de m�me pour mod�liser les interactions : ce sont les
produits des variables qu'on a ajout�es.
NON : c'est un peu plus compliqu�...
Les variables ajout�es ont tant�t deux valeurs (0 et 1), tant�t trois (0, 1 et -1).

  Reprenons.
  Deux variables qualitatives U et V � 3 valeurs (a, b et c).
  On remplace U par deux variables X1 et X2.
  Si U=a, on prend X1=1 et X2=0.
  Si U=b, on prend X1=0 et X2=1.
  Si U=c, on prend X1=X2=0.
  On remplace de m�me V par deux variables X3 et X4.
  Si on ne veut pas d'interaction, le mod�le est 
  Y ~ X1 + X2 + X3 + X4

  Si on veut des interactions, on remplace U par deux variables V1, V2.
  Si U=a, on prend V1=1, V2=0.
  Si U=b, on prend V1=0, V2=1.
  Si U=b, on prend V1=V2=-1.
  On remplace de m�me V par V3, V4.
  Le mod�le est alors
  Y ~ V1 + V2 + V3 + V4 + V1V3 + V1V4 + V2V3 + V2V4
  C'est plus g�n�ral que la transformation pr�c�dente, mais plus difficile � interpr�ter...

  A FAIRE : exemple et comparaison avec l'anova directe.

+ Two-way Anova

On a deux variables explicatives.

Supposons pour l'instant que ces variables n'interagissent pas.
Le mod�le est le suivant.

  Y(i,j) = mu + A(i) + B(j) + Erreur(i,j)

On dit que A(i) est l'effet traitement et que B(j) est l'effet bloc.

  A FAIRE

  (en partivulier, dire � quoi ressemble la table d'anova : on a juste
  une ligne suppl�mentaire.

+ Anova double

C'est pareil, mais cette fois-ci, on a deux variables explicatives, X1 et X2,
qui interagissent.
On va tester les hypoth�ses suivantes :

  la moyenne de d�pend pas de la valeur de X1
  la moyenne de d�pend pas de la valeur de X2
  la moyenne de d�pend pas de la valeur de (X1,X2)

Dans les deux premiers cas, on parle d'effet principal (main effect).
Dans le second, par exemple quand on �tudie l'effet de X1 quand X2=0,
on parle d'effet simple.

Le mod�le est donc le suivant (i et j sont les valeurs prises par X1
et X2) :

  Y(i,j) = mu + A(i) + B(j) + C(i,j) + Erreur(i,j)

A FAIRE : donner un exemple dans lequel la moyenne ne d�pend pas de X1
ni de X2, mais de (X1,X2). Par exemple, on peut avoir 

  E[ Y | X=(0,0) ] > E[ Y | X=(0,1) ]
  E[ Y | X=(1,0) ] < E[ Y | X=(1,1) ]

  (faire un dessin, c'est plus clair)

  A FAIRE

  Mod�le :
  Y(i,j,k) = mu + A(i) + B(j) + C(k) + Erreur(i,j,k)
  anova(lm( Y ~ A + B + C ))
  (rappeler que l'ordre est important...)

+ Anova � facteurs crois�s avec r�p�titions

On a plusieurs variables ind�pendantes, par exemple X1 et X2, et on a
plusieurs individus pour chaque valeur de (X1,X2).

  A FAIRE : exemple concret

+ Anova � facteurs crois�s sans r�p�titions

On a plusieurs variables ind�pendantes, par exemple X1 et X2, et on a
un seul individu pour chaque valeur de (X1,X2). Dans ce cas, on n'a
pas suffisemment d'information pour �tudier l'interaction des deux
variables.

  A FAIRE : exemple concret

+ Anova � facteurs hi�rarchis�s 

  ???????

  A FAIRE

+ Choix d'un mod�le

Qu'il s'agisse de r�gression ou d'analyse de la variance, on est
toujours amen� � choisir un mod�le, qui soit le plus simple possible,
et qui n�anmoins d�crive suffisemment bien la situation. Par exemple,
si on a une dizaine de variables pr�dictives, on essaiera de r�duire
le nombre de variables (soit en en oubliant, soit en les rempla�ant
par un nombre plus petit de combinaisons lin�aires), et de r�duire le
nombre d'interactions entre ces variables. 

On est donc amen� � comparer des mod�les.

+ Comparaison de mod�les

A FAIRE

  model1 <- lm(y1 ~ x1 + x2)
  model2 <- lm(y1 ~ x1 + x2 + x3 + x4)
  anova(model1,model2)

+ Mod�le lin�aire g�n�ralis�

Il s'agit de comparer deux mod�les.

  H0 : Y = b0 + b1 x1 + ... + bm xm
  H1 : Y = b0 + b1 x1 + ... + bm xm + ... . bn xn

On compare simplement le quotient de l'estimateur de la variance de Y
donn� par les deux mod�les, qui suit une loi de F.

PROBLEME : j'ai une autre d�finition du mod�le lin�aire g�n�ralis�.

A FAIRE : exemple � la main

A FAIRE : exemple avec R

+ R�gression logistique

A FAIRE (d�j� expliqu� ailleurs dans ce document ???)

+ Comparaison de deux mod�les logistiques

A FAIRE

  H0: b1=b2=...=bH=0
  Chi2 = -2( log L(K-H) - log L(K) )
  suit une loi du Chi2 � H degr�s de libert�.
  (L d�signe la vraissemblance)



* S�ries temporelles

A FAIRE

A FAIRE : On s'efforce de r�gler la hauteur du graphique pour que la
courbe ait des pentes assez douces, aux alentours de 45 degr�s.
Donner un exemple, avec un graphique trop haut, sur lequel on ne voit
rien, et un graphique tout petit mais tr�s clair.

  ?filter
  (Exercice : compute Centered Moving Averages with it)
  library(ts)
  help(filter)
  filter(y,rep(1,12),method="convolution",sides=1)[-(1:11)]





















* Exemples, � utiliser un peu plus haut

  HairEyeColor : 3 variables quantitatives
  InsectSprays : 1 variable quantitative, 1 qualitative
  LifeCycleSavings : 5 variables quantitatives
  Titanic : 4 variables qualitatives
  ToothGrowth : 2 variables quantitatives, 1 qualitative
  UCBAdmissions : 3 variables qualitatives
  airmiles : time series
  airquality : 4 variables quantitatives (bon pour une r�gression non lin�aire)
  anscombe : tr�s bon exemple (construit) de r�gression lin�aire
  attenu: coplot?
  chickwts: une variable quantitative, une qualitative (pr�dictive)
  chickwts: bon exemple de boxplots avec des intervalles de confiance sur la m�diane
  co2: time series (looks like at+sin(bt+c))
  eurodist: dist object
  faithful: 1 quantitative variable
  freeny: 5 variables quantitatives, r�gression bien lin�aire
          (est-ce un bon exemple pour comparer des mod�les ?)
  infert: r�gression logistique
  longley: r�gression lin�aire (6 variables)
  mtcars: une dizaine de variables, tant�t qualitatives, tant�t quantitatives
  nhtemp: time series
  phones: 6 s�ries temporelles (exemple d'utilisation de matplot)
  presidents: time series
  pressure: deux variables quantitatives (exemple de r�gression non lin�aire, ou exemple d'�chelle logarithmique).
  quakes: pairplot avec beaucoup de points (on doit pouvoir r�utiliser cet exemple pour faire un peu d'alg�bre lin�aire, d'ACP et de dessins en 3D).
  randu: mauvais nombres al�atoires
  rivers: longueur de rivi�res (exemple pour la loi de Benford)
  sleep: deux variables, une num�rique, une qualitative (pr�dictive)
  data(state)
    state.area: pour la loi de Benford ?
    state.x77: plein de variables quantitatives (r�gression pas claire)
  sunspots: time series (irregular sines)
  swiss: plein de variables quantitatives, une qualitatives (pairplot avec des couleurs)
  trees: 3 variables quantitatives, coplot
  volcano: contour plot
  warpbreaks: une donn�e num�rique, deux donn�es qualitatives (pr�dictives)
              boxplot avec plusieures donn�es qualitatives

A FAIRE:

  data(package=MASS)








coplot(..., show.given=F)
xyplot (in the lattice library) supercedes the coplot command.







* A CLASSER

  ?update
  ?step
  # Que signifie le point dans les pod�les suivants ?
  data(trees)
  pairs(trees, panel = panel.smooth, main = "trees data")
  plot(Volume ~ Girth, data = trees, log = "xy")
  coplot(log(Volume) ~ log(Girth) | Height, data = trees,
         panel = panel.smooth)
  summary(fm1 <- lm(log(Volume) ~ log(Girth), data = trees))
  summary(fm2 <- update(fm1, ~ . + log(Height), data = trees))
  step(fm2)
  ## i.e. Volume ~= c * Height * Girth^2  seems reasonable







* Simulations

A FAIRE

* ANOVA

ANOVA : il s'agit toujours de tester l'�galit� de moyennes, comme dans
le test t de Student, mais cette fois-ci, on a a plus de deux. On a
donc quelque chose du genre H0 : << mu1 = mu2 = mu3 >>. On pourrait
faire un test de Student pour chaque couple de variables, mais les
risques d'erreur s'accumuleraient. L'ANOVA consiste � calculer la
variance de la population totale de deux mani�res, d'une part � l'aide
de la moyenne des variances (MSE), d'autre part � l'aide de la variance des
moyennes (MSB) : si toutes les moyennes sont �gales, on obtient le m�me
r�sultat, si elles sont diff�rentes, MSB>MSE. Le quotient de ces deux
estimations de la variance suit une loi F de Fisher (A FAIRE : A VERIFIER).

Une autre mani�re de pr�senter les choses consiste � consid�rer une
variable qualitative sur la population (dont les valeurs correspondent
aux diff�rents �chantillons) et une variable quantitative . On cherche
alors s'il y a un lien entre ces deux variables. Le mod�le peut alors s'�crire

  Y(omega) = mu + alpha(X(omega)) + epsilon(omega)

X est la variable qualitative, epsilon un terme d'erreur et omega un
�l�ment de l'univers.

A FAIRE : exemple.

  ?aov

Voici encore une autre mani�re de pr�senter les choses : on peut
remplacer la variable quantitative par l'effectif des classes.

A FAIRE : exemple et interpr�tation.

Dans le cas de deux variables qualitatives, on peut tester l'effet de
la premi�re variable sur les effectifs, l'effet de la deuxi�me (on
parle d'effet principal ou marginal), et l'effet combin� des deux (on
parle d'effet simple). Cela fait trois tests.

  A FAIRE : exemple
  Faire un tableau, ajouter les effectifs marginaux, 
  et indiquer sur quelles cases on fait les tests.

  A FAIRE : expliquer comment on peut repr�sentere cela sur un dessin.

  ?coplot
  coplot(y1 ~ x1 | z1) 

between-subject design : on consid�re qu'il n'y a pas de diff�rence
entre les individus.

in-subject design : on consid�re qu'il y a une diff�rence entre les
sujets. C'est souvent le cas dans les exp�riences de psychologie : on
fait subir diff�rentes exp�riences aux sujets. Mais c'est le m�me
individu qui subit ces exp�riences. 

Carry-over effects : dans un in-subject design, il faut que les tests
que l'on fait subir aux individus soient ind�pendants (par exemple, si
on demande au sujet de r�aliser une tache dans certaines conditions,
pui ensuite dans d'autres conditions, il rique de se souvenir de ce
qu'il a fait la premi�re fois.

ANOVA for an in-subject design : les conditions (normalit� et
sph�ricit�) sont tr�s importantes.

ANOVA for an in-subject design : pratiquement, le tableau des
r�sultats a une ligne de plus, correspondant aux sujets.

A FAIRE : exemple

* R for psychologists

Diff�rentes mani�res de fabriquer des tables

  ?table
  ?ave
  ?by (quand on �tudie une variable quantitative par rapport � une/des variables(s) quantitative(s))

matplot

  sines <- outer(1:20, 1:4, function(x, y) sin(x / 20 * pi * y))
  matplot(sines, pch = 1:4, type = "o", col = rainbow(ncol(sines)))

Aussi pour des nuages de points :

  data(iris)                  # is data.frame with  `Species' factor
  table(iris$Species)
  iS <- iris$Species == "setosa"
  iV <- iris$Species == "versicolor"
  op <- par(bg = "bisque")
  matplot(c(1, 8), c(0, 4.5), type= "n", xlab = "Length", ylab = "Width",
          main = "Petal and Sepal Dimensions in Iris Blossoms")
  matpoints(iris[iS,c(1,3)], iris[iS,c(2,4)], pch = "sS", col = c(2,4))
  matpoints(iris[iV,c(1,3)], iris[iV,c(2,4)], pch = "vV", col = c(2,4))
  legend(1, 4, c("    Setosa Petals", "    Setosa Sepals",
                 "Versicolor Petals", "Versicolor Sepals"),
         pch = "sSvV", col = rep(c(2,4), 2))

Ne pas oublier de parler de 

  par(mfcol=c(3,2))
  sink("foo.result")

Paired t-test

  t.test(a1,b1,paired=TRUE)

  plot(a1,b1)
  abline(0,1)

  # Other plot
  matplot(t(cbind(a1,b1)),type="l")

Observe-t-on A plus souvent que B ?

  prop.test(sum(a1>b1), sum(a1>b1)+sum(a1<b1)).

Chi-test

  a1 <- c(1,1,1,1,1,1,1,0,0,0,0,0,0)
  b1 <- c(1,1,1,1,1,1,0,0,0,0,0,0,1)
  chisq.test(a1,b1)

On rappelle que ce test n'est qu'une approximation
(d'ailleurs, R nous le dit).
Pour une table 2x2, on peut utiliser le test (exact) de Fisher.

  fisher.test(a1,b1)

Voir aussi :

  ?loglin
  library(MASS)
  ?logml

Corr�lation ???

  cor.test(a1,b1) 

Partial correlation is the correlation of the residuals.

  cor(lm(x1~z1)$resid,lm(y1~z1)$resid)

Factor Analysis ???

  factanal(m1,factors=3)

???

  v1 <- kmeans(x1,3)$cluster
  matplot(t(v1),t="l")

Standardize :

  ?scale

On ne peut pas comparer des mod�les en les regardant s�par�m�nt.

  summary(lm(y ~ x1 + x2))
  summary(lm(y1 ~ x1 + x2 + x3 + x4))

  model1 <- lm(y1 ~ x1 + x2)
  model2 <- lm(y1 ~ x1 + x2 + x3 + x4)
  anova(model1,model2)

  A FAIRE : comparaison de mod�les
  library(MASS)
  ?addterm
  data(quine)
  quine.hi <- aov(log(Days + 2.5) ~ .^4, quine)
  quine.lo <- aov(log(Days+2.5) ~ 1, quine)
  addterm(quine.lo, quine.hi, test="F")

Simulations

  v1 <- matrix(sample(c(1, 2, 3, 4, 5), size=1000, replace=T), ncol=10)

Une autre mani�re de remplir des matrices ou des vecteurs.

  nsub1 <- nrow(q1)
  cors1 <- rep(NA,ns)
  for (i in 1:nsub1) cors1[i] <- cor(m1[i,],m2[i,])

AOV (within-subject) :

  data1<-c(
  49,47,46,47,48,47,41,46,43,47,46,45,
  48,46,47,45,49,44,44,45,42,45,45,40,
  49,46,47,45,49,45,41,43,44,46,45,40,
  45,43,44,45,48,46,40,45,40,45,47,40) # across subjects then conditions

  matrix(data1, ncol= 4, 
         dimnames = list(paste("subj", 1:12), c("Shape1.Color1", "Shape2.Color1", 
                         "Shape1.Color2", "Shape2.Color2")))        

  Hays.df <- data.frame(rt = data1, 
  subj = factor(rep(paste("subj", 1:12, sep=""), 4)),
  shape = factor(rep(rep(c("shape1", "shape2"), c(12, 12)), 2)),
  color = factor(rep(c("color1", "color2"), c(24, 24))))

  aov(rt ~ shape * color + Error(subj/(shape+color)), data=Hays.df)
  aov(rt ~ shape * color + Error(subj + subj:shape + subj:color), data=Hays.df)

  What goes inside the Error() statement, and the order in which they
  are arranged, are very important in ensuring correct statistical
  tests.

  Here we show you two examples of common errors. The first mistakenly
  computes the repeated measure design as if it was a randomized,
  between-subject design. The second only separates the subject error
  stratum. The aov() function will not prevent you from fitting these
  models because they are legitimate. But the tests are not what we
  want.

  summary(aov(rt ~ (shape * color) * subj, data=Hays.df))
  summary(aov(rt ~ shape * color + Error(subj), data=Hays.df))

Autre exemple (tir� du m�me document, � ne pas reprendre directement)

  MD497.dat <- matrix(c(
  420, 420, 480, 480, 600, 780,
  420, 480, 480, 360, 480, 600,
  480, 480, 540, 660, 780, 780,
  420, 540, 540, 480, 780, 900,
  540, 660, 540, 480, 660, 720,
  360, 420, 360, 360, 480, 540,
  480, 480, 600, 540, 720, 840,
  480, 600, 660, 540, 720, 900,
  540, 600, 540, 480, 720, 780,
  480, 420, 540, 540, 660, 780),
  ncol = 6, byrow = T)  # byrow=T so the matrix's layout is exactly like this
  
  MD497.df <- data.frame(
  rt    = as.vector(MD497.dat),
  subj  = factor(rep(paste("s", 1:10, sep=""), 6)),
  deg   = factor(rep(rep(c(0,4,8), c(10, 10, 10)), 2)),
  noise = factor(rep(c("no.noise", "noise"), c(30, 30))))

  taov <- aov(rt ~ deg * noise + Error(subj / (deg + noise)), data=MD497.df)
  summary(taov)

...

  summary(aov(rt ~ drug + Error(subj/drug), data = Stv.df))       
  summary(aov(rt ~ drug, data = Stv.df))



Un exemple assez long (un graphique fait � la main).

  Ela.mat <-matrix(c(
  19,22,28,16,26,22,
  11,19,30,12,18,28,
  20,24,24,24,22,29,
  21,25,25,15,10,26,
  18,24,29,19,26,28,
  17,23,28,15,23,22,
  20,23,23,26,21,28,
  14,20,29,25,29,29,
  16,20,24,30,34,36,
  26,26,26,24,30,32,
  22,27,23,33,36,45,
  16,18,29,27,26,34,
  19,21,20,22,22,21,
  20,25,25,29,29,33,
  21,22,23,27,26,35,
  17,20,22,23,26,28), nrow = 16, byrow = T)

  Ela.mul <- cbind.data.frame(subj=1:16, gp=factor(rep(1:2,rep(8,2))), Ela.mat)
  dimnames(Ela.mul)[[2]] <-
  c("subj","gp","d11","d12","d13","d21","d22","d23") # d12 = drug 1, dose 2

  Ela.uni <- data.frame(effect = as.vector(Ela.mat),
  subj = factor(paste("s", rep(1:16, 6), sep="")), 
  gp = factor(paste("gp", rep(rep(c(1, 2), c(8,8)), 6), sep="")),
  drug = factor(paste("dr", rep(c(1, 2), c(48, 48)), sep="")),
  dose=factor(paste("do", rep(rep(c(1,2,3), rep(16, 3)), 2), sep="")), 
  row.names = NULL)

  attach(Ela.uni)

  tmean <- tapply(effect, IND = list(gp, drug, dose), mean)
  tse   <- tapply(effect, IND = list(gp, drug, dose), se)
  tbarHeight <- matrix(tmean, ncol=3) 
  dimnames(tbarHeight) <- list(c("gp1dr1","gp2dr1","gp1dr2","gp2dr2"), 
            c("dose1","dose2" ,"dose3")) 
  tn <- tapply(effect, IND = list(gp, drug, dose), length)
  tu <- tmean + qt(.975, df=tn-1) * tse    # upper bound of 95% confidence int.
  tl <- tmean + qt(.025, df=tn-1) * tse    # lower bound
  tcol <- c("blue", "darkblue", "yellow", "orange")  # color of the bars

  tbars <- barplot(height=tbarHeight, beside=T, space=c(0, 0.5), 
                   ylab="", xlab="", axes=F, names.arg=NULL, ylim=c(-15, 40), 
                   col=tcol)

  segments(x0=tbars, x1=tbars, y0=tl, y1=tu)
  segments(x0=tbars-.1, x1=tbars+0.1, y0=tl, y1=tl)    # lower whiskers
  segments(x0=tbars-.1, x1=tbars+0.1, y0=tu, y1=tu)    # upper whiskers

  axis(2, at = seq(0, 40, by=10), labels = rep("", 5), las=1)
  tx <- apply(tbars, 2, mean)   # center positions for 3 clusters of bars

  segments(x0=0, x1=max(tbars)+1.0, y0=0, y1=0, lty=1, lwd = 2)
  text(c("Dose 1", "Dose 2", "Dose 3"), x = tx, y = -1.5, cex =1.5)
  mtext(text=seq(0,40,by=10), side = 2, at = seq(0,40,by=10), 
        line = 1.5, cex =1.5, las=1)
  mtext(text="Drug Effectiveness", side = 2, line = 2.5, at = 20, cex =1.8)

  tx1 <- c(0, 1, 1, 0)
  ty1 <- c(-15, -15, -13, -13)
  polygon(x=tx1, y=ty1, col=tcol[1])
  polygon(x=tx1, y=ty1 + 2.5, col=tcol[2])  # 2nd, moved 2.5 points up
  polygon(x=tx1, y=ty1 + 5, col=tcol[3])    # 3rd
  polygon(x=tx1, y=ty1 + 7.5, col=tcol[4])  # last

  text(x = 2.0, y = -14, labels="group 1, drug 1",  cex = 1.5, adj = 0)
  text(x = 2.0, y = -11.5, labels="group 2, drug 1",  cex = 1.5, adj = 0)
  text(x = 2.0, y = -9, labels="group 1, drug 2",  cex = 1.5, adj = 0)
  text(x = 2.0, y = -6.5, labels="group 2, drug 2",  cex = 1.5, adj = 0)

A la fin, il y a une explication sur l'argument Error de 
la commande aov. 

  A FAIRE : A LIRE

R�gression logistique. Il s'agit maintenant de pr�dire la valeur
d'une variable qualitative � deux valeurs � l'aide de variables
quantitatives. Pour une seule variable, on part de 

  P( Y=1 ) = exp(X) / (1 + exp(X) )

qui s'�crit encore 

  ln( P(Y) / (1-P(Y)) ) = X. 

On essaye donc d'�crire 

  ln( P(Y) / (1-P(Y)) ) = a0 + a1 X1 + a2 X2 + ...

Sous R la fonction est glm (Generalized Linear Model).
L'argument "binomial" dit quelle transformation il faut utiliser.

  summary(glm(y ~ x1 + x2 + x3, family=binomial))

On a aussi souvent besoin de connaitre la pertinence du mod�le.

  glm1 <- glm(y ~ x1 + x2 + x3, family=binomial)
  glm0 <- glm(y ~ 1, family=binomial)
  anova(glm0,glm1,test="Chisq")

Mod�les log-lin�aires

  ?glm

* Exemples fabriqu�s

(c'est moi qui les fabrique)

+ Test d'ind�pendance de deux variables qualitatives

  x <- sample( c(rep(0,3),rep(1,7)), 10, replace=T )
  y <- sample( c(0,1), 10, replace=T )

La commande table permet d'avoir le r�sultat sous forme de tableau de
contingence.

  > table(x,y)
     y
  x   0 1
    0 2 0
    1 6 2

On peut faire un test d'ind�pendance en utilisant le Chi2.

  > chisq.test(x,y, correct=T)

        Pearson's Chi-squared test with Yates' continuity correction

  data:  x and y
  X-squared = 0.0391, df = 1, p-value = 0.8433

  Warning message:
  Chi-squared approximation may be incorrect in: chisq.test(x, y, correct = T)

R nous rappelle � juste titre que le Chi2 n'est qu'une approximation :
dans ce cas pr�cis, elle n'est probablement pas valable (si on a plus
de 30 individus et si chaque case du tableau de contingence contient
un nombre au moins �gal � 5, on peut y aller les yeux ferm�s, mais
ici...). On peut alors faire un test plus exact, celui de Fisher.

  > fisher.test(t)

        Fisher's Exact Test for Count Data

  data:  t
  p-value = 1
  alternative hypothesis: true odds ratio is not equal to 1
  95 percent confidence interval:
   0.03845334        Inf
  sample estimates:
  odds ratio
         Inf

Je ne comprends pas pourquoi il donne souvent (pr�s d'une fois sur deux, 
d'apr�s le graphique suivant) une p-valeur �gale � 1.

  N <- 10000
  f <- NULL
  c <- NULL
  for (i in 1:N) {
    x <- sample( c(rep(0,3),rep(1,7)), 10, replace=T )
    y <- sample( c(0,1), 10, replace=T )
    x <- factor(x, levels=c(0,1))
    y <- factor(y, levels=c(0,1))
    t <- table(x,y)
    f <- append(f, fisher.test(t)$p.value)
    c <- append(c, chisq.test(t)$p.value)
  }
  plot(sort(f), type='l')
  points(sort(c), type='l', col='red')

=R_122.png

Voici n�anmoins un exemple o� on n'a pas 1.

  > x <- sample( c(rep(0,3),rep(1,7)), 10, replace=T )
  > y <- sample( c(0,1), 10, replace=T )
  > t <- table(x,y)
  > t
     y
  x   0 1
    0 4 1
    1 1 4
  > chisq.test(t)

        Pearson's Chi-squared test with Yates' continuity correction

  data:  t
  X-squared = 1.6, df = 1, p-value = 0.2059

  Warning message:
  Chi-squared approximation may be incorrect in: chisq.test(t)
  > fisher.test(t)

        Fisher's Exact Test for Count Data

  data:  t
  p-value = 0.2063
  alternative hypothesis: true odds ratio is not equal to 1
  95 percent confidence interval:
     0.45474 968.76176
  sample estimates:
  odds ratio
     10.9072

Calculons notre propre p-valeur � l'aide d'une simulation.

  x <- sample( c(rep(0,3),rep(1,7)), 10, replace=T )
  y <- sample( c(0,1), 10, replace=T )
  x <- factor(x, levels=c(0,1))
  y <- factor(y, levels=c(0,1))
  pValeur <- function (x,y, N=1000) {
    x <- factor(x)
    y <- factor(y)
    s <- numeric(N)
    for (i in 1:N) {
      xx <- sample( x, length(x), replace=T )
      yy <- sample( y, length(y), replace=T )
      s[i] <- as.numeric(chisq.test(table(xx,yy))$statistic)
    }
    t <- table(x,y)
    p <- sum( chisq.test(t)$statistic > s )/length(s)
    if( p>.5 ) p <- 1-p
    p
  }
  t <- table(x,y)
  c( ChiSq = chisq.test(t)$p.value, Fisher = fisher.test(t)$p.value, MonteCarlo = pValeur(x,y)
 )

Repr�sentons maintenant nos trois p-valeurs sur un m�me graphique.

  N <- 100
  f <- NULL
  c <- NULL
  s <- NULL
  for (i in 1:N) {
    x <- sample( c(rep(0,3),rep(1,7)), 10, replace=T )
    y <- sample( c(0,1), 10, replace=T )
    x <- factor(x, levels=c(0,1))
    y <- factor(y, levels=c(0,1))
    t <- table(x,y)
    f <- append(f, fisher.test(t)$p.value)
    c <- append(c, chisq.test(t)$p.value)
    s <- append(s, pValeur(x,y,100))
  }
  plot(sort(f), type='l')
  points(sort(c), type='l', col='green')
  points(sort(s), type='l', col='red')

  # J'ai de TR�S gros doutes sur la pertinence de mes calculs...
  # A FAIRE

= R_123.png

+ Exemples d'Anova

  library(MASS)
  data(anorexia)
  A FAIRE : dessin
  coplot(Postwt ~ Prewt | Treat, data=anorexia)
  plot(Postwt ~ Prewt, col=(2:10)[Treat])
  plot( Postwt - Prewt ~ Treat)
  A FAIRE : les traitements ont-ils la m�me efficacit� ?
  ?aov

  A FAIRE : comprendre les exemples de 
  ?bacteria

Avec une dizaine de variables :

  data(biopsy)

Comprendre des formules du genre :

  data(nlschools)
  library(nlme)
  nl1 <- nlschools
  attach(nl1)
  classMeans <- tapply(IQ, class, mean)
  nl1$IQave <- classMeans[as.character(class)]
  nl1$IQ <- nl1$IQ - nl1$IQave
  detach()
  cen <- c("IQ", "IQave", "SES")
  nl1[cen] <- scale(nl1[cen], center = TRUE, scale = FALSE)

  nl.lme <- lme(lang ~ IQ*COMB + IQave + SES,
                random = ~ IQ | class, data = nl1)
  summary(nl.lme)

Test non param�trique de la m�diane

  a <- runif(10, 0,1)
  b <- runif(10, 0,5)
  # On range les donn�es dans un Data Frame
  d <- data.frame( value = c(a,b), 
                   type  = c( rep("A",10),rep("B",10) ),
                   block = factor( c(1:10,1:10) ))
  # test non param�trique
  t <- table( d$value > mean(d$value), d$type )
  chisq.test(t) # p-value = 0.005
  # Test param�trique 
  anova(lm(value~type, data=d), test="F") # p-value = 0.0002
  # Test non param�trique
  wilcox.test(d$value[d$type=="A"], d$value[d$type=="B"]) # p-value = 0.0001
  # Kruskal--Wallis
  kruskal.test(d$value ~ d$type)
  friedman.test(d$value, d$type, d$block)
  # 
  anova(lm(value~type+other, data=d), test="F")

+ R�gression lin�aire

R�gression affine

  summary(lm(y~x))

R�gression vraiment lin�aire
(ou test sur l'annulation du coefficient)

  summary(lm(y~-1+x))

Graphiques (attention, il y en a plusieurs !!!)

  plot( lm(y~x), ask=T )

ou 

  op=par(mfrow=c(3,2))
  plot( lm(y~x) )
  par(op)
  
(les trois premiers sont faciles � comprendre ; le troisi�me est un
QQplot des r�sidus, pour v�rifier leur normalit� ; le quatri�me permet
de comparer la variance expliqu�e et la variance r�siduelle ; le
dernier donne la distance de Cook, ie, la distance entre les
param�tres estim�s avec ou sans le point, afin de rep�rer les points
aberrants).

R�gression et analyse de la variance ???

  anova(lm( y ~ x ))
  anova(lm( y ~ x+z ))
  anova(lm( y ~ x+z+w ))

R�gression polynomiale, recherche du degr� du polyn�me.

  anova(lm( y ~ x + poly(z,2) + w ), lm( y ~ x + poly(z,3) + w ) )

Ecriture du mod�le : on utilise des << + >> quand il n'y a pas d'interaction
et des << * >> quand (on pense qu') il y en a.
Un point signifie "toutes les autres variables du data frame" : 

  y~.

Lecture des r�sultats

  ?anova
  ?aov # idem, avec une interface diff�rente
  ?summary
  ?plot(..., ask=T)
  ?effects
  ?predict
  ?lm.influence
  ?glm



*********

* Divers

Comparaison de moyennes � l'aide de permutations.

  x <- c(40,40,41)
  y <- c(42,43,45)
  t.test(x,y)
  N <- 10000
  mx <- NULL
  my <- NULL
  for (i in 1:N) {
    v <- sample( c(x,y), replace=F )
    x1 <- v[1:length(x)]
    y1 <- v[length(x)+1:length(y)]
    mx <- append(mx, mean(x1))
    my <- append(my, mean(y1))
  }
  pValue <- function (x, m) {
    p <- sum(x<=m)/length(x)
    if( p>.5 ) p <- sum(x>=m)/length(x)
    2*p
  }

On trouve :

  > pValue( mx, mean(x) )
  [1] 0.0934
  > pValue( my, mean(y) )
  [1] 0.0934

Alors qu'en faisant des permutations avec remplacement, (A FAIRE :
comprendre quelle est la diff�rence, au niveau de l'interpr�tation du
r�sultat) on obtiendrait :

  > pValue( mx, mean(x) )
  [1] 0.1834
  > pValue( my, mean(y) )
  [1] 0.2432

On peut repr�senter cela graphiquement

  myPlot <- function (x,m) {
    x <- sort(x)
    plot( x ~ seq(0,1,length=length(x)), type="l", lwd=3 )
    confidence <- .05
    xx <- x[ (N*confidence/2) : (N - N*confidence/2) ]
    points( xx ~ seq(confidence/2, 1-confidence/2, length=length(xx)), type="l", col="green", lwd=3)
    abline(m,0, col="red")
    p <- sum(x<=m)/length(x)
    if( p>.5 ) p <- sum(x<m)/length(x)
    points( p,m, col='red', pch=4, lwd=2 )
  }
  myPlot( mx, mean(x) )

= R_119.png
= R_120.png

Voici le graphique que l'on obtiendrait avec des �chantillons normaux
standard de 50 individus chacun.

= R_121.png

A titre de comparaison, le test de Student nous donne :

  > t.test(x,y)

        Welch Two Sample t-test

  data:  x and y
  t = -3.182, df = 2.56, p-value = 0.06215
  alternative hypothesis: true difference in means is not equal to 0
  95 percent confidence interval:
   -6.3143919  0.3143919
  sample estimates:
  mean of x mean of y
   40.33333  43.33333

Dans tous les cas, la conclusion est la m�me : on ne rejette pas 
l'hypoth�se nulle << les deux moyennes sont �gales >>.

----------------------

vocabulaire

Factorial design : on a variables qualitatives et on repr�sente le
s�sultat de l'exp�rience par un tableau de contingences. On parle de
<< factorial design >> si aucune des cases de ce tableau n'est vide.
On examine toutes ces cases, i.e., on ne se contente pas de regarder
les effectgifs marginaux.

voici mes premi�res notes sur R

A FAIRE : les int�grer � celles ci-dessus.

* Types de donn�es

+ Vecteurs

Une suite d'objets, tous de m�me type (nombre, bool�en, chaine de caract�res).

+ Data Frame

Un tableau, avec plusieures colonnes ; chaque colonne est un vecteur
et porte un titre, les colonnes peuvent �tre de types diff�rents.

* R�gression

R�gression lin�aire

  lm(y ~ x)

R�gression r�sistante (il peut y avoir des donn�es fausses).

  rlm(y ~ x)

* A CLASSER

  curve  Tracer une courbe � l'aide de son �quation

Regarder des donn�es cat�goriques.

  > table(a>5)
  FALSE  TRUE
     10     7
  > table(a)
  a
  0 1 3 4 5 6 7 8 9
  1 2 2 4 1 3 1 1 2

Histogramme (l'unit� verticale est le nombre d'�l�ments).

  > hist(a)

Histogramme (l'unit� verticale est la proportion des �l�ments --
utile pour comparer deux histogrammes r�alis�s avec des populations
diff�rentes).

  > hist(a, probability=TRUE)

= R_4

Histogramme avec des choses en plus sur l'axe horizontal (???)

  > hist(a)
  > rug(jitter(a))

= R_5

Histogramme (on sp�cifie le nombre de classes).

  > hist(a, breaks=10)

= R_6

Histogramme (on sp�cifie les classes).

  > hist(a, breaks=c(0,3,5,7,max(a)))

= R_7

Frequency polygon

  > tmp = hist(a)
  > lines( c(min(tmp$breaks),tmp$mids,max(tmp$breaks)),
           c(0,tmp$counts,0), 
           type="l")

= R_9

Densit�s

  > density(a)
  Call:
        density(x = a)
  Data: a (17 obs.);      Bandwidth 'bw' = 1.143
         x                y
   Min.   :-3.430   Min.   :0.0002538
   1st Qu.: 0.535   1st Qu.:0.0165095
   Median : 4.500   Median :0.0653932
   Mean   : 4.500   Mean   :0.0629752
   3rd Qu.: 8.465   3rd Qu.:0.1003278
   Max.   :12.430   Max.   :0.1404533
  > hist(a, probability=TRUE)
  > points(density(a),type='l')
  > points(density(a,bw=.1),type='l')

= R_10

Bar plots

  > data(package='MASS')
  > library("MASS")
  > ?biopsy
  > data(biopsy)
  > barplot(table(biopsy$class, biopsy$V7), beside=TRUE)

= R_11

  > barplot(table(biopsy$V7, biopsy$class))

= R_12

Side-by-side boxplots

  > boxplot( biopsy$V7 [biopsy$class == 'benign'], 
             biopsy$V7 [biopsy$class == 'malignant'])
  > boxplot( biopsy$V7 ~ biopsy$class )

= R_14

Boxplots to compare different data.

  > data(crabs)
  > boxplot( crabs$RW, crabs$CW)

= R_15

We may have to scale them (so that they have mean 0 and standard deviation 1).

  > boxplot( as.data.frame(scale(data.frame( crabs$RW, crabs$CW ))))

= R_16

Strip charts : an alternative to box plots

  > stripchart(crabs$RW[1:20])

= R_17

Side by side strip charts (hint: put the data in a data frame?)

  > stripchart(data.frame(crabs$RW, crabs$CW))
  > stripchart(crabs)

= R_18
= R_19

Scatter Plot

  > plot(crabs$CL, crabs$CW)

  DESSIN

Scatter plot with linear regression

  > plot(crabs$CL, crabs$CW)
  > lm( crabs$CL ~ crabs$CW )
  Call:
  lm(formula = crabs$CL ~ crabs$CW)
  Coefficients:
  (Intercept)     crabs$CW
      -0.6619       0.8998

  > summary(lm( crabs$CL ~ crabs$CW ))

  Call:
  lm(formula = crabs$CL ~ crabs$CW)

  Residuals:
      Min      1Q  Median      3Q     Max
  -1.6732 -0.4943 -0.1069  0.5915  1.6396

  Coefficients:
               Estimate Std. Error t value Pr(>|t|)
  (Intercept) -0.661948   0.238574  -2.775  0.00606 **
  crabs$CW     0.899846   0.006404 140.504  < 2e-16 ***
  ---
  Signif. codes:  0 `***' 0.001 `**' 0.01 `*' 0.05 `.' 0.1 ` ' 1

  Residual standard error: 0.7112 on 198 degrees of freedom
  Multiple R-Squared: 0.9901,     Adjusted R-squared:  0.99
  F-statistic: 1.974e+04 on 1 and 198 DF,  p-value: < 2.2e-16

  > abline(lm( crabs$CL ~ crabs$CW ))

= R_21

Histogram of residuals

  > lm.res = lm(crabs$CL ~ crabs$CW)
  > plot(residuals(lm.res))    # Non
  > hist(residuals(lm.res))

= R_22

Residual plot : on fait une r�gression, puis on fait un "scatter plot"
avec en abscisse les valeurs th�oriques et en ordonn�es les valeurs r�elles.

  A FAIRE
  DESSIN

On peut aussi repr�senter les valeurs calcul�es en abscisse et
les valeurs r�siduelles en ordonn�e.

  > ?lm
  > plot(lm.res$fitted.values, lm.res$residuals)
  > abline(0,0)

  DESSIN

Paired scatter plot

  A FAIRE

Normal plot : en abscisse, les quantiles d'une distribution normale, 
en ordonn�e, les quatiles effectivement observ�es. Si c'est une droite,
les donn�es sont normales.

  > qqnorm(a); qqline(a)

= R_24

  > qqnorm(crabs$CL); qqline(crabs$CL)

= R_25

  > x = rnorm(100); qqnorm(x); qqline(x)

= R_26

  > x = runif(100); qqnorm(x); qqline(x)

= R_27

Normal plot of residuals : do a regression and check if the residuals are 
normal.

  > lm.res = lm(crabs$CL ~ crabs$CW)
  > qqnorm(residuals(lm.res)); qqline(residuals(lm.res))

= R_28

  > x = rnorm(1000)
  > y = exp(x)
  > qqnorm(y); qqline(y)

= R_29

  > y = x[x>0]
  > qqnorm(y); qqline(y)

= R_30

  > y = rexp(1000)
  > qqnorm(y); qqline(y)

= R_31

* Manipulation des donn�es

Extraire un ou plusieurs �l�ments d'un vecteur :

  > a[1]
  [1] 1
  > a[1:3]
  [1] 1 4 9

  > a[1,3,5]
  Error in a[1, 3, 5] : incorrect number of dimensions
  > a[c(1,3,5)]
  [1] 1 9 8

Extraire un ou plusieurs �l�ments d'un vecteur � l'aide
de conditions bool�ennes.

  > a>5
   [1] FALSE FALSE  TRUE  TRUE  TRUE  TRUE FALSE FALSE  TRUE FALSE FALSE  TRUE
  [13] FALSE FALSE  TRUE FALSE FALSE
  > a[a>5]
  [1] 9 6 8 6 6 9 7

Attention aux connecteurs logiques : ce sont & et |.

  > a[a>3 & a<7]
  [1] 4 6 6 4 6 4 5 4
  > a[a<3 | a>7]
  [1] 1 9 8 9 0 1

Pour la n�gation, c'est bien !

  > a[!is.na(x)]

Compter le nombre d'�l�ments qui v�rifient une condition.

  > sum(a>5)
  [1] 7

Tri des donn�es

  > sort(a)
   [1] 0 1 1 3 3 4 4 4 4 5 6 6 6 7 8 9 9

Transformer des donn�es num�riques en donn�es cat�goriques.
(voir aussi le param�tre break de la fonction hist)

  > b = cut(a, breaks=c(0, 3, 7, 10))
  > b
   [1] (0,3]  (3,7]  (7,10] (3,7]  (7,10] (3,7]  (0,3]  (3,7]  (3,7]  (3,7]
  [11] (3,7]  (7,10] <NA>   (0,3]  (3,7]  (0,3]  (3,7]
  Levels:  (0,3] (3,7] (7,10]
  > table(b)
  b
   (0,3]  (3,7] (7,10]
       4      9      3
  > ?factor

Mise � l'�chelle des donn�es pour les comparer : si le Data Frame foo contient
deux colonnes num�riques, on peut les mettre � la m�me �chelle pour les comparer :

  bar = as.data.frame(scale(bar))

* Programmation

Boucle

  > for ( i in 1:100 ) { ... }

D�finition d'une fonction

  > f = function(x) sqrt(var(x))
  > f(a); sd(a)
  [1] 2.687115
  [1] 2.687115

D�finition d'une fonction plus longue : on ajoute des accolades ; 
la derni�re valeur calcul�e est renvoy�e.

  foo = function(x) {
    a = fivenum(x)
    a[4] - a[2]
  }

On peut voir le code d'une fonction en tapant son nom,
sans parenth�ses.

  > abline
  function (a = NULL, b = NULL, h = NULL, v = NULL, reg = NULL,
    coef = NULL, untf = FALSE, col = par("col"), lty = par("lty"),
    lwd = NULL, ...)
  {
    if (!is.null(reg))
      a <- reg
    if (!is.null(a) && is.list(a)) {
      temp <- as.vector(coefficients(a))
      if (length(temp) == 1) {
        a <- 0
        b <- temp
      }
      else {
        a <- temp[1]
        b <- temp[2]
      }
    }
    if (!is.null(coef)) {
      a <- coef[1]
      b <- coef[2]
    }
    .Internal(abline(a, b, h, v, untf, col, lty, lwd, ...))
    invisible()
  }

* A FAIRE

A FAIRE : les fonctions pnorm, qnorm. page 47

------------

Exemples de donn�es

Donn�es num�riques univari�es

     data(aircondit)

Donn�es num�riques bivari�es

     data(cars)
     plot(cars, xlab = "Speed (mph)", ylab = "Stopping distance (ft)",
          las = 1)
     lines(lowess(cars$speed, cars$dist, f = 2/3, iter = 3), col = "red")
     title(main = "cars data")

     plot(cars, xlab = "Speed (mph)", ylab = "Stopping distance (ft)",
          las = 1, log = "xy")
     title(main = "cars data (logarithmic scales)")
     lines(lowess(cars$speed, cars$dist, f = 2/3, iter = 3), col = "red")

  Autre exemple: trees

  Autre exemple:
    data(longley)
    pairs(longley)

Donn�es cat�goriques bivari�es.

  Autre exemple: Titanic

Donn�es multivari�es en partie num�riques en partie cat�goriques

  ?ToothGrotwth
  The Effect of Vitamin C on Tooth Growth in Guinea Pigs
  data(ToothGrowth)

Time series

     data(nhtemp)
     plot(nhtemp, main = "nhtemp data",
       ylab = "Mean annual temperature in New Haven, CT (deg. F)")

------------

Exemples

     data(ToothGrowth)
     coplot(len ~ dose | supp, data = ToothGrowth, panel = panel.smooth,
            xlab = "ToothGrowth data: given is supplement type")


     data(HairEyeColor)
     ## Full mosaic
     mosaicplot(HairEyeColor)
     ## Aggregate over sex:
     x <- apply(HairEyeColor, c(1, 2), sum)
     x
     mosaicplot(x, main = "Relation between hair and eye color")

     data(cars)
     plot(cars, xlab = "Speed (mph)", ylab = "Stopping distance (ft)",
          las = 1)
     lines(lowess(cars$speed, cars$dist, f = 2/3, iter = 3), col = "red")
     title(main = "cars data")
     plot(cars, xlab = "Speed (mph)", ylab = "Stopping distance (ft)",
          las = 1, log = "xy")
     title(main = "cars data (logarithmic scales)")
     lines(lowess(cars$speed, cars$dist, f = 2/3, iter = 3), col = "red")
     summary(fm1 <- lm(log(dist) ~ log(speed), data = cars))
     opar <- par(mfrow = c(2, 2), oma = c(0, 0, 1.1, 0),
                 mar = c(4.1, 4.1, 2.1, 1.1))
     plot(fm1)
     par(opar)

     ## An example of polynomial regression
     plot(cars, xlab = "Speed (mph)", ylab = "Stopping distance (ft)",
         las = 1, xlim = c(0, 25))
     d <- seq(0, 25, len = 200)
     for(degree in 1:4) {
       fm <- lm(dist ~ poly(speed, degree), data = cars)
       assign(paste("cars", degree, sep="."), fm)
       lines(d, predict(fm, data.frame(speed=d)), col = degree)
     }
     anova(cars.1, cars.2, cars.3, cars.4)


     data(Titanic)
     mosaicplot(Titanic, main = "Survival on the Titanic")
     ## Higher survival rates in children?
     apply(Titanic, c(3, 4), sum)
     ## Higher survival rates in females?
     apply(Titanic, c(2, 4), sum)
     ## Use loglm() in package `MASS' for further analysis ...


     data(trees)
     pairs(trees, panel = panel.smooth, main = "trees data")
     plot(Volume ~ Girth, data = trees, log = "xy")
     coplot(log(Volume) ~ log(Girth) | Height, data = trees,
            panel = panel.smooth)
     summary(fm1 <- lm(log(Volume) ~ log(Girth), data = trees))
     summary(fm2 <- update(fm1, ~ . + log(Height), data = trees))
     step(fm2)
     ## i.e. Volume ~= c * Height * Girth^2  seems reasonable


     data(faithful)
     f.tit <-  "faithful data: Eruptions of Old Faithful"

     ne60 <- round(e60 <- 60 * faithful$eruptions)
     all.equal(e60, ne60)             # relative diff. ~ 1/10000
     table(zapsmall(abs(e60 - ne60))) # 0, 0.02 or 0.04
     faithful$better.eruptions <- ne60 / 60
     te <- table(ne60)
     te[te >= 4]                      # (too) many multiples of 5 !
     plot(names(te), te, type="h", main = f.tit, xlab = "Eruption time (sec)")

     plot(faithful[, -3], main = f.tit,
          xlab = "Eruption time (min)",
          ylab = "Waiting time to next eruption (min)")
     lines(lowess(faithful$eruptions, faithful$waiting, f = 2/3, iter = 3),
           col = "red")


   data(longley)
     longley.x <- data.matrix(longley[, 1:6])
     longley.y <- longley[, "Employed"]
     pairs(longley, main = "longley data")
     summary(fm1 <- lm(Employed ~ ., data = longley))
     opar <- par(mfrow = c(2, 2), oma = c(0, 0, 1.1, 0),
                 mar = c(4.1, 4.1, 2.1, 1.1))
     plot(fm1)
     par(opar)


     data(precip)
     dotchart(precip[order(precip)], main = "precip data")
     title(sub = "Average annual precipitation (in.)")


     data(iris3)
     dni3 <- dimnames(iris3)
     ii <- data.frame(matrix(aperm(iris3, c(1,3,2)), ncol=4,
                        dimnames=list(NULL, sub(" L.",".Length",
                                                sub(" W.",".Width", dni3[[2]])))),
                      Species = gl(3,50,lab=sub("S","s",sub("V","v",dni3[[3]]))))
     data(iris)
     all.equal(ii, iris) # TRUE



     matplot((-4:5)^2, main = "Quadratic") # almost identical to plot(*)
     sines <- outer(1:20, 1:4, function(x, y) sin(x / 20 * pi * y))
     matplot(sines, pch = 1:4, type = "o", col = rainbow(ncol(sines)))




     x <- 0:50/50
     matplot(x, outer(x, 1:8, function(x, k) sin(k*pi * x)),
             ylim = c(-2,2), type = "plobcsSh",
             main= "matplot(,type = \"plobcsSh\" )")
     ## pch & type =  vector of 1-chars :
     matplot(x, outer(x, 1:4, function(x, k) sin(k*pi * x)),
             pch = letters[1:4], type = c("b","p","o"))

     data(iris)                  # is data.frame with  `Species' factor
     table(iris$Species)
     iS <- iris$Species == "setosa"
     iV <- iris$Species == "versicolor"
     op <- par(bg = "bisque")
     matplot(c(1, 8), c(0, 4.5), type= "n", xlab = "Length", ylab = "Width",
             main = "Petal and Sepal Dimensions in Iris Blossoms")
     matpoints(iris[iS,c(1,3)], iris[iS,c(2,4)], pch = "sS", col = c(2,4))
     matpoints(iris[iV,c(1,3)], iris[iV,c(2,4)], pch = "vV", col = c(2,4))
     legend(1, 4, c("    Setosa Petals", "    Setosa Sepals",
                    "Versicolor Petals", "Versicolor Sepals"),
            pch = "sSvV", col = rep(c(2,4), 2))

     nam.var <- colnames(iris)[-5]
     nam.spec <- as.character(iris[1+50*0:2, "Species"])
     iris.S <- array(NA, dim = c(50,4,3), dimnames = list(NULL, nam.var, nam.spec))
     for(i in 1:3) iris.S[,,i] <- data.matrix(iris[1:50+50*(i-1), -5])

     matplot(iris.S[,"Petal.Length",], iris.S[,"Petal.Width",], pch="SCV",
             col = rainbow(3, start = .8, end = .1),
             sub = paste(c("S", "C", "V"), dimnames(iris.S)[[3]],
                         sep = "=", collapse= ",  "),
             main = "Fisher's Iris Data")










------------

     for(fn in methods("predict"))
        cat(fn,":\n\t",deparse(args(get(fn))),"\n")

revoir les histoires de conversion, � partir de la page 38.
factor stack split unstack t rbind

outer paste

Je suis arriv� page 38.

* Distributions statistiques

                                loi multinomiale
                                (plusieures cat�gories d'�v�nements)

  loi hyperg�om�trique          loi binomiale                         Poisson
  (tirage sans remise)          (2 cat�gories d'�v�nements)           (p=0 ou 1)

                                Loi normale
                                (chi2, student, fisher)


  Chi_n^2 = somme des carr�s de n lois normales
  Pour n grand, Chi_n^2 ~ N(n, sqrt(2n))
  Application : intervalle de confiance de l'�cart-type.
  Dessiner le graphe de la densit� du Chi2, pour diff�rents degr�s de libert�.

  Fisher
  F_{n,m} = (Chi_n^2 / n) / (Chi_m^2 / m)
  (test F de rapport de variances,
  analyse de variance)

  Student
  T_n = N(0,1)/sqrt( Chi_n^2 / n )
      = sqrt( F_{1,n} )
  (test de comparaison de moyenne, 
  probabilit� d'observer un �cart donn� � la moyenne,
  estimation des param�tres d'une population)
  C'est la distribution de la moyenne empirique d'un 
  �chantillon de n individus d'une population de N>>n individus.
    (moyenne empirique - moyenne r�elle)/(variance empirique/sqrt(n)) ~ T_n
  Pour n>1000, T_n ~ N(0,1)
  Application : calcul d'intervalle de confiance pour
  la moyenne.

  /home/zoonek/spool/WWW/DOC/STAT/biol10.biol.umontreal.ca/BIO2041/pdf/Cours_05-Int_confiance.pdf

* bootstrap

Parfois, les distributions ne sont pas normales.
On peut se ramener � des distributions normales � l'aide
d'une transformation (log, etc.), ou par
des m�thodes de r��chantillonage, comme
le bootstrap ou le jackknife.

A FAIRE

* A CLASSER

  text   affiche du texte � un endrot du dessin
  mtext  affiche du texte dans la marge


* EN COURS

Analyse en composantes principales.

a <- Seconde13[3:7]
a <- as.matrix(a)
a[is.na(a)]=10
cov(a)
b <- eigen(cov(a), symmetric=TRUE)
x <- b$vectors[,1]
y <- b$vectors[,2]
Il faut projeter orthogonalement sur Vect(x,y)

C'est d�j� l�...

library(mva)
a <- Seconde13[3:7]
a <- as.matrix(a)
a[is.na(a)]=10
p <- princomp(a)
p
p$scores
plot( p$scores[,2] ~ p$score[,1], pch=" " )
text( p$score[,1], p$score[,2], as.vector(Seconde13[,1]) )
plot(p$sdev, type="h")

EFFACER CE QUI PRECEDE

a <- Seconde13[3:7]
a <- a - t( array( apply(a, 2, mean, na.rm=T), dim(t(a)) ))
apply(a, 2, mean, na.rm=T)
a <- as.matrix(a)
a[is.na(a)]=0
a <- a / t( array( apply(a, 2, sd), dim(t(a)) ))
apply(a, 2, sd)
library(mva)
p <- princomp(a)

# ACP :
plot( p$scores[,2] ~ p$score[,1], pch=" " )
text( p$score[,1], p$score[,2], as.vector(Seconde13[,1]) )

# Les valeurs propres
plot(p$sdev, type="h")

# Le cercle des covariances
A FAIRE

A FAIRE : la m�me chose, mais � la main.

* Bibliographie

+ W. Feller, 

A FAIRE

+ T; Hastie et al., The Elements of Statistical Learning : Data mining, Inference and Prediction, SV 2001, 72 HAS 01a

(avec des dessins en couleurs)

+ B. Fleury, A First course in multivariate Statistics, SV, 72 FLU 97a

+ E.J. Dudewicz and S.N. Mishra, Modern Mathematical Statistics, JW, 1988, 72 DUD 88a

Les six premiers chapitre constituent un cours de probabilit�s.

7,8 : estimateurs

9 : tests (en insistant sur la th�orie de la d�cision et en expliquant
d'o� viennent ces tests)

[Je n'ai pas lu le reste du livre : Interval estimation, Ranking and
selection procedures, Decision theory, Non-parametric statistical
inference, Regression and linear statistical inference, Analysis of
variance, Robust Statistical procedures (jackknife, bootstrap).]

+ A FAIRE : les r�f�rfences du livre que j'avais lu il y a quelques ann�es sur la th�orie de la d�cision.

+ D.C. Hoaglin, F. Mosteller, J.W. Tukey, Understanding Robust and Exploratory Data Analysis, 1983, 72 UND 83

stem-and-leaf displays, qqplot, symetry plot, regression, study of the residuals,
transforming data, M-estimators

Je n'ai pas compl�tement lu la partie sur les M-estimateurs.

+ A First Course in Multivariate Statistics, B. Flury, SV 1997, 72 FLU 97a

R�gression.
Si (X,Y) est une v.a. bivari�e, la r�gression de Y sur X, est
l'esp�rance de Y sachant X (c'est une fonction de x).  (Si (X,Y) est
normale ou, de mani�re plus g�n�rale, si Y=aX+b, on retrouve la notion usuelle de r�gression.)

+ L. Lebart, A. Morineau and M. Piron, Statistique exploratoire multidimensionnelle, Dunod, 1997, 72 LEB 97a

A FAIRE : comprendre les fonctions :

  princomp
  prcomp
  factanal
  kmeans
  hclust
  plot.agnes               Plots of an Agglomerative Hierarchical Clustering
  plot.diana               Plots of a Divisive Hierarchical Clustering
  plot.mona                Banner of Monothetic Divisive Hierarchical Clusterings
  plot.partition           Plot of a Partition of the Data Set

MASS : Modern Applied Statistics with S
(avec plein de jeux de donn�es)

  library(help=MASS)
  library(MASS)
  ...


R�seaux de neurones

  library(help=nnet)
  library(nnet)
  ...

S�ries temporelles

  library(help=ts)
  library(ts)
  ...

Trois types de tableaux de nombres :
valeurs d'une variable quatitative, tableau de contingence, tableau
de pr�sence-absence contenant des 0 et des 1 (sous R, ce dernier type
de tableau est plut�t un tableau dont les colonnes sont des facteurs).

A FAIRE : diff�rence entre corr�lation et covariance (la covariance a
une unit�, pas la corr�lation).

Le zoo des tests statistiques : A FAIRE

A FAIRE : le vocabulaire de la statistique est tr�s mal con�u. Des
m�thodes similaires (au niveau technique ou au niveau des applications)
portent des noms compl�tement diff�rents. Essayer de r�sumer
ce vocabulaire � l'aide d'un tableau.

Gauss-Markov Theorem: Least squares estimates of beta have the
smallest variance among all linear unbiased estimates. (But it is not
a good idea to restrict oneself to unbiased estimates...)

* A CLASSER (exemples divers)



?by

Legend under the graph (not over...)

  par("mar") # borders, see ?par
  # [1] 5.1 4.1 4.1 2.1
  # Now increase size of the bottom-border:
  par(mar=c(10.1, 4.1, 4.1, 2.1))
  # And set cpd=TRUE, so all plotting is clipped to the figure
  # (not the plot) region:
  par(xpd=TRUE)
  # Your barplot:
  bp <- barplot(1:3)
  # Text for the legend:
  legend.text <- c("cats", "dogs", "cows")
  # And plot the legend below the existing plot:
  legend(1,-0.5, legend.text, fill=heat.colors(length(legend.text)))
  # Or much nicer, center the legend:
  legend(mean(range(b)), -0.5, legend.text, xjust = 0.5,
        fill=heat.colors(length(legend.text)))

Same, horizontal.

  ## increase size of the bottom-border:
  par(mar= c(6, 4, 4, 2) + .1)
  ## Set xpd=TRUE, so all plotting is clipped to the figure
  ## (not the plot) region:
  par(xpd=TRUE)
  ## Your barplot:
  bp <- barplot(1:3)
  ## Text for the legend:
  legend.text <- c("cats", "dogs", "cows")
  ## And plot the legend below the existing plot -- centering it
  legend(mean(range(bp)), -0.3, legend.text, xjust = 0.5,
        fill=heat.colors(length(legend.text)), horiz = TRUE)

Search for outliers, Mahalanobis distance

  As I want to do some multivariate calibration using these data, I
  checked whether some multivariate outliers existed. I calculated
  Mahalanobis distances and did a

  qqplot(qchisq(ppoints(382),169),XMaha)

  where XMaha contained my Mahalanobis distances. The points on my QQ
  plot were nicely aligned onto a y=x line, so no outliers.



* A FAIRE

  Beaux exemples de graphiques :
    http://www.visualmining.com/examples/index.html

  ?plotmath
  Les symboles math�matiques dans les graphiques

  Mon probl�me avec outer() est d�crit dans la FAQ : If you have a
  function that cannot handle two vectors but can handle two scalars,
  then you can still use outer() but you will need to wrap your
  function up first, to simulate vectorized behavior. Suppose your
  function is
    foo <- function(x, y, happy) {
      stopifnot(length(x) == 1, length(y) == 1) # scalars only!
      (x + y) * happy
    }
  If you define the general function
    wrapper <- function(x, y, my.fun, ...) {
      sapply(seq(along=x), FUN = function(i) my.fun(x[i], y[i], ...))
    }
  then you can use outer() by writing, e.g.,
    outer(1:4, 1:2, FUN = wrapper, my.fun = foo, happy = 10)

  GAM (from the FAQ):
  7.17 Are GAMs implemented in R?
  There is a gam() function for Generalized Additive Models in package
  mgcv, but it is not an exact clone of what is described in the White
  Book (no lo() for example). Package gss can fit spline-based GAMs
  too. And if you can accept regression splines you can use glm(). For
  gaussian GAMs you can use bruto() from package mda.

  mixtures

  CART
  library(help=rparts)

  GAM


  EDA: Exploratory Data Analysis
  OLS: Ordinary Least Squares
  RSS: Residual Sum of Squares (la quantit� que l'on cherche � minimiser avec les OLS)

  Comment mentir avec des statistiques
  ex: faire plein de tests afin d'augmenter le risque d'erreur de type 1
  ex: prendre des hypoth�ses non sym�triques par ce qu'on veut que le
  r�sultat soit dans un sens.

  V�rifier l'ind�pendance de deux variables � l'aide d'un chi-plot.
  Andrew curve ???

  ?image
  (to plot a matrix, in image analysis)
  ?read.pnm
  (to read it from a file)

  Fitting a distribution to a given law, and finding the parameters.
  library(MASS)
  ?fitdistr

  Calculs num�riques
  Minimiser une fonction :
  ?optim
  ?lnm
  Trouver une racine (une seule variable)
  ?uniroot

  A FAIRE : modifier plot.lm
  pour ajouter qqline au qqplot des r�sidus
  et ajouter un lissage des r�sidus.

  Clustering (variante de l'ACP?)
    library(cluster)
    clusplot(a, pam(a, 3)$clustering, diss = FALSE, plotchar = TRUE, color = TRUE)

     data(votes.repub)
     votes.diss <- daisy(votes.repub)
     votes.clus <- pam(votes.diss, 2, diss = TRUE)$clustering
     clusplot(votes.diss, votes.clus, diss = TRUE, shade = TRUE)

     data(iris)
     iris.x <- iris[, 1:4]
     clusplot(iris.x, pam(iris.x, 3)$clustering, diss = FALSE,
              plotchar = TRUE, color = TRUE)

  mentionner refcard.pdf
  Pour les graphiques, renvoyer au document en espagnol (m�me si on ne parle pas cette langue -- je n'en comprends pas un mot, mais j'ai trouv� le document tr�s instructif)
  s�ries temporelles
  fr�quences cumul�es
  Intervalle de confiance pour les param�tres d'une r�gression
  ANOVA et r�gression :
    quand on fait une r�gression, 
    variance de Y = variance expliqu�e par X + variance r�siduelle
  Le Chi2 est un test courant filtrant, pour pr�venir que l'on a collect� assez de donn�es pour rejeter H0
  Le Chi2 d'ind�pendance (deux variables qualitatives)
  Parler aussi de processus (Markov, Poisson)
    file:///home/zoonek/spool/WWW/DOC/STAT/rfv.insa-lyon.fr/%257Ejolion/STAT/poly.html
  S�ries temporelles : repr�senter les points de coordonn�es (x_n, x_{n+k}), o� k est un entier fix�. Par exemple, avec un mauvais g�n�rateur al�atoire. Ca sert � rep�rer de l'ordre dans le chaos apparent.
  Tests fish�riens ou tests de permutations
  Exemple : analyse d'image
  Exemple : analyse de son
  R�seaux de neurones
  ACP apr�s avoir remplac� les variables par le rang (de Pearson)

  Tracer des suites, ou des fonctions de distribution discr�tes :
  lines(..., type='b')

  conditional logistic regression

  library(nlme)

  Contrasts in linear models

  weibull survival analysis

  Mixture Analysis: les donn�es proviennent de deux mod�les (ou plus), mais on ne sait pas � quel mod�le se ratachent les individus (typiquement : l'histogramme des donn�es a deux pics).
 
  Classification � l'aide d'une droite (on a deux variables
  quantitatives, un variable qualitative � deux valeurs, on fait un
  diagramme de dispersion sur les deux premi�res variables, on
  repr�sente les individus par un symbole diff�rent selon la valeur de
  la derni�re variable, on cherche un droite qui s�pare le plan en
  deux, selon la valeur de ce param�tre.

  Contour plot / surface repr�sentant la densit� d'une v.a. bivari�e.

  KalmanLike(ts)          Kalman Filtering
  (c'est une r�gression lin�aire incr�mentale).

+ Hauck-Donner phenomenon 

> From <@uconnvm.uconn.edu:kent@darwin.eeb.uconn.edu> Wed Jan 7 12:51 GMT 1998
> To: ripley@stats.ox.ac.uk (Prof Brian Ripley)
> Cc: s-news@utstat.toronto.edu
> Subject: Re: Summary of Robust Regression Algorithms
> From: kent@darwin.eeb.uconn.edu (Kent E. Holsinger)
>
> >>>>> "Brian" == Prof Brian Ripley <ripley@stats.ox.ac.uk> writes:
>
> Brian> My best example of this not knowing the literature is the
> Brian> Hauck-Donner (1977) phenomenon: a small t-value in a
> Brian> logistic regression indicates either an insignificant OR a
> Brian> very significant effect, but step.glm assumes the first,
> Brian> and I bet few users of glm() stop to think.
>
> All right I confess. This is a new one for me. Could some one explain
> the Hauck-Donner effect to me? I understand that the t-values from
> glm() are a Wald approximation and may not be terribly reliable, but I
> don't understand how a small t-value could indicate "either an
> insignificant OR a very significant effect."
>
> Thanks for the help. It's finding gems like these that make this group
> so extraordinarily valuable.

There is a description in V&R2, pp. 237-8., given below. I guess I was
teasing people to look up Hauck-Donner phenomenon in our index.
(I seem to remember this was new to my co-author too, so you were in
good company. This is why it is such a good example of a fact which
would be useful to know but hardly anyone does. Don't ask me how I
knew: I only know that I first saw this in about 1980.)

There is a little-known phenomenon for binomial GLMs that was pointed
out by Hauck & Donner (1977: JASA 72:851-3). The standard errors and
t values derive from the Wald approximation to the log-likelihood,
obtained by expanding the log-likelihood in a second-order Taylor
expansion at the maximum likelihood estimates. If there are some
\hat\beta_i which are large, the curvature of the log-likelihood at
\hat{\vec{\beta}} can be much less than near \beta_i = 0, and so the
Wald approximation underestimates the change in log-likelihood on
setting \beta_i = 0. This happens in such a way that as |\hat\beta_i|
\to \infty, the t statistic tends to zero. Thus highly significant
coefficients according to the likelihood ratio test may have
non-significant t ratios.

To expand a little, if |t| is small it can EITHER mean than the Taylor
expansion works and hence the likelihood ratio statistic is small OR
that |\hat\beta_i| is very large, the approximation is poor and the
likelihood ratio statistic is large. (I was using `significant' as
meaning practically important.) But we can only tell if |\hat\beta_i|
is large by looking at the curvature at \beta_i=0, not at
|\hat\beta_i|. This really does happen: from later on in V&R2:

There is one fairly common circumstance in which both convergence
problems and the Hauck-Donner phenomenon (and trouble with
\sfn{step}) can occur. This is when the fitted probabilities
are extremely close to zero or one. Consider a medical diagnosis
problem with thousands of cases and around fifty binary
explanatory variables (which may arise from coding fewer
categorical factors); one of these indicators is rarely true but
always indicates that the disease is present. Then the
fitted probabilities of cases with that indicator should be one,
which can only be achieved by taking \hat\beta_i = \infty.
The result from \sfn{glm} will be warnings and an estimated
coefficient of around +/- 10 [and an insignificant t value].

That was based on a real-life example, which prompted me to write what
is now stepAIC. Once I had that to try, I found lots of examples.

Brian Ripley

Voir aussi :

  http://www.r-project.org/nocvs/mail/r-help/2002/1487.html

+ A CLASSER

  AIC
  library(MASS); ?stepAIC

  Interfa�age avec des bases de donn�es

  Estimation d'un param�tre � l'aide d'un estimateur/test/intervalle de confiance
  
  ?str
     data(LifeCycleSavings)
     summary(lm.SR <- lm(sr ~ pop15 + pop75 + dpi + ddpi,
                         data = LifeCycleSavings),
             corr = TRUE)
     str(lmI <- lm.influence(lm.SR))



  par(fg='white', bg='black', col='white', col.axis='white', col.lab='white', col.main='white', col.sub='white');plot(0,0)

  SPC: Statistics Process Control

  On peut faire ses propres QQplots pour comparer deux distributions.
    x <- rexp(100)
    qqplot( qexp(ppoints(100)), sort(x) )
    abline(0,1)

  qqplot : expliquer comment lire un QQplot.
  En particulier : distribution d�centr�e, 
  distribution plus dispers�e qu'une normale, moins dispers�e, etc.

  ?split
  ?lapply
  ?by

  Comparer (graphiquement) la loi de Student avec la loi normale.

  Donner un exemple d'utilisation de la commande legend
  (c'est une commande s�par�e).
  (par exemple quand il y a plusieurs courbes, de couleurs diff�rentes)

  ?persp
  ?contour
  Pour repr�senter une loi normale multivari�e

  Estimateurs/Tests/Intervalles de confiance
  R�gression: estimation des corfficients/tests sur les coefs/IC des coefs/IC des valeurs pr�dites/comparaison de mod�les

  Histogramme avec des barres colori�es (ou hachur�es)
  Avec des ombres
  
  Colorier entre deux courbes (�crire une fonction pour �a).
  x <- runif(20)
  y <- 1-2*x+.1*rnorm(20)
  res <- lm(y~x)
  plot(y~x)
  new <- data.frame( x=seq(0,1,length=21) )
  p <- predict(res, new, interval='prediction')
  for (l in seq(0,1,length=100)){
    points( (l*p[,2]+(1-l)*p[,3]) ~ new$x, type='l', col="red" )
  }
  p <- predict(res, new, interval='confidence')
  for (l in seq(0,1,length=100)){
    points( (l*p[,2]+(1-l)*p[,3]) ~ new$x, type='l', col="green" )
  }
  points(y~x)
  p <- predict(res, new)
  points( p ~ new$x, type='l' )

  ?rug
  (en dessous d'un histogramme ou d'un boxplot)


* Plan de la nouvelle version de ce document

  Syntaxe de R
    RTFM/Documentation (?, help.search, exampl, demo, library(), library(help=...), data)
    Les diff�rents types de donn�es
    Saisie des donn�es
    Manipulations des types de donn�es
    Matrices et alg�bre lin�aire
    Structures de contr�le
    Fonctions (elles n'ont pas d'effet de bord : en clair, il n'y a pas de variables globales)
    Persistance
    library
      R CMD ...
    Objets
    ESS
    sweave
  
  Graphiques avec R
    Commandes de base
    Options (d�tailler)

  Mise en garde : je suis incomp�tent

  Le Zoo des lois de probabilit�s

  Donn�es univari�es
    param�tres statistiques (mean, var, sd, median, quartiles, mad, etc.)
    dotplot
    scatterplot
    boxplot
    stem-and-leaf plot
    histogramme
    rug
    symetry plot (mentionner le test de Wilcoxon)
    qqplot (mentionner le test de Shapiro)
    ces quatre graphiques sur une seule figure
    Transformations des donn�es, boxcox
    (donn�es ordonn�es)
    barplot : donn�es qualitatives
    pie    

  Tests statistiques : th�orie
  Zoo des tests statistiques
    (dans un premier paragraphe, lister tous les tests,
    si possible dans un tableau)
  M�thodes non param�triques
    robustesse
    r�sistance
    breakdown (la proportion d'individus que l'on peut modifier sans parvenir � envoyer les estimateurs � l'infini).

  Repr�sentation graphiques de donn�es multivari�es (sans la r�gression)
    deux variables quantitatives
    une variable quantitative, une qualitative
    deux variables qualitatives
    Plusieurs variables quantitatives : pairs
    Plusieurs variables quantitatives : treillis
    Trois variables quantitatives : ternary plot
    Plus de deux variables : d�coupage en tranches (treillis)
    starplots

  Repr�sentation graphiques de donn�es multivari�es (suite)
    ACP
    Analyse en composantes robustes
    Aggr�gation autour des centres mobiles
    Classification hi�rarchique (dendogramme)
    A FAIRE : une ou plusieurs des variables sont qualitatives
    (analyse factorielle discriminante, des correspondances simples/multiples, etc.)

  R�gression : PLAN A REVOIR
    R�gression
    Avant de commencer la r�gression : lissage, quelques m�thodes robustes
    Avant de commencer la r�gression : transformations
    R�gression lin�aire : d�finition
    Comparaison avec l'ACP
    R�sidus : graphiques pour explorer une r�gression
      (les r�sidus vus comme une seule variable (boxplot, hist, etc.)
      (les r�sidus en fonction de la pr�diction, en fonction d'une variable ind�pendante (tr�s mauvaise id�e: prendre l'exemple d'un mod�le constant y~1), de la variable ind�pendante)
    R�sidus non normaux
    H�t�rosc�dasticit� des r�sidus
    Influence, leverage (?), distance de Cook
    Autocorr�lation 
    R�gression multiple
    Graphiques pour explorer une r�gression multiple    
    Multicolin�arit�
    R�gression curvilin�aire
    R�gression non lin�aire
    Exemple : un probl�me de classification (r�gression lin�aire, curvilin�aire, plus proches voisins)
    Tests statistiques sur une r�gression
    Lecture du r�sultat d'une r�gression : premi�re pr�sentation de l'Anova

    A FAIRE :
    R�gression robuste (WLS,IRLS)
    Mod�le lin�aire g�n�ralis�
    R�gression logistique

  Anova
    Motivation
    Calculs d�taill�s sur un exemple, � la main
    Calculs d�taill�s sur un exemple, avec R
    R�gression et sommes de carr�s : une autre motivation de l'Anova
    Anova et comparaison de mod�les

  S�ries temporelles

A EFFACER : 

Tests d'hypoth�ses : les risques de la r�gression multiple
+ R�gression et sommes de carr�s
+ Lecture du r�sultat d'une r�gression
+ Les risques de la r�gression multiple
+ Graphiques pour la r�gression multiple
+ R�gression curvilin�aire
+ R�gression non lin�aire
+ R�gression non lin�aire
+ R�gression robuste
+ Probl�matique de l'anova simple : comparaison de trois moyennes
+ Motivation de l'ANOVA simple
+ Autre motivation de l'anova
+ Exemple d'ANOVA simple, � la main
+ Exemple d'ANOVA simple, � la main
+ Exemple d'ANOVA simple, avec R
+ Le rapport de corr�lation
+ Tests post-hoc
+ Th�or�me de Gauss--Markov
+ Anova non param�trique
+ Lien avec la r�gression
+ Anova between et within
+ Pourquoi y a-t-il deux fonctions pour l'ANOVA ?
+ L'anova est un cas particulier de la r�gression
+ Two-way Anova
+ Anova double
+ Anova � facteurs crois�s avec r�p�titions
+ Anova � facteurs crois�s sans r�p�titions
+ Anova � facteurs hi�rarchis�s 
+ Choix d'un mod�le
+ Comparaison de mod�les
+ Mod�le lin�aire g�n�ralis�
+ R�gression logistique
+ Comparaison de deux mod�les logistiques
* S�ries temporelles
* Exemples, � utiliser un peu plus haut
* A CLASSER

        
  

+ Estimateurs biais� et non biais�s de la variance
+ Divers
* Echantillons et tests statistiques
+ Exemples
+ Mod�lisation d'une exp�rience statistique
+ Un peu de vocabulaire...
+ Estimateur
+ Estimateur sans biais 
+ M�thode du maximum de vraissemblance (MLE : Maximum Likelihood Estimators)
+ M�thode des moments (MME : Method of Moments Estimation)
+ In�galit� de Cramer-Rao
+ Statistique suffisante
+ BUE (Best Unbiaised Estimators, aka UMVUE, Uniformly Minimum Variance Unbiased Estimator)
+ Test statistique 
+ Hypoth�ses H0 (nulle) et H1 (alternative)
+ Erreur de type I 
+ p-valeur 
+ Erreur de type II 
+ Puissance
+ Hypoth�se simple
+ Hypoth�se composite 
+ Intervalle de confiance
+ UMP (Uniform Most Powerful) tests
+ Test non param�trique
+ Robustesse
+ R�sistance
+ Trois mani�res de faire des tests statistiques
+ Th�orie de la d�cision

* Le zoo des tests statistiques
+ Lecture du r�sultat de ces tests
+ ATTENTION
+ Le test T de Student
+ Robustesse du test T de Student
+ Test de Z
+ Test de Student : comparaison de la moyenne de deux �chantillons
+ Robustesse du test T de Student
+ Plusieurs mani�res de comparer des moyennes
+ Le Chi^2 et le calcul de la variance
+ Loi de Fisher (test F) et comparaison de la variance de deux �chantillons

* Le zoo des tests statistiques (suite)
+ Le test du Chi^2 (comparaison de distributions)
+ Test de Fisher : ind�pendance de deux variables qualitatives
* Le zoo des test statistiques : tests non param�triques
+ Test U de Wilcoxon : comparaison de deux "moyennes"
+ Test de Wilcoxon (A FAIRE : fusionner avec le paragraphe pr�c�dent)A
+ Test de Kolmogorov-Smirnov (comparaison de distributions)

* Comment se ramener � des distributions normales ?
+ Nettoyage des donn�es
+ Comment v�rifier qu'une distribution est sym�trique ?
+ Comment v�rifier qu'une distribution est normale ?
+ Transformations : racine carr�e, logarithme

* Que faire si les donn�es ne sont vraiment pas normales ?
+ M�thodes non param�triques
+ Comparaison de moyennes � l'aide de permutations
+ Jackknife
+ M�thode de Mont�-Carlo et bootstrap
+ Courbe d'influence

* Repr�sentation graphique de donn�es bivari�es (ou multivari�es)
+ Donn�es bivari�es quantitatives et r�gression
+ Donn�es multivari�es quantitatives
+ Donn�es bivari�es qualitative/quantitative
+ Donn�es bivari�es qualitatives
+ Donn�es multivari�es qualitatives
+ Donn�es multivari�es : toutes les variables sauf une ou deux sont qualitatives.
+ Graphe en coordonn�es barycentriques (ternary plot)
+ Graphiques �toil�s (star plots)
* Repr�sentation graphique de donn�es multivari�es (statistique multidimensionnelle)
+ Donn�es multivari�es : variables quantitatives (analyse en composantes principales)
+ Donn�es multivari�es quantitatives : analyse en composantes robustes
+ Donn�es multivari�es quantitatives : aggr�gation autour des centres mobiles 
+ Donn�es multivari�es quantitatives : classification hi�rarchique (dendogramme)
+ Donn�es multivari�es quantitatives (fin)
+ Donn�es multivari�es quantitatives avec une variable qualitative (analyse factorielle discriminante)
+ Donn�es multivari�es qualitatives : analyse factorielle des correspondances simples
+ Donn�es multivari�es qualitatives : analyse des composantes multiples
+ Analyse canonique 

* Vocabulaire de la r�gression et de l'analyse de la variance
+ R�gression
+ R�gression multiple 
+ R�gression r�gularis�e 
+ Analyse de la variance 
+ Analyse de la covariance 
+ Analyse discriminante 
+ Analyse des correspondances 
+ Mod�le lin�aire (ou r�gression lin�aire)
+ Mod�le lin�aire g�n�ralis� 
+ Lien
+ Fonction logistique
+ Fonction probit
+ Mod�le de variables latentes
+ Analyse factorielle discriminante
+ R�seaux de neurones
+ Mod�les log-lin�aires
+ R�gression logistique
+ A FAIRE

* R�gression et analyse de la variance (Anova)
+ R�gression
+ Exemples
+ Graphiques pour explorer une r�gression
+ Probl�mes possibles avec les r�sidus
+ R�sidus
+ Influence
+ Multicolin�arit�
+ Transformation des donn�es
+ R�gression et sommes de carr�s
+ Lecture du r�sultat d'une r�gression
+ Tests d'hypoth�se sur une r�gression lin�aire
+ Comparaison de mod�les
+ D�finition de l'Anova
+ Les risques de la r�gression multiple
+ Graphiques pour la r�gression multiple
+ R�gression curvilin�aire
+ R�gression non lin�aire
+ R�gression non lin�aire
+ Application de la r�gression � un probl�me de classification
+ Application de la r�gression curvilin�aire � un probl�me de classification
+ Autre mani�re de r�soudre un probl�me de classification : la m�thode des plus proches voisins
+ R�gression robuste
+ Probl�matique de l'anova simple : comparaison de trois moyennes
+ Motivation de l'ANOVA simple
+ Autre motivation de l'anova
+ Exemple d'ANOVA simple, � la main
+ Exemple d'ANOVA simple, � la main
+ Exemple d'ANOVA simple, avec R
+ Le rapport de corr�lation
+ Tests post-hoc
+ Th�or�me de Gauss--Markov
+ Anova non param�trique
+ Lien avec la r�gression
+ Anova between et within
+ Pourquoi y a-t-il deux fonctions pour l'ANOVA ?
+ L'anova est un cas particulier de la r�gression
+ Two-way Anova
+ Anova double
+ Anova � facteurs crois�s avec r�p�titions
+ Anova � facteurs crois�s sans r�p�titions
+ Anova � facteurs hi�rarchis�s 
+ Choix d'un mod�le
+ Comparaison de mod�les
+ Mod�le lin�aire g�n�ralis�
+ R�gression logistique
+ Comparaison de deux mod�les logistiques
* S�ries temporelles
* Exemples, � utiliser un peu plus haut
* A CLASSER
* Simulations
* ANOVA
* R for psychologists
* Exemples fabriqu�s
+ Test d'ind�pendance de deux variables qualitatives
+ Exemples d'Anova
+ R�gression lin�aire
*********
* Divers
* Types de donn�es
+ Vecteurs
+ Data Frame
* R�gression
* A CLASSER
* Manipulation des donn�es
* Programmation
* A FAIRE
* Distributions statistiques
* bootstrap
* A CLASSER
* EN COURS
* Bibliographie
+ W. Feller, 
+ T; Hastie et al., The Elements of Statistical Learning : Data mining, Inference and Prediction, SV 2001, 72 HAS 01a
+ B. Fleury, A First course in multivariate Statistics, SV, 72 FLU 97a
+ E.J. Dudewicz and S.N. Mishra, Modern Mathematical Statistics, JW, 1988, 72 DUD 88a
+ A FAIRE : les r�f�rfences du livre que j'avais lu il y a quelques ann�es sur la th�orie de la d�cision.
+ A First Course in Multivariate Statistics, B. Flury, SV 1997, 72 FLU 97a
+ L. Lebart, A. Morineau and M. Piron, Statistique exploratoire multidimensionnelle, Dunod, 1997, 72 LEB 97a
* A CLASSER (exemples divers)
* A FAIRE
* Plan de la nouvelle version de ce document
    
