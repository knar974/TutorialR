library(MASS)
#library(mva)
library(cluster)
#library(ts)

png(file="g1.png", width=600, height=600)
  data(EuStockMarkets)
  x <- EuStockMarkets
  # We aren't interested in the spot prices, but in the returns
  # return[i] = ( price[i] - price[i-1] ) / price[i-1]
  y <- apply(x, 2, function (x) { diff(x)/x[-length(x)] })
  # We normalize the data
  z <- apply(y, 2, function (x) { (x-mean(x))/sd(x) })
  # A single time series
  r <- z[,1]
  # The runs
  f <- factor(cumsum(abs(diff(sign(r))))/2)
  r <- r[-1]
  accumulative.return <- tapply(r, f, sum)
  trend.number <- table(f)
  boxplot(abs(accumulative.return) ~ trend.number, col='pink',
          main="Accumulative return")
dev.off()

png(file="g2.png", width=600, height=600)
  boxplot(abs(accumulative.return)/trend.number ~ trend.number,
          col='pink', main="Average return")
dev.off()

png(file="g3.png", width=600, height=600)
  op <- par(mfrow=c(2,2))
  for (i in 1:4) {
    r <- z[,i]
    f <- factor(cumsum(abs(diff(sign(r))))/2)
    r <- r[-1]
    accumulative.return <- tapply(r, f, sum)
    trend.number <- table(f)
    boxplot(abs(accumulative.return) ~ trend.number, col='pink')
  }
  par(op)    
dev.off()

png(file="g4.png", width=600, height=600)
  op <- par(mfrow=c(2,2))
  for (i in 1:4) {
    r <- z[,i]
    f <- factor(cumsum(abs(diff(sign(r))))/2)
    r <- r[-1]
    accumulative.return <- tapply(r, f, sum)
    trend.number <- table(f)
    boxplot(abs(accumulative.return)/trend.number ~ trend.number, col='pink')
  }
  par(op)    
dev.off()

png(file="g5.png", width=600, height=600)
  data(volcano)
  M <- volcano
  n <- dim(M)[1]
  m <- dim(M)[2]
  M1 <- M [1:(n-1),] [,1:(m-1)]
  M2 <- M [2:n,] [,1:(m-1)]
  M3 <- M [1:(n-1),] [,2:m]
  M4 <- M [2:n,] [,2:m]
  # Avec des quadripixels qui se chevauchent
  M0 <- (M1+M2+M3+M4)/4

  # Avec des quadripixels qui ne se chevauchent pas
  nn <- floor((n-1)/2)
  mm <- floor((m-1)/2)
  M00 <- M0 [2*(1:nn),] [,2*(1:mm)]

  op <- par(mfrow=c(2,2))
  image(M, main="Image initiale")
  image(M0, main="Quadripixels chevauchants")
  image(M00, main="Quadripixels non chevauchants")
  par(op)
dev.off()

png(file="g6.png", width=600, height=600)
  n <- 100
  m <- matrix(runif(2*n),nc=2)
  library(ape)
  r <- mst(dist(m)) # La matrice d'incidence (de l'arbre couvrant
                    # minimal des points pr�c�dents).
  plot(m)
  n <- dim(r)[1]
  w <- which(r!=0)
  i <- as.vector(row(r))[w]
  j <- as.vector(col(r))[w]
  segments( m[i,1], m[i,2], m[j,1], m[j,2], col='red' )
dev.off()

png(file="g7.png", width=600, height=600)
  several.times <- function (n, f, ...) {
    for (i in 1:n) {
      f(...)
    }
  }
  matrix.multiplication <- function (s) {
    A <- matrix(1:(s*s), nr=s, nc=s) 
    B <- matrix(1:(s*s), nr=s, nc=s) 
    C <- A %*% B
  }
  v <- NULL
  for (i in 2:10) {
    v <- append(v, 
                system.time( several.times( 10000, matrix.multiplication, i )) [1])
  }
  plot(v, type='b', pch=15, main="Temps de calcul de produits matriciels")
dev.off()

png(file="g8.png", width=600, height=600)
  x <- seq(0,4, length=100)
  y <- sqrt(x)
  plot(y~x, type='l', lwd=3, main=expression(y == sqrt(x)) )
dev.off()

png(file="g9.png", width=600, height=600)
  data(beav1)
  plot(beav1$temp ~ beav1$time)
dev.off()

png(file="g10.png", width=600, height=600)
  data(longley)
  pairs(longley)
dev.off()

png(file="g11.png", width=600, height=200)
  stripchart(longley$Unemployed)  
dev.off()

png(file="g12.png", width=600, height=600)
  hist(longley$Unemployed)
dev.off()

png(file="g13.png", width=200, height=600)
  boxplot(longley$Unemployed)
dev.off()

png(file="g14.png", width=600, height=600)
  n <- 100
  x <- rnorm(n)
  y <- 1 - x^2 + .3*rnorm(n)
  plot(y~x, xlab='abscisses', ylab="ordonn�es", main="Titre")
dev.off()

png(file="g15.png", width=600, height=600)
  x <- seq(-5,5,length=200)
  y <- sqrt(1+x^2)
  plot(y~x, type='l',
       ylab=expression( sqrt(1+x^2) ))
  title(main=expression("graphe de la fonction f"(x) == sqrt(1+x^2)))
dev.off()

png(file="g16.png", width=600, height=600)
  x <- seq(-5,5,length=200)
  #plot(0,0, xlim=c(-5,5), ylim=c(0,6), type='n',xlab='', ylab='')
  op <- par(mfrow=c(2,2))
  for (i in 1:4) {
    y <- sqrt(i+x^2)
    plot(y~x, type='l', ylim=c(0,6),
           ylab=substitute( expression( sqrt(i+x^2) ), list(i=i) ))
    title(main=substitute("graphe de la fonction f"(x) == sqrt(i+x^2),
                          list(i=i)))
  }
  par(op)
dev.off()

png(file="g17.png", width=600, height=600)
  plot(1:10, 1:10, main = "text(...) examples\n~~~~~~~~~~~~~~",
       sub = "R is GNU �, but not � ...")
  mtext("�ISO-accents�: � �� �� �<� �<�", side=3)
  points(c(6,2), c(2,1), pch = 3, cex = 4, col = "red")
  text(6, 2, "the text is CENTERED around (x,y) = (6,2) by default",
       cex = .8)
  text(2, 1, "or Left/Bottom - JUSTIFIED at (2,1) by `adj = c(0,0)'",
       adj = c(0,0))
  text(4, 9, expression(hat(beta) == (X^t * X)^{-1} * X^t * y))
  text(4, 8.4, "expression(hat(beta) == (X^t * X)^{-1} * X^t * y)", cex = .75)
  text(4, 7, expression(bar(x) == sum(frac(x[i], n), i==1, n)))
dev.off()

png(file="g18.png", width=600, height=600)
  # Exemple du manuel
  plot(1:9, type="n", axes=FALSE, frame=TRUE, ylab="",
       main= "example(Japanese)", xlab= "using Hershey fonts")
  par(cex=3)
  Vf <- c("serif", "plain")
  text(4, 2, "\\#J2438\\#J2421\\#J2451\\#J2473", vfont = Vf)
  text(4, 4, "\\#J2538\\#J2521\\#J2551\\#J2573", vfont = Vf)
  text(4, 6, "\\#J467c\\#J4b5c", vfont = Vf)
  text(4, 8, "Japan", vfont = Vf)
  par(cex=1)
  text(8, 2, "Hiragana")
  text(8, 4, "Katakana")
  text(8, 6, "Kanji")
  text(8, 8, "English")
dev.off()

png(file="g19.png", width=600, height=600)
  # Autre exemple du manuel (qui contient aussi des tables
  # de katakana et de kanji)
  make.table <- function(nr, nc) {
    opar <- par(mar=rep(0, 4), pty="s")
    plot(c(0, nc*(10%/%nc) + 1), c(0, -(nr + 1)),
         type="n", xlab="", ylab="", axes=FALSE)
    invisible(opar)
  }

  get.r <- function(i, nr)   i %% nr + 1
  get.c <- function(i, nr)   i %/% nr + 1
  Esc2 <- function(str)      paste("\\", str, sep="")

  draw.title <- function(title, nc)
    text((nc*(10%/%nc) + 1)/2, 0, title, font=2)

  draw.vf.cell <- function(typeface, fontindex, string, i, nr, raw.string=NULL) {
    r <- get.r(i, nr)
    c <- get.c(i, nr)
    x0 <- 2*(c - 1)
    if (is.null(raw.string)) raw.string <- Esc2(string)
    text(x0 + 1.1, -r, raw.string, col="grey")
    text(x0 + 2,   -r, string, vfont=c(typeface, fontindex))
    rect(x0 +  .5, -(r - .5), x0 + 2.5, -(r + .5), border="grey")
  }

  draw.vf.cell2 <- function(string, alt, i, nr) {
    r <- get.r(i, nr)
    c <- get.c(i, nr)
    x0 <- 3*(c - 1)
    text(x0 + 1.1, -r, Esc2(string <- Esc2(string)), col="grey")
    text(x0 + 2.2, -r, Esc2(Esc2(alt)), col="grey", cex=.6)
    text(x0 + 3,   -r, string, vfont=c("serif", "plain"))
    rect(x0 +  .5, -(r - .5), x0 + 3.5, -(r + .5), border="grey")
  }

  tf <- "serif"
  fi <- "plain"
  nr <- 25
  nc <- 4
  oldpar <- make.table(nr, nc)
  index <- 0
  digits <- c(0:9,"a","b","c","d","e","f")
  draw.title("Hiragana : \\\\#J24nn", nc)
  for (i in 2:7) {
    for (j in 1:16) {
      if (!((i == 2 && j == 1) || (i == 7 && j > 4))) {
        draw.vf.cell(tf, fi, paste("\\#J24", i, digits[j], sep=""),
                     index, nr)
        index <- index + 1
      }
    }
  }
dev.off()

png(file="g20.png", width=600, height=600)
  plot(runif(5), ylim=c(0,1), type='l')
  for (i in c('red', 'blue', 'green')) {
    lines( runif(5), col=i )
  }
  title(main="diff�rentes couleurs de trait")
dev.off()

png(file="g21.png", width=600, height=600)
  plot(runif(5), ylim=c(0,1), type='n')
  for (i in 5:1) {
    lines( runif(5), col=i, lwd=i )
  }
  title(main="diff�rentes �paisseurs de trait")
dev.off()

png(file="g22.png", width=600, height=800)
  op <- par(mfrow=c(3,2))
  plot(runif(5), type='p', main="plot type 'p' (points)")
  plot(runif(5), type='l', main="plot type 'l' (lines)")
  plot(runif(5), type='b', main="plot type 'b' (both points and lines)")
  plot(runif(5), type='s', main="plot type 's' (stair steps)")
  plot(runif(5), type='h', main="plot type 'h' (histogram)")
  plot(runif(5), type='n', main="plot type 'n' (no plot)")
  par(op)
dev.off()

png(file="g23.png", width=600, height=600)
  plot(0,0, xlim=c(1,5), ylim=c(-.5,4), 
       axes=F, xlab='', ylab='',
       main="Symboles disponibles")
  for (i in 0:4) {
    for (j in 1:5) {
      n <- 5*i+j
      points(j,i, pch=n, cex=3)
      text(j,i-.25, as.character(n))
    }
  }
dev.off()

png(file="g24.png", width=600, height=600)
  hist(longley$Unemployed, density=3, angle=45)
dev.off()

png(file="g25.png", width=600, height=600)
  op <- par(mfrow = c(2, 2))
  for (i in 1:4) 
    plot(runif(20), runif(20), 
         main=paste("random plot (",i,")",sep=''))
  par(op)
  mtext("Four plots, without enough room for this title", 
         side=3, font=2, cex=2, col='red')
dev.off()

png(file="g26.png", width=600, height=600)
  op <- par(mfrow = c(2, 2), oma=c(0,0,3,0))
  for (i in 1:4) 
    plot(runif(20), runif(20), 
         main=paste("random plot (",i,")",sep=''))
  par(op)
  mtext("Four plots, with some room for this title", 
        side=3, line=1.5, font=2, cex=2, col='red')
dev.off()

png(file="g27.png", width=600, height=600)
  n <- 20
  x <- rnorm(n)
  y <- x^2 - 1 + .3*rnorm(n)
  plot(y~x)
  op <- par()
  for (i in 2:10) {
    done <- FALSE
    while(!done) {
      a <- c( sort(runif(2,0,1)), 
              sort(runif(2,0,1)) )
      par(fig=a, new=T)
      r <- try(plot(runif(5), type='l', col=i))
      done <- !inherits(r, "try-error")
    }
  }
  par(op)
dev.off()

png(file="g28.png", width=600, height=600)
  plot(runif(5), runif(5), xlim=c(0,1), ylim=c(0,1))
  points(runif(5), runif(5), col='orange', pch=16, cex=3)
  lines(runif(5), runif(5), col='red')
  segments(runif(5), runif(5), runif(5), runif(5), col='blue')
  title(main="Superpositions...")
dev.off()

png(file="g29.png", width=600, height=600)
  my.col <- function (f, g, xmin, xmax, col, N=200) {
    x <- seq(xmin,xmax,length=N)
    fx <- f(x)
    gx <- g(x)
    plot(0,0, type='n', 
         xlim=c(xmin,xmax),
         ylim=c( min(fx,gx), max(fx,gx) ) )
    polygon( c(x,rev(x)), c(fx,rev(gx)), col='red', border=0 )
    lines(x,fx,lwd=3)
    lines(x,gx,lwd=3)
  }
  my.col( function(x) x^2, function(x) x^2+10*sin(x), -6, 6)
dev.off()

png(file="g30.png", width=600, height=600)
  # Exemple du manuel
  ch.col <- c("rainbow(n, start=.7, end=.1)", "heat.colors(n)",
               "terrain.colors(n)", "topo.colors(n)", "cm.colors(n)")
  n <- if(.Device == "postscript") 64 else 16
       # Since for screen, larger n may give color allocation problem
  nt <- length(ch.col)
  i <- 1:n; j <- n / nt; d <- j/6; dy <- 2*d
  plot(i,i+d, type="n", yaxt="n", ylab="", main=paste("color palettes;  n=",n))
  for (k in 1:nt) {
    rect(i-.5,(k-1)*j+ dy, i+.4,  k*j, col=eval(parse(text=ch.col[k])))
    text(2*j,  k * j +dy/4, ch.col[k])
  }
dev.off()

png(file="g31.png", width=600, height=600)
  x <- seq(-6,6,length=200)
  y <- sin(x)
  z <- cos(x)
  plot(y~x, type='l', lwd=3, 
       ylab='', xlab='angle', main="Fonctions trigonom�triques")
  abline(h=0,lty=3)
  abline(v=0,lty=3)
  lines(z~x, type='l', lwd=3, col='red')
  legend(-6,-1, yjust=0,
         c("Sinus", "Cosinus"),
         lwd=3, lty=1, col=c(par('fg'), 'red'),
        )
dev.off()

png(file="g32.png", width=600, height=600)
  library(grid)
  grid.show.viewport(viewport(x=0.6, y=0.6,
                     w=unit(1, "inches"), h=unit(1, "inches")))
dev.off()

png(file="g33.png", width=600, height=600)
  grid.show.layout(grid.layout(4,2,
                   heights=unit(rep(1, 4),
                                c("lines", "lines", "lines", "null")),
                   widths=unit(c(1, 1), "inches")))
dev.off()

png(file="g34.png", width=600, height=600)
  dessine <- function () {
    push.viewport(viewport(w = 0.9, h = 0.9, 
                           xscale=c(-.1,1.1), yscale=c(-.1,1.1)))
    grid.rect(gp=gpar(fill=rgb(.5,.5,0)))
    grid.points( runif(50), runif(50) )
    pop.viewport()
  }
  grid.newpage()
  grid.rect(gp=gpar(fill=rgb(.3,.3,.3)))
  push.viewport(viewport(layout=grid.layout(2, 2)))
  for (i in 1:2) {
    for (j in 1:2) {
      push.viewport(viewport(layout.pos.col=i,
                             layout.pos.row=j))
      dessine()
      pop.viewport()
    }
  }
  pop.viewport()
dev.off()

png(file="g35.png", width=600, height=600)
  grid.multipanel(vp=viewport(0.5, 0.5, 0.8, 0.8))
dev.off()

png(file="g36.png", width=600, height=600)
  do.it <- function (x=runif(100), y=runif(100), 
                     a=.9, b=.1, 
                     col1=rgb(0,.3,0), col2=rgb(1,1,0)) {
    xscale <- range(x) + c(-1,1)*.05
    yscale <- range(y) + c(-1,1)*.05
    grid.newpage()
    grid.rect(gp=gpar(fill=col1, col=col1))
    w1 <- a - b/2
    w2 <- 1 - a - b/2
    c1 <- b/3 + w1/2
    c2 <- a + b/6 + w2/2
    vp1 <- viewport(x=c1, y=c1, width=w1, height=w1,
                    xscale=xscale, yscale=yscale)
    push.viewport(vp1)
    grid.rect(gp=gpar(fill=col2, col=col2))
    grid.points(x,y)
    pop.viewport()
    vp2 <- viewport(x=c1, y=c2, width=w1, height=w2,
                    xscale=xscale, yscale=c(0,1))
    push.viewport(vp2)
    grid.rect(gp=gpar(fill=col2, col=col2))
    grid.points(x,rep(.5,length(x)))
    pop.viewport()
    vp3 <- viewport(x=c2, y=c1, width=w2, height=w1,
                    xscale=c(0,1), yscale=yscale)
    push.viewport(vp3)
    grid.rect(gp=gpar(fill=col2, col=col2))
    grid.points(rep(.5,length(y)),y)
    pop.viewport()
  }
  do.it()
dev.off()

png(file="g37.png", width=600, height=600)
  op <- par(mfrow=c(2,2))
  data(EuStockMarkets)
  x <- EuStockMarkets
  # We aren't interested in the spot prices, but in the returns
  # return[i] = ( price[i] - price[i-1] ) / price[i-1]
  y <- apply(x, 2, function (x) { diff(x)/x[-length(x)] })
  # We normalize the data
  z <- apply(y, 2, function (x) { (x-mean(x))/sd(x) })
  for (i in 1:4) {
    d <- density(z[,i])
    plot(d$x,log(d$y),ylim=c(-5,1),xlim=c(-5,5))
    curve(log(dnorm(x)),col='red',add=T)
  }
  par(op)
dev.off()

png(file="g38.png", width=600, height=600)
  n <- dim(z)[1]
  N <- 2000
  m <- matrix(rnorm(n*N), nc=N, nr=n)
  a <- apply(m^3,2,mean)
  b <- apply(z^3,2,mean)
  hist(a, col='light blue', xlim=range(c(a,b)),
       main="Troisi�me moment")
  points(b, rep(.2*par("usr")[3] + .8*par("usr")[4], length(b)), type='h', col='red',lwd=3)
  points(b, rep(.2*par("usr")[3] + .8*par("usr")[4], length(b)), col='red', lwd=3)
dev.off()

png(file="g39.png", width=600, height=600)
  n <- dim(z)[1]
  N <- 2000
  m <- matrix(rnorm(n*N), nc=N, nr=n)
  a <- apply(m^4,2,mean)
  b <- apply(z^4,2,mean)
  hist(a, col='light blue', xlim=range(c(a,b)),
       main="Distribution attendue de la kurtoris et valeurs observ�es")
  points(b, rep(.2*par("usr")[3] + .8*par("usr")[4], length(b)), type='h', col='red',lwd=3)
  points(b, rep(.2*par("usr")[3] + .8*par("usr")[4], length(b)), col='red', lwd=3)
dev.off()

png(file="g40.png", width=600, height=200)
  data(faithful)
  stripchart(faithful$eruptions)
dev.off()

png(file="g41.png", width=600, height=200)
  # Bruit uniquement horizontal
  stripchart(faithful$eruptions, jitter=TRUE)
dev.off()

png(file="g42.png", width=600, height=200)
  stripchart(faithful$eruptions, method='jitter')
dev.off()

png(file="g43.png", width=600, height=200)
  my.jittered.stripchart <- function (x) {
    x.name <- deparse(substitute(x))
    n <- length(x)
    plot( runif(n) ~ x, xlab=x.name, ylab='random' )
  }
  my.jittered.stripchart(faithful$eruptions)
dev.off()

png(file="g44.png", width=600, height=200)
  my.jittered.stripchart <- function (x) {
    x.name <- deparse(substitute(x))
    n <- length(x)
    x <- x + diff(range(x))*.05* (-.5+runif(n))
    plot( runif(n) ~ x, xlab=paste("jittered", x.name), ylab='random' )
  }
  my.jittered.stripchart(faithful$eruptions)
dev.off()

png(file="g45.png", width=600, height=600)
  plot(sort(faithful$eruptions))
dev.off()

png(file="g46.png", width=600, height=600)
  plot(sort(faithful$eruptions))
  rug(faithful$eruptions, side=2)
dev.off()

png(file="g47.png", width=600, height=600)
  x <- round( rnorm(100), digits=1 )
  plot(sort(x))
  rug(jitter(x), side=2)
dev.off()

png(file="g48.png", width=600, height=600)
  effectifs.cumules <- function (x) {
    x.name <- deparse(substitute(x))
    n <- length(x)
    plot( 1:n ~ sort(x), xlab=x.name, ylab='effectifs cumul�s')
  }    
  effectifs.cumules(faithful$eruptions)
dev.off()

png(file="g49.png", width=600, height=800)
  data(islands)
  dotchart(islands)
dev.off()

png(file="g50.png", width=600, height=800)
  dotchart(sort(log(islands)))
dev.off()

png(file="g51.png", width=800, height=600)
  op <- par(mfcol=c(2,4))
  do.it <- function (x) {
    hist(x, probability=T, col='light blue')
    lines(density(x), col='red', lwd=3)
    x <- sort(x)
    q <- ppoints(length(x))
    plot(q~x, type='l')
    abline(h=c(.25,.5,.75), lty=3, lwd=3, col='blue')
  }
  n <- 200
  do.it(rnorm(n))
  do.it(rlnorm(n))
  do.it(-rlnorm(n))
  do.it(rnorm(n, c(-5,5)))
  par(op)
dev.off()

png(file="g52.png", width=600, height=600)
  boxplot(faithful$eruptions, range=0)
dev.off()

png(file="g53.png", width=600, height=200)
  boxplot(faithful$eruptions, range=0, horizontal=TRUE)
dev.off()

png(file="g54.png", width=600, height=600)
  op <- par(mfrow=c(1,2))
  do.it <- function (x) {
    d <- density(x)
    plot(d, type='l')
    q <- quantile(x)
    do.it <- function (i, col) {
      x <- d$x[i]
      y <- d$y[i]
      polygon( c(x,rev(x)), c(rep(0,length(x)),rev(y)), border=NA, col=col )
    }
    do.it(d$x <= q[2], 'red')
    do.it(q[2] <= d$x & d$x <= q[3], 'green')
    do.it(q[3] <= d$x & d$x <= q[4], 'blue')
    do.it(d$x >= q[4], 'yellow')
    lines(d, lwd=3)
  }
  do.it( rnorm(2000) )
  do.it( rlnorm(200) )
  par(op)
dev.off()

png(file="g55.png", width=600, height=200)
  boxplot(faithful$eruptions, horizontal=TRUE)
dev.off()

png(file="g56.png", width=600, height=200)
  # Il y en a, c'est g�nant, mais pas pathologique
  boxplot(rnorm(500), horizontal=TRUE)
dev.off()

png(file="g57.png", width=600, height=200)
  x <- c(rnorm(30),20)
  x <- sample(x, length(x))
  boxplot( x, horizontal=T )
dev.off()

png(file="g58.png", width=600, height=200)
  library(boot)
  data(aml)
  boxplot( aml$time, horizontal=T )
dev.off()

png(file="g59.png", width=600, height=200)
  data(attenu)
  boxplot(attenu$dist, horizontal=T)
dev.off()

png(file="g60.png", width=600, height=200)
  data(attenu)
  boxplot(log(attenu$dist), horizontal=T)
dev.off()

png(file="g61.png", width=600, height=300)
  y <- c(rnorm(10+100+1000+10000+100000))
  x <- c(rep(1,10), rep(2,100), rep(3,1000), rep(4,10000), rep(5,100000))
  x <- factor(x)
  plot(y~x, horizontal=T, las=1)
dev.off()

png(file="g62.png", width=200, height=600)
  boxplot(faithful$eruptions, notch=TRUE)
dev.off()

png(file="g63.png", width=300, height=600)
  data(breslow)
  boxplot(breslow$n, notch=TRUE)
dev.off()

png(file="g64.png", width=600, height=200)
  boxplot(faithful$eruptions, horizontal=T)
  rug(faithful$eruption, ticksize=.2)
dev.off()

png(file="g65.png", width=600, height=600)
  hist(faithful$eruptions)
dev.off()

png(file="g66.png", width=600, height=600)
  hist(faithful$eruptions, breaks=20, col="light blue")
dev.off()

png(file="g67.png", width=600, height=600)
  op <- par(mfrow=c(2,1))
  hist(faithful$eruptions, breaks=seq(1,6,.5), col='light blue')
  hist(faithful$eruptions, breaks=.25+seq(1,6,.5), col='light blue')
  par(op)
dev.off()

png(file="g68.png", width=600, height=600)
  hist(faithful$eruptions, 
       probability=TRUE, breaks=20, col="light blue")
  points(density(faithful$eruptions, bw=.1), type='l', col='red', lwd=3)
dev.off()

png(file="g69.png", width=600, height=600)
  hist(faithful$eruptions, 
       probability=TRUE, breaks=20, col="light blue")
  points(density(faithful$eruptions, bw=1),  type='l', lwd=3, col='black')
  points(density(faithful$eruptions, bw=.5), type='l', lwd=3, col='blue')
  points(density(faithful$eruptions, bw=.3), type='l', lwd=3, col='green')
  points(density(faithful$eruptions, bw=.1), type='l', lwd=3, col='red')
dev.off()

png(file="g70.png", width=600, height=600)
  hist(faithful$eruptions, 
       probability=TRUE, breaks=20, col="light blue")
  rug(faithful$eruptions)
  points(density(faithful$eruptions, bw=.1), type='l', lwd=3, col='red')
  f <- function(x) {
    dnorm(x, 
          mean=mean(faithful$eruptions), 
          sd=sd(faithful$eruptions),
    ) 
  }
  curve(f, add=T, col="red", lwd=3, lty=2)
dev.off()

png(file="g71.png", width=600, height=600)
  symetry.plot <- function (x,...) {
    x <- x[ !is.na(x) ]
    x <- sort(x)
    x <- abs(x - median(x))
    n <- length(x)
    nn <- ceiling(n/2)
    plot( x[n:(n-nn+1)] ~ x[1:nn] ,
          xlab='Distance below median',
          ylab='Distance above median', 
          ...)    
  }
  symetry.plot(faithful$eruptions)
  abline(0,1)  
dev.off()

png(file="g72.png", width=600, height=600)
  n <- 100
  N <- 1e3
  symetry.plot( rnorm(n), pch='.', col='red', 
                main=paste("Echantillon de", n, "individus") )
  for (i in 1:N) {
    x <- sort(rnorm(n))
    x <- abs(x - median(x))
    l <- length(x)
    ll <- ceiling(n/2)
    points( x[l:(l-ll+1)] ~ x[1:ll], pch='.', col='red' )
  }
  abline(0,1)
dev.off()

png(file="g73.png", width=600, height=600)
  n <- 10
  N <- 1e3
  symetry.plot( rnorm(n), pch=15, col='red', cex=.5,
                main=paste("Echantillon de", n, "individus") )
  for (i in 1:N) {
    x <- sort(rnorm(n))
    x <- abs(x - median(x))
    l <- length(x)
    ll <- ceiling(n/2)
    points( x[l:(l-ll+1)] ~ x[1:ll], pch=15, col='red', cex=.5 )
  }
  abline(0,1)
dev.off()

png(file="g74.png", width=600, height=600)
  symetry.plot <- function (x, col2='red',...) {
    x <- x[ !is.na(x) ]
    x <- sort(x)
    x <- abs(x - median(x))
    n <- length(x)
    nn <- ceiling(n/2)
    plot( x[n:(n-nn+1)] ~ x[1:nn] ,
          xlab='Distance below median',
          ylab='Distance above median', 
          ...)
    m <- mean(x)
    s <- sd(x)
    N <- 1000
    for (i in 1:N) {
      y <- sort(rnorm(n, mean=m, sd=s))
      y <- abs(y - median(y))
      n <- length(y)
      nn <- ceiling(n/2)
      points( y[n:(n-nn+1)] ~ y[1:nn], pch='.', col=col2 )
    }
    points( x[n:(n-nn+1)] ~ x[1:nn], ...)
    abline(0,1, ...)
  }
  symetry.plot(faithful$eruptions)
dev.off()

png(file="g75.png", width=600, height=600)
  symetry.plot(rnorm(100))
dev.off()

png(file="g76.png", width=600, height=600)
  symetry.plot(runif(100))
dev.off()

png(file="g77.png", width=600, height=600)
  data(airquality)
  x <- airquality[,4]
  hist(x, probability=TRUE, breaks=20, col="light blue")
  rug(jitter(x, 5))
  points(density(x), type='l', lwd=3, col='red')
  f <- function(t) {
    dnorm(t, mean=mean(x), sd=sd(x) ) 
  }
  curve(f, add=T, col="red", lwd=3, lty=2)
dev.off()

png(file="g78.png", width=600, height=600)
  x <- airquality[,4]
  qqnorm(x)
  qqline(x)
dev.off()

png(file="g79.png", width=600, height=600)
  y <- rnorm(100)
  qqnorm(y)
  qqline(y)
dev.off()

png(file="g80.png", width=600, height=600)
  y <- rnorm(100)^2
  qqnorm(y)
  qqline(y)
dev.off()

png(file="g81.png", width=600, height=600)
  my.qqnorm <- function (x, N=1000, ...) {
    op <- par()
    x <- x[!is.na(x)]
    n <- length(x)
    m <- mean(x)
    s <- sd(x)
    print("a")
    qqnorm(x, axes=F, ...)
    for (i in 1:N) {
      par(new=T)
      qqnorm(rnorm(n, mean=m, sd=s), col='red', pch='.', 
             axes=F, xlab='', ylab='', main='')
    }
    par(new=T)
    qqnorm(x, ...)
    qqline(x, col='blue', lwd=3)
    par(op)
  }
  my.qqnorm(rnorm(100))
dev.off()

png(file="g82.png", width=600, height=600)
  my.qqnorm(runif(100), main='loi uniforme')
dev.off()

png(file="g83.png", width=600, height=600)
  my.qqnorm(exp(rnorm(100)), main='loi log-normale')
dev.off()

png(file="g84.png", width=600, height=600)
  my.qqnorm(c(rnorm(50), 5+rnorm(50)), main='deux pics')
dev.off()

png(file="g85.png", width=600, height=600)
  my.qqnorm(c(rnorm(50), 20+rnorm(50)), main='deux pics �loign�s')
dev.off()

png(file="g86.png", width=600, height=600)
  x <- rnorm(100)
  x <- x + x^3
  my.qqnorm(x, main='distribution tr�s �tal�e')
dev.off()

png(file="g87.png", width=600, height=600)
  y <- exp(rnorm(100))
  qqnorm(y, main='(1) Loi log-normale'); qqline(y, col='red')
dev.off()

png(file="g88.png", width=600, height=600)
  y <- rnorm(100)^2
  qqnorm(y, ylim=c(-2,2), main="(2) Carr� d'une va suivant une loi normale")
  qqline(y, col='red')
dev.off()

png(file="g89.png", width=600, height=600)
  y <- -exp(rnorm(100))
  qqnorm(y, ylim=c(-2,2), main="(3) Oppos� d'une v.a. suivant une loi log-normale")
  qqline(y, col='red')
dev.off()

png(file="g90.png", width=600, height=600)
  y <- runif(100, min=-1, max=1)
  qqnorm(y, ylim=c(-2,2), main='(4) Loi uniforme'); qqline(y, col='red')
dev.off()

png(file="g91.png", width=600, height=600)
  y <- rnorm(10000)^3
  qqnorm(y, ylim=c(-2,2), main="(5) Cube d'une v.a. suivant une loi normale")
  qqline(y, col='red')
dev.off()

png(file="g92.png", width=600, height=600)
  y <- c(rnorm(50), 5+rnorm(50))
  qqnorm(y, main='(6) Deux pics')
  qqline(y, col='red')
dev.off()

png(file="g93.png", width=600, height=600)
  y <- c(rnorm(50), 20+rnorm(50))
  qqnorm(y, main='(7) Deux pics plus �loign�s')
  qqline(y, col='red')
dev.off()

png(file="g94.png", width=600, height=600)
  y <- sample(seq(0,1,.1), 100, replace=T)
  qqnorm(y, main='(7) Loi discr�te')
  qqline(y, col='red')
dev.off()

png(file="g95.png", width=600, height=600)
  x <- seq(from=0, to=2, length=100)
  y <- exp(x)-1
  plot( y~x, type='l', xlim=c(-2,2), ylim=c(-2,2), col='red')
  lines( x~y, type='l', col='green')
  x <- -x
  y <- -y
  lines( y~x, type='l', col='blue', )
  lines( x~y, type='l', col='cyan')
  abline(0,1)
  legend( -2, 2,
          c( "loi moins concentr�e que la normale � droite",  
             "loi plus concentr�e que la normale � droite",
             "loi moins concentr�e que la normale � gauche",
             "loi plus concentr�e que la normale � gauche"
           ),
          lwd=3,
          col=c("red", "green", "blue", "cyan")
        )
  title(main="Lecture d'un qqplot")
dev.off()

png(file="g96.png", width=600, height=600)
  op <- par()
  layout( matrix( c(2,2,1,1), 2, 2, byrow=T ),
          c(1,1), c(1,6),
        )
  # Le graphique
  n <- 100
  y <- rnorm(n)
  x <- qnorm(ppoints(n))[order(order(y))]
  par(mar=c(5.1,4.1,0,2.1))
  plot( y~x, col="blue" )
  y1 <- scale( rnorm(n)^2 )
  x <- qnorm(ppoints(n))[order(order(y1))]
  lines(y1~x, type="p", col="red")
  y2 <- scale( -rnorm(n)^2 )
  x <- qnorm(ppoints(n))[order(order(y2))]
  lines(y2~x, type="p", col="green")
  abline(0,1)

  # La l�gende
  # Quelqu'un sait-il comment superposer des graphiques ?
  # Je parviens uniquement � les juxtaposer...
  # (normalement, c'est le param�tre graphique "fig", mais �a ne marche pas...)
  # Si : voir un peu plus loin (il faut pr�ciser par(new=T)).
  par(bty='n', ann=F)
  g <- seq(0,1, length=10)
  e <- g^2
  f <- sqrt(g)
  h <- c( rep(1,length(e)), rep(2,length(f)), rep(3,length(g)) )
  par(mar=c(0,4.1,0,0))
  boxplot( c(e,f,g) ~ h, horizontal=T, 
           border=c("red", "green", "blue"),
           xaxt='n',
           yaxt='n', 
           )
  title(main="Lecture d'un qqplot")
  par(op)
dev.off()

png(file="g97.png", width=600, height=600)
  y <- rnorm(100)^2
  y <- scale(x)
  y <- sort(x)
  x <- qnorm( seq(0,1,length=length(y)) )
  plot(y~x)
  abline(0,1)
dev.off()

png(file="g98.png", width=600, height=600)
  qq <- function (y, ylim, quantiles=qnorm,
      main = "Q-Q Plot", xlab = "Theoretical Quantiles",
      ylab = "Sample Quantiles", plot.it = TRUE, ...)
  {
    y <- y[!is.na(y)]
    if (0 == (n <- length(y)))
      stop("y is empty")
    if (missing(ylim))
      ylim <- range(y)
    x <- quantiles(ppoints(n))[order(order(y))]
    if (plot.it)
      plot(x, y, main = main, xlab = xlab, ylab = ylab, ylim = ylim,
            ...)
    # From qqline
    y <- quantile(y, c(0.25, 0.75))
    x <- quantiles(c(0.25, 0.75))
    slope <- diff(y)/diff(x)
    int <- y[1] - slope * x[1]
    abline(int, slope, ...)
    invisible(list(x = x, y = y))
  }

  y <- runif(100)
  qq(y, quantiles=qunif)
dev.off()

png(file="g99.png", width=600, height=600)
  two.point.line <- function (x1,y1,x2,y2, ...) {
    a1 <- (y2-y1)/(x2-x1)
    a0 <- y1 - a1 * x1
    abline(a0,a1,...)
  }
  trended.probability.plot <- function (x, q=qnorm) {
    n <- length(x)
    plot( sort(x) ~ q(ppoints(n)), , xlab='theoretical quantiles', ylab='sample quantiles')
    two.point.line(q(.25), quantile(x,.25), q(.75), quantile(x,.75), col='red')
  }
  detrended.probability.plot <- function (x, q=qnorm) {
    n <- length(x)
    x <- sort(x)
    x1 <- q(.25)
    y1 <- quantile(x,.25)
    x2 <- q(.75)
    y2 <- quantile(x,.75)
    a1 <- (y2-y1)/(x2-x1)
    a0 <- y1 - a1 * x1
    u <- q(ppoints(n))
    x <- x - (a0 + a1 * u)
    plot(x ~ u, xlab='theoretical quantiles', ylab='sample quantiles')    
    abline(h=0, col='red')
  }

  op <- par(mfrow=c(3,2))
  x <- runif(20)
  trended.probability.plot(x)
  detrended.probability.plot(x)
  x <- runif(500)
  trended.probability.plot(x)
  detrended.probability.plot(x)
  trended.probability.plot(x, qunif)
  detrended.probability.plot(x,qunif)
  par(op)
dev.off()

png(file="g100.png", width=600, height=600)
  xy <- matrix(c( 0, 0,
                 .2, .9, 
                 .3, .95, 
                 .5, .99,
                  1, 1), byrow=T, nc=2)
  plot(xy, type='b', pch=15)
  polygon(xy, border=F, col='pink')
  lines(xy, type='b', pch=15)
  abline(0,1,lty=2)
dev.off()

png(file="g101.png", width=600, height=600)
  x <- c(0,20,2720,3000)/3000
  y <- c(0,100000,100100,100110)/100110
  plot(x,y, type='b', pch=15)
  polygon(x,y, border=F, col='pink')
  lines(x,y, type='b', pch=15)
  abline(0,1,lty=2)
dev.off()

png(file="g102.png", width=600, height=600)
  library(ineq)
  op <- par(mfrow=c(2,3))
  plot(Lc(runif(n,0,1)), main="uniforme [0,1]", col='red')
  plot(Lc(runif(n,0,10)), main="uniforme [0,10]", col='red')
  plot(Lc(runif(n,10,11)), main="uniforme [10,11]", col='red')
  plot(Lc(rlnorm(n)), main="log-normale", col='red')
  plot(Lc(rlnorm(n,0,4)), main="log-normale, plus large", col='red')
  plot(Lc(rcauchy(n,1)), main="Cauchy", col='red')
  plot(Lc(exp(rcauchy(n,1))), main="log-Cauchy", col='red')
  plot(Lc(rpois(n,1)), main="Poisson de moyenne 1", col='red')
  plot(Lc(rpois(n,10)), main="Poisson de moyenne 10", col='red')
  par(op)
dev.off()

png(file="g103.png", width=600, height=400)
  # (Graphique trompeur : l'origine n'est pas sur le dessin)
  data(esoph)
  dotchart(table(esoph$agegp))
dev.off()

png(file="g104.png", width=600, height=600)
  barplot(table(esoph$agegp))
dev.off()

png(file="g105.png", width=600, height=600)
  hist(as.numeric(esoph$agegp), 
       breaks=seq(.5,.5+length(levels(esoph$agegp)),step=1),
       col='light blue')
dev.off()

png(file="g106.png", width=600, height=200)
  boxplot(as.numeric(esoph$agegp), horizontal=T)
dev.off()

png(file="g107.png", width=600, height=200)
  stripchart(jitter(as.numeric(esoph$agegp),2), method='jitter')
dev.off()

png(file="g108.png", width=600, height=600)
  plot(table(esoph$agegp), type='b', pch=7)
dev.off()

png(file="g109.png", width=600, height=600)
  data(HairEyeColor)
  x <- apply(HairEyeColor, 2, sum)
  barplot(x)
  title(main="Graphique en colonnes")
dev.off()

png(file="g110.png", width=600, height=600)
  barplot(x, col=1, density=c(3,7,11,20), angle=c(45,-45,45,-45))
  title(main="Graphique en colonnes")
dev.off()

png(file="g111.png", width=200, height=600)
  x <- apply(HairEyeColor, 2, sum)
  barplot(as.matrix(x), legend.text=TRUE)
  title("Graphique en barre")
dev.off()

png(file="g112.png", width=600, height=200)
  barplot(as.matrix(x), horiz=TRUE, col=rainbow(length(x)), legend.text=TRUE)
  title(main="Graphique en barre")
dev.off()

png(file="g113.png", width=600, height=600)
  data(attenu)
  op <- par(las=2) # �crire les labels perpendiculairement aux axes
  barplot(table(attenu$event))
  title(main="Graphique en colonnes")
  par(op)
dev.off()

png(file="g114.png", width=600, height=600)
  op <- par(las=2)
  barplot(rev(sort(table(attenu$event))))
  title(main="Graphique de Par�to")
  par(op)
dev.off()

png(file="g115.png", width=600, height=600)
  # Avec la commande barplot, je n'y arrive pas.
  pareto <- function (x) {
    op <- par(mar = c(5, 4, 4, 5) + 0.1)
    par(las=2)
    if( ! inherits(x, "table") ) {
      x <- table(x)
    }
    x <- rev(sort(x))
    plot( x, type='h', axes=F, lwd=16 )
    axis(2)
    points( x, type='h', lwd=12, col=heat.colors(length(x)) )
    y <- cumsum(x)/sum(x)
    par(new=T)
    plot(y, type="b", lwd=3, pch=7, axes=F, xlab='', ylab='', main='')
    points(y, type='h')
    axis(4)
    print(names(x))
    axis(1, at=1:length(x), labels=names(x))
    par(op)
  }
  pareto(attenu$event)    
  title(main="Graphique de Par�to avec effectifs cumul�s")
dev.off()

png(file="g116.png", width=600, height=600)
  x <- apply(HairEyeColor, 2, sum)
  pie(x)
  title(main="Camembert")
dev.off()

png(file="g117.png", width=600, height=200)
  x <- apply(HairEyeColor, 2, sum)
  dotchart(x)
dev.off()

png(file="g118.png", width=600, height=600)
  data(Cars93)
  dotchart(table(Cars93$Manufacturer))
dev.off()

png(file="g119.png", width=600, height=1100)
  library(nlme)
  data(Milk)
  dotchart(table(Milk$Cow))
dev.off()

png(file="g120.png", width=600, height=600)
  data(cars)
  plot(cars$dist ~ cars$speed, 
       xlab = "Speed (mph)", 
       ylab = "Stopping distance (ft)", 
       las = 1)
  title(main = "Nuage de points")
dev.off()

png(file="g121.png", width=600, height=600)
  plot(cars$dist ~ cars$speed, 
       xlab = "Speed (mph)", 
       ylab = "Stopping distance (ft)", 
       las = 1)
  title(main = "cars data")
  rug(side=1, jitter(cars$speed, 5))
  rug(side=2, jitter(cars$dist, 20))
dev.off()

png(file="g122.png", width=600, height=600)
  op <- par()
  layout( matrix( c(2,1,0,3), 2, 2, byrow=T ),
          c(1,6), c(4,1),
        )

  par(mar=c(1,1,5,2))
  plot(cars$dist ~ cars$speed, 
       xlab='', ylab='',
       las = 1)
  rug(side=1, jitter(cars$speed, 5) )
  rug(side=2, jitter(cars$dist, 20) )
  title(main = "cars data")

  par(mar=c(1,2,5,1))
  boxplot(cars$dist, axes=F)
  title(ylab='Stopping distance (ft)', line=0)

  par(mar=c(5,1,1,2))
  boxplot(cars$speed, horizontal=T, axes=F)
  title(xlab='Speed (mph)', line=1)

  par(op)
dev.off()

png(file="g123.png", width=600, height=600)
  plot(dist ~ speed, data=cars)
  abline(lm(dist ~ speed, data=cars), col='red')
dev.off()

png(file="g124.png", width=600, height=600)
  plot(cars, xlab = "Speed (mph)", ylab = "Stopping distance (ft)",
       las = 1)
  lines(lowess(cars$speed, cars$dist, f = 2/3, iter = 3), col = "red")
  title(main = "cars data")
dev.off()

png(file="g125.png", width=600, height=600)
  x <- c(15, 9, 75, 90, 1, 1, 11, 5, 9, 8, 33, 11, 11, 
         20, 14, 13, 10, 28, 33, 21, 24, 25, 11, 33)
  # j'ai essay� pendant pr�s d'une demi-heure d'utiliser la commande stars
  # pour faire �a, mais sans succ�s.
  clock.plot <- function (x, col=rainbow(n), ...) {
    if( min(x)<0 ) x <- x - min(x)
    if( max(x)>1 ) x <- x/max(x)
    n <- length(x)
    if(is.null(names(x))) names(x) <- 0:(n-1)
    m <- 1.05
    plot(0, type='n', xlim=c(-m,m), ylim=c(-m,m), 
         axes=F, xlab='', ylab='', ...)
    a <- pi/2 - 2*pi/200*0:200
    polygon( cos(a), sin(a) )
    v <- .02
    a <- pi/2 - 2*pi/n*0:n
    segments( (1+v)*cos(a), (1+v)*sin(a), (1-v)*cos(a), (1-v)*sin(a) )
    segments( cos(a), sin(a), 0, 0, col='light grey', lty=3) 
    ca <- -2*pi/n*(0:50)/50
    for (i in 1:n) {
      a <- pi/2 - 2*pi/n*(i-1)
      b <- pi/2 - 2*pi/n*i
      polygon( c(0, x[i]*cos(a+ca), 0),
               c(0, x[i]*sin(a+ca), 0),
               col=col[i] )
      v <- .1
      text((1+v)*cos(a), (1+v)*sin(a), names(x)[i])
    }
  }
  clock.plot(x, main="Affluence d'un site Web en fonction de l'heure")
dev.off()

png(file="g126.png", width=600, height=600)
  library(lattice)
  y <- cars$dist
  x <- cars$speed
  # vitesse <- shingle(x, co.intervals(x, number=6))
  vitesse <- equal.count(x)
  histogram(~ y | vitesse)
dev.off()

png(file="g127.png", width=600, height=600)
  bwplot(~ y | vitesse, layout=c(1,6))
dev.off()

png(file="g128.png", width=600, height=600)
  densityplot(~ y | vitesse, aspect='xy')
dev.off()

png(file="g129.png", width=600, height=600)
  densityplot(~ y | vitesse, layout=c(1,6))
dev.off()

png(file="g130.png", width=600, height=300)
  y <- cars$dist
  x <- cars$speed
  q <- quantile(x)
  o1 <- x<q[2]
  o2 <- q[2]<x & x<q[3]
  o3 <- q[3]<x & x<q[4]
  o4 <- q[4]<x 
  dotchart(c(median(y[o1]), median(y[o2]), 
             median(y[o3]), median(y[o4])),
           labels=as.character(1:4),
           xlab="speed", ylab="distance")
dev.off()

png(file="g131.png", width=600, height=600)
  my.dotchart <- function (y,x,...) {
    x <- as.matrix(x)
    z <- NULL
    for (i in 1:dim(x)[2]) {
      q <- quantile(x[,i])
      for (j in 1:4) {
        z <- append(z, median(y[ q[j] <= x[,i] & x[,i] <= q[j+1] ]))
        names(z)[length(z)] <- paste(colnames(x)[i], as.character(j))
      }
    }
    dotchart(z,...)
  }
  my.dotchart(y,x, xlab="speed", ylab="distance")
dev.off()

png(file="g132.png", width=600, height=600)
  my.dotchart <- function (y,x,...) {
    x <- as.matrix(x)
    z <- NULL
    for (i in 1:dim(x)[2]) {
      q <- quantile(x[,i])
      for (j in 1:4) {
        ya <- y[ q[j] <= x[,i] & x[,i] <= q[j+1] ]
        z <- rbind(z, quantile(ya))
        rownames(z)[dim(z)[1]] <- paste(colnames(x)[i], as.character(j))
      }
    }
    dotchart(t(z))
  }
  my.dotchart(y,x, xlab="speed", ylab="distance")
dev.off()

png(file="g133.png", width=600, height=300)
  my.dotchart <- function (y,x,...) {
    x <- as.matrix(x)
    z <- NULL
    for (i in 1:dim(x)[2]) {
      q <- quantile(x[,i])
      for (j in 1:4) {
        ya <- y[ q[j] <= x[,i] & x[,i] <= q[j+1] ]
        z <- rbind(z, quantile(ya))
        rownames(z)[dim(z)[1]] <- paste(colnames(x)[i], as.character(j))
      }
    }
    xmax <- max(z)
    xmin <- min(z)
    n <- dim(z)[1]
    plot( z[,3], 1:n, xlim=c(xmin,xmax), ylim=c(1,n), axes=F, frame.plot=T, pch='.', ... )
    axis(1)
    axis(2, at=1:n, las=1)
    abline( h=1:n, lty=3 )
    # m�diane
    points( z[,3], 1:n, pch=16, cex=3 )
    # quartiles
    segments( z[,2], 1:n, z[,4], 1:n, lwd=7 )
    # min et max
    segments( z[,1], 1:n, z[,5], 1:n )
  }
  my.dotchart(y,x, xlab="speed", ylab="distance")
dev.off()

png(file="g134.png", width=600, height=600)
  data(InsectSprays)
  boxplot(count ~ spray, data = InsectSprays,
          xlab = "Type of spray", ylab = "Insect count",
          main = "InsectSprays data", varwidth = TRUE, col = "lightgray")
dev.off()

png(file="g135.png", width=600, height=600)
  library(Simple)
  n <- 1000
  k <- 10
  x <- factor(sample(1:5, n, replace=T))
  m <- rnorm(k,sd=2)
  s <- sample( c(rep(1,k-1),2) )
  y <- rnorm(n, m[x], s[x])
  x[x %in% order(m)[c(1,5)]] <- order(m)[1]
  simple.violinplot(y~x, col='pink')
dev.off()

png(file="g136.png", width=600, height=400)
  my.dotchart <- function (y,x,...) {
    x <- data.frame(x)
    z <- NULL
    cn <- NULL
    for (i in 1:dim(x)[2]) {
      if( is.numeric(x[,i]) ) {
        q <- quantile(x[,i])
        for (j in 1:4) {
          ya <- y[ q[j] <= x[,i] & x[,i] <= q[j+1] ]
          z <- rbind(z, quantile(ya))
          cn <- append(cn, paste(colnames(x)[i], as.character(j)))
        }
      } else {
        for (j in levels(x[,i])) {
          ya <- y[ x[,i] == j ]
          z <- rbind(z, quantile(ya))
          cn <- append(cn, paste(colnames(x)[i], as.character(j)))
        }
      }
    }
    xmax <- max(z)
    xmin <- min(z)
    n <- dim(z)[1]
    plot( z[,3], 1:n, xlim=c(xmin,xmax), ylim=c(1,n), axes=F, frame.plot=T, pch='.', ... )
    axis(1)
    axis(2, at=1:n, labels=cn, las=1)
    abline( h=1:n, lty=3 )
    # m�diane
    points( z[,3], 1:n, pch=16, cex=3 )
    # quartiles
    segments( z[,2], 1:n, z[,4], 1:n, lwd=7 )
    # min et max
    segments( z[,1], 1:n, z[,5], 1:n )
  }
  spray <- InsectSprays$spray
  y <- InsectSprays$count
  my.dotchart(y,spray, xlab="count", ylab="spray")
dev.off()

png(file="g137.png", width=600, height=600)
  stripchart(InsectSprays$count ~ InsectSprays$spray, method='jitter')
dev.off()

png(file="g138.png", width=600, height=600)
  data(iris)
  plot(iris[1:4], pch=21, bg=c("red", "green", "blue")[as.numeric(iris$Species)])
dev.off()

png(file="g139.png", width=600, height=600)
  a <- InsectSprays$count
  b <- rnorm(length(a))
  plot(b~a, pch=21, 
       bg=c("red", "green", "blue", "cyan", "yellow", "black")
            [as.numeric(InsectSprays$spray)])
dev.off()

png(file="g140.png", width=600, height=600)
  a <- as.vector(t(iris[1]))
  b <- rnorm(length(a))
  plot(b~a, pch=21, bg=c("red", "green", "blue")[as.numeric(iris$Species)])
dev.off()

png(file="g141.png", width=600, height=600)
  do.it <- function (v) {
    n <- 100
    y <- sample( 1:3, n, replace=T )
    a <- runif(1)
    b <- runif(1)
    c <- runif(1)
    x <- ifelse( y==1, a+v*rnorm(n), 
         ifelse( y==2, b+v*rnorm(n), c+v*rnorm(n) ))
    r <- rnorm(n)
    plot( r ~ x, pch=21, bg=c('red', 'green', 'blue')[y] )
  }
  do.it(.1)
dev.off()

png(file="g142.png", width=600, height=600)
  do.it(.05)
dev.off()

png(file="g143.png", width=400, height=800)
  hists <- function (x, y, ...) {
    y <- factor(y)
    n <- length(levels(y))
    op <- par( mfcol=c(n,1) )    
    b <- hist(x, ..., plot=F)$breaks
    for (l in levels(y)){
      hist(x[y==l], breaks=b, probability=T, ylim=c(0,.3), main=l, col='lightblue', ...)
      points(density(x[y==l]), type='l', lwd=3, col='red')
    }
    par(op)
  }
  hists(InsectSprays$count, InsectSprays$spray)
dev.off()

png(file="g144.png", width=600, height=600)
  library(lattice)
  histogram( ~ count | spray, data=InsectSprays)
dev.off()

png(file="g145.png", width=600, height=600)
  densityplot( ~ count | spray, data = InsectSprays )
dev.off()

png(file="g146.png", width=600, height=600)
  bwplot( ~ count | spray, data = InsectSprays )
dev.off()

png(file="g147.png", width=600, height=600)
  bwplot( ~ count | spray, data = InsectSprays, layout=c(1,6) )
dev.off()

png(file="g148.png", width=600, height=600)
  data(HairEyeColor)
  a <- as.table( apply(HairEyeColor, c(1,2), sum) )
  barplot(a, legend.text = attr(a, "dimnames")$Hair)
dev.off()

png(file="g149.png", width=600, height=600)
  barplot(a, beside=TRUE, legend.text = attr(a, "dimnames")$Hair)
dev.off()

png(file="g150.png", width=600, height=600)
  barplot(t(a), legend.text = attr(a, "dimnames")$Eye)
dev.off()

png(file="g151.png", width=600, height=600)
  barplot(t(a), beside=TRUE, legend.text = attr(a, "dimnames")$Eye)
dev.off()

png(file="g152.png", width=600, height=600)
  b <- a / apply(a, 1, sum)
  barplot(t(b))
dev.off()

png(file="g153.png", width=600, height=600)
  c <- t( t(a) / apply(a, 2, sum) )
  barplot(c)
dev.off()

png(file="g154.png", width=600, height=600)
  plot(a)
dev.off()

png(file="g155.png", width=600, height=600)
  plot(t(a))
dev.off()

png(file="g156.png", width=600, height=600)
  plot(a, col=heat.colors(dim(a)[2]))
dev.off()

png(file="g157.png", width=600, height=600)
  plot(a, color=T)
dev.off()

png(file="g158.png", width=600, height=600)
  plot(a, shade=T)
dev.off()

png(file="g159.png", width=600, height=600)
  plot(t(a), shade=T)
dev.off()

png(file="g160.png", width=600, height=600)
  data(HairEyeColor)
  a <- apply(HairEyeColor, c(1,2) , sum)
  qualplot <- function (a) {
    matplot( row(a), a, type='l', axes=F,
             col = 1:dim(a)[2]+1,
             lty = 1:dim(a)[2],
             lwd=3,
             xlab=names(dimnames(a))[1], ylab=names(dimnames(a))[2] )
    axis(1, 1:dim(a)[1], row.names(a))
    axis(2)
    legend(1, max(a), row.names(t(a)),
           lwd=3, cex=1.5,
           col=1:dim(a)[2]+1, lty=1:dim(a)[2])
  }
  # Pour une utilisation interactive
  qualplots <- function (a) {
    op = par(ask=T)
    qualplot(a)
    qualplot(t(a))
    par(op)
  }
  qualplot(a)
dev.off()

png(file="g161.png", width=600, height=600)
  qualplot(t(a))
dev.off()

png(file="g162.png", width=600, height=600)
  qualplotfreq <- function (a) {
    a <- t( t(a) / apply(a,2,sum) )
    qualplot(a)
  }
  qualplotsfreq <- function (a) {
    op = par(ask=T)
    qualplotfreq(a)
    qualplotfreq(t(a))
    par(op)
  }
  qualplotfreq(a)
dev.off()

png(file="g163.png", width=600, height=600)
  qualplotfreq(t(a))
dev.off()

png(file="g164.png", width=600, height=600)
  data(bacteria)
  fourfoldplot( table(bacteria$y, bacteria$ap) )
dev.off()

png(file="g165.png", width=600, height=600)
  fourfoldplot( table(bacteria$y, bacteria$ap, bacteria$week) )
dev.off()

png(file="g166.png", width=600, height=600)
  n <- 50
  x <- rnorm(n)
  y <- rnorm(n)
  z <- rnorm(n)
  my.renorm <- function (z) {
    z <- abs(z)
    z <- 10*z/max(z)
    z
  }
  z <- my.renorm(z)
  plot(x,y,cex=z)
dev.off()

png(file="g167.png", width=600, height=600)
  plot(x,y,cex=z,pch=16,col='red')
  points(x,y,cex=z)
dev.off()

png(file="g168.png", width=600, height=600)
  u <- sample(c('red','green','blue'),n,replace=T)
  plot(x,y,cex=z,pch=16,col=u)
  points(x,y,cex=z)
dev.off()

png(file="g169.png", width=600, height=600)
  z2 <- rnorm(n)
  z2 <- my.renorm(z2)
  plot(x,y,cex=z)
  points(x,y,cex=z2,col='red')
dev.off()

png(file="g170.png", width=600, height=600)
  # Autre renormalisation (pertinente s'il n'y a pas de z�ro)
  my.renorm <- function (z) { 
    z <- (z-min(z)) / (max(z)-min(z))
    z <- 1+9*z
    z
  }
  z <- my.renorm(z)
  z2 <- my.renorm(z2)
  plot(x,y,cex=z)
  points(x,y,cex=z2,col='red')
dev.off()

png(file="g171.png", width=600, height=600)
  n <- 50
  x <- runif(n)
  y <- runif(n)
  z1 <- rnorm(n)
  z2 <- rnorm(n)
  z3 <- rnorm(n)
  z4 <- rnorm(n)
  z5 <- rnorm(n)
  stars( data.frame(z1,z2,z3,z4,z5), location=cbind(x,y), 
         labels=NULL, len=1/sqrt(n)/2 )
dev.off()

png(file="g172.png", width=600, height=600)
  v <- .2
  n <- 50
  x <- runif(n)
  y <- runif(n)
  z1 <- x+y+v*rnorm(n)
  z2 <- x*y+v*rnorm(n)
  z3 <- x^2 + y^2 + v*rlnorm(n)
  stars( data.frame(z1,z2,z3), location=cbind(x,y), 
         labels=NULL, len=1/sqrt(n)/2, axes=T,
         draw.segments=T, col.segments=1:5 )
dev.off()

png(file="g173.png", width=600, height=600)
  n <- 10
  d <- data.frame(y1=abs(rnorm(n)),
                  y2=abs(rnorm(n)),
                  y3=abs(rnorm(n)),
                  y4=abs(rnorm(n)),
                  y5=abs(rnorm(n))
                 )
  matplot(d, type='l')
dev.off()

png(file="g174.png", width=600, height=600)
  barplot(t(as.matrix(d)))
dev.off()

png(file="g175.png", width=600, height=600)
  line.chart <- function (d) {
    m <- d
    m <- t(apply(m,1,cumsum))
    print(m)
    n1 <- dim(m)[1]
    n2 <- dim(m)[2]
    col = rainbow(n)
    plot.new()
    plot.window(xlim=c(1,n1), ylim=c(min(m),max(m)))
    axis(1)
    axis(2)
    for (i in n2:1) {
      polygon(c(1:n1,n1,1), c(m[,i],0,0), col=col[i], border=0)
    }
    for (i in n2:1) {
      lines(m[,i], lwd=2)
    }
  }
  line.chart(d)
dev.off()

png(file="g176.png", width=600, height=600)
  shaded.pie <- function (...) {
    pie(...)
    op <- par(new=T)
    a <- seq(0,2*pi,length=100)
    for (i in (256:64)/256) {
      r <- .8-.1*(1-i)
      polygon( .1+r*cos(a), -.2+r*sin(a), border=NA, col=rgb(i,i,i))
    }
    par(new=T)
    pie(...)
    par(op)
  }
  x <- rpois(10,5)
  x <- x[x>0]
  shaded.pie(x)
dev.off()

png(file="g177.png", width=600, height=600)
  data(LifeCycleSavings)
  plot(LifeCycleSavings)
dev.off()

png(file="g178.png", width=600, height=600)
  panel.hist <- function(x, ...) {
    usr <- par("usr"); 
    on.exit(par(usr))
    par(usr = c(usr[1:2], 0, 1.5) )
    h <- hist(x, plot = FALSE)
    breaks <- h$breaks; nB <- length(breaks)
    y <- h$counts; y <- y/max(y)
    rect(breaks[-nB], 0, breaks[-1], y, ...)
  }
  # Le coefficient de corr�lation
  my.panel.smooth <- 
  function (x, y, col = par("col"), bg = NA, pch = par("pch"),
            cex = 1, col.smooth = "red", span = 2/3, iter = 3, ...)
  {
    points(x, y, pch = pch, col = col, bg = bg, cex = cex)
    ok <- is.finite(x) & is.finite(y)
    if (any(ok))
      lines(lowess(x[ok], y[ok], f = span, iter = iter), col = col.smooth,
            ...)
    usr <- par('usr')
    text( (usr[1]+usr[2])/2, (usr[3]+9*usr[4])/10, 
          floor(100*cor(x,y))/100,
          col='blue', cex=3, adj=c(.5,1) )
  }
  pairs(LifeCycleSavings,
        diag.panel=panel.hist,
        upper.panel=panel.smooth,
        lower.panel=my.panel.smooth);
dev.off()

png(file="g179.png", width=600, height=600)
  cor.plot <- function (x) {
    n <- dim(x)[1]
    m <- dim(x)[2]
    N <- 1000
    col = topo.colors(N)
    plot(NA, xlim=c(0,1.2), ylim=c(-1,0))
    for (i in 1:n) {
      for (j in 1:m) {
        polygon( c((j-1)/m, (j-1)/m, j/m, j/m),
                 -c((i-1)/m, i/m, i/m, (i-1)/m),
                 col = col[ N*(x[i,j]+1)/2 ] )
      }
    }
    for (i in 1:N) {
      polygon( c(1.1, 1.1, 1.2, 1.2),
               -c((i-1)/N, i/N, i/N, (i-1)/N),
               col = col[N-i+1],
               border=NA )
    }
    # Exercice : ajouter une l�gende et le nom des variables
  }

  n <- 200
  x1 <- rnorm(n)
  x2 <- rnorm(n)
  x3 <- rnorm(n)
  x <- rnorm(n)
  x4 <- x + .1*rnorm(n)
  x5 <- x + .1*rnorm(n)
  y <- 1 + x1 + x4 + rnorm(n)
  d <- data.frame(y,x1,x2,x3,x4,x5)
  cor.plot(cor(d))
dev.off()

png(file="g180.png", width=600, height=600)
  my.dotchart(LifeCycleSavings[,1], LifeCycleSavings[,-1],
              xlab='savings', ylab='')
dev.off()

png(file="g181.png", width=600, height=600)
  to.factor.vector <- function (x, number=4) {
    resultat <- NULL
    intervalles <- co.intervals(x,number,overlap=0)
    for (i in 1:number) {
      if( i==1 ) intervalles[i,1] = min(x)
      else 
        intervalles[i,1] <- intervalles[i-1,2]
      if( i==number )
        intervalles[i,2] <- max(x)
    }
    for (valeur in x) {
      r <- NA
      for (i in 1:number) {
        if( valeur >= intervalles[i,1] & valeur <= intervalles[i,2] )
          r <- i
      }
      resultat <- append(resultat, r)
    }
    factor(resultat, levels=1:number)
  }
  to.factor <- function (x, number=4) {
    if(is.vector(x)) 
      r <- to.factor.vector(x, number)
    else {
      r <- NULL
      for (v in x) {
        a <- to.factor.vector(v)
        if( is.null(r) ) 
          r <- data.frame(a)
        else 
          r <- data.frame(r,a)
      }
      names(r) <- names(x)
    }
    r
  }
  x <- to.factor(LifeCycleSavings[,-1])
  y <- LifeCycleSavings[,1]
  y <- as.vector(matrix(y,nr=length(y),ncol=dim(x)[2]))
  for (i in names(x)) {
    levels(x[[i]]) <- paste(i, levels(x[[i]]))
  }
  col <- gl( dim(x)[2], length(levels(x[,1])), 
             labels=rainbow( dim(x)[2] ))
  col <- as.vector(col)
  x <- factor(as.vector(as.matrix(x)))
  boxplot(y~x, horizontal=T, las=1, col=col)
dev.off()

png(file="g182.png", width=600, height=300)
  bwplot( ~ LifeCycleSavings[,1] | equal.count(LifeCycleSavings[,2], number=4),
          layout=c(1,4) )
dev.off()

png(file="g183.png", width=600, height=300)
  bwplot( ~ LifeCycleSavings[,1] | equal.count(LifeCycleSavings[,3], number=4),
          layout=c(1,4) )
dev.off()

png(file="g184.png", width=600, height=300)
  bwplot( ~ LifeCycleSavings[,1] | equal.count(LifeCycleSavings[,4], number=4),
          layout=c(1,4) )
dev.off()

png(file="g185.png", width=600, height=300)
  bwplot( ~ LifeCycleSavings[,1] | equal.count(LifeCycleSavings[,5], number=4),
          layout=c(1,4) )
dev.off()

png(file="g186.png", width=600, height=600)
  data(mtcars)
  stars(mtcars[, 1:7], key.loc = c(14, 2),
        main = "Motor Trend Cars : stars(*, full = F)", full = FALSE)
dev.off()

png(file="g187.png", width=600, height=600)
  stars(mtcars[, 1:7], key.loc = c(14, 1.5),
        main = "Motor Trend Cars : full stars()",flip.labels=FALSE)
dev.off()

png(file="g188.png", width=600, height=600)
  palette(rainbow(12, s = 0.6, v = 0.75))
  stars(mtcars[, 1:7], len = 0.8, key.loc = c(12, 1.5),
        main = "Motor Trend Cars", draw.segments = TRUE)
dev.off()

png(file="g189.png", width=600, height=600)
  stars(mtcars[, 1:7], locations = c(0,0), radius = FALSE,
        key.loc=c(0,0), main="Motor Trend Cars", lty = 2)
dev.off()

png(file="g190.png", width=600, height=600)
  # Tir� du manuel
  x <- seq(-10, 10, length=50)
  y <- x
  f <- function(x,y) {
    r <- sqrt(x^2+y^2)
    10 * sin(r)/r
  }
  z <- outer(x, y, f)
  z[is.na(z)] <- 1
  persp(x, y, z, theta = 30, phi = 30, expand = 0.5, col = "lightblue",
        shade=.5,
        xlab = "X", ylab = "Y", zlab = "Z")
dev.off()

png(file="g191.png", width=600, height=600)
  # Exemple du manuel
  data(volcano)
  z <- 2 * volcano        # Exaggerate the relief
  x <- 10 * (1:nrow(z))   # 10 meter spacing (S to N)
  y <- 10 * (1:ncol(z))   # 10 meter spacing (E to W)
  persp(x, y, z, theta = 120, phi = 15, scale = FALSE, axes = FALSE)
  # Voir aussi les autres exemples dans 
  #   demo(persp)
dev.off()

png(file="g192.png", width=600, height=600)
  # Toujours un exemple du manuel
  data("volcano")
  rx <- range(x <- 10*1:nrow(volcano))
  ry <- range(y <- 10*1:ncol(volcano))
  ry <- ry + c(-1,1) * (diff(rx) - diff(ry))/2
  tcol <- terrain.colors(12)
  opar <- par(pty = "s", bg = "lightcyan")
  plot(x = 0, y = 0,type = "n", xlim = rx, ylim = ry, xlab = "", ylab = "")
  u <- par("usr")
  rect(u[1], u[3], u[2], u[4], col = tcol[8], border = "red")
  contour(x, y, volcano, col = tcol[2], lty = "solid", add = TRUE,
          vfont = c("sans serif", "plain"))
  title("A Topographic Map of Maunga Whau", font = 4)
  abline(h = 200*0:4, v = 200*0:4, col = "lightgray", lty = 2, lwd = 0.1)
  par(opar)
dev.off()

png(file="g193.png", width=600, height=600)
  # Exemple du manuel
  data(volcano)
  x <- 10*(1:nrow(volcano))
  y <- 10*(1:ncol(volcano))
  image(x, y, volcano, col = terrain.colors(100), axes = FALSE)
  contour(x, y, volcano, levels = seq(90, 200, by=5), add = TRUE, col = "peru")
  axis(1, at = seq(100, 800, by = 100))
  axis(2, at = seq(100, 600, by = 100))
  box()
  title(main = "Maunga Whau Volcano", font.main = 4)
dev.off()

png(file="g194.png", width=600, height=600)
  data(volcano)
  x <- 10*(1:nrow(volcano))
  x <- rep(x, ncol(volcano))
  y <- 10*(1:ncol(volcano))
  y <- rep(y, each=nrow(volcano))
  z <- as.vector(volcano)
  wireframe( z ~ x * y )
dev.off()

png(file="g195.png", width=600, height=600)
  cloud( z ~ x * y )
dev.off()

png(file="g196.png", width=600, height=600)
  data(iris)
  print(cloud(Sepal.Length ~ Petal.Length * Petal.Width,
              data = iris, cex = .8,
              groups = Species,
              subpanel = panel.superpose,
              main = "Stereo",
              screen = list(z = 20, x = -70, y = 3)),
        split = c(1,1,2,1), more = TRUE)
  print(cloud(Sepal.Length ~ Petal.Length * Petal.Width,
              data = iris, cex = .8,
              groups = Species,
              subpanel = panel.superpose,
              main = "Stereo",
              screen = list(z = 20, x = -70, y = 0)),
        split = c(2,1,2,1))
dev.off()

png(file="g197.png", width=600, height=600)
  n <- 100
  m <- matrix( rnorm(5*n)+c(1,-1,3,0,2), nr=n, nc=5, byrow=T )
  matplot(1:5, t(m), type='l')
  title(main="Nuage de points homog�ne")
dev.off()

png(file="g198.png", width=600, height=600)
  n <- 50
  k <- 2
  m <- matrix( rnorm(5*k*n)+runif(5*k,min=-10,max=10), nr=n, nc=5, byrow=T )
  matplot(1:5, t(m), type='l')
  title(main="Nuage de points avec des (2) grumeaux")
dev.off()

png(file="g199.png", width=600, height=600)
  n <- 50
  k <- 5
  m <- matrix( rnorm(5*k*n)+runif(5*k,min=-10,max=10), nr=n, nc=5, byrow=T )
  matplot(1:5, t(m), type='l')
  title(main="Nuage de points avec des (5) grumeaux")
dev.off()

png(file="g200.png", width=600, height=600)
  matplot(1:5, t(princomp(m)$scores), type='l')
  title(main="idem, apr�s ACP")
dev.off()

png(file="g201.png", width=600, height=600)
  matplot(1:5, t(m), type='l')
  title(main="Nuage de points avec des grumeaux moins visibles")
dev.off()

png(file="g202.png", width=600, height=600)
  library(MASS)
  data(Skye)

  ternary <- function(X, pch = par("pch"), lcex = 1,
                      add = FALSE, ord = 1:3, ...)
  {
    X <- as.matrix(X)
    if(any(X) < 0) stop("X must be non-negative")
    s <- drop(X %*% rep(1, ncol(X)))
    if(any(s<=0)) stop("each row of X must have a positive sum")
    if(max(abs(s-1)) > 1e-6) {
      warning("row(s) of X will be rescaled")
      X <- X / s
    }
    X <- X[, ord]
    s3 <- sqrt(1/3)
    if(!add)
    {
      oldpty <- par("pty")
      on.exit(par(pty=oldpty))
      par(pty="s")
      plot(c(-s3, s3), c(0.5-s3, 0.5+s3), type="n", axes=FALSE,
           xlab="", ylab="")
      polygon(c(0, -s3, s3), c(1, 0, 0), density=0)
      lab <- NULL
      if(!is.null(dn <- dimnames(X))) lab <- dn[[2]]
      if(length(lab) < 3) lab <- as.character(1:3)
      eps <- 0.05 * lcex
      text(c(0, s3+eps*0.7, -s3-eps*0.7),
           c(1+eps, -0.1*eps, -0.1*eps), lab, cex=lcex)
    }
    points((X[,2] - X[,3])*s3, X[,1], ...)
  }

  ternary(Skye/100, ord=c(1,3,2))
dev.off()

png(file="g203.png", width=600, height=600)
  tri <-
  function(a, f, m, symb = 2, grid = F, ...)
  {
    ta <- paste(substitute(a))
    tf <- paste(substitute(f))
    tm <- paste(substitute(m))

    tot <- 100/(a + f +m)
    b <- f * tot
    y <- b * .878
    x <- m * tot + b/2
    par(pty = "s")
    oldcol <- par("col")
    plot(x, y, axes = F, xlab = "", ylab = "", 
         xlim = c(-10, 110), ylim= c(-10, 110), type = "n", ...)
    points(x,y,pch=symb)
    par(col = oldcol)
    trigrid(grid)
    text(-5, -5, ta)
    text(105, -5, tm)
    text(50, 93, tf)
    par(pty = "m")
    invisible()
  }

  trigrid  <-
  function(grid = F)
  {
    lines(c(0, 50, 100, 0), c(0, 87.8, 0, 0)) #draw frame
    if(!grid) {
      for(i in 1:4 * 20) {
        lines(c(i, i - 1), c(0, 2 * .878)) #side a-c (base)
        lines(c(i, i + 1), c(0, 2 * .878))
        T.j <- i/2 #side a-b (left)
        lines(c(T.j, T.j + 2), c(i * .878, i * .878))
        lines(c(T.j, T.j + 1), c(i * .878, (i - 2) * .878))
        T.j <- 100 - i/2 #side b-c (right)
        lines(c(T.j, T.j - 2), c(i * .878, i * .878))
        lines(c(T.j, T.j - 1), c(i * .878, (i - 2) * .878))
      }
    } else {
      for(i in 1:4 * 20) {
        # draw dotted grid
        lines(c(i, i/2), c(0, i * .878), lty = 4, col = 3)
        lines(c(i, (50 + i/2)), c(0, .878 * (100 - i)), lty = 4, col = 3)
        lines(c(i/2, (100 - i/2)), c(i * .878, i * .878), lty = 4, col = 3)
      }
      par(lty = 1, col = 1)
    }
  }

  # some random data in three variables
  c1<- runif(5, 10, 20)
  c2<- runif(5, 1, 5)
  c3 <- runif(5, 15, 25)
  # basic plot
  tri(c1,c2,c3)
dev.off()

png(file="g204.png", width=600, height=600)
  # plot with different symbols and a grid
  tri(c1,c2,c3, symb=7, grid=T) 
dev.off()

png(file="g205.png", width=600, height=600)
  data(iris)
  plot(iris[1:4], pch=21, 
       bg=c("red", "green", "blue")[as.numeric(iris$Species)])
dev.off()

png(file="g206.png", width=600, height=600)
  a <- rnorm(10)
  b <- 1+ rnorm(10)
  c <- 1+ rnorm(10)
  d <- rnorm(10)
  x <- c(a,b,c,d)
  y <- factor(c( rep("A",20), rep("B",20)))
  z <- factor(c( rep("U",10), rep("V",20), rep("U",10) ))
  op = par(mfrow=c(2,2))
  plot(x~y)
  plot(x~z)
  plot(x[z=="U"] ~ y[z=="U"], border="red", ylim=c(min(x),max(x)))
  plot(x[z=="V"] ~ y[z=="V"], border="blue", add=T)
  plot(x[y=="A"] ~ z[y=="A"], border="red", ylim=c(min(x),max(x)))
  plot(x[y=="B"] ~ z[y=="B"], border="blue", add=T)
  par(op)
dev.off()

png(file="g207.png", width=600, height=600)
  l <- rep("",length(x))
  for (i in 1:length(x)){
    l[i] <- paste(y[i],z[i])
  }
  l <- factor(l)
  boxplot(x~l)
dev.off()

png(file="g208.png", width=600, height=600)
  # l est une liste � deux �l�ments
  myplot1 <- function (x, l, ...) {
    t <- tapply(x,l,mean)
    l1 <- levels(l[[1]])
    l2 <- levels(l[[2]])
    matplot(t,
            type='l', lty=1, col=1:length(l2),
            axes=F, ...)
    axis(1, 1:2, l1)
    axis(2)
    lim <- par("usr")
    legend(lim[1] + .05*(lim[2]-lim[1]), lim[4],
           l2, lwd=1, lty=1, col=1:length(l2) )
  }
  op <- par(mfrow=c(1,2))
  myplot1( x, list(y,z), ylim=c(0,2) )
  myplot1( x, list(z,y), ylim=c(0,2) )
  par(op)
dev.off()

png(file="g209.png", width=600, height=600)
  # l est une liste � deux �l�ments
  myplot3 <- function (x, l, ...) {
    l1 <- levels(l[[1]])
    l2 <- levels(l[[2]])
    t0 <- tapply(x,l,min)
    t1 <- tapply(x,l,function(x)quantile(x,.25))
    t2 <- tapply(x,l,median)
    t3 <- tapply(x,l,function(x)quantile(x,.75))
    t4 <- tapply(x,l,max)
    matplot(cbind(t0,t1,t2,t3,t4),
            type='l', 
            lty=c(rep(3,length(l2)), rep(2,length(l2)), 
                  rep(1,length(l2)), rep(2,length(l2)),
                  rep(3,length(l2)) ),
            col=1:length(l2),
            axes=F, ...)
    axis(1, 1:2, l1)
    axis(2)
    lim <- par("usr")
    legend(lim[1] + .05*(lim[2]-lim[1]), lim[4],
           l2, lwd=1, lty=1, col=1:length(l2) )
  }
  op <- par(mfrow=c(1,2))
  myplot3( x, list(y,z) )
  myplot3( x, list(z,y) )
  par(op)
dev.off()

png(file="g210.png", width=600, height=600)
  data(quakes)
  Depth <- equal.count(quakes$depth, number=8, overlap=.1)
  xyplot(lat ~ long | Depth, data = quakes)
dev.off()

png(file="g211.png", width=600, height=600)
  plot(lat ~ long, data=quakes)
dev.off()

png(file="g212.png", width=600, height=600)
  op <- par(mfrow=c(2,2))
  plot(lat ~ long, data=quakes)
  plot(lat ~ -depth, data=quakes)
  plot(-depth ~ long, data=quakes)
  par(op)
dev.off()

png(file="g213.png", width=600, height=600)
  library(mva)
  biplot(princomp(quakes[1:3]))
dev.off()

png(file="g214.png", width=600, height=600)
  pairs( princomp(quakes[1:3])$scores )
dev.off()

png(file="g215.png", width=600, height=600)
  data(barley)
  barchart(yield ~ variety | year * site, data=barley)
dev.off()

png(file="g216.png", width=600, height=600)
  barchart(yield ~ variety | year * site, data = barley,
           ylab = "Barley Yield (bushels/acre)",
           scales = list(x = list(0, abbreviate = TRUE,
                         minlength = 5)))
dev.off()

png(file="g217.png", width=600, height=600)
  # Rat�...
  dotplot(yield ~ variety | year * site, data = barley)
dev.off()

png(file="g218.png", width=400, height=1000)
  dotplot(variety ~ yield | year * site, data = barley)
dev.off()

png(file="g219.png", width=400, height=1000)
  data(barley)
  dotplot(variety ~ yield | site, groups = year,
          data = barley, 
          layout = c(1, 6), aspect = .5, pch = 16,
          col.line = c("grey", "transparent"),
          panel = "panel.superpose",
          panel.groups = "panel.dotplot")
dev.off()

png(file="g220.png", width=600, height=600)
  library(nlme)
  data(bdf)
  d <- data.frame( iq=bdf$IQ.perf, sex=bdf$sex, den=bdf$denomina )
  d <- d[1:100,] 
  bwplot( ~ d$iq | d$sex + d$den )
dev.off()

png(file="g221.png", width=600, height=600)
  histogram( ~ d$iq | d$sex + d$den )
dev.off()

png(file="g222.png", width=600, height=600)
  densityplot( ~ d$iq | d$sex + d$den )
dev.off()

png(file="g223.png", width=600, height=600)
  d <- data.frame( x=bdf$aritPOST, y=bdf$sex, z=equal.count(bdf$langPRET) )
  bwplot( ~ x | y + z, data=d )
dev.off()

png(file="g224.png", width=600, height=600)
  histogram( ~ x | y + z, data=d )
dev.off()

png(file="g225.png", width=600, height=600)
  densityplot( ~ x | y + z, data=d )
dev.off()

png(file="g226.png", width=600, height=600)
  d <- data.frame( x= (bdf$IQ.perf>11), y=bdf$sex, z=bdf$denomina )
  d <- as.data.frame(table(d))
  barchart( Freq ~ x | y * z, data=d )
dev.off()

png(file="g227.png", width=600, height=600)
  n <- 200
  x <- rnorm(n)
  y <- x^3+rnorm(n)
  plot1 <- xyplot(y~x)
  plot2 <- bwplot(x)
  # Attention : l'ordre est xmin, ymin, xmax, ymax
  print(plot1, position=c(0,.2,1,1), more=T)
  print(plot2, position=c(0,0,1,.2), more=F)
dev.off()

png(file="g228.png", width=600, height=600)
  n <- 200
  x <- rnorm(n)
  y <- x^4+rnorm(n)
  k <- .7
  op <- par(mar=c(0,0,0,0))
  # Attention : l'ordre est xmin, xmax, ymin, ymax
  par(fig=c(0,k,0,k))
  plot(y~x)
  par(fig=c(0,k,k,1), new=T)
  boxplot(x, horizontal=T)  
  par(fig=c(k,1,0,k), new=T)
  boxplot(y, horizontal=F)  
  par(op)
dev.off()

png(file="g229.png", width=600, height=1000)
  dotplot(variety ~ yield | site, data = barley, groups = year,
          panel = function(x, y, subscripts, ...) {
              dot.line <- trellis.par.get("dot.line")
              panel.abline(h = y, col = dot.line$col,
                           lty = dot.line$lty)
              panel.superpose(x, y, subscripts, ...)
          },
          key = list(space="right", transparent = TRUE,
                     points=list(pch=trellis.par.get("superpose.symbol")$pch[1:2],
                                 col=trellis.par.get("superpose.symbol")$col[1:2]),
                     text=list(c("1932", "1931"))),
          xlab = "Barley Yield (bushels/acre) ",
          aspect=0.5, layout = c(1,6), ylab=NULL)
dev.off()

png(file="g230.png", width=800, height=800)
  show.settings()
dev.off()

png(file="g231.png", width=600, height=600)
  y <- cars$dist
  x <- cars$speed
  vitesse <- shingle(x, co.intervals(x, number=6))
  histogram(~ x | vitesse, type = "density",
            panel = function(x, ...) {
              ps <- trellis.par.get('plot.symbol')
              nps <- ps
              nps$cex <- 1
              trellis.par.set('plot.symbol', nps)
              panel.histogram(x, ...)
              panel.densityplot(x, col = 'brown', lwd=3) 
              panel.xyplot(x = jitter(x), y = rep(0, length(x)), col='brown' )
              panel.mathdensity(dmath = dnorm,
                                args = list(mean=mean(x),sd=sd(x)),
                                lwd=3, lty=2, col='white')
              trellis.par.set('plot.symbol', ps)
            })
dev.off()

png(file="g232.png", width=600, height=600)
  ## banking
  data(sunspot)
  xyplot(sunspot ~ 1:37 ,type = "l",
         scales = list(y = list(log = TRUE)),
         sub = "log scales")
dev.off()

png(file="g233.png", width=600, height=600)
  xyplot(sunspot ~ 1:37 ,type = "l", aspect="xy",
         scales = list(y = list(log = TRUE)),
         sub = "log scales")
dev.off()

png(file="g234.png", width=600, height=600)
  #library(help=mva)
  library(mva)
  data(USArrests)
  p <- princomp(USArrests)
  biplot(p)
dev.off()

png(file="g235.png", width=600, height=600)
  plot(p)
dev.off()

png(file="g236.png", width=600, height=600)
  a <- seq(0,2*pi,length=100)
  plot( cos(a), sin(a), type='l', lty=3,
        xlab='comp 1', ylab='comp 2', main="Cercle des corr�lations" )
  v <- t(p$loadings)[1:2,]
  arrows(0,0, v[1,], v[2,], col='red')
  text(v[1,], v[2,],colnames(v))
dev.off()

png(file="g237.png", width=600, height=600)
  # Copy-pasted with the help of the "deparse" command:
  #   cat( deparse(x), file='foobar')
  notes <- matrix( c(15, NA, 7, 15, 11, 7, 7, 8, 11, 11, 13, 6, 14, 19, 9,
      8, 6, NA, 7, 14, 11, 13, 16, 10, 18, 7, 7, NA, 11, NA, NA, 6,
      15, 5, 11, 7, 3, NA, 3, 1, 10, 1, 1, 18, 13, 2, 2, 0, 7, 9, 13,
      NA, 19, 0, 17, 8, 2, 9, 2, 5, 12, 0, 8, 12, 8, 4, 8, 0, 5, 5.5,
      1, 12, 4, 13, 5, 11, 6, 0, 7, 8, 11, 9, 9, 9, 14, 8, 5, 8, 5, 5,
      12, 6, 16.5, 13.5, 15, 3, 10.5, 1.5, 10.5, 9, 15, 7.5, 12, 13.5,
      4.5, 13.5, 13.5, 6, 12, 7.5, 9, 6, 13.5, 13.5, 15, 13.5, 6, NA,
      13.5, 4.5, 14, NA, 14, 14, 14, 8, 16, NA, 6, 6, 12, NA, 7, 15,
      13, 17, 18, 5, 14, 17, 17, 13, NA, NA, 16, 14, 18, 13, 17, 17,
      8, 4, 16, 16, 16, 10, 15, 8, 10, 13, 12, 14, 8, 19, 7, 7, 9, 8,
      15, 16, 8, 7, 12, 5, 11, 17, 13, 13, 7, 12, 15, 8, 17, 16, 16,
      6, 7, 11, 15, 15, 19, 12, 15, 16, 13, 19, 14, 4, 13, 13, 19, 11,
      15, 7, 20, 16, 10, 12, 16, 14, 0, 0, 11, 9, 4, 10, 0, 0, 5, 11,
      12, 7, 12, 17, NA, 6, 6, 9, 7, 0, 7, NA, 15, 3, 20, 11, 10, 13,
      0, 0, 6, 1, 5, 6, 5, 4, 2, 0, 8, 9, NA, 0, 11, 11, 0, 7, 0, NA,
      NA, 7, 0, NA, NA, 6, 9, 6, 4, 5, 4, 3 ),
    nrow=30)
  notes <- data.frame(notes)
  # Ce ne sont pas les vrais noms
  row.names(notes) <- c("Anouilh", "Balzac", "Camus", "Dostoievski",
                        "Eschyle", "F�nelon", "Giraudoux", "Hom�re",
                        "Ionesco", "Jarry", "Kant", "La Fontaine",
                        "Marivaux", "Nerval", "Ossian", "Platon",
                        "Quevedo", "Racine", "Shakespeare", "T�rence",
                        "Updike", "Voltaire", "Whitman", "X", "Yourcenar",
                        "Zola", "27", "28", "29", "30")
  attr(notes, "names") <- c("C1", "DM1", "C2", "DS1", "DM2", "C3", "DM3", 
                            "DM4", "DS2")
  notes <- as.matrix(notes)
  notes <- t(t(notes) - apply(notes, 2, mean, na.rm=T))
  # Get rid of NAs
  notes[ is.na(notes) ] <- 0
  # plots
  plot(princomp(notes))
dev.off()

png(file="g238.png", width=600, height=600)
  biplot(princomp(notes))
dev.off()

png(file="g239.png", width=600, height=600)
  pairs(princomp(notes)$scores)
dev.off()

png(file="g240.png", width=600, height=600)
  pairs(princomp(notes)$scores[,1:3])
dev.off()

png(file="g241.png", width=600, height=600)
  p <- princomp(notes)
  pairs( rbind(p$scores, p$loadings)[,1:3], 
         col=c(rep(1,p$n.obs),rep(2, length(p$center))),
         pch=c(rep(1,p$n.obs),rep(3, length(p$center))),
       )
dev.off()

png(file="g242.png", width=600, height=600)
  library(lattice)
  splom(princomp(notes)$scores[,1:3])
dev.off()

png(file="g243.png", width=600, height=600)
  my.acp <- function (x) {
    n <- dim(x)[1]
    p <- dim(x)[2]
    # Translation pour se ramener � de l'alg�bre lin�aire
    centre <- apply(x, 2, mean)
    x <- x - matrix(centre, nr=n, nc=p, byrow=T)
    # diagonalisations, changements de bases
    e1 <- eigen( t(x) %*% x, symmetric=T )
    e2 <- eigen( x %*% t(x), symmetric=T )
    variables <- t(e2$vectors) %*% x
    individus <- t(e1$vectors) %*% t(x)
    # Les vecteurs qui nous int�ressent sont les colonnes 
    # des matrices pr�c�dentes. Pour les dessiner, en particulier 
    # avec la commande pairs, on les transpose.
    variables <- t(variables)
    individus <- t(individus)
    valeurs.propres <- e1$values
    # Dessin
    plot( individus[,1:2], 
          xlim=c( min(c(individus[,1],-individus[,1])), 
                  max(c(individus[,1],-individus[,1])) ),
          ylim=c( min(c(individus[,2],-individus[,2])), 
                  max(c(individus[,2],-individus[,2])) ),
          xlab='', ylab='', frame.plot=F )
    par(new=T)
    plot( variables[,1:2], col='red',
          xlim=c( min(c(variables[,1],-variables[,1])), 
                  max(c(variables[,1],-variables[,1])) ),
          ylim=c( min(c(variables[,2],-variables[,2])), 
                  max(c(variables[,2],-variables[,2])) ),
          axes=F, xlab='', ylab='', pch='.')
    axis(3, col='red')
    axis(4, col='red')
    arrows(0,0,variables[,1],variables[,2],col='red')
    # On renvoie les donn�es
    invisible(list(donnees=x, centre=centre, individus=individus, 
                   variables=variables, valeurs.propres=valeurs.propres))
  }

  n <- 20
  p <- 5
  x <- matrix( rnorm(p*n), nr=n, nc=p )
  my.acp(x)
  title(main="ACP � la main")
dev.off()

png(file="g244.png", width=600, height=600)
  biplot(princomp(x))
dev.off()

png(file="g245.png", width=600, height=600)
  b <- read.table('ling.txt')
  names(b) <- c(letters[1:26], 'langue')
  a <- b[,1:26]
  a <- a/apply(a,1,sum)
  biplot(princomp(a))
dev.off()

png(file="g246.png", width=600, height=600)
  plot(hclust(dist(a)))
dev.off()

png(file="g247.png", width=600, height=600)
  kmeans.plot <- function (data, n=2, iter.max=10) {
    k <- kmeans(data,n,iter.max)
    p <- princomp(data)
    u <- p$loadings
    # Les observations
    x <- (t(u) %*% t(data))[1:2,]
    x <- t(x)
    # Les centres
    plot(x, col=k$cluster, pch=3, lwd=3)
    c <- (t(u) %*% t(k$center))[1:2,]
    c <- t(c)
    points(c, col = 1:n, pch=7, lwd=3)
    # Un segment joignant chaque observation � son centre
    for (i in 1:n) {
      for (j in (1:length(data[,1]))[k$cluster==i]) {
        segments( x[j,1], x[j,2], c[i,1], c[i,2], col=i )
      }
    }
    text( x[,1], x[,2], attr(x, "dimnames")[[1]] )
  }
  kmeans.plot(a,2)
dev.off()

png(file="g248.png", width=600, height=600)
  # plot(lda(a,b[,27])) # Bug ?
  plot(lda(as.matrix(a),b[,27]))
dev.off()

png(file="g249.png", width=600, height=600)
  n <- 100
  v <- .1
  a <- rcauchy(n)
  b <- rcauchy(n)
  c <- rcauchy(n)
  d <- data.frame( x1 =  a+b+c+v*rcauchy(n),
                   x2 =  a+b-c+v*rcauchy(n),
                   x3 =  a-b+c+v*rcauchy(n),
                   x4 = -a+b+c+v*rcauchy(n),
                   x5 =  a-b-c+v*rcauchy(n),
                   x6 = -a+b-c+v*rcauchy(n) )
  biplot(princomp(d))
dev.off()

png(file="g250.png", width=600, height=600)
  rank.and.normalize.vector <- function (x) {
    x <- (rank(x)-.5)/length(x)
    x <- qnorm(x)
  }
  rank.and.normalize <- function (x) {
    if( is.vector(x) )
      return( rank.and.normalize.vector(x) )
    if( is.data.frame(x) ) {
      d <- NULL
      for (v in x) {
        if( is.null(d) )
          d <- data.frame( rank.and.normalize(v) )
        else 
          d <- data.frame(d, rank.and.normalize(v))
      }
      names(d) <- names(x)
      return(d)
    }
    stop("Data type not handled")
  }
  biplot(princomp(apply(d,2,rank.and.normalize)))
dev.off()

png(file="g251.png", width=600, height=600)
  pairs( princomp(d)$scores )
dev.off()

png(file="g252.png", width=600, height=600)
  pairs( princomp(apply(d,2,rank.and.normalize))$scores )
dev.off()

png(file="g253.png", width=600, height=600)
  n <- 100
  v <- .1
  # Des donn�es � peu pr�s planes
  x <- rnorm(n)
  y <- x*x + v*rnorm(n)
  z <- v*rnorm(n)
  d <- cbind(x,y,z)
  # On effectue une rotation
  random.rotation.matrix <- function (n) {
    m <- NULL
    for (i in 1:n) {
      x <- rnorm(n)
      x <- x / sqrt(sum(x*x))
      y <- rep(0,n)
      if (i>1) for (j in 1:(i-1)) {
        y <- y + sum( x * m[,j] ) * m[,j]
      }
      x <- x - y
      x <- x / sqrt(sum(x*x))
      m <- cbind(m, x)
    }
    m
  }
  m <- random.rotation.matrix(3)
  d <- t( m %*% t(d) )
  pairs(d)
  title(main="Les points sont dans un plan")
dev.off()

png(file="g254.png", width=600, height=600)
  pairs(cmdscale(dist(d),3))
  title(main="MDS")
dev.off()

png(file="g255.png", width=600, height=600)
  pairs(princomp(d)$scores)
  title(main="Analyse en composantes principales")
dev.off()

png(file="g256.png", width=600, height=600)
  library(pixmap)
  x <- read.pnm("photo1.ppm")
  d <- cbind( as.vector(x@red),
              as.vector(x@green),
              as.vector(x@blue) )
  m <- apply(d,2,mean)
  d <- t(  t(d) - m )
  s <- apply(d,2,sd)
  d <- t(  t(d) / s )
  library(som)
  r1 <- som(d,5,5)
  plot(r1)
dev.off()

png(file="g257.png", width=600, height=600)
  x <- r1$code.sum$x
  y <- r1$code.sum$y
  n <- r1$code.sum$nobs
  co <- r1$code   # Is it in the same order that x, y and n?
  co <- t( t(co) * s + m )
  plot(x, y, 
       pch=15,
       cex=5,      
       col=rgb(co[,1], co[,2], co[,3])
      )
dev.off()

png(file="g258.png", width=600, height=600)
  x <- r1$code.sum$x
  y <- r1$code.sum$y
  n <- r1$code.sum$nobs
  co <- r1$code   # Is it in the same order that x, y and n?
  co <- t( t(co) * s + m )
  plot(x, y, 
       pch=15,
       cex=5*n/max(n),      
       col=rgb(co[,1], co[,2], co[,3])
      )
dev.off()

png(file="g259.png", width=600, height=600)
  library(class)
  r2 <- SOM(d)
  plot(r2)
dev.off()

png(file="g260.png", width=600, height=600)
  x <- r2$grid$pts[,1]
  y <- r2$grid$pts[,2]
  n <- 1   # Where???
  co <- r2$codes
  co <- t( t(co) * s + m )
  plot(x, y, 
       pch=15,
       cex=5*n/max(n),
       col=rgb(co[,1], co[,2], co[,3])
      )
dev.off()

png(file="g261.png", width=600, height=600)
  op <- par(mfrow=c(2,2))
  for (i in 1:4) {
    r2 <- SOM(d) 
    plot(r2)
  }
  par(op)
dev.off()

png(file="g262.png", width=600, height=600)
  x <- r1$code.sum$x
  y <- r1$code.sum$y
  v <- r1$code

  op <- par(mfrow=c(2,2), mar=c(1,1,1,1))
  for (k in 1:dim(v)[2]) {
    m <- matrix(NA, nr=max(x), nc=max(y))
    for (i in 1:length(x)) {
      m[ x[i], y[i] ] <- v[i,k]
    }
    image(m, col=rainbow(255), axes=F)
  }
  par(op)
dev.off()

png(file="g263.png", width=600, height=600)
  x <- r2$grid$pts[,1]
  y <- r2$grid$pts[,2]
  v <- r2$codes

  op <- par(mfrow=c(2,2), mar=c(1,1,1,1))
  for (k in 1:dim(v)[2]) {
    m <- matrix(NA, nr=max(x), nc=max(y))
    for (i in 1:length(x)) {
      m[ x[i], y[i] ] <- v[i,k]
    }
    image(m, col=rainbow(255), axes=F)
  }
  par(op)
dev.off()

png(file="g264.png", width=600, height=600)
  library(MASS)
  data(HairEyeColor)
  x <- HairEyeColor[,,1]+HairEyeColor[,,2]
  biplot(corresp(x, nf = 2))
dev.off()

png(file="g265.png", width=600, height=600)
  biplot(corresp(t(x), nf = 2))
dev.off()

png(file="g266.png", width=600, height=600)
  # ???
  plot(corresp(x, nf=1))
dev.off()

png(file="g267.png", width=600, height=600)
  n <- 100
  m <- matrix(sample(c(T,F),n^2,replace=T), nr=n, nc=n)
  biplot(corresp(m, nf=2), main="Analyse des correspondances de donn�es al�atoires")
dev.off()

png(file="g268.png", width=600, height=600)
  vp <- corresp(m, nf=100)$cor
  plot(vp, ylim=c(0,max(vp)), type='l', 
       main="Analyse des correspondances de donn�es al�atoires")
dev.off()

png(file="g269.png", width=600, height=600)
  n <- 100
  x <- matrix(1:n, nr=n, nc=n, byrow=F)
  y <- matrix(1:n, nr=n, nc=n, byrow=T)
  m <- abs(x-y) <= n/10
  biplot(corresp(m, nf=2), 
         main='Analyse des correspondances de donn�es "en bande"')
dev.off()

png(file="g270.png", width=600, height=600)
  vp <- corresp(m, nf=100)$cor
  plot(vp, ylim=c(0,max(vp)), type='l', 
       main='Analyse des correspondances de donn�es "en bande"')
dev.off()

png(file="g271.png", width=600, height=600)
  n <- 100
  x <- matrix(1:n, nr=n, nc=n, byrow=F)
  y <- matrix(1:n, nr=n, nc=n, byrow=T)
  m <- abs(x-y) <= n/10
  plot.boolean.matrix <- function (m) { # Voir aussi levelplot
    nx <- dim(m)[1]
    ny <- dim(m)[2]
    x <- matrix(1:nx, nr=nx, nc=ny, byrow=F)
    y <- matrix(1:ny, nr=nx, nc=ny, byrow=T)
    plot( as.vector(x)[ as.vector(m) ], as.vector(y)[ as.vector(m) ], pch=16 )
  }
  plot.boolean.matrix(m)
dev.off()

png(file="g272.png", width=600, height=600)
  ox <- sample(1:n, n, replace=F)
  oy <- sample(1:n, n, replace=F)
  reorder.matrix <- function (m,ox,oy) {
    m <- m[ox,]
    m <- m[,oy]
    m
  }
  m2 <- reorder.matrix(m,ox,oy)
  plot.boolean.matrix(m2)
dev.off()

png(file="g273.png", width=600, height=600)
  a <- corresp(m2)
  o1 <- order(a$rscore)
  o2 <- order(a$cscore)
  m3 <- reorder.matrix(m2,o1,o2)
  plot.boolean.matrix(m3)
dev.off()

png(file="g274.png", width=600, height=600)
  n <- 100
  p <- .05
  done <- F 
  while( !done ){
    # On obtient souvent des matrices singuli�res
    m2 <- matrix( sample(c(F,T), n*n, replace=T, prob=c(1-p, p)), nr=n, nc=n )
    done <- det(m2) != 0
  }
  plot.boolean.matrix(m2)
dev.off()

png(file="g275.png", width=600, height=600)
  a <- corresp(m2)
  o1 <- order(a$rscore)
  o2 <- order(a$cscore)
  m3 <- reorder.matrix(m2,o1,o2)
  plot.boolean.matrix(m3)
dev.off()

png(file="g276.png", width=600, height=600)
  # Analyse des correspondances
  my.ac <- function (x) {
    if(any(x<0))
      stop("Expecting a contingency matrix -- with no negative entries")
    x <- x/sum(x)
    nr <- dim(x)[1]
    nc <- dim(x)[2]
    marges.lignes <- apply(x,2,sum)
    marges.colonnes <- apply(x,1,sum)
    profils.lignes <- x / matrix(marges.lignes, nr=nr, nc=nc, byrow=F)
    profils.colonnes <- x / matrix(marges.colonnes, nr=nr, nc=nc, byrow=T)
    # On n'oublie pas de centrer la matrice : on calcule la 
    # matrice des fr�quences sous l'hypoth�se d'ind�pendance des deux variables
    # et on fait la diff�rence.
    x <- x - outer(marges.colonnes, marges.lignes)
    e1 <- eigen( t(x) %*% diag(1/marges.colonnes) %*% x %*% diag(1/marges.lignes) )
    e2 <- eigen( x %*% diag(1/marges.lignes) %*% t(x) %*% diag(1/marges.colonnes) )
    v.col <- solve( e2$vectors, x )
    v.row <- solve( e1$vectors, t(x) )
    v.col <- t(v.col)
    v.row <- t(v.row)
    if(nr<nc)
      valeurs.propres <- e1$values
    else
      valeurs.propres <- e2$values
    # Dessin
    plot( v.row[,1:2], 
          xlab='', ylab='', frame.plot=F )
    par(new=T)
    plot( v.col[,1:2], col='red',
          axes=F, xlab='', ylab='', pch='+')
    axis(3, col='red')
    axis(4, col='red')
    # On renvoie les donn�es
    invisible(list(donnees=x, colonnes=v.col, lignes=v.row, 
                   valeurs.propres=valeurs.propres))
  }    

  nr <- 3
  nc <- 5
  x <- matrix(rpois(nr*nc,10), nr=nr, nc=nc)
  my.ac(x)
dev.off()

png(file="g277.png", width=600, height=600)
  plot(corresp(x,nf=2))
dev.off()

png(file="g278.png", width=600, height=600)
  library(MASS)
  data(farms)
  farms.mca <- mca(farms, abbrev=TRUE)
  farms.mca
  plot(farms.mca)
dev.off()

png(file="g279.png", width=600, height=600)
  # Pas beau
  my.table.to.data.frame <- function (a) {
    r <- NULL
    d <- as.data.frame.table(a)
    n1 <- dim(d)[1]
    n2 <- dim(d)[2]-1
    for (i in 1:n1) {
      for (j in 1:(d[i,n2+1])) {
        r <- rbind(r, d[i,1:n2])
      }
      row.names(r) <- 1:dim(r)[1]
    }
    r
  }
  r <- my.table.to.data.frame(HairEyeColor)
  plot(mca(r))
dev.off()

png(file="g280.png", width=1000, height=500)
  x <- HairEyeColor[,,1]+HairEyeColor[,,2]
  op <- par(mfcol=c(1,2))
  biplot(corresp(x, nf = 2), 
         main="Analyse des correspondances simples")  
  plot(mca(my.table.to.data.frame(x)), rows=F, 
       main="Analyse des correspondances multiples")
  par(op)
dev.off()

png(file="g281.png", width=600, height=600)
  # Analyse des correspondances multiples
  tableau.disjonctif.vecteur <- function (x) {
    y <- matrix(0, nr=length(x), nc=length(levels(x)))
    for (i in 1:length(x)) {
      y[i, as.numeric(x[i])] <- 1
    }
    y
  }
  tableau.disjonctif <- function (x) {
    if( is.vector(x) )
      y <- tableau.disjonctif.vecteur(x)
    else {
      y <- NULL
      y.names <- NULL
      for (i in 1:length(x)) {
        y <- cbind(y, tableau.disjonctif.vecteur(x[,i]))
        y.names <- c( y.names, paste(names(x)[i], levels(x[,i]), sep='') )
      }
    }
    colnames(y) <- y.names
    y
  }
  my.acm <- function (x, garder.un=F) {
    # x est un data.frame qui contient uniquement des facteurs
    # y est une matrice qui contient des 0 et des 1
    y <- tableau.disjonctif(x)
    # Nombre d'observations
    n <- dim(y)[1]
    # Nombre de variables
    s <- length(x)
    # Nombre de colonnes du tableau disjonctif
    p <- dim(y)[2]
    # La matrice et les poids
    F <- y/(n*s)
    Dp <- diag(t(y)%*%y) / (n*s)
    Dn <- rep(1/n,n)
    # On effectue l'analyse
    # Ne pas oublier d'enlever la valeur propre 1 !!!
    # (elle provient du fait qu'on n'a pas centr� la matrice)
    e1 <- eigen( t(F) %*% diag(1/Dn) %*% F %*% diag(1/Dp) )
    e2 <- eigen( F %*% diag(1/Dp) %*% t(F) %*% diag(1/Dn) )
    variables <- t(e2$vectors) %*% F
    individus <- t(e1$vectors) %*% t(F)
    variables <- t(variables)
    individus <- t(individus)
    valeurs.propres <- e1$values
    if( !garder.un ) {
      variables <- variables[,-1]
      individus <- individus[,-1]
      valeurs.propres <- valeurs.propres[-1]
    }
    plot( jitter(individus[,2], factor=5) ~ jitter(individus[,1], factor=5), 
          xlab='', ylab='', frame.plot=F )
    par(new=T)
    plot( variables[,1:2], col='red',
          axes=FALSE, xlab='', ylab='', type='n' )
    text( variables[,1:2], colnames(y), col='red')
    axis(3, col='red')
    axis(4, col='red')
    j <- 1
    col = rainbow(s)
    for (i in 1:s) {
      jj <- j + length(levels(x[,i])) - 1
      print( paste(j,jj) )
      lines( variables[j:jj,1], variables[j:jj,2], col=col[i] )
      j <- jj+1
    }
    invisible(list( donnees=x, variables=variables, individus=individus, 
                    valeurs.propres=valeurs.propres ))
  }
  
  random.data.1 <- function () {
    n <- 100
    m <- 3
    l <- c(3,2,5)
    x <- NULL    
    for (i in 1:m) {
      v <- factor( sample(1:l[i], n, replace=T), levels=1:l[i] )
      if( is.null(x) )
        x <- data.frame(v)
      else 
        x <- data.frame(x, v)
    }
    names(x) <- LETTERS[1:m]
    x
  }
  r <- NULL
  while(is.null(r)) {
    x1 <- random.data.1()
    try(r <- my.acm(x1))
  }
dev.off()

png(file="g282.png", width=600, height=600)
  my.random.data.2 <- function () {
    n <- 100
    m <- 3
    l <- c(3,2,3)
    x <- NULL    
    for (i in 1:m) {
      v <- factor( sample(1:l[i], n, replace=T), levels=1:l[i] )
      if( is.null(x) )
        x <- data.frame(v)
      else 
        x <- data.frame(x, v)
    }
    x[,3] <- factor( ifelse( runif(n)>.8, x[,1], x[,3] ), levels=1:l[1])
    names(x) <- LETTERS[1:m]
    x
  }
  r <- NULL
  while(is.null(r)) {
    x2 <- my.random.data.2()
    try(r <- my.acm(x2))
  }
dev.off()

png(file="g283.png", width=600, height=600)
  library(MASS)
  plot(mca(x1))
dev.off()

png(file="g284.png", width=600, height=600)
  plot(mca(x2))
dev.off()

png(file="g285.png", width=600, height=600)
  my.acm(x1, garder.un=T)
dev.off()

png(file="g286.png", width=600, height=600)
  my.acm(x2, garder.un=T)
dev.off()

png(file="g287.png", width=600, height=600)
  tableau.disjonctif.vecteur <- function (x) {
    if( is.factor(x) ){
      y <- matrix(0, nr=length(x), nc=length(levels(x)))
      for (i in 1:length(x)) {
      y[i, as.numeric(x[i])] <- 1
      }
      return(y)
    } else 
    return(x)
  }
  tableau.disjonctif <- function (x) {
    if( is.vector(x) )
      y <- tableau.disjonctif.vecteur(x)
    else {
      y <- NULL
      y.names <- NULL
      for (i in 1:length(x)) {
        y <- cbind(y, tableau.disjonctif.vecteur(x[,i]))
        if( is.factor(x[,i]) )
          y.names <- c( y.names, paste(names(x)[i], levels(x[,i]), sep='') )
        else 
          y.names <- c(y.names, names(x)[i])
      }
    }
    colnames(y) <- y.names
    y
  }
  my.am <- function (x) {
    y <- tableau.disjonctif(x)
    # Nombre d'observations
    n <- dim(y)[1]
    # Nombre de variables
    s <- length(x)
    # Nombre de colonnes du tableau disjonctif
    p <- dim(y)[2]

    # La matrice et les poids
    # Chaque variable a un poids �gal � 1, 
    # mais pour les variables qualitatives, qui sont �clat�es en 
    # plusieurs "sous-variables", c'est la somme des poids de ces 
    # "sous-variables" qui vaut 1.
    Dp <- diag(t(y)%*%y) / n
    j <- 1
    for(i in 1:s){
      if( is.factor(x[,i]) )
        j <- j + length(levels(x[,i]))
      else {
        Dp[j] <- 1
        j <- j+1
      }      
    }
    Dn <- rep(1,n)
    # Ce n'est pas une bonne id�e de centrer la variable...
    f <- ne.pas.centrer(y)
    # On effectue l'analyse
    e1 <- eigen( t(f) %*% diag(1/Dn) %*% f %*% diag(1/Dp) )
    e2 <- eigen( f %*% diag(1/Dp) %*% t(f) %*% diag(1/Dn) )
    variables <- t(e2$vectors) %*% f
    individus <- t(e1$vectors) %*% t(f)
    variables <- t(variables)
    individus <- t(individus)
    valeurs.propres <- e1$values
    # Il arrive que les erreurs d'arrondi rendent la matrice 
    # non diagonalisable sur R. On se retrouve alors avec des 
    # valeurs propres complexes et (pire) des vecteurs sur C.
    # C'est pour cette raison qu'il est pr�f�rable d'utiliser
    # la SVD, qui donne toujours des r�sultats r�els...
    if( any(Im(variables)!=0) | any(Im(individus)!=0) | 
        any(Im(valeurs.propres)!=0) ){
      warning("Matrice non diagonalisable sur R !!!")
      variables <- Re(variables)
      individus <- Re(individus)
      valeurs.propres <- Re(valeurs.propres)
    }
    plot( jitter(individus[,2], factor=5) ~ jitter(individus[,1], factor=5), 
          xlab='', ylab='', frame.plot=F )
    par(new=T)
    plot( variables[,1:2], col='red',
          axes=FALSE, xlab='', ylab='', type='n' )
    text( variables[,1:2], colnames(y), col='red')
    axis(3, col='red')
    axis(4, col='red')
    col = rainbow(s)
    j <- 1
    for (i in 1:s) {
      if( is.factor(x[,i]) ){
        jj <- j + length(levels(x[,i])) - 1
        print( paste(j,jj) )
        lines( variables[j:jj,1], variables[j:jj,2], col=col[i] )
        j <- jj+1
      } else {
        arrows(0,0,variables[j,1],variables[j,2],col=col[i])
        j <- j+1
      }
    }
  }
  ne.pas.centrer <- function (y) { y }
  
  n <- 500
  m <- 3
  p <- 2
  l <- c(3,2,5)
  x <- NULL    
  for (i in 1:m) {
    v <- factor( sample(1:l[i], n, replace=T), levels=1:l[i] )
    if( is.null(x) )
      x <- data.frame(v)
    else 
      x <- data.frame(x, v)
  }
  x <- cbind( x, matrix( rnorm(n*p), nr=n, nc=p ) )
  names(x) <- LETTERS[1:(m+p)]
  x1 <- x
  my.am(x1)
dev.off()

png(file="g288.png", width=600, height=600)
  n <- 500
  m <- 3
  p <- 2
  l <- c(3,2,5)
  x <- NULL    
  for (i in 1:m) {
    v <- factor( sample(1:l[i], n, replace=T), levels=1:l[i] )
    if( is.null(x) )
      x <- data.frame(v)
    else 
      x <- data.frame(x, v)
  }
  x <- cbind( x, matrix( rnorm(n*p), nr=n, nc=p ) )
  names(x) <- LETTERS[1:(m+p)]
  x[,3] <- factor( ifelse( runif(n)>.8, x[,1], x[,3] ), levels=1:l[1])
  x[,5] <- scale( ifelse( runif(n)>.9, as.numeric(x[,1]), as.numeric(x[,2]) )) + .1*rnorm(n)
  x2 <- x
  my.am(x2)
dev.off()

png(file="g289.png", width=600, height=600)
  ne.pas.centrer <- function (y) {
    centre <- apply(y, 2, mean)
    y - matrix(centre, nr=n, nc=dim(y)[2], byrow=T)
  }
  my.am(x1)
dev.off()

png(file="g290.png", width=600, height=600)
  my.am(x2)
dev.off()

png(file="g291.png", width=600, height=600)
  to.factor.numeric.vector <- function (x, number) {
    resultat <- NULL
    intervalles <- co.intervals(x,number,overlap=0)
    for (i in 1:number) {
      if( i==1 ) intervalles[i,1] = min(x)
      else
        intervalles[i,1] <- intervalles[i-1,2]
      if( i==number )
        intervalles[i,2] <- max(x)
    }
    for (valeur in x) {
      r <- NA
      for (i in 1:number) {
        if( valeur >= intervalles[i,1] & valeur <= intervalles[i,2] )
          r <- i
      }
      resultat <- append(resultat, r)
    }
    factor(resultat, levels=1:number)
  }
  to.factor.vector <- function (x, number) {
    if( is.factor(x) ) 
      return(x)
    else
      return(to.factor.numeric.vector(x,number))
  }
  to.factor <- function (x, number=4 ) {
    y <- NULL
    for (a in x) {
      aa <- to.factor.vector(a, number)
      if( is.null(y) )
        y <- data.frame(aa)
      else 
        y <- data.frame(y,aa)
    }
    names(y) <- names(x)
    y
  }
  my.am(to.factor(x1))
dev.off()

png(file="g292.png", width=600, height=600)
  my.am(to.factor(x1, number=3))
dev.off()

png(file="g293.png", width=600, height=600)
  my.am(to.factor(x2))
dev.off()

png(file="g294.png", width=600, height=600)
  my.am(to.factor(x2, number=3))
dev.off()

png(file="g295.png", width=600, height=600)
  library(MASS)
  n <- 100
  k <- 5
  x1 <- runif(k,-5,5) + rnorm(k*n)
  x2 <- runif(k,-5,5) + rnorm(k*n)
  x3 <- runif(k,-5,5) + rnorm(k*n)
  x4 <- runif(k,-5,5) + rnorm(k*n)
  x5 <- runif(k,-5,5) + rnorm(k*n)
  y <- factor(rep(1:5,n))
  plot(lda(y~x1+x2+x3+x4+x5))
dev.off()

png(file="g296.png", width=600, height=600)
  plot(lda(y~x1+x2+x3+x4+x5), dimen=2) 
dev.off()

png(file="g297.png", width=600, height=600)
  plot(lda(y~x1))
dev.off()

png(file="g298.png", width=600, height=600)
  plot(lda(y~x1+x2+x3+x4+x5)$svd, type='h')
dev.off()

png(file="g299.png", width=600, height=600)
  x <- rbind(matrix(rnorm(100, sd = 0.3), ncol = 2),
             matrix(rnorm(100, mean = 1, sd = 0.3), ncol = 2))
  cl <- kmeans(x, 2, 20)
  plot(x, col = cl$cluster, pch=3, lwd=1)
  points(cl$centers, col = 1:2, pch = 7, lwd=3)
  segments( x[cl$cluster==1,][,1], x[cl$cluster==1,][,2], 
            cl$centers[1,1], cl$centers[1,2])
  segments( x[cl$cluster==2,][,1], x[cl$cluster==2,][,2], 
            cl$centers[2,1], cl$centers[2,2], 
            col=2)
dev.off()

png(file="g300.png", width=600, height=600)
  # �a n'est pas �a
  cl <- kmeans(notes, 6, 20)
  plot(notes, col = cl$cluster, pch=3, lwd=3)
  points(cl$centers, col = 1:6, pch=7, lwd=3)
dev.off()

png(file="g301.png", width=600, height=600)
  n <- 6
  cl <- kmeans(notes, n, 20)
  p <- princomp(notes)
  u <- p$loadings
  x <- (t(u) %*% t(notes))[1:2,]
  x <- t(x)
  plot(x, col=cl$cluster, pch=3, lwd=3)
  c <- (t(u) %*% t(cl$center))[1:2,]
  c <- t(c)
  points(c, col = 1:n, pch=7, lwd=3)
  for (i in 1:n) {
    print(paste("Cluster", i))
    for (j in (1:length(notes[,1]))[cl$cluster==i]) {
      print(paste("Point", j))
      segments( x[j,1], x[j,2], c[i,1], c[i,2], col=i )
    }
  }
  text( x[,1], x[,2], attr(x, "dimnames")[[1]] )
dev.off()

png(file="g302.png", width=600, height=600)
  clusplot( notes, pam(notes, 6)$clustering )
dev.off()

png(file="g303.png", width=600, height=600)
  clusplot( notes, pam(notes, 2)$clustering )
dev.off()

png(file="g304.png", width=600, height=600)
  clusplot( daisy(notes), pam(notes,2)$clustering, diss=T )
dev.off()

png(file="g305.png", width=600, height=600)
  clusplot( daisy(notes), pam(notes,6)$clustering, diss=T )
dev.off()

png(file="g306.png", width=600, height=600)
  clusplot(fanny(notes,2))
dev.off()

png(file="g307.png", width=600, height=600)
  clusplot(fanny(notes,10))
dev.off()

png(file="g308.png", width=600, height=600)
  data(USArrests)
  hc <- hclust(dist(USArrests), "ave")
  plot(hc)
dev.off()

png(file="g309.png", width=600, height=600)
  plot(hc, hang = -1)
dev.off()

png(file="g310.png", width=600, height=600)
  plot(hclust(dist(notes)))
dev.off()

png(file="g311.png", width=600, height=600)
  p <- princomp(notes)
  u <- p$loadings
  x <- (t(u) %*% t(notes))[1:2,]
  x <- t(x)
  plot(x, col="red")
  c <- hclust(dist(notes))$merge
  y <- NULL
  n <- NULL
  for (i in (1:(length(notes[,1])-1))) {
    print(paste("Step", i))
    if( c[i,1]>0 ){
      a <- y[ c[i,1], ]
      a.n <- n[ c[i,1] ]
    } else {
      a <- x[ -c[i,1], ]
      a.n <- 1
    }
    if( c[i,2]>0 ){
      b <- y[ c[i,2], ]
      b.n <- n[ c[i,2] ]
    } else {
      b <- x[ -c[i,2], ]
      b.n <- 1
    }
    n <- append(n, a.n+b.n)
    m <- ( a.n * a + b.n * b )/( a.n + b.n )
    y <- rbind(y, m)
    segments( m[1], m[2], a[1], a[2], col="red" )
    segments( m[1], m[2], b[1], b[2], col="red" )
    if( i> length(notes[,1])-1-6 ){
      op=par(ps=30)
      text( m[1], m[2], paste(length(notes[,1])-i), col="red" )
      par(op)
    }
  }
  text( x[,1], x[,2], attr(x, "dimnames")[[1]] )
dev.off()

png(file="g312.png", width=600, height=600)
  ## Do the same with centroid clustering and squared Euclidean distance,
  ## cut the tree into ten clusters and reconstruct the upper part of the
  ## tree from the cluster centers.
  hc <- hclust(dist(USArrests)^2, "cen")
  memb <- cutree(hc, k = 10)
  cent <- NULL
  for(k in 1:10){
    cent <- rbind(cent, colMeans(USArrests[memb == k, , drop = FALSE]))
  }
  hc1 <- hclust(dist(cent)^2, method = "cen", members = table(memb))
  opar <- par(mfrow = c(1, 2))
  plot(hc,  labels = FALSE, hang = -1, main = "Original Tree")
dev.off()

png(file="g313.png", width=600, height=600)
  plot(hc1, labels = FALSE, hang = -1, main = "Re-start from 10 clusters")
dev.off()

png(file="g314.png", width=600, height=600)
  n <- 1000
  x <- runif(n,-1,1)
  y <- ifelse(runif(n)>.5,-.1,.1) + .02*rnorm(n)
  d <- data.frame(x=x, y=y)
  plot(d,type='p', xlim=c(-1,1), ylim=c(-1,1))
dev.off()

png(file="g315.png", width=600, height=600)
  test.kmeans <- function (d, ...) {
    cl <- kmeans(d,2)
    plot(d, col=cl$cluster, main="kmeans", ...)
    points(cl$centers, col=1:2, pch=7, lwd=3)
  }
  test.kmeans(d, xlim=c(-1,1), ylim=c(-1,1))
dev.off()

png(file="g316.png", width=600, height=600)
  test.hclust <- function (d, ...) {
    hc <- hclust(dist(d))
    remplir <- function (m, i, res=NULL) {
      if(i<0) {
        return( c(res, -i) )
      } else {
        return( c(res, remplir(m, m[i,1], NULL), remplir(m, m[i,2], NULL) ) )
      }
    }
    a <- remplir(hc$merge, hc$merge[n-1,1])
    b <- remplir(hc$merge, hc$merge[n-1,2])
    co <- rep(1,n)
    co[b] <- 2
    plot(d, col=co, main="hclust", ...)
  }
  test.hclust(d, xlim=c(-1,1), ylim=c(-1,1))
dev.off()

png(file="g317.png", width=600, height=600)
  get.sample <- function (n=1000, p=.7) {
    x1 <- rnorm(n)
    y1 <- rnorm(n)
    r2 <- 7+rnorm(n)
    t2 <- runif(n,0,2*pi)
    x2 <- r2*cos(t2)
    y2 <- r2*sin(t2)
    r <- runif(n)>p
    x <- ifelse(r,x1,x2)
    y <- ifelse(r,y1,y2)
    d <- data.frame(x=x, y=y)
    d
  }
  d <- get.sample()
  plot(d,type='p', xlim=c(-10,10), ylim=c(-10,10))
dev.off()

png(file="g318.png", width=600, height=600)
  test.kmeans(d, xlim=c(-10,10), ylim=c(-10,10))
dev.off()

png(file="g319.png", width=600, height=600)
  test.hclust(d, xlim=c(-10,10), ylim=c(-10,10))
dev.off()

png(file="g320.png", width=600, height=600)
  y <- abs(y)
  d <- data.frame(x=x, y=y)
  plot(d,type='p', xlim=c(-10,10), ylim=c(0,10))
dev.off()

png(file="g321.png", width=600, height=600)
  test.kmeans(d)
dev.off()

png(file="g322.png", width=600, height=600)
  test.hclust(d)
dev.off()

png(file="g323.png", width=600, height=600)
  d <- get.sample()
  x <- d$x; y <- d$y
  d <- data.frame(x=x, y=y, xx=x*x, yy=y*y, xy=x*y)
  test.kmeans(d)
dev.off()

png(file="g324.png", width=600, height=600)
  test.hclust(d)
dev.off()

png(file="g325.png", width=600, height=600)
  d <- data.frame(x=x, y=y, xx=x*x, yy=y*y, xy=x*y, xpy=x*x+y*y)
  test.kmeans(d)
dev.off()

png(file="g326.png", width=600, height=600)
  test.hclust(d)
dev.off()

png(file="g327.png", width=600, height=600)
  library(KernSmooth)
  r <- bkde2D(d, bandwidth=c(.5,.5))
  persp(r$fhat)
dev.off()

png(file="g328.png", width=600, height=600)
  n <- length(r$x1)
  plot( matrix(r$x1, nr=n, nc=n, byrow=F), 
        matrix(r$x2, nr=n, nc=n, byrow=T), 
        col=r$fhat>.001 )
dev.off()

png(file="g329.png", width=600, height=600)
  density.classification.plot <- function (x,y,d.lim=.5,n.lim=5) {
    n <- length(x)
    # Calcul des distances
    a <- matrix(x, nr=n, nc=n, byrow=F) - matrix(x, nr=n, nc=n, byrow=T) 
    b <- matrix(y, nr=n, nc=n, byrow=F) - matrix(y, nr=n, nc=n, byrow=T) 
    a <- a*a + b*b
    # On regarde si chaque observation est dans un amas
    b <- apply(a<d.lim, 1, sum)>=n.lim
    plot(x, y, col=b)
    points(x,y,pch='.')
  }
  density.classification.plot(d$x,d$y)
dev.off()

png(file="g330.png", width=600, height=600)
  # Attention : le code qui suit est tr�s r�cursif -- or, oar d�faut,
  # R limite la pile des appels de fonctions � 500 �l�ments. On
  # commence donc par augmenter cette valeur.
  options(expressions=10000)

  density.classification.plot <- function (x,y,d.lim=.5,n.lim=5) {
    n <- length(x)
    # Calcul des distances
    a <- matrix(x, nr=n, nc=n, byrow=F) - matrix(x, nr=n, nc=n, byrow=T) 
    b <- matrix(y, nr=n, nc=n, byrow=F) - matrix(y, nr=n, nc=n, byrow=T) 
    a <- a*a + b*b
    # On regarde si chaque observation est dans un amas
    b <- apply(a<d.lim, 1, sum)>=n.lim
    # On classe les observations
    cl <- rep(0,n)
    m <- 1
    numerote <- function (i,co,cl) {
      print(paste(co, i))
      for (j in (1:n)[ a[i,]<d.lim & b & cl==0 ]) {
        #print(paste("  ",j))
        cl[j] <- co
        try( cl <- numerote(j,co,cl) )   # Trop r�cursif...
      }
      cl
    }
    for (i in 1:n) {
      if (b[i]) { # Est-on dans un amas ?
        # Num�ro de l'amas
        if (cl[i] == 0) {
          co <- m
          cl[i] <- co
          m <- m+1
        } else {
          co <- cl[i]          
        }
        # On num�rote les points proches
        #print(co)
        cl <- numerote(i,co,cl)
      }
    }
    plot(x, y, col=cl)
    points(x,y,pch='.')
  }
  density.classification.plot(d$x,d$y)
dev.off()

png(file="g331.png", width=600, height=600)
  density.classification.plot <- function (x,y,d.lim=.5,n.lim=5, ...) {
    n <- length(x)
    # Calcul des distances
    a <- matrix(x, nr=n, nc=n, byrow=F) - matrix(x, nr=n, nc=n, byrow=T) 
    b <- matrix(y, nr=n, nc=n, byrow=F) - matrix(y, nr=n, nc=n, byrow=T) 
    a <- a*a + b*b
    # On regarde si chaque observation est dans un amas
    b <- apply(a<d.lim, 1, sum)>=n.lim
    # On classe les observations
    cl <- rep(0,n)
    m <- 0
    for (i in 1:n) {
      if (b[i]) { # Est-on dans un amas ?
        # Num�ro de l'amas
        if (cl[i] == 0) {
          m <- m+1
          co <- m
          cl[i] <- co
          print(paste("Processing cluster", co))
          done <- F 
          while (!done) {
            done <- T
            for (j in (1:n)[cl==co]) {
              l <- (1:n)[ a[j,]<d.lim & b & cl==0 ]
              if( length(l)>0 ) {
                done <- F
                for (k in l) { 
                  cl[k] <- co 
                  #print(k)
                }
              }
            }
            
          }
        } else {
          # Amas d�j� trait� : on ne fait rien
        }
      }
    }
    plot(x, y, col=cl, ...)
    points(x,y,pch='.')
  }
  density.classification.plot(d$x,d$y)
dev.off()

png(file="g332.png", width=600, height=600)
  op <- par(mfrow=c(3,3))
  for (d.lim in c(.2,1,2)) {
    for (n.lim in c(3,5,10)) {
      density.classification.plot(d$x,d$y,d.lim,n.lim, 
        main=paste("d.lim = ",d.lim, ",  n.lim = ",n.lim, sep=''))
    }
  }
  par(op)
dev.off()

png(file="g333.png", width=600, height=200)
  n <- 100
  x <- sample(c(-1,1), n, replace=T)
  plot(x, type='h', main="Tirages de Bernoulli")
dev.off()

png(file="g334.png", width=600, height=600)
  n <- 1000
  x <- sample(c(-1,1), n, replace=T)
  plot(cumsum(x), type='l',
       main="Sommes cumul�es de tirages de Bernoulli")
dev.off()

png(file="g335.png", width=600, height=200)
  n <- 100
  x <- sample(c(-1,1), n, replace=T, prob=c(.2,.8))
  plot(x, type='h',
       main="Tirages de Bernoulli sans �quiprobabilit�")
dev.off()

png(file="g336.png", width=600, height=600)
  n <- 200
  x <- sample(c(-1,1), n, replace=T, prob=c(.2,.8))
  plot(cumsum(x), type='l',
       main="Sommes cumul�es de tirages de Bernoulli")
dev.off()

png(file="g337.png", width=600, height=200)
  n <- 200
  x <- runif(n)
  x <- x>.3
  plot(x, type='h', main="Tirages de Bernoulli")
dev.off()

png(file="g338.png", width=600, height=600)
  N <- 10000
  n <- 20
  p <- .5
  x <- rep(0,N)
  for (i in 1:N) {
    x[i] <- sum(runif(n)<p)
  }
  hist(x, 
       col='light blue',
       main="Simulation d'une loi binomiale")
dev.off()

png(file="g339.png", width=600, height=600)
  N <- 1000
  n <- 10
  p <- .5
  x <- rbinom(N,n,p)
  hist(x, 
       xlim=c(min(x),max(x)), probability=T, nclass=max(x)-min(x)+1, 
       col='lightblue',
       main='Loi binomiale, n=10, p=.5')
  lines(density(x,bw=1), col='red', lwd=3)
dev.off()

png(file="g340.png", width=600, height=600)
  N <- 100000
  n <- 100
  p <- .5
  x <- rbinom(N,n,p)
  hist(x, 
       xlim=c(min(x),max(x)), probability=T, nclass=max(x)-min(x)+1, 
       col='lightblue',
       main='Loi binomiale, n=100, p=p')
  lines(density(x,bw=1), col='red', lwd=3)
dev.off()

png(file="g341.png", width=600, height=600)
  p <- .9
  x <- rbinom(N,n,p)
  hist(x, 
       xlim=c(min(x),max(x)), probability=T, nclass=max(x)-min(x)+1, 
       col='lightblue',
       main='Loi binomiale, n=100, p=p')
  lines(density(x,bw=1), col='red', lwd=3)
dev.off()

png(file="g342.png", width=600, height=600)
  N <- 10000
  n <- 100
  p <- .5
  x <- NULL
  for (i in 1:N) {
    x <- append(x, sum(sample( c(1,0), n, replace=T, prob=c(p, 1-p) )))
  }
  hist(x, 
       xlim=c(min(x),max(x)), probability=T, nclass=max(x)-min(x)+1, 
       col='lightblue',
       main='Loi binomiale, n=100, p=.5')
  lines(density(x,bw=1), col='red', lwd=3)
dev.off()

png(file="g343.png", width=600, height=600)
  N <- 10000
  n <- 5
  urne <- c(rep(1,15),rep(0,5))
  x <- NULL
  for (i in 1:N) {
    x <- append(x, sum(sample( urne, n, replace=F )))
  }
  hist(x, 
       xlim=c(min(x),max(x)), probability=T, nclass=max(x)-min(x)+1, 
       col='lightblue',
       main='Loi hyperg�om�trique, n=20, p=.75; k=5')
  lines(density(x,bw=1), col='red', lwd=3)
dev.off()

png(file="g344.png", width=600, height=600)
  N <- 10000
  n <- 5
  x <- rhyper(N, 15, 5, 5)
  hist(x, 
       xlim=c(min(x),max(x)), probability=T, nclass=max(x)-min(x)+1, 
       col='lightblue',
       main='Loi hyperg�om�trique, n=20, p=.75, k=5')
  lines(density(x,bw=1), col='red', lwd=3)
dev.off()

png(file="g345.png", width=600, height=600)
  N <- 10000
  n <- 5
  x <- rhyper(N, 300, 100, 100)
  hist(x, 
       xlim=c(min(x),max(x)), probability=T, nclass=max(x)-min(x)+1, 
       col='lightblue',
       main='Loi hyperg�om�trique, n=400, p=.75, k=100')
  lines(density(x,bw=1), col='red', lwd=3)
dev.off()

png(file="g346.png", width=600, height=600)
  N <- 10000
  x <- rpois(N, 1)
  hist(x, 
       xlim=c(min(x),max(x)), probability=T, nclass=max(x)-min(x)+1, 
       col='lightblue',
       main='Loi de Poisson, lambda=1')
  lines(density(x,bw=1), col='red', lwd=3)
dev.off()

png(file="g347.png", width=600, height=600)
  N <- 10000
  x <- rpois(N, 3)
  hist(x, 
       xlim=c(min(x),max(x)), probability=T, nclass=max(x)-min(x)+1, 
       col='lightblue',
       main='Loi de Poisson, lambda=3')
  lines(density(x,bw=1), col='red', lwd=3)
dev.off()

png(file="g348.png", width=600, height=600)
  N <- 10000
  x <- rpois(N, 5)
  hist(x, 
       xlim=c(min(x),max(x)), probability=T, nclass=max(x)-min(x)+1, 
       col='lightblue',
       main='Loi de Poisson, lambda=5')
  lines(density(x,bw=1), col='red', lwd=3)
dev.off()

png(file="g349.png", width=600, height=600)
  N <- 10000
  x <- rpois(N, 20)
  hist(x, 
       xlim=c(min(x),max(x)), probability=T, nclass=max(x)-min(x)+1, 
       col='lightblue',
       main='Loi de Poisson, lambda=20')
  lines(density(x,bw=1), col='red', lwd=3)
dev.off()

png(file="g350.png", width=600, height=600)
  N <- 10000
  x <- rgeom(N, .5)
  hist(x, 
       xlim=c(min(x),max(x)), probability=T, nclass=max(x)-min(x)+1, 
       col='lightblue',
       main='Loi g�om�trique, p=.5')
  lines(density(x,bw=1), col='red', lwd=3)
dev.off()

png(file="g351.png", width=600, height=600)
  N <- 10000
  x <- rgeom(N, .1)
  hist(x, 
       xlim=c(min(x),max(x)), probability=T, nclass=max(x)-min(x)+1, 
       col='lightblue',
       main='Loi g�om�trique, p=.1')
  lines(density(x,bw=1), col='red', lwd=3)
dev.off()

png(file="g352.png", width=600, height=600)
  N <- 10000
  x <- rgeom(N, .01)
  hist(x, 
       xlim=c(min(x),max(x)), probability=T, nclass=20,
       col='lightblue',
       main='Loi g�om�trique, p=.01')
  lines(density(x), col='red', lwd=3)
dev.off()

png(file="g353.png", width=600, height=600)
  N <- 100000
  x <- rnbinom(N, 10, .25)
  hist(x, 
       xlim=c(min(x),max(x)), probability=T, nclass=max(x)-min(x)+1, 
       col='lightblue',
       main='Loi binomiale n�gative, n=10, p=.25')
  lines(density(x,bw=1), col='red', lwd=3)
dev.off()

png(file="g354.png", width=600, height=600)
  N <- 10000
  x <- rnbinom(N, 10, .5)
  hist(x, 
       xlim=c(min(x),max(x)), probability=T, nclass=max(x)-min(x)+1, 
       col='lightblue',
       main='Loi binomiale n�gative, n=10, p=.5')
  lines(density(x,bw=1), col='red', lwd=3)
dev.off()

png(file="g355.png", width=600, height=600)
  N <- 10000
  x <- rnbinom(N, 10, .75)
  hist(x, 
       xlim=c(min(x),max(x)), probability=T, nclass=max(x)-min(x)+1, 
       col='lightblue',
       main='Loi binomiale n�gative, n=10, p=.75')
  lines(density(x,bw=1), col='red', lwd=3)
dev.off()

png(file="g356.png", width=600, height=600)
  curve(dexp(x), xlim=c(0,10), col='red', lwd=3,
        main='Densit� de la loi exponentielle')
dev.off()

png(file="g357.png", width=600, height=600)
  n <- 1000
  x <- rexp(n)
  hist(x, probability=T,
       col='light blue', main='Loi exponentielle')
  lines(density(x), col='red', lwd=3)
  curve(dexp(x), xlim=c(0,10), col='red', lwd=3, lty=2,
        add=T)
dev.off()

png(file="g358.png", width=600, height=600)
  limite.centrale <- function (r=runif, m=.5, s=1/sqrt(12), n=c(1,3,10,30), N=1000) {
    for (i in n) {
      x <- matrix(r(i*N),nc=i)
      x <- ( apply(x, 1, sum) - i*m )/(sqrt(i)*s)
      hist(x, col='light blue', probability=T, main=paste("n =",i), 
           ylim=c(0,max(.4, density(x)$y)))
      lines(density(x), col='red', lwd=3)
      curve(dnorm(x), col='blue', lwd=3, lty=3, add=T)
      if( N>100 ) {
        rug(sample(x,100))
      } else {
        rug(x)
      }
    }
  }
  op <- par(mfrow=c(2,2))
  limite.centrale()
  par(op)
dev.off()

png(file="g359.png", width=600, height=600)
  op <- par(mfrow=c(2,2))
  limite.centrale(rexp, m=1, s=1)
  par(op)
dev.off()

png(file="g360.png", width=600, height=600)
  op <- par(mfrow=c(2,2))
  limite.centrale(rexp, m=1, s=1)
  par(op)
dev.off()

png(file="g361.png", width=600, height=600)
  op <- par(mfrow=c(2,2))
  limite.centrale(function (n) { rnorm(n, sample(c(-3,3),n,replace=T)) }, 
                  m=0, s=sqrt(10), n=c(1,2,3,10))
  par(op)
dev.off()

png(file="g362.png", width=600, height=600)
  curve(dnorm(x), xlim=c(-3,3), col='red', lwd=3)
  title(main='Densit� de la loi normale')
dev.off()

png(file="g363.png", width=600, height=600)
  curve(pnorm(x), xlim=c(-3,3), col='red', lwd=3)
  title(main='Primitive de la densit� de la loi normale')
dev.off()

png(file="g364.png", width=600, height=600)
  curve(qnorm(x), xlim=c(0,1), col='red', lwd=3)
  title(main='Fonction quantile de la loi normale')
dev.off()

png(file="g365.png", width=600, height=600)
  n <- 1000
  x <- rnorm(n)
  hist(x, probability=T, col='light blue', main='Loi normale')
  lines(density(x), col='red', lwd=3)
  curve(dnorm(x), add=T, col='red', lty=2, lwd=3)
  legend(par('usr')[2], par('usr')[4], xjust=1,
         c('sample density', 'theoretical density'),
         lwd=2, lty=c(1,2),
         col='red')
dev.off()

png(file="g366.png", width=600, height=600)
  curve(dchisq(x,1), xlim=c(0,5), col='red', lwd=3)
  abline(h=0,lty=3)
  abline(v=0,lty=3)
  title(main="Loi du Chi2 � un degr� de libert�")
dev.off()

png(file="g367.png", width=600, height=600)
  curve(dchisq(x,1), xlim=c(0,10), ylim=c(0,.6), col='red', lwd=3)
  curve(dchisq(x,2), add=T, col='green', lwd=3)
  curve(dchisq(x,3), add=T, col='blue', lwd=3)
  curve(dchisq(x,5), add=T, col='orange', lwd=3)
  abline(h=0,lty=3)
  abline(v=0,lty=3)
  legend(par('usr')[2], par('usr')[4], xjust=1,
         c('df=1', 'df=2', 'df=3', 'df=5'),
         lwd=3,
         lty=1,
         col=c('red', 'green', 'blue', 'orange')
        )
  title(main='Lois du Chi^2')
dev.off()

png(file="g368.png", width=600, height=600)
  curve( dt(x,1), xlim=c(-3,3), ylim=c(0,.4), col='red', lwd=2 )
  curve( dt(x,2), add=T, col='blue', lwd=2 )
  curve( dt(x,5), add=T, col='green', lwd=2 )
  curve( dt(x,10), add=T, col='orange', lwd=2 )
  curve( dnorm(x), add=T, lwd=3, lty=3 )
  title(main="Lois T de Student")
  legend(par('usr')[2], par('usr')[4], xjust=1,
         c('df=1', 'df=2', 'df=5', 'df=10', 'loi normale'),
         lwd=c(2,2,2,2,2), 
         lty=c(1,1,1,1,3),
         col=c('red', 'blue', 'green', 'orange', par("fg")))
dev.off()

png(file="g369.png", width=600, height=600)
  curve(df(x,1,1), xlim=c(0,2), ylim=c(0,.8), lty=2)
  curve(df(x,3,1), add=T)
  curve(df(x,6,1), add=T, lwd=3)
  curve(df(x,3,3), add=T, col='red')
  curve(df(x,6,3), add=T, lwd=3, col='red')
  curve(df(x,3,6), add=T, col='blue')
  curve(df(x,6,6), add=T, lwd=3, col='blue')
  title(main="Densit� de la loi de Fisher")
  legend(par('usr')[2], par('usr')[4], xjust=1,
         c('df=(1,1)', 'df=(3,1)', 'df=(6,1)', 
           'df=(3,3)', 'df=(6,3)', 
           'df=(3,6)', 'df=(6,6)'),
         lwd=c(1,1,3,1,3,1,3),
         lty=c(2,1,1,1,1,1,1),
         col=c(par("fg"), par("fg"), par("fg"), 'red', 'red', 'blue', 'blue'))
dev.off()

png(file="g370.png", width=600, height=600)
  curve(dlnorm(x), xlim=c(-.2,5), lwd=3,
        main="Densit� de la loi log-normale")
dev.off()

png(file="g371.png", width=600, height=600)
  curve(dcauchy(x),xlim=c(-5,5), ylim=c(0,.5), lwd=3)
  curve(dnorm(x), add=T, col='red', lty=2)
  legend(par('usr')[2], par('usr')[4], xjust=1,
         c('Loi de Cauchy', 'Loi normale'),
         lwd=c(3,1),
         lty=c(1,2),
         col=c(par("fg"), 'red'))
dev.off()

png(file="g372.png", width=600, height=600)
  curve(dexp(x), xlim=c(0,3), ylim=c(0,2))
  curve(dweibull(x,1), lty=3, lwd=3, add=T)
  curve(dweibull(x,2), col='red', add=T)
  curve(dweibull(x,.8), col='blue', add=T)
  title(main="Densit� de la loi de Weibull")
  legend(par('usr')[2], par('usr')[4], xjust=1,
         c('Loi exponentielle', 'Loi de Weibull, shape=1',
           'Loi de Weibull, shape=2', 'Loi de Weibull, shape=.8'),
         lwd=c(1,3,1,1),
         lty=c(1,3,1,1),
         col=c(par("fg"), par("fg"), 'red', 'blue'))
dev.off()

png(file="g373.png", width=600, height=600)
  curve( dgamma(x,1,1), xlim=c(0,5) )
  curve( dgamma(x,2,1), add=T, col='red' )
  curve( dgamma(x,3,1), add=T, col='green' )
  curve( dgamma(x,4,1), add=T, col='blue' )
  curve( dgamma(x,5,1), add=T, col='orange' )
  title(main="Densit� de la loi gamma")
  legend(par('usr')[2], par('usr')[4], xjust=1,
         c('k=1 (loi exponentielle)', 'k=2', 'k=3', 'k=4', 'k=5'),
         lwd=1, lty=1,
         col=c(par('fg'), 'red', 'green', 'blue', 'orange') )
dev.off()

png(file="g374.png", width=600, height=600)
  n <- 500
  x1 <- rexp(n,17)
  x2 <- rexp(n,17)
  x3 <- rexp(n,17)
  x <- x1 + x2 + x3
  # Plus simple, mais moins lisible :
  # k <- 3
  # x <- drop(apply( matrix( rexp(n*k,17), nr=n, nc=k ), 1, sum))
  y <- qgamma(ppoints(n),3,17)
  plot( sort(x) ~ sort(y), log='xy' )
  abline(0,1, col='red')
  title("Comparaison d'une loi Gamma et d'une somme de vaiid exponentielles")
dev.off()

png(file="g375.png", width=600, height=600)
  curve( dbeta(x,1,1), xlim=c(0,1), ylim=c(0,4) )
  curve( dbeta(x,2,1), add=T, col='red' )
  curve( dbeta(x,3,1), add=T, col='green' )
  curve( dbeta(x,4,1), add=T, col='blue' )
  curve( dbeta(x,2,2), add=T, lty=2, lwd=2, col='red' )
  curve( dbeta(x,3,2), add=T, lty=2, lwd=2, col='green' )
  curve( dbeta(x,4,2), add=T, lty=2, lwd=2, col='blue' )
  curve( dbeta(x,2,3), add=T, lty=3, lwd=3, col='red' )
  curve( dbeta(x,3,3), add=T, lty=3, lwd=3, col='green' )
  curve( dbeta(x,4,3), add=T, lty=3, lwd=3, col='blue' )
  title(main="Densit� de la loi b�ta")
  legend(par('usr')[1], par('usr')[4], xjust=0,
         c('(1,1)', '(2,1)', '(3,1)', '(4,1)', 
           '(2,2)', '(3,2)', '(4,2)',
           '(2,3)', '(3,3)', '(4,3)' ),
         lwd=1, #c(1,1,1,1, 2,2,2, 3,3,3),
         lty=c(1,1,1,1, 2,2,2, 3,3,3),
         col=c(par('fg'), 'red', 'green', 'blue', 
               'red', 'green', 'blue', 
               'red', 'green', 'blue' ))
dev.off()

png(file="g376.png", width=600, height=600)
  N <- 500
  n <- 5
  y <- drop(apply( matrix( runif(n*N), nr=N, nc=n), 1, max ))
  x <- qbeta(ppoints(N), n, 1)
  plot( sort(y) ~ x )
  abline(0,1, col='red')
  title("Statistique d'ordre et loi b�ta")
dev.off()

png(file="g377.png", width=600, height=600)
  N <- 500
  n <- 5
  k <- 3
  y <- drop(apply( matrix( runif(n*N), nr=n, nc=N), 2, sort )[n-k,])
  x <- qbeta(ppoints(N), n-k, k+1) # Exercice : d'o� viennent ces coefficients ?
  plot( sort(y) ~ x )
  abline(0,1, col='red')
  title("Statistique d'ordre et loi b�ta")
dev.off()

png(file="g378.png", width=600, height=600)
  # Je reconnais avoir tout d'abord trouv� les coefficients en tatonnant :
  op <- par(mfrow=c(5,5), mar=c(0,0,0,0) )
  for (i in 1:5) {
    for (j in 1:5) {
      plot( sort(y) ~ qbeta(ppoints(N), j, i), xlab='', ylab='', axes=F )
      abline(0,1, col='red')
      box()
      text( (par('usr')[1]+par('usr')[2])/2, 
            (par('usr')[3]+par('usr')[4])/2, 
            paste(j,i),
            cex=3, col='blue' )
    }
  }
  par(op)
dev.off()

png(file="g379.png", width=600, height=600)
  curve(dbeta(x,8,4),xlim=c(0,1))
  title(main="Distribution a posteriori")
dev.off()

png(file="g380.png", width=600, height=600)
  curve(dbeta(x,10,10), xlim=c(0,1), lwd=3)
  curve(dbeta(x,1,1), add=T, col='red', lwd=3)
  curve(dbeta(x,2,2), add=T, col='green', lwd=3)
  curve(dbeta(x,5,2), add=T, col='blue',lwd=3)
  curve(dbeta(x,.1,.5), add=T, col='orange')
  legend(par('usr')[2], par('usr')[4], xjust=1,
         c('B(10,10)', 'B(1,1)', 'B(2,2)', 'B(5,2)', 'B(.1,.5)'),
         lwd=c(3,3,3,3,1), lty=1,
         col=c(par('fg'),'red','green','blue','orange'))
  title("Densit� de quelques lois B�ta")
dev.off()

png(file="g381.png", width=600, height=600)
  # Exemple du manuel
  library(nor1mix)
  ppos <- which("package:nor1mix" == search())
  nms <- ls(pat="^MW.nm", pos = ppos)
  nms <- nms[order(as.numeric(substring(nms,6)))]
  op <- par(mfrow=c(4,4), mgp = c(1.2, 0.5, 0), tcl = -0.2,
            mar = .1 + c(2,2,2,1), oma = c(0,0,3,0))
  for(n in nms) { plot(get(n, pos = ppos)) }
    mtext("The Marron-Wand Densities", outer = TRUE,
          font = 2, cex = 1.6)
  par(op)
dev.off()

png(file="g382.png", width=600, height=600)
  rmnorm <- function (R, C, mu=rep(0,dim(C)[1])) {
    A <- t(chol(C))
    n <- dim(C)[1]
    t(mu + A %*% matrix(rnorm(R*n),nr=n))
  }
  C <- matrix(c(2,.5,.5,1),nr=2)
  mu <- c(2,1)
  y <- rmnorm(1000,C, mu)
  cov(y)
  plot(y)

  abline(h=mu[2], lty=3, lwd=3, col='blue')  
  abline(v=mu[1], lty=3, lwd=3, col='blue')  
  e <- eigen(C)
  r <- sqrt(e$values)
  v <- e$vectors
  N <- 100
  theta <- seq(0,2*pi, length=N)
  x <- mu[1] + r[1]*v[1,1]*cos(theta) +
       r[2]*v[1,2]*sin(theta)
  y <- mu[2] + r[1]*v[2,1]*cos(theta) +
       r[2]*v[2,2]*sin(theta)
  lines(x,y, lwd=3, col='blue')
dev.off()

png(file="g383.png", width=600, height=600)
  x <- read.table("SUNW.csv", header=T, sep=",")
  x <- x$Close
  x <- diff(log(x))   # Compute the returns
  qqnorm(x, main="Normality of stock returns (15 years)")
  qqline(x, col='red')
dev.off()

png(file="g384.png", width=600, height=600)
  qqnorm(x[1:90], main="Normality of stock returns (3 months)")
  qqline(x[1:90], col='red')
dev.off()

png(file="g385.png", width=600, height=600)
  plot(density(x), main="Stock returns density vs normal density")
  m <- mean(x)
  s <- sd(x)
  curve( dnorm(x, m, s), col='red', add=T)
dev.off()

png(file="g386.png", width=600, height=600)
  plot(density(x), log='y', main="Stock returns density vs normal density")
  curve( dnorm(x, m, s), col='red', add=T)
dev.off()

png(file="g387.png", width=600, height=600)
  plot(density(x), log='y', ylim=c(1e-1,1.5e1), xlim=c(-.2,.2),
       main="Stock returns density vs normal density (detail)")
  curve( dnorm(x, m, s), col='red', add=T)
dev.off()

png(file="g388.png", width=600, height=600)
  library(evd)
  curve(dfrechet(x, shape=1), lwd=3, xlim=c(-1,2), ylim=c(0,1),
        ylab="", main="density of the Frechet distribution")
  for (s in seq(.1,2,by=.1)) {
    curve(dfrechet(x, shape=s), add=T)
  }
  curve(dfrechet(x, shape=2), lwd=3, add=T, col='red')
  curve(dfrechet(x, shape=.5), lwd=3, add=T, col='blue')
dev.off()

png(file="g389.png", width=600, height=600)
  curve(drweibull(x, shape=1), lwd=3, xlim=c(-2,1), ylim=c(0,1),
        ylab="", main="density of the (reverse) Weibull distribution")
  for (s in seq(.1,2,by=.1)) {
    curve(drweibull(x, shape=s), add=T)
  }
  curve(drweibull(x, shape=2), lwd=3, add=T, col='red')
  curve(drweibull(x, shape=.5), lwd=3, add=T, col='blue')
dev.off()

png(file="g390.png", width=600, height=600)
  curve(dgumbel(x), lwd=3, xlim=c(-2,2), ylim=c(0,1),
        ylab="", main="density of the Gumbel distribution")
dev.off()

png(file="g391.png", width=600, height=600)
  curve(dgev(x, shape=0), lwd=3, xlim=c(-2,2), ylim=c(0,1),
        ylab="", main="density of the GEV distribution")
  for (s in seq(-2,2,by=.1)) {
    curve(dgev(x, shape=s), add=T)
  }
  curve(dgev(x, shape=-1), lwd=3, add=T, col='red')
  curve(dgev(x, shape=1), lwd=3, add=T, col='blue')
dev.off()

png(file="g392.png", width=600, height=600)
  x <- read.table("SUNW.csv", header=T, sep=",")
  x <- x$Close
  x <- diff(log(x))   # Compute the returns
  x <- sort(x)
  n <- length(x)
  m <- floor(.9*n)
  y <- (1:n)/n
  plot(x,y, type='l', main="empirical cdf of stock returns")
  lines(x[m:n], y[m:n], col='red', lwd=3)
dev.off()

png(file="g393.png", width=600, height=600)
  plot(x[m:n], y[m:n], col='red', lwd=3,
       type='l', main="empirical conditionnal excess cdf of stock returns")
dev.off()

png(file="g394.png", width=600, height=600)
  plot(x[m:n], (y[m:n] - y[m])/(1-y[m]) , col='red', lwd=3,
       type='l', main="rescaled empirical conditionnal excess cdf of stock returns")
dev.off()

png(file="g395.png", width=600, height=600)
  curve(dgpd(x, shape=0), lwd=3, xlim=c(-.1,2), ylim=c(0,2),
        ylab="", main="density of the Generalized Pereto Distribution (GPD)")
  for (s in seq(-2,2,by=.1)) {
    curve(dgpd(x, shape=s), add=T)
  }
  curve(dgpd(x, shape=-1), lwd=3, add=T, col='red')
  curve(dgpd(x, shape=1), lwd=3, add=T, col='blue')
dev.off()

png(file="g396.png", width=600, height=600)
  curve(pgpd(x, shape=0), lwd=3, xlim=c(-.1,2), ylim=c(0,1),
        ylab="", main="cdf of the Generalized Pereto Distribution (GPD)")
  for (s in seq(-2,2,by=.1)) {
    curve(pgpd(x, shape=s), add=T)
  }
  curve(pgpd(x, shape=-1), lwd=3, add=T, col='red')
  curve(pgpd(x, shape=1), lwd=3, add=T, col='blue')
dev.off()

png(file="g397.png", width=600, height=600)
  x <- read.table("SUNW.csv", header=T, sep=",")
  x <- x$Close
  x <- diff(log(x))   # Compute the returns
  x <- sort(x)
  n <- length(x)
  m <- floor(.9*n)
  y <- (1:n)/n
  op <- par(mfrow=c(3,3), mar=c(2,2,2,2))
  for (s in seq(0,2,length=9)) {
    plot(qgpd(ppoints(n-m+1),shape=s), x[m:n],
         xlab='', ylab='')
  }
  par(op)
dev.off()

png(file="g398.png", width=600, height=600)
  qqnorm(x)
dev.off()

png(file="g399.png", width=600, height=600)
  x <- sort(x)
  e <- rep(NA, length(x))
  for (i in seq(along=x)) {
    u <- x[i]
    e[i] <- mean( (x-u)[x>u] )
  }
  plot(x, e, type='o', main="Sample mean excess plot")
dev.off()

png(file="g400.png", width=600, height=600)
  op <- par(mfrow=c(3,3))
  for (f in c("SUNW", "ADBE", "ADPT", 
              "PCAR", "COST", "INTC",
              "MSFT", "ADCT", "BMET")) {
    x <- read.table(paste(f,".csv", sep=''), header=T, sep=",")
    x <- x$Close
    x <- diff(log(x))   # Compute the returns
    x <- sort(x)
    e <- rep(NA, length(x))
    for (i in seq(along=x)) {
      u <- x[i]
      e[i] <- mean( (x-u)[x>u] )
    }
    plot(x, e, type='o', main="Sample mean excess plot")
  }
  par(op)
dev.off()

png(file="g401.png", width=600, height=600)
  op <- par(mfrow=c(3,3))
  for (f in c("SUNW", "ADBE", "ADPT", 
              "PCAR", "COST", "INTC",
              "MSFT", "ADCT", "BMET")) {
    x <- read.table(paste(f,".csv", sep=''), header=T, sep=",")
    x <- x$Close
    x <- -diff(log(x))   # Compute the returns
    x <- sort(x)
    e <- rep(NA, length(x))
    for (i in seq(along=x)) {
      u <- x[i]
      e[i] <- mean( (x-u)[x>u] )
    }
    plot(x, e, type='o', main="Sample mean excess plot")
  }
  par(op)
dev.off()

png(file="g402.png", width=600, height=600)
  n <- 5
  x <- y <- z <- vector()
  for(i in 1:10000){
    t <- rnorm(n)
    z <- append(z, sum(t*t)/n)
    t <- t - mean(t)
    t <- t*t
    x <- append(x, sum(t)/n)
    y <- append(y, sum(t)/(n-1))
  }
  boxplot(x,y,z)
dev.off()

png(file="g403.png", width=600, height=600)
  plot(density(x))
  points(density(y), type="l", col="red")
  points(density(z), type="l", col="blue")
dev.off()

png(file="g404.png", width=600, height=600)
  op <- par( mfrow = c(3,1) )
  hist(x, xlim=c(0,5), breaks=20)
  hist(y, xlim=c(0,5), breaks=20)
  hist(z, xlim=c(0,5), breaks=20)
  par(op)
dev.off()

png(file="g405.png", width=600, height=600)
  x <- sqrt(x)
  y <- sqrt(x)
  z <- sqrt(z)
  boxplot(x,y,z)
dev.off()

png(file="g406.png", width=600, height=600)
  plot(density(x))
  points(density(y), type="l", col="red")
  points(density(z), type="l", col="blue")
dev.off()

png(file="g407.png", width=600, height=600)
  op <- par( mfrow = c(3,1) )
  hist(x, xlim=c(0,5), breaks=20)
  hist(y, xlim=c(0,5), breaks=20)
  hist(z, xlim=c(0,5), breaks=20)
  par(op)
dev.off()

png(file="g408.png", width=600, height=600)
  # Choix de la moyenne
  m <- runif(1, min=-1, max=1)
  # Les n individus
  n <- 5
  v <- rnorm(n, mean=m)
  # Calcul de la densit�
  N <- 1000
  l <- seq(-2,2, length=N)
  y <- vector()
  for (i in l) {
    y <- append(y, prod(dnorm(v,mean=i)))
  }
  plot(y~l, type='l')
  # Moyenne r�elle
  points(m, prod(dnorm(v,mean=m)), lwd=3)
  # Moyenne empirique
  points(mean(v), prod(dnorm(v,mean=mean(v))), col='red', lwd=3)
dev.off()

png(file="g409.png", width=600, height=600)
  f <- function (x, p, m1, s1, m2, s2) {
    p*dnorm(x,mean=m1,sd=s1) + (1-p)*dnorm(x,mean=m2,sd=s2)
  }
  data(faithful)
  fn <- function(arg) {
    prod(f(faithful$eruptions, arg[1], arg[2], arg[3], arg[4], arg[5]))
  }
  start <- c(.5, 
             min(faithful$eruptions), var(faithful$eruptions),
             max(faithful$eruptions), var(faithful$eruptions),
            )
  p <- optim(start, function(a){-fn(a)/fn(start)}, control=list(trace=1))$par
  hist(faithful$eruptions, breaks=20, probability=T, col='light blue')
  lines(density(faithful$eruptions,bw=.15), col='blue', lwd=3)
  curve(f(x, p[1], p[2], p[3], p[4], p[5]), add=T, col='red', lwd=3)
  #curve(dnorm(x, mean=p[2], sd=p[3]), add=T, col='red', lwd=3, lty=2)
  #curve(dnorm(x, mean=p[4], sd=p[5]), add=T, col='red', lwd=3, lty=2)
  legend(par('usr')[2], par('usr')[4], xjust=1,
         c('sample density', 'theoretical density'),
         lwd=3, lty=1,
         col=c('blue', 'red'))
dev.off()

png(file="g410.png", width=600, height=600)
  op <- par(mfrow=c(2,2))
  curve(dnorm(x-5)+dnorm(x+5), xlim=c(-10,10))
  curve(dnorm(x-5)+.4*dnorm(x+5), xlim=c(-10,10))
  curve(dnorm(5*(x-5)) + .5*dnorm(x+5), xlim=c(-10,10))
  par(op)
dev.off()

png(file="g411.png", width=600, height=600)
  get.sample <- function (n=10, p=1/100) {
    ifelse( runif(n)>p, runif(n), 2 )
  }
  N <- 1000
  d <- rep(NA,N) 
  for (i in 1:N) {
    d[i] <- max(get.sample())
  }
  hist(d, probability=T, ylim=c(0, max(density(d)$y)), col='light blue')
  lines(density(d), type='l', col='red', lwd=3)
dev.off()

png(file="g412.png", width=600, height=600)
  get.sample <- function (n=100, p=1/100) {
    ifelse( runif(n)>p, runif(n), 2 )
  }
  N <- 1000
  d <- rep(NA,N) 
  for (i in 1:N) {
    d[i] <- max(get.sample())
  }
  #hist(d, breaks=seq(0,3,by=.02),
  #     probability=T, ylim=c(0, max(density(d)$y)), col='light blue')
  #lines(density(d), type='l', col='red', lwd=3)
  plot(density(d), type='l', col='red', lwd=3)
dev.off()

png(file="g413.png", width=600, height=600)
  get.sample <- function (n=100, p=1/100) {
    ifelse( runif(n)>p, runif(n), 2+2*runif(n) )
  }
  N <- 1000
  d <- rep(NA,N) 
  for (i in 1:N) {
    d[i] <- max(get.sample())
  }
  #hist(d, breaks=seq(0,4,by=.05),
  #     probability=T, ylim=c(0, max(density(d)$y)), col='light blue')
  #lines(density(d), type='l', col='red', lwd=3)
  plot(density(d), type='l', col='red', lwd=3)
dev.off()

png(file="g414.png", width=600, height=600)
  colorie <- function (x, y1, y2, N=1000, ...) {
    for (t in (0:N)/N) {
      lines(x, t*y1+(1-t)*y2, ...)
    }
  }
  # Non, il y a d�j� une fonction qui fait �a...
  colorie <- function (x, y1, y2, ...) {
    polygon( c(x, x[length(x):1]), c(y1, y2[length(y2):1]), ... )
  }
  x <- seq(-6,6, length=100)
  y <- dnorm(x)
  plot(y~x, type='l')
  i = x<qnorm(.025)
  colorie(x[i],y[i],rep(0,sum(i)) ,col='red')
  i = x>qnorm(.975)
  colorie(x[i],y[i],rep(0,sum(i)) ,col='red')
  lines(y~x)
  title(main="Risque d'erreur de type I")
dev.off()

png(file="g415.png", width=600, height=600)
  x <- seq(-6,6, length=1000)
  y <- dnorm(x)
  plot(y~x, type='l')
  y2 <- dnorm(x-.5)
  lines(y2~x)
  i <- x>qnorm(.025) & x<qnorm(.975)
  colorie(x[i],y2[i],rep(0,sum(i)), col='red')
  segments( qnorm(.025),0,qnorm(.025),dnorm(qnorm(.025)), col='red' )
  segments( qnorm(.975),0,qnorm(.975),dnorm(qnorm(.975)), col='red' )
  lines(y~x)
  lines(y2~x)
  title(main="Risque d'erreur de type II �lev�")
dev.off()

png(file="g416.png", width=600, height=600)
  x <- seq(-6,6, length=1000)
  y <- dnorm(x)
  plot(y~x, type='l')
  y2 <- dnorm(x-3.5)
  lines(y2~x)
  i <- x>qnorm(.025) & x<qnorm(.975)
  colorie(x[i],y2[i],rep(0,sum(i)), col='red')
  segments( qnorm(.025),0,qnorm(.025),dnorm(qnorm(.025)), col='red' )
  segments( qnorm(.975),0,qnorm(.975),dnorm(qnorm(.975)), col='red' )
  lines(y~x)
  lines(y2~x)
  title(main="Risque d'erreur de type II plus faible")
dev.off()

png(file="g417.png", width=600, height=600)
  delta <- seq(-1.5, 1.5, length=500)
  p <- NULL
  for (d in delta) {
    p <- append(p, 
                power.t.test(delta=abs(d), sd=1, sig.level=0.05, n=20,
                             type='one.sample')$power)
  }
  plot(1-p~delta, type='l',
       xlab='diff�rence entre les moyennes', ylab="probabilit� d'une erreur de type II",
       main="Variation des risques d'erreurs de type II dans un test T de Student")
  abline(h=0,lty=3)
  abline(h=0.05,lty=3)
  abline(v=0,lty=3)
dev.off()

png(file="g418.png", width=600, height=600)
  delta <- seq(0, 1.5, length=100)
  p <- NULL
  for (d in delta) {
    p <- append(p, 
                power.t.test(delta=d, sd=1, sig.level=0.05, n=20,
                             type='one.sample')$power)
  }
  plot(p~delta, type='l',
       ylab='power', main='Power of a one-sample t-test')
dev.off()

png(file="g419.png", width=600, height=600)
  N <- seq(10,200, by=5)
  delta <- NULL
  for (n in N) {
    delta <- append(delta, 
                    power.t.test(n=n, sd=1, sig.level=.05, 
                                 power=.80, type='one.sample')$delta
                   )
  }
  plot(delta~N, type='l', xlab='sample size')
  delta <- NULL
  for (n in N) {
    delta <- append(delta, 
                    power.t.test(n=n, sd=1, sig.level=.01, 
                                 power=.80, type='one.sample')$delta
                   )
  }
  lines(delta~N, col='red')
  delta <- NULL
  for (n in N) {
    delta <- append(delta, 
                    power.t.test(n=n, sd=1, sig.level=.001, 
                                 power=.80, type='one.sample')$delta
                   )
  }
  lines(delta~N, col='blue')
  legend(par('usr')[2], par('usr')[4], xjust=1,
         c('significance level=.05', 'significance level=.01', 'significance level=.001'),
         col=c(par('fg'), 'red', 'blue'),
         lwd=1, lty=1)
  title(main='Sample size and difference detected for tests of pover 0.80')
dev.off()

png(file="g420.png", width=600, height=600)
  p <- c()
  for (i in 1:1000) {
    x <- rnorm(200)
    p <- append(p, t.test(x)$p.value)
  }
  hist(p, col='light blue')
dev.off()

png(file="g421.png", width=600, height=600)
  p <- sort(p)
  p[950]
  p[50]
  x <- 1:1000
  plot(p ~ x, main="p-valeur d'un test T de Student quand H0 est vraie")
dev.off()

png(file="g422.png", width=600, height=600)
  # Taille de chaque �chantillon
  n <- 10
  # Nombre de simulations � effectuer pour avoir une bonne
  # approximation de la probabilit�
  m <- 1000
  # Nombre de points pour tracer la courbe
  k <- 50
  # Valeur maximale de la moyenne
  M <- 2
  r <- vector()
  for (j in M*(0:k)/k) {
    res <- 0
    for (i in 1:m) {
      x <- rnorm(10, mean=j)
      if( t.test(x)$p.value > .05 ){
        res <- res + 1
      }
    }
    r <- append(r, res/m)
  }
  rr <- M*(0:k)/k
  plot(r~rr, type="l",
       xlab='diff�rence entre les moyennes',
       ylab="probabilit� d'une erreur de type II")

  # Comparaison avec la courbe obtenue par power.t.test
  x <- seq(0,2,length=200)
  y <- NULL
  for (m in x) {
    y <- append(y, 1-power.t.test(delta=m, sd=1, n=10, sig.level=.05, 
                                  type='one.sample')$power)
  }
  lines(x,y,col='red')

  # Courbe th�orique 
  # (c'est un test de Z, ce n'est pas trop diff�rent...)
  r2 <- function (p,q,conf,x) {
    p(q(1-conf/2)-x) - p(q(conf/2)-x)
  }
  f <- function(x) {
    p <- function (t) { pnorm(t, sd=1/sqrt(10)) }
    q <- function (t) { qnorm(t, sd=1/sqrt(10)) }
    r2(p,q,.05,x)
  }
  curve( f(x) , add=T, col="blue" )

  # Courbe th�orique (pour un test T)
  f <- function(x) {
    p <- function (t) { pt(sqrt(10)*t, 10) } # Est-ce correct ?
    q <- function (t) { qt(t, 10)/sqrt(10) }
    r2(p,q,.05,x)
  }
  curve( f(x) , add=T, col="green" )

  legend(par('usr')[2], par('usr')[4], xjust=1,
         c('simulation', 'power.t.test', 'valeur exacte pour un test de Z',
           'valeur exacte'),
         col=c(par('fg'),'red','blue','green'),
         lwd=1,lty=1)
  title(main="Risque d'erreur de type II dans un test T de Student, en fonction de la diff�rence des moyennes")
dev.off()

png(file="g423.png", width=600, height=600)
  N <- 10000
  x <- 100*(1:N)/N
  plot( x~I(x/100), type='n', ylab="pourcentages cumul�s", xlab="p-value" )
  do.it <- function (m, col) {
    p <- c()
    for (i in 1:N) {
      x <- m+rnorm(200)
      p <- append(p, t.test(x)$p.value)
    }
    p <- sort(p)
    x <- 100*(1:N)/N
    lines(x ~ p, type='l', col=col)
  }
  do.it(0,   par('fg'))
  do.it(.05, 'red')
  do.it(.1,  'green')
  do.it(.15, 'blue')
  do.it(.2,  'orange')
  abline(v=.05)
  title(main='r�partition des p-valeurs')
  legend(par('usr')[2],par('usr')[3],xjust=1,yjust=1,
         c('m=0', 'm=0.05', 'm=.01', 'm=.015', 'm=.02'),
         col=c(par('fg'), 'red', 'green', 'blue', 'orange'),
         lty=1,lwd=1)
dev.off()

png(file="g424.png", width=600, height=200)
  x <- 1:10
  y <- c(7:20, 200)
  boxplot(x,y, horizontal=T)
dev.off()

png(file="g425.png", width=600, height=200)
  boxplot(x,y, log="x", horizontal=T)
dev.off()

png(file="g426.png", width=600, height=600)
  curve(dnorm(x), from=-5, to=5, add=F, col="orange", lwd=3, lty=2)  
  curve(dt(x,100), from=-5, to=5, add=T, col=par('fg'))  
  curve(dt(x,5),  from=-5, to=5, add=T, col="red")  
  curve(dt(x,2),  from=-5, to=5, add=T, col="green")  
  curve(dt(x,1),  from=-5, to=5, add=T, col="blue")  
  legend(par('usr')[2], par('usr')[4], xjust=1,
         c('loi normale', 'df=100', 'df=5', 'df=2', 'df=1'),
         col=c('orange', par('fg'), 'red', 'green', 'blue'),
         lwd=c(3,1,1,1,1),
         lty=c(2,1,1,1,1))
  title(main="Densit� de la loi T de Student")
dev.off()

png(file="g427.png", width=600, height=600)
  N <- 50
  n <- 5
  v <- matrix(c(0,0),nrow=2)
  for (i in 1:N) {
    x <- rnorm(n)
    v <- cbind(v, t.test(x)$conf.int)
  }
  v <- v[,2:(N+1)]
  plot(apply(v,2,mean), ylim=c(min(v),max(v)),
       ylab='Intervalle de confiance', xlab='')
  abline(0,0)
  c <- apply(v,2,min)>0 | apply(v,2,max)<0
  segments(1:N,v[1,],1:N,v[2,], col=c(par('fg'),'red')[c+1], lwd=3)
  title(main="la moyenne r�elle est parfois en dehors de l'intervalle de confiance")
dev.off()

png(file="g428.png", width=600, height=600)
  N <- 1000
  n <- 10
  delta <- .8
  v <- vector()
  w <- vector()
  for (i in 1:N) {
    x <- delta+runif(n, min=-1, max=1)
    v <- append(v, t.test(x)$p.value)
    w <- append(w, wilcox.test(x)$p.value)
  }
  plot(sort(v), type='l', lwd=3, lty=2, ylab="p-valeur")
  lines(sort(w), col='red')
  legend(par('usr')[1], par('usr')[4], xjust=0,
         c('test de Student', 'test de Wilcoxon'),
         lwd=c(2,1),
         lty=c(2,1),
         col=c(par("fg"), 'red'))
dev.off()

png(file="g429.png", width=600, height=600)
  N <- 1000
  n <- 100
  delta <- .1
  v <- vector()
  w <- vector()
  for (i in 1:N) {
    x <- delta+runif(n, min=-1, max=1)
    v <- append(v, t.test(x)$p.value)
    w <- append(w, wilcox.test(x)$p.value)
  }
  plot(sort(v), type='l', lwd=3, lty=2)
  lines(sort(w), col='red')
  legend(par('usr')[1], par('usr')[4], xjust=0,
         c('test de Student', 'test de Wilcoxon'),
         lwd=c(2,1),
         lty=c(2,1),
         col=c(par("fg"), 'red'))
dev.off()

png(file="g430.png", width=600, height=600)
  N <- 1000
  n <- 100
  delta <- .8
  v <- vector()
  w <- vector()
  for (i in 1:N) {
    x <- delta+runif(n, min=-1, max=1)
    v <- append(v, t.test(x)$p.value)
    w <- append(w, wilcox.test(x)$p.value)
  }
  plot(sort(v), type='l', lwd=3, lty=2)
  lines(sort(w), col='red')
  legend(par('usr')[1], par('usr')[4], xjust=0,
         c('test de Student', 'test de Wilcoxon'),
         lwd=c(2,1),
         lty=c(2,1),
         col=c(par("fg"), 'red'))
dev.off()

png(file="g431.png", width=600, height=600)
  N <- 1000
  n <- 10
  delta <- 1
  v <- vector()
  w <- vector()
  for (i in 1:N) {
    x <- delta+rcauchy(n)
    v <- append(v, t.test(x)$p.value)
    w <- append(w, wilcox.test(x)$p.value)
  }
  plot(sort(v), type='l', lwd=3, lty=2)
  lines(sort(w), col='red')
dev.off()

png(file="g432.png", width=600, height=600)
  N <- 1000
  n <- 100
  delta <- 1
  v <- vector()
  w <- vector()
  for (i in 1:N) {
    x <- delta+rcauchy(n)
    v <- append(v, t.test(x)$p.value)
    w <- append(w, wilcox.test(x)$p.value)
  }
  plot(sort(v), type='l', lwd=3, lty=2)
  lines(sort(w), col='red')
dev.off()

png(file="g433.png", width=600, height=600)
  N <- 1000
  n <- 10
  v <- 100
  a <- NULL
  b <- NULL
  for (i in 1:N) {
    x <- rnorm(n)
    y <- rnorm(n, 0, v)
    a <- append(a, t.test(x,y)$p.value)
    b <- append(b, t.test(x/var(x), y/var(y))$p.value)
  }
  plot(sort(a), type='l', col="green")
  points(sort(b), type="l", col="red")
  abline(0,1/N)
dev.off()

png(file="g434.png", width=600, height=600)
  N <- 1000
  n <- 10
  v <- 100
  a <- NULL
  b <- NULL
  c <- NULL
  d <- NULL
  for (i in 1:N) {
    x <- rnorm(n)
    y <- rnorm(n, 100, v)
    a <- append(a, t.test(x,y)$p.value)
    b <- append(b, t.test(x/var(x), y/var(y))$p.value)
    c <- append(c, t.test(x, y/10000)$p.value)
    d <- append(d, wilcox.test(x, y)$p.value)
  }
  plot(sort(a), type='l', col="green")
  points(sort(b), type="l", col="red")
  points(sort(c), type="l", col="blue")
  points(sort(d), type="l", col="orange")
  abline(0,1/N)
  legend(par('usr')[1], par('usr')[4], 
         c('Test de Student', 'Test de Student renormalis�',
           'Test de Student renormalis� avec les variances exp�rimentales',
           'Test U de Wilcoxon (non param�trique)'),
         col=c('green', 'blue', 'red', 'orange'),
         lwd=1,lty=1)
  title(main='Test de Student sur des �chantillons non �quivariants')
dev.off()

png(file="g435.png", width=600, height=300)
  data(sleep)
  boxplot(extra ~ group, data=sleep,
          horizontal=T,
          xlab='extra', ylab='group')
dev.off()

png(file="g436.png", width=600, height=600)
  curve(dchisq(x,2),  from=0, to=5, add=F, col="red",
        ylab="dchisq(x,i)") 
  n <- 10
  col <- rainbow(n)
  for (i in 1:n) { 
    curve(dchisq(x,i),  from=0, to=5, add=T, col=col[i])
  }
  legend(par('usr')[2], par('usr')[4], xjust=1,
          paste('df =',1:n),
         lwd=1,
         lty=1,
         col=col)
  title(main="Densit� de la loi du Chi^2")
dev.off()

png(file="g437.png", width=600, height=600)
  chisq.var.test <- function (x, var=1, conf.level=.95,
                              alternative='two.sided') {
    result <- list()
    alpha <- 1-conf.level
    n <- length(x)
    v <- var(x)
    result$var <- v
    result$sd <- sd(x)
    chi2 <- (n-1)*v/var
    result$chi2 <- chi2
    p <- pchisq(chi2,n-1)
    if( alternative == 'less' ) {
      stop("Not implemented yet")
    } else if (alternative == 'greater') {
      stop("Not implemented yet")
    } else if (alternative == 'two.sided') {
      if(p>.5) 
        p <- 1-p
      p <- 2*p
      result$p.value <- p
      result$conf.int.var <- c(
        (n-1)*v / qchisq(alpha/2, df=n-1, lower.tail=F),
        (n-1)*v / qchisq(alpha/2, df=n-1, lower.tail=T),
      )
    }
    result$conf.int.sd <- sqrt( result$conf.int.var )
    result
  }
  x <- rnorm(100)
  chisq.var.test(x)

  # On peut v�rifier que les r�sultats sont corrects en regardant si
  # la distribution des p-valeurs est bien uniforme dans [0,1].
  v <- NULL
  for (i in 1:1000) { 
    v <- append(v, chisq.var.test(rnorm(100))$p.value) 
  } 
  plot(sort(v))
dev.off()

png(file="g438.png", width=600, height=600)
  p1 <- NULL
  p2 <- NULL
  for (i in 1:100) {
    x <- rnorm(10)
    p1 <- append(p1, chisq.var.test(x)$p.value)
    p2 <- append(p2, var.test(x, rnorm(10000))$p.value)
  }
  plot( p1 ~ p2 )
  abline(0,1,col='red')
dev.off()

png(file="g439.png", width=600, height=600)
  p <- .3
  col.values <- c(par('fg'),'red', 'blue', 'green', 'orange')
  n.values <- c(5,10,20,50,100)
  plot(0, type='n', xlim=c(0,1), ylim=c(0,1), xlab='exact', ylab='approximate')
  for (i in 1:length(n.values)) {
    n <- n.values[i]
    x <- NULL
    y <- NULL
    for (a in 0:n) {
      x <- append(x, binom.test(a,n,p)$p.value)
      y <- append(y, prop.test(a,n,p)$p.value)
    }
    o <- order(x)
    lines(x[o],y[o], col=col.values[i])
  }
  legend(par('usr')[1],par('usr')[4],
         as.character(n.values),
         col=col.values,
         lwd=1,lty=1)
  title(main="Comparaison du test bin�mial et de son approximation")
dev.off()

png(file="g440.png", width=600, height=600)
  p <- .3
  n <- 5
  N <- 1000
  e <- rbinom(N, n, p)
  x <- y <- NULL
  for (a in e) {
    x <- append(x, binom.test(a,n,p)$p.value)
    y <- append(y, prop.test(a,n,p)$p.value)
  }
  x <- sort(x)
  y <- sort(y)
  plot(x, type='l', lwd=3, ylab='p-valeur')
  lines(y, col='red')
  legend(par('usr')[2], par('usr')[3], xjust=1, yjust=0,
         c('exact', 'approch�'),
         lwd=c(3,1),
         lty=1,
         col=c(par("fg"),'red'))
  title(main="Test binomial (H0 vraie)")
dev.off()

png(file="g441.png", width=600, height=600)
  p1 <- .3
  p2 <- .5
  n <- 5
  N <- 1000
  e <- rbinom(N, n, p1)
  x <- y <- NULL
  for (a in e) {
    x <- append(x, binom.test(a,n,p2)$p.value)
    y <- append(y, prop.test(a,n,p2)$p.value)
  }
  x <- sort(x)
  y <- sort(y)
  plot(x, type='l', lwd=3, ylab='p-valeur')
  lines(y, col='red')
  legend(par('usr')[2], par('usr')[3], xjust=1, yjust=0,
         c('exact', 'approch�'),
         lwd=c(3,1),
         lty=1,
         col=c(par("fg"),'red'))
  title(main="Test binomial (H0 fausse)")
dev.off()

png(file="g442.png", width=600, height=600)
  p <- .3
  col.values <- c(par('fg'),'red', 'blue', 'green', 'orange')
  n.values <- c(5,10,20,50,100)
  plot(0, type='n', xlim=c(0,1), ylim=c(0,1), xlab='exact', ylab='approximate')
  for (i in 1:length(n.values)) {
    n <- n.values[i]
    x <- NULL
    y <- NULL
    z <- NULL
    for (a in 0:n) {
      x <- append(x, binom.test(a,n,p)$p.value)
      y <- append(y, chisq.test(c(a,n-a),p=c(p,1-p))$p.value)
      z <- append(z, prop.test(a,n,p)$p.value)
    }
    o <- order(x)
    lines(x[o],y[o], col=col.values[i])
    lines(x[o],z[o], col=col.values[i], lty=3)
  }
  legend(par('usr')[1],par('usr')[4],
         as.character(c(n.values, "prop.test", "chisq.test")),
         col=c(col.values, par('fg'), par('fg')),
         lwd=1,
         lty=c(rep(1,length(n.values)), 1,3) 
        )
  title(main="Comparaison du test bin�mial et de ses approximations")
dev.off()

png(file="g443.png", width=600, height=600)
  multinom.test <- function (x, p, N=1000) {
    n <- sum(x)
    m <- length(x)
    chi2 <- sum( (x-n*p)^2/(n*p) )
    v <- NULL
    for (i in 1:N) {
      x <- table(factor(sample(1:m, n, replace=T, prob=p), levels=1:m))
      v <- append(v, sum( (x-n*p)^2/(n*p) ))
    }
    sum(v>=chi2)/N
  }
  multinom.test( c(25,40,25,25), p=c(.25,.25,.25,.25) ) # 0.13
  chisq.test(    c(25,40,25,25), p=c(.25,.25,.25,.25) )   # 0.12

  N <- 100
  m <- 4
  n <- 10
  p <- c(.25,.25,.1,.4)
  x <- NULL
  y <- NULL
  for (i in 1:N) {
    a <- table( factor(sample(1:m, n, replace=T, prob=p), levels=1:m) )
    x <- append(x, multinom.test(a,p))
    y <- append(y, chisq.test(a,p=p)$p.value)
  }
  plot(y~x)
  abline(0,1,col='red')
  title("Comparaison d'un test multinomial de Monte-Carlo et du test du Chi^2")
dev.off()

png(file="g444.png", width=600, height=600)
  # On tire 10 individus au hasard, dans une population r�partie
  # en 4 classes. On r�p�te l'exp�rience 100 fois.
  N <- 1000
  m <- 4
  n <- 10
  p <- c(.24,.26,.1,.4)
  p.valeur.chi2 <- rep(NA,N)
  for (i in 1:N) {
    echantillon <- table(factor(sample(1:m, replace=T, prob=p), levels=1:m))
    p.valeur.chi2[i] <- chisq.test(echantillon,p=p)$p.value
  }
  plot( sort(p.valeur.chi2), type='l', lwd=3 )
  abline(0, 1/N, lty=3, col='red', lwd=3)
  title(main="R�partition des p-valeurs lors d'un test du Chi2")
dev.off()

png(file="g445.png", width=600, height=600)
  foo <- function (N) {
    population1 <- c(rep('A',10), rep('B',20), rep('A',60), rep('B',10))
    population1 <- factor(population1, levels=c('A','B'))
    population2 <- c(rep('C',10), rep('C',20), rep('D',60), rep('D',10))
    population2 <- factor(population2, levels=c('C','D'))
    o <- sample(1:100, N, replace=T)
    table( population2[o], population1[o] )
  }
  a <- foo(1000)
  op <- par(mfcol=c(1,2))
  plot( a, shade=T )
  plot( t(a), shade=T )
  par(op)
dev.off()

png(file="g446.png", width=600, height=600)
  n1 <- 10
  n2 <- 100
  N <- 1000
  x1 <- rep(NA,N)
  x2 <- rep(NA,N)
  for (i in 1:N) {
    x1[i] <- fisher.test(foo(n1))$p.value
    x2[i] <- fisher.test(foo(n2))$p.value
  }
  plot( sort(x1), type='l', lwd=3, ylab='p-valeur')
  lines( sort(x2), col='blue', lwd=3 )
  abline(0,1/N,col='red',lwd=3,lty=3)
  abline(h=c(0,.05),lty=3)
  abline(v=c(0,N*.05),lty=3)
  title(main="p-valeurs d'un test de Fisher, H0 faux")
  legend(par('usr')[1],par('usr')[4],
         c("n=10", "n=100"),
         col=c(par('fg'), 'blue'),
         lwd=3,
         lty=1)
dev.off()

png(file="g447.png", width=600, height=600)
  foo <- function (N) {
    population1 <- c(rep('A',2), rep('B',8), rep('A',18), rep('B',72))
    population1 <- factor(population1, levels=c('A','B'))
    population2 <- c(rep('C',2), rep('C',8), rep('D',18), rep('D',72))
    population2 <- factor(population2, levels=c('C','D'))
    o <- sample(1:100, N, replace=T)
    table( population2[o], population1[o] )
  }
  n1 <- 10
  n2 <- 100
  N <- 1000
  x1 <- rep(NA,N)
  x2 <- rep(NA,N)
  for (i in 1:N) {
    x1[i] <- fisher.test(foo(n1))$p.value
    x2[i] <- fisher.test(foo(n2))$p.value
  }
  plot( sort(x1), type='l', lwd=3, ylab='p-valeur', ylim=c(0,1))
  lines( sort(x2), col='blue', lwd=3 )
  abline(0,1/N,col='red',lwd=3,lty=3)
  abline(h=c(0,.05),lty=3)
  abline(v=c(0,N*.05),lty=3)
  title(main="p-valeurs d'un test de Fisher, H0 vrai")
  legend(par('usr')[2], .2, xjust=1, yjust=0,
         c("n=10", "n=100"),
         col=c(par('fg'), 'blue'),
         lwd=3,
         lty=1)
dev.off()

png(file="g448.png", width=600, height=600)
  sign.test <- function (x, mu=0) {
    n <- length(x)
    y <- sum(x<mu) # should warn about ties!
    p.value <- min(c( pbinom(y,n,.5), pbinom(y,n,.5,lower.tail=F) ))*2
    p.value
  }
  N <- 500
  n <- 200
  res <- rep(NA,N)
  for (i in 1:N) {
    res[i] <- sign.test(rlnorm(n),mu=1)
  }
  plot(sort(res))
  abline(0,1/N,lty=2)
dev.off()

png(file="g449.png", width=600, height=600)
  N <- 500
  n <- 10
  res <- rep(NA,N)
  for (i in 1:N) {
    res[i] <- sign.test(rlnorm(n),mu=2)
  }
  plot(sort(res), ylim=c(0,1))
  abline(0,1/N,lty=2)
dev.off()

png(file="g450.png", width=600, height=600)
  op <- par(mfrow=c(2,2))
  for (n in c(10,1e2,1e3,1e4)) {
    x <- runif(n)
    y <- 1 - x + .2*rnorm(n)
    plot(y~x, main=paste("sample with", n, "observations"))
  }
  par(op)
dev.off()

png(file="g451.png", width=600, height=600)
  my.lss <- function (x, y, ...) {
    n <- length(x)
    sx <- sum(x)
    sy <- sum(y)
    sxx <- sum(x*x)
    sxy <- sum(x*y)
    d <- n*sxx-sx*sx
    a <- (sxx*sy - sx*sxy)/d
    b <- (-sx*sy + n*sxy)/d
    plot(x,y, ...)
    abline(a, b, col='red', ...)
    c(a,b)
  }

  n <- 10
  x <- runif(n)
  y <- 1 - 2*x + .3*rnorm(n)
  my.lss(x,y)
dev.off()

png(file="g452.png", width=600, height=600)
  n <- 10
  x <- runif(n)
  y <- 1 - x + .2*rnorm(n)
  res <- lm( y ~ x )
  plot(y~x, pch=16)
  abline(res, col='red')
dev.off()

png(file="g453.png", width=600, height=600)
  data(anscombe)
  ff <- y ~ x
  op <- par(mfrow=c(2,2), mar=.1+c(4,4,1,1), oma= c(0,0,2,0))
  for(i in 1:4) {
    ff[2:3] <- lapply(paste(c("y","x"), i, sep=""), as.name)
    ## or   ff[[2]] <- as.name(paste("y", i, sep=""))
    ##      ff[[3]] <- as.name(paste("x", i, sep=""))
    assign(paste("lm.",i,sep=""), lmi <- lm(ff, data= anscombe))
    #print(anova(lmi))
  }
  for(i in 1:4) {
    ff[2:3] <- lapply(paste(c("y","x"), i, sep=""), as.name)
    plot(ff, data =anscombe, col="red", pch=21, bg = "orange", cex = 1.2,
         xlim=c(3,19), ylim=c(3,13))
    abline(get(paste("lm.",i,sep="")), col="blue")
  }
  mtext("Anscombe's 4 Regression data sets", outer = TRUE, cex=1.5)
  par(op)
dev.off()

png(file="g454.png", width=600, height=600)
  do.it <- function (x, y) {
    plot(x,y, main=paste("cor =", round(cor(x,y), digits=2)))
    abline(lm(y~x), col='red', lwd=3)
  }

  n <- 100
  x <- runif(n)
  x <- x[order(x)]
  y <- x
  do.it(x,y)
  abline(0,1,lty=2)
dev.off()

png(file="g455.png", width=600, height=600)
  y <- rnorm(n,x,.1)
  do.it(x,y)
  abline(0,1,lty=2)
dev.off()

png(file="g456.png", width=600, height=600)
  y <- rnorm(n,x,1)
  do.it(x,y)
  abline(0,1,lty=2)
dev.off()

png(file="g457.png", width=600, height=600)
  y <- runif(n)
  do.it(x,y)
dev.off()

png(file="g458.png", width=600, height=600)
  x <- runif(n,-1,1)
  y <- x*x
  do.it(x,y)
dev.off()

png(file="g459.png", width=600, height=600)
  y <- rnorm(n, x*x, .1)
  do.it(x,y)
  x <- sort(x)
  lines(x,x*x,lty=2)
dev.off()

png(file="g460.png", width=600, height=600)
  y <- rnorm(n, x*x, 1)
  do.it(x,y)
  x <- sort(x)
  lines(x,x*x,lty=2)
dev.off()

png(file="g461.png", width=600, height=600)
  x <- runif(n)
  y <- rnorm(n,-x,1)
  do.it(x,y)
  abline(0,-1,lty=2)
dev.off()

png(file="g462.png", width=600, height=600)
  y <- rnorm(n,-x,.1)
  do.it(x,y)
  abline(0,-1,lty=2)
dev.off()

png(file="g463.png", width=600, height=600)
  y <- -x
  do.it(x,y)
  abline(0,-1,lty=2)
dev.off()

png(file="g464.png", width=600, height=600)
  data(cars)
  x <- cars$speed
  y <- cars$dist
  plot(y~x)
  o <- order(x)
  n <- length(x)
  m <- floor(n/2)
  p1 <- c( median(x[o[1:m]]), median(y[o[1:m]]) )
  m <- ceiling(n/2)
  p2 <- c( median(x[o[m:n]]), median(y[o[m:n]]) )
  p <- rbind(p1,p2)
  points(p, pch='+', lwd=3, cex=5, col='red' )
  lines(p, col='red', lwd=3)
  title(main="Droite de Brown-Mood")
dev.off()

png(file="g465.png", width=600, height=600)
  three.group.resistant.line <- function (y, x) { 
    o <- order(x)
    n <- length(x)
    o1 <- o[1:floor(n/3)]
    o2 <- o[ceiling(n/3):floor(2*n/3)]
    o3 <- o[ceiling(2*n/3):n]
    p1 <- c( median(x[o1]), median(y[o1]) )
    p2 <- c( median(x[o2]), median(y[o2]) )
    p3 <- c( median(x[o3]), median(y[o3]) )
    p <- rbind(p1,p2,p3)
    g <- apply(p,2,mean)
    plot(y~x)
    points(p, pch='+', lwd=3, cex=3, col='red')
    polygon(p, border='red')
    a <- (p3[2] - p1[2])/(p3[1] - p1[1])
    b <- g[2]-a*g[1]
    abline(b,a,col='red')
  }
  three.group.resistant.line(cars$dist, cars$speed)
dev.off()

png(file="g466.png", width=600, height=600)
  n <- 100
  x <- runif(n,min=0,max=2)
  y <- x*(1-x) + rnorm(n)
  three.group.resistant.line(y,x)
dev.off()

png(file="g467.png", width=600, height=600)
  droite.des.medianes <- function (y,x) {
    n <- length(x)
    b <- matrix(NA, nr=n, nc=n)
    # Exercice : �crire �a sans aucune boucle
    for (i in 1:n) {
      for (j in 1:n) {
        if(i!=j)
          b[i,j] <- ( y[i] - y[j] )/( x[i] - x[j] )
      }
    }
    b <- median(b, na.rm=T)
    a <- median(y-b*x)
    plot(y~x)
    abline(a,b, col='red')
    title(main="La droite des m�dianes")
  }
  droite.des.medianes(cars$dist, cars$speed)
dev.off()

png(file="g468.png", width=600, height=600)
  autre.droite.des.medianes <- function (y,x) {
   n <- length(x)
    b <- matrix(NA, nr=n, nc=n)
    # Exercice : �crire �a sans aucune boucle
    for (i in 1:n) {
      for (j in 1:n) {
        if(i!=j)
          b[i,j] <- ( y[i] - y[j] )/( x[i] - x[j] )
      }
    }
    b <- median( apply(b, 1, median, na.rm=T), na.rm=T ) # Seule chose qui change
    a <- median(y-b*x)
    plot(y~x)
    abline(a,b, col='red')
    title(main="La droite des m�dianes")
  }
  autre.droite.des.medianes(cars$dist, cars$speed)
dev.off()

png(file="g469.png", width=600, height=600)
  data(cars)
  plot(cars)
  abline(lm(cars$dist ~ cars$speed), col='red')
  title(main="R�gression dist ~ speed")
dev.off()

png(file="g470.png", width=600, height=600)
  plot(cars)
  r <- lm(cars$dist ~ cars$speed)
  abline(r, col='red')
  r <- lm(cars$speed ~ cars$dist)
  a <- r$coefficients[1] # Intercept
  b <- r$coefficients[2] # slope
  abline(-a/b , 1/b, col="blue")
  title(main="R�gression dist ~ speed et speed ~ dist")
dev.off()

png(file="g471.png", width=600, height=600)
  plot(cars)
  r <- lm(cars$dist ~ cars$speed)
  abline(r, col='red')
  segments(cars$speed, cars$dist, cars$speed, r$fitted.values,col="red")
  title(main="R�gression dist ~ speed : on mesure les distances verticalement")
dev.off()

png(file="g472.png", width=600, height=600)
  plot(cars)
  r <- lm(cars$speed ~ cars$dist)
  a <- r$coefficients[1] # Intercept
  b <- r$coefficients[2] # slope
  abline(-a/b , 1/b, col="blue")
  segments(cars$speed, cars$dist, r$fitted.values, cars$dist, col="blue")
  title(main="R�gression speed ~ dist : on mesure les distances horizontalement")
dev.off()

png(file="g473.png", width=600, height=600)
  plot(cars)
  r <- lm(cars$dist ~ cars$speed)
  abline(r, col='red')
  r <- lm(cars$speed ~ cars$dist)
  a <- r$coefficients[1] # Intercept
  b <- r$coefficients[2] # slope
  abline(-a/b , 1/b, col="blue")
  r <- princomp(cars)
  b <- r$loadings[2,1] / r$loadings[1,1]
  a <- r$center[2] - b * r$center[1]
  abline(a,b)
  title(main="Comparaison de trois r�gressions")
dev.off()

png(file="g474.png", width=600, height=600)
  x <- rnorm(100)
  y <- x + rnorm(100)
  plot(y~x)
  r <- lm(y~x)
  abline(r, col='red')
  r <- lm(x ~ y)
  a <- r$coefficients[1] # Intercept
  b <- r$coefficients[2] # slope
  abline(-a/b , 1/b, col="blue")
  r <- princomp(cbind(x,y))
  b <- r$loadings[2,1] / r$loadings[1,1]
  a <- r$center[2] - b * r$center[1]
  abline(a,b)
  title(main="Comparaison de trois r�gressions")
dev.off()

png(file="g475.png", width=600, height=600)
  plot(y~x, xlim=c(-4,4), ylim=c(-4,4) )
  abline(a,b)
  # Matrice de changement de base
  u <- r$loadings
  # Projection sur le premier axe
  p <- matrix( c(1,0,0,0), nrow=2 )
  X <- rbind(x,y)
  X <- r$center + solve(u, p %*% u %*% (X - r$center))
  segments( x, y, X[1,], X[2,] )
  title(main="ACP : on mesure les distances perpendiculairement � la droite")
dev.off()

png(file="g476.png", width=600, height=600)
  x <- cars$speed
  y <- cars$dist
  my.lar <- function (y,x) {
    f <- function (arg) {
      a <- arg[1]
      b <- arg[2]
      sum(abs(y-a-b*x)) 
    }
    r <- optim( c(0,0), f )$par
    plot( y~x )
    abline(lm(y~x), col='red', lty=2)
    abline(r[1], r[2])
    legend( par("usr")[1], par("usr")[4], yjust=1,
            c("Moindres carr�s", "Moindres valeurs absolues"),
            lwd=1, lty=c(2,1),
            col=c(par('fg'),'red'))
  }
  my.lar(y,x)
dev.off()

png(file="g477.png", width=600, height=600)
  library(MASS)
  n <- 20
  x <- rnorm(n)
  y <- 1 - 2*x + rnorm(n)
  y[ sample(1:n, floor(n/4)) ] <- 10
  plot(y~x)
  abline(1,-2,lty=3)
  abline(lm(rlm(y~x)), col='red')
  abline(lm(y~x), lty=3, lwd=3)
dev.off()

png(file="g478.png", width=600, height=600)
  n <- 100
  x <- rnorm(n)
  y <- 1 - 2*x + rcauchy(n,1)
  plot(y~x)
  abline(1,-2,lty=3)
  abline(lm(rlm(y~x)), col='red')
  abline(lm(y~x), lty=3, lwd=3)
dev.off()

png(file="g479.png", width=600, height=600)
  #library(lqs)   # merged into MASS
  x <- rnorm(20)
  y <- 1 - x + rnorm(20)
  x <- c(x,10)
  y <- c(y,1)
  plot(y~x)
  abline(1,-1, lty=3)
  abline(lm(y~x))
  abline(rlm(y~x, psi = psi.bisquare, init = "lts"), col='orange',lwd=3)
  abline(rlm(y~x), col='red')
  abline(rlm(y~x, psi = psi.hampel, init = "lts"), col='green')
  abline(rlm(y~x, psi = psi.bisquare), col='blue')
  title(main='R�gression de Huber (rlm)')
dev.off()

png(file="g480.png", width=600, height=600)
  n <- 100
  x <- rnorm(n)
  y <- 1 - 2*x + rnorm(n)
  y[ sample(1:n, floor(n/4)) ] <- 7
  plot(y~x)
  r1 <- lm(y~x)
  r2 <- lqs(y~x, method='lts')
  abline(r1, col='red')
  abline(r2, col='green')
  abline(1,-2,lty=3)
  legend( par("usr")[1], par("usr")[3], yjust=0,
          c("R�gression lin�aire", "R�gression �lagu�e"),
          lty=1, lwd=1,
          col=c("red", "green") )
  title("Moindres carr�s �lagu�s")
dev.off()

png(file="g481.png", width=600, height=600)
  op <- par(mfrow=c(2,2))
  plot(r1)
  par(op)
dev.off()

png(file="g482.png", width=600, height=600)
  # Des donn�es pas trop gentilles...
  n <- 10
  x <- rnorm(n)
  y <- 1 - 2*x + rnorm(n)
  x[1] <- 5
  y[1] <- 0
  my.wls <- function (y,x) {
    # On effectue une premi�re r�gression
    r <- lm(y~x)$residuals
    # On calcule les poids
    w <- compute.weights(r)
    # on fait une nouvelle r�gression
    lm(y~x, weights=w)
  }
  compute.weights <- function (r) {
    # On calcule les poids comme on veut, du moment que la comme des 
    # poids est 1 et que les points de r�sidus �lev�s ont des poids faibles.
    # Ce choix que je fais n'est probablement ni standard ni judicieux
    w <- r*r
    w <- w/mean(w)
    w <- 1/(1+w)
    w <- w/mean(w)
  }
  plot(y~x)
  abline(1,-2, lty=3)
  abline(lm(y~x))
  abline(my.wls(y,x), col='red')
  title(main="R�gression pond�r�e")
dev.off()

png(file="g483.png", width=600, height=600)
  my.irls.plot <- function (y,x, n=10) {
    plot(y~x)
    abline(lm(y~x))
    r <- lm(y~x)$residuals
    for (i in 1:n) {
      w <- compute.weights(r)
      print(w)
      r <- lm(y~x, weights=w)
      abline(r, col=topo.colors(n)[i], lwd=ifelse(i==n,3,1))
      r <- r$residuals
    }
    lm(y~x, weights=w)
  }
  my.irls.plot(y,x)
  abline(1,-2, lty=3)
  abline(my.wls(y,x), col='blue', lty=3, lwd=3)
  title(main="R�gression it�rativement repond�r�e")
dev.off()

png(file="g484.png", width=600, height=600)
  y <- cars$dist
  x <- cars$speed
  o = order(x)
  plot( y~x )
  do.it <- function (model, col) {
    r <- lm( model )
    yp <- predict(r)
    lines( yp[o] ~ x[o], col=col, lwd=3 )
  }
  do.it(y~x, col="red")
  do.it(y~x+I(x^2), col="blue")
  do.it(y~-1+I(x^2), col="green")
  legend(par("usr")[1], par("usr")[4], 
         c("fonction affine", "polyn�me de degr� 2", "mon�me de degr� 2"),
         lwd=3,
         col=c("red", "blue", "green"),
        )
dev.off()

png(file="g485.png", width=600, height=600)
  n <- 5
  p <- matrix( nrow=n, ncol=n+1 )
  for (i in 1:n) {
    p[i,1:(i+1)] <- summary(lm( y ~ poly(x,i) ))$coefficients[,4]
  }
  matplot(p, type='l', lty=1, lwd=3)
  legend( par("usr")[1], par("usr")[4],
          as.character(1:n),
          lwd=3, lty=1, col=1:n
        )
  title(main="Evolution des p-valeurs (famille orthonormale)")
dev.off()

png(file="g486.png", width=600, height=600)
  p <- matrix( nrow=n, ncol=n+1 )
  p[1,1:2] <- summary(lm(y ~ x) )$coefficients[,4]
  p[2,1:3] <- summary(lm(y ~ x+I(x^2)) )$coefficients[,4]
  p[3,1:4] <- summary(lm(y ~ x+I(x^2)+I(x^3)) )$coefficients[,4]
  p[4,1:5] <- summary(lm(y ~ x+I(x^2)+I(x^3)+I(x^4)) )$coefficients[,4]
  p[5,1:6] <- summary(lm(y ~ x+I(x^2)+I(x^3)+I(x^4)+I(x^5)) )$coefficients[,4]
  matplot(p, type='l', lty=1, lwd=3)
  legend( par("usr")[1], par("usr")[4],
          as.character(1:n),
          lwd=3, lty=1, col=1:n
        )
  title(main="Evolution des p-valeurs (famille non orthonormale)")
dev.off()

png(file="g487.png", width=600, height=600)
  # Construction de la matrice
  n <- 5
  m <- matrix( ncol=n+1, nrow=length(x) )
  for (i in 2:(n+1)) {
    m[,i] <- x^(i-1)
  }
  m[,1] <- 1
  # Orthonormalisation (Gram--Schmidt)
  for (i in 1:(n+1)) {
    if(i==1) m[,1] <- m[,1] / sqrt( t(m[,1]) %*% m[,1] )
    else {
      for (j in 1:(i-1)) {
        m[,i] <- m[,i] - (t(m[,i]) %*% m[,j])*m[,j]
      }
      m[,i] <- m[,i] / sqrt( t(m[,i]) %*% m[,i] )
    }
  }
  p <- matrix( nrow=n, ncol=n+1 )
  p[1,1:2] <- summary(lm(y~ -1 +m[,1:2] ))$coefficients[,4]
  p[2,1:3] <- summary(lm(y~ -1 +m[,1:3] ))$coefficients[,4]
  p[3,1:4] <- summary(lm(y~ -1 +m[,1:4] ))$coefficients[,4]
  p[4,1:5] <- summary(lm(y~ -1 +m[,1:5] ))$coefficients[,4]
  p[5,1:6] <- summary(lm(y~ -1 +m[,1:6] ))$coefficients[,4]
  matplot(p, type='l', lty=1, lwd=3)
  legend( par("usr")[1], par("usr")[4],
          as.character(1:n),
          lwd=3, lty=1, col=1:n
        )
  title(main="Idem, orthonormalisation � la main")
dev.off()

png(file="g488.png", width=600, height=600)
  library(ts)
  data(beavers)
  y <- beaver1$temp
  x <- 1:length(y)
  plot(y~x)
  for (i in 1:10) {
    r <- lm( y ~ poly(x,i) )
    lines( predict(r), type="l", col=i )
  }
  summary(r)
dev.off()

png(file="g489.png", width=600, height=600)
  n <- 100
  x <- rnorm(n)
  y <- exp(x)
  plot(y~x)
  title(main="Relation non polyn�miale")
dev.off()

png(file="g490.png", width=600, height=600)
  n <- 100
  x <- rnorm(n)
  y <- exp(x) + .1*rnorm(n)
  plot(y~x)
  title(main="Relation non polyn�miale")
dev.off()

png(file="g491.png", width=600, height=600)
  library(modreg)
  plot(cars$speed, cars$dist)
  lines( smooth.spline(cars$speed, cars$dist), col='red')
  abline(lm(dist~speed,data=cars), col='blue', lty=2)
dev.off()

png(file="g492.png", width=600, height=600)
  plot(quakes$long, quakes$lat)
  lines( smooth.spline(quakes$long, quakes$lat), col='red', lwd=3)
dev.off()

png(file="g493.png", width=600, height=600)
  library(Design)
  # Spline � 4 noeuds
  r3 <- lm( quakes$lat ~ rcs(quakes$long) )
  plot( quakes$lat ~ quakes$long )
  o <- order(quakes$long)
  lines( quakes$long[o], predict(r)[o], col='red', lwd=3 )
  r <- lm( quakes$lat ~ rcs(quakes$long,10) )
  lines( quakes$long[o], predict(r)[o], col='blue', lwd=6, lty=3 )
  title(main="R�gression avec rcs")
  legend( par("usr")[1], par("usr")[3], yjust=0,
          c("4 noeuds", "10 noeuds"),
          lwd=c(3,3), lty=c(1,3), col=c("red", "blue") )
dev.off()

png(file="g494.png", width=600, height=600)
  library(splines)
  data(quakes)
  x <- quakes[,2]
  y <- quakes[,1]
  o <- order(x)
  x <- x[o]
  y <- y[o]
  r1 <- lm( y ~ bs(x,df=10) )
  r2 <- lm( y ~ ns(x,df=6) )
  plot(y~x)
  lines(predict(r1)~x, col='red', lwd=3)
  lines(predict(r2)~x, col='green', lwd=3)
dev.off()

png(file="g495.png", width=600, height=600)
  # Le manuel dit de faire attention aux pr�dictions
  # avec d'autres valeurs de x : je ne vois pas de probl�me.
  plot(y~x)
  xp <- seq(min(x), max(x), length=200)
  lines(predict(r2) ~ x, col='green', lwd=3)
  lines(xp, predict(r2,data.frame(x=xp)), col='blue', lwd=7, lty=3)
dev.off()

png(file="g496.png", width=600, height=600)
  broken.line <- function (x, y) { 
    n <- length(x)
    n2 = floor(n/2)
    o <- order(x)
    m <- mean(c(x[o[n2+0:1]]))
    x1 <- x[o[1:n2]]
    y1 <- y[o[1:n2]]
    n2 <- n2+1
    x2 <- x[o[n2:n]]
    y2 <- y[o[n2:n]]
    r1 <- lm(y1~x1)
    r2 <- lm(y2~x2)
    plot(y~x)
    segments(x[o[1]], r1$coef[1] + x[o[1]]*r1$coef[2],
             m, r1$coef[1] + m *r1$coef[2],
             col='red')
    segments(m, r2$coef[1] + m*r2$coef[2],
             x[o[n]], r2$coef[1] + x[o[n]] *r2$coef[2],
             col='blue')
    abline(v=m, lty=3)
  }
  n <- 10
  x <- runif(n)
  y <- 1-x+.2*rnorm(n)
  broken.line(x,y)
dev.off()

png(file="g497.png", width=600, height=600)
  z <- x*(1-x)
  broken.line(x,z)
dev.off()

png(file="g498.png", width=600, height=600)
  broken.line <- function (x,y) {
    n <- length(x)
    o <- order(x)
    n1 <- floor((n+1)/2)
    n2 <- ceiling((n+1)/2)
    m <- mean(c( x[o[n1]], x[o[n2]] ))
    plot(y~x)
    B1 <- function (xx) {
      x <- xx
      x[xx<m] <- m - x[xx<m]
      x[xx>=m] <- 0
      x
    }
    B2 <- function (xx) {
      x <- xx
      x[xx>m] <- x[x>m] -m
      x[xx<=m] <- 0
      x
    }
    x1 <- B1(x)
    x2 <- B2(x)
    r <- lm(y~x1+x2)
    xx <- seq(x[o[1]],x[o[n]],length=100)
    yy <- predict(r, data.frame(x1=B1(xx), x2=B2(xx)))
    lines( xx, yy, col='red' )
    abline(v=m, lty=3)        
  }
  broken.line(x,y)
dev.off()

png(file="g499.png", width=600, height=600)
  broken.line(x,z)
dev.off()

png(file="g500.png", width=600, height=600)
  plot(y~x)
  lines(lowess(x,y), col="red")
dev.off()

png(file="g501.png", width=600, height=600)
  plot(z~x)
  lines(lowess(x,z), col="red")
dev.off()

png(file="g502.png", width=600, height=600)
  data(quakes)
  plot(lat~long, data=quakes)
  lines(lowess(quakes$long, quakes$lat), col='red', lwd=3)
dev.off()

png(file="g503.png", width=600, height=600)
  n <- 1000
  x <- runif(n, min=-1,max=1)
  y <- (x-1)*x*(x+1) + .5*rnorm(n)
  # Ne pas utiliser ce code sur des donn�es trop grosses
  moyenne.mobile <- function (y,x, r=.1) {
    o <- order(x)
    n <- length(x)
    m <- floor((1-r)*n)
    p <- n-m
    x1 <- vector(mode='numeric',length=m)
    y1 <- vector(mode='numeric',length=m)
    y2 <- vector(mode='numeric',length=m)
    y3 <- vector(mode='numeric',length=m)
    for (i in 1:m) {
      xx <- x[ o[i:(i+p)] ]
      yy <- y[ o[i:(i+p)] ]
      x1[i] <- mean(xx)
      y1[i] <- quantile(yy,.25)
      y2[i] <- quantile(yy,.5)
      y3[i] <- quantile(yy,.75)
    }
    plot(y~x)
    lines(x1,y2,col='red', lwd=3)
    lines(x1,y1,col='blue', lwd=2)
    lines(x1,y3,col='blue', lwd=2)
  }
  moyenne.mobile(y,x)
dev.off()

png(file="g504.png", width=600, height=600)
  library(gregmisc)
  bandplot(x,y)
dev.off()

png(file="g505.png", width=600, height=600)
  library(modreg)
  plot(cars$speed, cars$dist)
  lines(ksmooth(cars$speed, cars$dist, "normal", bandwidth=2), col='red')
  lines(ksmooth(cars$speed, cars$dist, "normal", bandwidth=5), col='green')
  lines(ksmooth(cars$speed, cars$dist, "normal", bandwidth=10), col='blue')
dev.off()

png(file="g506.png", width=600, height=600)
  curve(dnorm(x), xlim=c(-3,3), ylim=c(0,1.1))
  x <- seq(-3,3,length=200)
  D.Epanechikov <- function (t) {
    ifelse(abs(t)<1, 3/4*(1-t^2), 0)
  }
  lines(D.Epanechikov(x) ~ x, col='red')
  D.tricube <- function (t) { # aka "triweight kernel"
    ifelse(abs(t)<1, (1-abs(t)^3)^3, 0)
  }
  lines(D.tricube(x) ~ x, col='blue')
  legend( par("usr")[1], par("usr")[4], yjust=1,
          c("noyau gaussien", "noyau d'Epanechikov", "noyau tricube"),
          lwd=1, lty=1,
          col=c(par('fg'),'red', 'blue'))
  title(main="Diff�rents noyaux")
dev.off()

png(file="g507.png", width=600, height=600)
  # Sur des donn�es r�elles...
  library(KernSmooth)
  data(quakes)
  x <- quakes$long
  y <- quakes$lat
  plot(y~x)
  bw <- dpill(x,y) # .2
  lines( locpoly(x,y,degree=0, bandwidth=bw), col='red' )
  lines( locpoly(x,y,degree=1, bandwidth=bw), col='green' )
  lines( locpoly(x,y,degree=2, bandwidth=bw), col='blue' )
  legend( par("usr")[1], par("usr")[3], yjust=0,
          c("degr� = 0", "degr� = 1", "degr� = 2"),
          lwd=1, lty=1,
          col=c('red', 'green', 'blue'))
  title(main="R�gression polynomiale locale")
dev.off()

png(file="g508.png", width=600, height=600)
  plot(y~x)
  bw <- .5
  lines( locpoly(x,y,degree=0, bandwidth=bw), col='red' )
  lines( locpoly(x,y,degree=1, bandwidth=bw), col='green' )
  lines( locpoly(x,y,degree=2, bandwidth=bw), col='blue' )
  legend( par("usr")[1], par("usr")[3], yjust=0,
          c("degr� = 0", "degr� = 1", "degr� = 2"),
          lwd=1, lty=1,
          col=c('red', 'green', 'blue'))
  title(main="R�gression polynomiale locale (fen�tre plus large)")
dev.off()

png(file="g509.png", width=600, height=600)
  n <- 50
  x <- runif(n)
  f <- function (x) { cos(3*x) + cos(5*x) }
  y <- f(x) + .2*rnorm(n)
  plot(y~x)
  curve(f(x), add=T, lty=2)
  bw <- dpill(x,y)
  lines( locpoly(x,y,degree=0, bandwidth=bw), col='red' )
  lines( locpoly(x,y,degree=1, bandwidth=bw), col='green' )
  lines( locpoly(x,y,degree=2, bandwidth=bw), col='blue' )
  legend( par("usr")[1], par("usr")[3], yjust=0,
          c("degr� = 0", "degr� = 1", "degr� = 2"),
          lwd=1, lty=1,
          col=c('red', 'green', 'blue'))
dev.off()

png(file="g510.png", width=600, height=600)
  a <- locpoly(x,y,degree=0, bandwidth=bw)
  b <- locpoly(x,y,degree=1, bandwidth=bw)
  c <- locpoly(x,y,degree=2, bandwidth=bw)
  matplot( cbind(a$x,b$x,c$x), abs(cbind(a$y-f(a$x), b$y-f(b$x), c$y-f(c$x)))^2, 
           xlab='', ylab='',
           type='l', lty=1, col=c('red', 'green', 'blue') )
  legend( .8*par("usr")[1]+.2*par("usr")[2], par("usr")[4], yjust=1,
          c("degr� = 0", "degr� = 1", "degr� = 2"),
          lwd=1, lty=1,
          col=c('red', 'green', 'blue'))
  title(main="Erreur quadratique")
dev.off()

png(file="g511.png", width=600, height=600)
  f <- function (x) { sqrt(abs(x-.5)) }
  y <- f(x) + .1*rnorm(n)
  plot(y~x)
  curve(f(x), add=T, lty=2)
  bw <- dpill(x,y)
  lines( locpoly(x,y,degree=0, bandwidth=bw), col='red' )
  lines( locpoly(x,y,degree=1, bandwidth=bw), col='green' )
  lines( locpoly(x,y,degree=2, bandwidth=bw), col='blue' )
  legend( par("usr")[1], par("usr")[3], yjust=0,
          c("degr� = 0", "degr� = 1", "degr� = 2"),
          lwd=1, lty=1,
          col=c('red', 'green', 'blue'))
dev.off()

png(file="g512.png", width=600, height=600)
  a <- locpoly(x,y,degree=0, bandwidth=bw)
  b <- locpoly(x,y,degree=1, bandwidth=bw)
  c <- locpoly(x,y,degree=2, bandwidth=bw)
  matplot( cbind(a$x,b$x,c$x), abs(cbind(a$y-f(a$x), b$y-f(b$x), c$y-f(c$x)))^2, 
           xlab='', ylab='',
           type='l', lty=1, col=c('red', 'green', 'blue') )
  legend( .8*par("usr")[1]+.2*par("usr")[2], par("usr")[4], yjust=1,
          c("degr� = 0", "degr� = 1", "degr� = 2"),
          lwd=1, lty=1,
          col=c('red', 'green', 'blue'))
  title(main="Erreur quadratique")
dev.off()

png(file="g513.png", width=600, height=600)
  # C'est lin�aire
  library(modreg)
  n <- 10
  op <- par(mfrow=c(2,2))
  for (i in 1:4) {
    x <- rnorm(n)
    y <- 1-2*x+.3*rnorm(n)
    plot(y~x)
    lo <- loess(y~x)
    xx <- seq(min(x),max(x),length=100)
    yy <- predict(lo, data.frame(x=xx))
    lines(xx,yy, col='red')
    lo <- loess(y~x, family='sym')
    xx <- seq(min(x),max(x),length=100)
    yy <- predict(lo, data.frame(x=xx))
    lines(xx,yy, col='red', lty=2)
    lines(lowess(x,y),col='blue',lty=2)
  #  abline(lm(y~x), col='green')
  #  abline(1,-2, col='green', lty=2)
  }
  par(op)
dev.off()

png(file="g514.png", width=600, height=600)
  # �a n'est pas lin�aire
  n <- 10
  op <- par(mfrow=c(2,2))
  for (i in 1:4) {
    x <- rnorm(n)
    y <- x*(1-x)+.3*rnorm(n)
    plot(y~x)
    lo <- loess(y~x)
    xx <- seq(min(x),max(x),length=100)
    yy <- predict(lo, data.frame(x=xx))
    lines(xx,yy, col='red')
    lo <- loess(y~x, family='sym')
    xx <- seq(min(x),max(x),length=100)
    yy <- predict(lo, data.frame(x=xx))
    lines(xx,yy, col='red', lty=2)
    lines(lowess(x,y),col='blue',lty=2)
  #  curve(x*(1-x), add = TRUE, col = "green", lty=2)
  }
  par(op)
dev.off()

png(file="g515.png", width=600, height=600)
  my.ridge <- function (y,x,k=0) {
    xm <- apply(x,2,mean)
    ym <- mean(y)
    y <- y - ym
    x <- t( t(x) - xm )
    ss <- function (b) {
      t( y - x %*% b ) %*% ( y - x %*% b ) + k * t(b) %*% b
    }
    b <- nlm(ss, rep(0,dim(x)[2]))$estimate
    c(ym-t(b)%*%xm, b)
  }
  my.ridge.test <- function (n=20, s=.1) {
    x <- rnorm(n)
    x1 <- x + s*rnorm(n)
    x2 <- x + s*rnorm(n)
    x <- cbind(x1,x2)
    y <- x1 + x2 + 1 + rnorm(n)
    lambda <- c(0, .001, .01, .1, .2, .5, 1, 2, 5, 10)
    b <- matrix(nr=length(lambda), nc=1+dim(x)[2])
    for (i in 1:length(lambda)) {
      b[i,] <- my.ridge(y,x,lambda[i])
    }
    plot(b[,2], b[,3], type="b", xlim=range(c(b[,2],1)), ylim=range(c(b[,3],1)))
    text(b[,2], b[,3], lambda, adj=c(-.2,-.2), col="blue")
    points(1,1,pch="+", cex=3, lwd=3)
    points(b[8,2],b[8,3],pch=15)
  }
  my.ridge.test()
dev.off()

png(file="g516.png", width=600, height=600)
  op <- par(mfrow=c(3,3))
  for (i in 1:9) {
    my.ridge.test()
  }
  par(op)
dev.off()

png(file="g517.png", width=600, height=600)
  op <- par(mfrow=c(3,3))
  for (i in 1:9) {
    my.ridge.test(20,10)
  }
  par(op)
dev.off()

png(file="g518.png", width=600, height=600)
  my.sample <- function (n=20) {
    x <- rnorm(n)
    x1 <- x + .1*rnorm(n)
    x2 <- x + .1*rnorm(n)
    y <- 0 + x1 - x2 + rnorm(n)
    cbind(y, x1, x2)
  }

  n <- 500
  r <- matrix(NA, nr=n, nc=3)
  s <- matrix(NA, nr=n, nc=3)
  for (i in 1:n) {
    m <- my.sample()
    r[i,] <- lm(m[,1]~m[,-1])$coef
    s[i,2:3] <- lm.ridge(m[,1]~m[,-1], lambda=.1)$coef
    s[i,1] <- mean(m[,1])
  }
  plot( density(r[,1]), xlim=c(-3,3),
        main="Variance �lev�e en cas de multicolin�arit�")
  abline(v=0, lty=3)
  lines( density(r[,2]), col='red' )
  lines( density(s[,2]), col='red', lty=2 )
  abline(v=1, col='red', lty=3)
  lines( density(r[,3]), col='blue' )
  lines( density(s[,3]), col='blue', lty=2 )
  abline(v=-1, col='blue', lty=3)
  # On indique la moyenne, pour bien montrer que c'est biais�
  evaluate.density <- function (d,x, eps=1e-6) {
    density(d, from=x-eps, to=x+2*eps, n=4)$y[2]
  }
  x<-mean(r[,2]); points( x, evaluate.density(r[,2],x) )
  x<-mean(s[,2]); points( x, evaluate.density(s[,2],x) )
  x<-mean(r[,3]); points( x, evaluate.density(r[,3],x) )
  x<-mean(s[,3]); points( x, evaluate.density(s[,3],x) )
  legend( par("usr")[1], par("usr")[4], yjust=1,
          c("terme constant", "x1", "x2"),
          lwd=1, lty=1, 
          col=c(par('fg'), 'red', 'blue') )
  legend( par("usr")[2], par("usr")[4], yjust=1, xjust=1,
          c("r�gression classique", "ridge regression"),
          lwd=1, lty=c(1,2), 
          col=par('fg') )
dev.off()

png(file="g519.png", width=600, height=600)
  n <- 500
  v <- matrix(c(0,1,-1), nr=n, nc=3, byrow=T)
  mse <- NULL
  kl <- c(1e-4, 2e-4, 5e-4, 1e-3, 2e-3, 5e-3, 1e-2, 2e-2, 5e-2, 
          .1, .2, .3, .4, .5, .6, .7, .8, .9, 1, 1.2, 1.4, 1.6, 1.8, 2)
  for (k in kl) {
    r <- matrix(NA, nr=n, nc=3)
    for (i in 1:n) {
      m <- my.sample()
      r[i,2:3] <- lm.ridge(m[,1]~m[,-1], lambda=k)$coef
      r[i,1] <- mean(m[,1])
    }
    mse <- append(mse, apply( (r-v)^2, 2, mean )[2])
  }
  plot( mse ~ kl, type='l' )  
  title(main="�volution de la MSE")
dev.off()

png(file="g520.png", width=600, height=600)
  plot( mse-min(mse)+.01 ~ kl, type='l', log='y' )
  title(main="�volution de la MSE")
dev.off()

png(file="g521.png", width=600, height=600)
  plot( rank(mse) ~ kl, type='l' )
  title(main="�volution de la MSE")
dev.off()

png(file="g522.png", width=600, height=600)
  m <- my.sample()
  b <- matrix(NA, nr=length(kl), nc=2)
  for (i in 1:length(kl)) {
    b[i,] <- lm.ridge(m[,1]~m[,-1], lambda=kl[i])$coef
  }
  matplot(kl, b, type="l")
  abline(h=c(0,-1,1), lty=3)
  # Estimation empirique de la valeur de k
  k <- min( lm.ridge(m[,1]~m[,-1], lambda=kl)$GCV )
  abline(v=k, lty=3)
  title(main="Le biais vers 0 dans la ridge regression")
dev.off()

png(file="g523.png", width=600, height=600)
  m <- my.sample()
  b <- matrix(NA, nr=length(kl), nc=2)
  for (i in 1:length(kl)) {
    b[i,] <- lm.ridge(m[,1]~m[,-1], lambda=kl[i])$coef
  }
  matplot(kl, b, type="l", log='x')
  abline(h=c(0,-1,1), lty=3)
  k <- min( lm.ridge(m[,1]~m[,-1], lambda=kl)$GCV )  
  abline(v=k, lty=3)
  title(main="Le biais vers 0 dans la ridge regression")
dev.off()

png(file="g524.png", width=600, height=600)
  my.lm.ridge.diag <- function (y, x, k=.1) {
    my <- mean(y)
    y <- y - my
    mx <- apply(x,2,mean)
    x <- x - matrix(mx, nr=dim(x)[1], nc=dim(x)[2], byrow=T)
    sx <- apply(x,2,sd)
    x <- x/matrix(sx, nr=dim(x)[1], nc=dim(x)[2], byrow=T)
    b <- solve( t(x) %*% x + diag(k, dim(x)[2]), t(x) %*% y)
    v <- solve( t(x) %*% x + diag(k, dim(x)[2]), 
         t(x) %*% x %*% solve( t(x) %*% x + diag(k, dim(x)[2]), 
         diag( var(y), dim(x)[2] ) ))
    ss <- t(b) %*% t(x) %*% y
    list( b = b, varb = v, ss = ss )
  }

  m <- my.sample()
  b <- matrix(NA, nr=length(kl), nc=2)
  v <- matrix(NA, nr=length(kl), nc=1)
  ss <- matrix(NA, nr=length(kl), nc=1)
  for (i in 1:length(kl)) {
    r <- my.lm.ridge.diag(m[,1], m[,-1], k=kl[i])
    b[i,] <- r$b
    v[i,] <- sum(diag(r$v))
    ss[i,] <- r$ss
  }
  matplot(kl, b, type="l", lty=1, col=par('fg'), axes=F, ylab='')
  axis(1)
  abline(h=c(0,-1,1), lty=3)
  par(new=T)
  matplot(kl, v, type="l", col='red', axes=F, ylab='')
  par(new=T)
  matplot(kl, ss, type="l", col='blue', axes=F, ylab='')
  legend( par("usr")[2], par("usr")[4], yjust=1, xjust=1,
          c("param�tres", "variance", "sommes de carr�s"),
          lwd=1, lty=1, col=c(par('fg'), "red", "blue") )
dev.off()

png(file="g525.png", width=600, height=600)
  matplot(log(kl), b, type="l", lty=1, col=par('fg'), axes=F, ylab='')
  axis(1)
  abline(h=c(0,-1,1), lty=3)
  par(new=T)
  matplot(log(kl), v, type="l", col='red', axes=F, ylab='')
  par(new=T)
  matplot(log(kl), ss, type="l", col='blue', axes=F, ylab='')
  # Je n'arrive pas � placer la l�gende si l'�chelle est logarithmique...
  legend( par("usr")[1], 
          .9*par("usr")[3] + .1*par("usr")[4], 
          yjust=0, xjust=0,
          c("param�tres", "variance", "sommes de carr�s"),
          lwd=1, lty=1, col=c(par('fg'), "red", "blue") )
dev.off()

png(file="g526.png", width=600, height=600)
  op <- par(mfrow=c(3,3))
  for (j in 1:9) {
    m <- my.sample()
    b <- matrix(NA, nr=length(kl), nc=2)
    for (i in 1:length(kl)) {
      b[i,] <- lm.ridge(m[,1]~m[,-1], lambda=kl[i])$coef
    }
    matplot(kl, b, type="l", log='x')
    abline(h=c(0,-1,1), lty=3)
    k <- min( lm.ridge(m[,1]~m[,-1], lambda=kl)$GCV )  
    abline(v=k, lty=3)
  }
  par(op)
dev.off()

png(file="g527.png", width=600, height=600)
  m <- my.sample()
  N <- 20
  err <- matrix(nr=length(kl), nc=N)
  for (j in 1:N) {
    s <- sample(dim(m)[1], floor(3*dim(m)[1]/4))
    mm <- m[s,]
    mv <- m[-s,]
    for (i in 1:length(kl)) {
      r <- lm.ridge(mm[,1]~mm[,-1], lambda=kl[i])
      # BUG...
      b <- r$coef / r$scales
      a <- r$ym - t(b) %*% r$xm
      p <- rep(a, dim(mv)[1]) + mv[,-1] %*% b
      e <- p-mv[,1]
      err[i,j] <- sum(e*e)
    }
  }
  err <- apply(err, 1, mean)
  plot(err ~ kl, type='l', log='x')
dev.off()

png(file="g528.png", width=600, height=600)
  my.lasso <- function (y,x,k=0) {
    xm <- apply(x,2,mean)
    ym <- mean(y)
    y <- y - ym
    x <- t( t(x) - xm )
    ss <- function (b) {
      t( y - x %*% b ) %*% ( y - x %*% b ) + k * sum(abs(b))
    }
    b <- nlm(ss, rep(0,dim(x)[2]))$estimate
    c(ym-t(b)%*%xm, b)
  }

  my.lasso.test <- function (n=20) {
    s <- .1
    x <- rnorm(n)
    x1 <- x + s*rnorm(n)
    x2 <- x + s*rnorm(n)
    x <- cbind(x1,x2)
    y <- x1 + x2 + 1 + rnorm(n)
    lambda <- c(0, .001, .01, .1, .2, .5, 1, 2, 5, 10)
    b <- matrix(nr=length(lambda), nc=1+dim(x)[2])
    for (i in 1:length(lambda)) {
      b[i,] <- my.lasso(y,x,lambda[i])
    }
    plot(b[,2], b[,3], type="b", xlim=range(c(b[,2],1)), ylim=range(c(b[,3],1)))
    text(b[,2], b[,3], lambda, adj=c(-.2,-.2), col="blue")
    points(1,1,pch="+", cex=3, lwd=3)
    points(b[8,2],b[8,3],pch=15)
  }
  my.lasso.test()
dev.off()

png(file="g529.png", width=600, height=600)
  op <- par(mfrow=c(3,3))
  for (i in 1:9) {
    my.lasso.test()
  }
  par(op)
dev.off()

png(file="g530.png", width=600, height=600)
  op <- par(mfrow=c(3,3))
  for (i in 1:9) {
    my.lasso.test(1000)
  }
  par(op)
dev.off()

png(file="g531.png", width=600, height=600)
  # Je ne mets pas de dessin � cause d'un bug dans la fonction l1ce :
  # d'une part, elle exige qu'on lui donne un data.frame ; d'autre part, 
  # elle exige que ce data.frame soit une variable globale...

  library(lasso2)
  set.seed(73823)
  #other.lasso.test <- function (n=20) {
    s <- .1
    x <- rnorm(n)
    x1 <- x + s*rnorm(n)
    x2 <- x + s*rnorm(n)
    y <- x1 + x2 + 1 + rnorm(n)
    d <- data.frame(y,x1,x2)
    lambda <- c(0, .001, .01, .1, .2, .5, 1, 2, 5, 10)
    b <- matrix(nr=length(lambda), nc=dim(d)[2])
    for (i in 1:length(lambda)) {
      try( b[i,] <- l1ce(y~x1+x2, data=d, bound=lambda[i], absolute.t=T)$coefficients )
      # J'ai eu le message d'erreur tr�s informatif : 
      #   Oops, something went wrong in .C("lasso",..): -1
    }
    plot(b[,2], b[,3], type="b", xlim=range(c(b[,2],1)), ylim=range(c(b[,3],1)))
    text(b[,2], b[,3], lambda, adj=c(-.2,-.2), col="blue")
    points(1,1,pch="+", cex=3, lwd=3)
    points(b[8,2],b[8,3],pch=15)
  #}
  #other.lasso.test()
dev.off()

png(file="g532.png", width=600, height=600)
  get.sample <- function (n=20,s=.1) {
    x <- rnorm(n)
    x1 <- x + s*rnorm(n)
    x2 <- x + s*rnorm(n)
    y <- x1 + x2 + 1 + rnorm(n)
    data.frame(y,x1,x2)
  }
  lambda <- c(0, .001, .01, .1, .2, .5, 1, 2, 5, 10)

  do.it <- function (n=20,s=.1) {
    d <- get.sample(n,s)
    y <- d$y
    x <- cbind(d$x1,d$x2)
    ridge <- matrix(nr=length(lambda), nc=1+dim(x)[2])
    for (i in 1:length(lambda)) {
      ridge[i,] <- my.ridge(y,x,lambda[i])
    }
    lasso <- matrix(nr=length(lambda), nc=1+dim(x)[2])
    for (i in 1:length(lambda)) {
      lasso[i,] <- my.lasso(y,x,lambda[i])
    }
    xlim <- range(c( 1, ridge[,2], lasso[,2] ))        
    ylim <- range(c( 1, ridge[,3], lasso[,3] ))        
    plot(ridge[,2], ridge[,3], type="b", col='red', xlim=xlim, ylim=ylim)
    points(ridge[8,2],ridge[8,3],pch=15,col='red')
    lines(lasso[,2], lasso[,3], type="b")
    points(lasso[8,2],lasso[8,3],pch=15)
    points(1,1,pch="+", cex=3, lwd=3)
  }

  op <- par(mfrow=c(3,3))
  for (i in 1:9) {
    do.it()
  }
  par(op)
dev.off()

png(file="g533.png", width=600, height=600)
  op <- par(mfrow=c(3,3))
  for (i in 1:9) {
    do.it(100)
  }
  par(op)
dev.off()

png(file="g534.png", width=600, height=600)
  op <- par(mfrow=c(3,3))
  for (i in 1:9) {
    do.it(20,10)
  }
  par(op)
dev.off()

png(file="g535.png", width=600, height=600)
  my.pcr <- function (y,x,k) {
    n <- dim(x)[1]
    p <- dim(x)[2]
    ym <- mean(y)
    xm <- apply(x,2,mean)
    # Id�alement, il faudrait aussi normaliser x et y... (Exercice laiss� au lecteur)
    y <- y - ym 
    x <- t( t(x) - xm )
    pc <- princomp(x)
    b <- lm(y~pc$scores[,1:k]-1)$coef
    b <- c(b, rep(0,p-k))
    b <- pc$loadings %*% b
    names(b) <- colnames(x)
    b <- c(ym-t(b)%*%xm, b)
    b
  }
  get.sample <- function (n=20, s=.1) {
    x <- rnorm(n)
    x1 <- x + s*rnorm(n)
    x2 <- x + s*rnorm(n)
    x3 <- x + s*rnorm(n)
    x4 <- x + s*rnorm(n)
    x <- cbind(x1,x2,x3,x4)
    y <- x1 + x2 - x3 - x4 + 1 + rnorm(n)
    list(x=x,y=y)
  }
  pcr.test <- function (n=20, s=.1) {
    s <- get.sample(n,s)
    x <- s$x
    y <- s$y
    pcr <- matrix(nr=4,nc=5)
    for (k in 1:4) {
      pcr[k,] <- my.pcr(y,x,k)
    }
    plot(pcr[,2], pcr[,3], type="b", xlim=range(c(pcr[,2],1)), ylim=range(c(pcr[,3],1)))
    points(pcr[4,2],pcr[4,3], lwd=2)
    points(1,1,pch="+", cex=3, lwd=3)
  }
  pcr.test()
dev.off()

png(file="g536.png", width=600, height=600)
  pcr.test <- function (n=20, s=.1) {
    s <- get.sample(n,s)
    x <- s$x
    y <- s$y

    lambda <- c(0, .001, .01, .1, .2, .5, 1, 2, 5, 10)
    ridge <- matrix(nr=length(lambda), nc=1+dim(x)[2])
    for (i in 1:length(lambda)) {
      ridge[i,] <- my.ridge(y,x,lambda[i])
    }

    pcr <- matrix(nr=4,nc=5)
    for (k in 1:4) {
      pcr[k,] <- my.pcr(y,x,k)
    }

    xlim <- range(c( 1, ridge[,2], pcr[,2] ))        
    ylim <- range(c( 1, ridge[,3], pcr[,3] ))        
    plot(ridge[,2], ridge[,3], type="b", col='red', xlim=xlim, ylim=ylim)
    points(ridge[4,2],ridge[4,3],pch=15,col='red')

    lines(pcr[,2], pcr[,3], type="b")
    points(pcr[4,2],pcr[4,3], lwd=2)
    points(1,1,pch="+", cex=3, lwd=3)    
  }
  op <- par(mfrow=c(3,3))
  for (i in 1:9) {
    pcr.test()    
  }
  par(op)
dev.off()

png(file="g537.png", width=600, height=600)
  n <- 100
  x <- seq(-2,2,length=n)
  y <- exp(x)
  plot(y~x, type='l', lwd=3)
  title(main='Croissance exponentielle')
dev.off()

png(file="g538.png", width=600, height=600)
  x <- seq(-2,2,length=n)
  y <- exp(-x)
  plot(y~x, type='l', lwd=3)
  title(main='D�croissance exponentielle')
dev.off()

png(file="g539.png", width=600, height=600)
  x <- seq(-2,4,length=n)
  y <- 1-exp(-x)
  plot(y~x, type='l', lwd=3)
  title(main='Exponentielle n�gative')
dev.off()

png(file="g540.png", width=600, height=600)
  x <- seq(0,5,length=n)
  u <- 1
  v <- 2
  y <- u/(u-v) * (exp(-v*x) - exp(-u*x))
  plot(y~x, type='l', lwd=3)
  title(main='Exponentielle double')
dev.off()

png(file="g541.png", width=600, height=600)
  x <- seq(-5,5,length=n)
  y <- 1/(1+exp(-x))
  plot(y~x, type='l', lwd=3)
  title(main='Croissance sigmo�de')
dev.off()

png(file="g542.png", width=600, height=600)
  x <- seq(-2,5,length=n)
  y <- exp(-exp(-x))
  plot(y~x, type='l', lwd=3)
  title(main='Sigmo�de moins sym�trique')
dev.off()

png(file="g543.png", width=600, height=600)
  library(nls)
  f <- function (x,p) {
    u <- p[1]
    v <- p[2]
    u/(u-v) * (exp(-v*x) - exp(-u*x))    
  }
  n <- 100
  x <- runif(n,0,2)
  y <- f(x, c(3.14,2.71)) + .1*rnorm(n)
  r <- nls( y ~ f(x,c(a,b)), start=c(a=3, b=2.5) )
  plot(y~x)
  xx <- seq(0,2,length=200)
  lines(xx, f(xx,r$m$getAllPars()), col='red', lwd=3)
  lines(xx, f(xx,c(3.14,2.71)), lty=2)
dev.off()

png(file="g544.png", width=600, height=600)
  op <- par(mfrow=c(2,2))
  p <- profile(r)
  plot(p, conf = c(95, 90, 80, 50)/100)
  plot(p, conf = c(95, 90, 80, 50)/100, absVal = FALSE)
  par(op)
dev.off()

png(file="g545.png", width=600, height=600)
  rm(r)
  while(!exists("r")) {
    x <- runif(n,0,2)
    y <- SSbiexp(x,1,1,-1,2) + .01*rnorm(n)
    try(  r <- nls(y ~ SSbiexp(x,a,u,b,v))  )
  }
  plot(y~x)
  xx <- seq(0,2,length=200)
  lines(xx, SSbiexp(xx,
                    r$m$getAllPars()[1],
                    r$m$getAllPars()[2],
                    r$m$getAllPars()[3],
                    r$m$getAllPars()[4],
                    ), col='red', lwd=3)
  title(main='biexponential')
dev.off()

png(file="g546.png", width=600, height=600)
  op <- par(mfrow=c(2,2))
  try(plot(profile(r)))
  par(op)
dev.off()

png(file="g547.png", width=600, height=600)
  rm(r)
  while(!exists("r")) {
    x <- runif(n,-5,5)
    y <- SSlogis(x,1,0,1) + .1*rnorm(n)
    try( r <- nls(y ~ SSlogis(x,a,m,s)) )
  }
  plot(y~x)
  xx <- seq(-5,5,length=200)
  lines(xx, SSlogis(xx,
                    r$m$getAllPars()[1],
                    r$m$getAllPars()[2],
                    r$m$getAllPars()[3],
                    ), col='red', lwd=3)
  title(main='logistic')
dev.off()

png(file="g548.png", width=600, height=600)
  rm(r)
  while(!exists("r")) {
    x <- runif(n,-5,5)
    y <- SSfpl(x,-1,1,0,1) + .1*rnorm(n)
    try( r <- nls(y ~ SSfpl(x,a,b,m,s)) )
  }
  plot(y~x)
  xx <- seq(-5,5,length=200)
  lines(xx, SSfpl(xx,
                    r$m$getAllPars()[1],
                    r$m$getAllPars()[2],
                    r$m$getAllPars()[3],
                    r$m$getAllPars()[4],
                    ), col='red', lwd=3)
  title(main='4-parameter logistic model')
dev.off()

png(file="g549.png", width=600, height=600)
  rm(r)
  while(!exists("r")) {
    x <- runif(n,-5,5)
    y <- SSmicmen(x,1,1) + .01*rnorm(n)
    try( r <- nls(y ~ SSmicmen(x,m,h)) )
  }
  plot(y~x, ylim=c(-5,5))
  xx <- seq(-5,5,length=200)
  lines(xx, SSmicmen(xx,
                    r$m$getAllPars()[1],
                    r$m$getAllPars()[2],
                    ), col='red', lwd=3)
  title(main='Michaelis-Menten')
dev.off()

png(file="g550.png", width=600, height=600)
  rm(r)
  while(!exists("r")) {
    x <- runif(n,0,5)
    y <- SSmicmen(x,1,1) + .1*rnorm(n)
    try( r <- nls(y ~ SSmicmen(x,m,h)) )
  }
  plot(y~x)
  xx <- seq(0,5,length=200)
  lines(xx, SSmicmen(xx,
                    r$m$getAllPars()[1],
                    r$m$getAllPars()[2],
                    ), col='red', lwd=3)
  title(main='Michaelis-Menten')
dev.off()

png(file="g551.png", width=600, height=600)
  rm(r)
  while(!exists("r")) {
    x <- runif(n,0,1)
    y <- SSfol(1,x,1,2,1) + .1*rnorm(n)
    try( r <- nls(y ~ SSfol(1,x,a,b,c)) )
  }
  plot(y~x)
  xx <- seq(0,1,length=200)
  lines(xx, SSfol(1,
                     xx,
                     r$m$getAllPars()[1],
                     r$m$getAllPars()[2],
                     r$m$getAllPars()[3],
                    ), col='red', lwd=3)
  title(main='SSfol')
dev.off()

png(file="g552.png", width=600, height=600)
  rm(r)
  while(!exists("r")) {
    x <- runif(n,0,2)
    y <- SSasymp(x,1,.5,1) + .1*rnorm(n)
    try( r <- nls(y ~ SSasymp(x,a,b,c)) )
  }
  plot(y~x, xlim=c(-.5,2),ylim=c(0,1.3))
  xx <- seq(-1,2,length=200)
  lines(xx, SSasymp(xx,
                    r$m$getAllPars()[1],
                    r$m$getAllPars()[2],
                    r$m$getAllPars()[3],
                   ), col='red', lwd=3)
  title(main='SSasymp')
  # Voir aussi SSasympOff et SSasympOrig
dev.off()

png(file="g553.png", width=600, height=600)
  # Copi� sur le manuel
  xx <- seq(0, 5, len = 101)
  yy <- 5 - 4 * exp(-xx/(2*log(2)))
  par(mar = c(0, 0, 4.1, 0))
  plot(xx, yy, type = "l", axes = FALSE, ylim = c(0,6), xlim = c(-1, 5),
       xlab = "", ylab = "", lwd = 2,
       main = "Parameters in the SSasymp model")
  usr <- par("usr")
  arrows(usr[1], 0, usr[2], 0, length = 0.1, angle = 25)
  arrows(0, usr[3], 0, usr[4], length = 0.1, angle = 25)
  text(usr[2] - 0.2, 0.1, "x", adj = c(1, 0))
  text(-0.1, usr[4], "y", adj = c(1, 1))
  abline(h = 5, lty = 2, lwd = 0)
  arrows(-0.8, 2.1, -0.8, 0, length = 0.1, angle = 25)
  arrows(-0.8, 2.9, -0.8, 5, length = 0.1, angle = 25)
  text(-0.8, 2.5, expression(phi[1]), adj = c(0.5, 0.5))
  segments(-0.4, 1, 0, 1, lty = 2, lwd = 0.75)
  arrows(-0.3, 0.25, -0.3, 0, length = 0.07, angle = 25)
  arrows(-0.3, 0.75, -0.3, 1, length = 0.07, angle = 25)
  text(-0.3, 0.5, expression(phi[2]), adj = c(0.5, 0.5))
  segments(1, 3.025, 1, 4, lty = 2, lwd = 0.75)
  arrows(0.2, 3.5, 0, 3.5, length = 0.08, angle = 25)
  arrows(0.8, 3.5, 1, 3.5, length = 0.08, angle = 25)
  text(0.5, 3.5, expression(t[0.5]), adj = c(0.5, 0.5))
dev.off()

png(file="g554.png", width=600, height=600)
  # Copi� sur le manuel
  xx <- seq(0.5, 5, len = 101)
  yy <- 5 * (1 -  exp(-(xx - 0.5)/(2*log(2))))
  par(mar = c(0, 0, 4.0, 0))
  plot(xx, yy, type = "l", axes = FALSE, ylim = c(0,6), xlim = c(-1, 5),
       xlab = "", ylab = "", lwd = 2,
       main = "Parameters in the SSasympOff model")
  usr <- par("usr")
  arrows(usr[1], 0, usr[2], 0, length = 0.1, angle = 25)
  arrows(0, usr[3], 0, usr[4], length = 0.1, angle = 25)
  text(usr[2] - 0.2, 0.1, "x", adj = c(1, 0))
  text(-0.1, usr[4], "y", adj = c(1, 1))
  abline(h = 5, lty = 2, lwd = 0)
  arrows(-0.8, 2.1, -0.8, 0, length = 0.1, angle = 25)
  arrows(-0.8, 2.9, -0.8, 5, length = 0.1, angle = 25)
  text(-0.8, 2.5, expression(phi[1]), adj = c(0.5, 0.5))
  segments(0.5, 0, 0.5, 3, lty = 2, lwd = 0.75)
  text(0.5, 3.1, expression(phi[3]), adj = c(0.5, 0))
  segments(1.5, 2.525, 1.5, 3, lty = 2, lwd = 0.75)
  arrows(0.7, 2.65, 0.5, 2.65, length = 0.08, angle = 25)
  arrows(1.3, 2.65, 1.5, 2.65, length = 0.08, angle = 25)
  text(1.0, 2.65, expression(t[0.5]), adj = c(0.5, 0.5))
dev.off()

png(file="g555.png", width=600, height=600)
  # Copi� sur le manuel
  xx <- seq(0, 5, len = 101)
  yy <- 5 * (1- exp(-xx/(2*log(2))))
  par(mar = c(0, 0, 3.5, 0))
  plot(xx, yy, type = "l", axes = FALSE, ylim = c(0,6), xlim = c(-1, 5),
       xlab = "", ylab = "", lwd = 2,
       main = "Parameters in the SSasympOrig model")
  usr <- par("usr")
  arrows(usr[1], 0, usr[2], 0, length = 0.1, angle = 25)
  arrows(0, usr[3], 0, usr[4], length = 0.1, angle = 25)
  text(usr[2] - 0.2, 0.1, "x", adj = c(1, 0))
  text(-0.1, usr[4], "y", adj = c(1, 1))
  abline(h = 5, lty = 2, lwd = 0)
  arrows(-0.8, 2.1, -0.8, 0, length = 0.1, angle = 25)
  arrows(-0.8, 2.9, -0.8, 5, length = 0.1, angle = 25)
  text(-0.8, 2.5, expression(phi[1]), adj = c(0.5, 0.5))
  segments(1, 2.525, 1, 3.5, lty = 2, lwd = 0.75)
  arrows(0.2, 3.0, 0, 3.0, length = 0.08, angle = 25)
  arrows(0.8, 3.0, 1, 3.0, length = 0.08, angle = 25)
  text(0.5, 3.0, expression(t[0.5]), adj = c(0.5, 0.5))
dev.off()

png(file="g556.png", width=600, height=600)
  # Copi� sur le manuel
  xx <- seq(-0.5, 5, len = 101)
  yy <- 1 + 4 / ( 1 + exp((2-xx)))
  par(mar = c(0, 0, 3.5, 0))
  plot(xx, yy, type = "l", axes = FALSE, ylim = c(0,6), xlim = c(-1, 5),
       xlab = "", ylab = "", lwd = 2,
       main = "Parameters in the SSfpl model")
  usr <- par("usr")
  arrows(usr[1], 0, usr[2], 0, length = 0.1, angle = 25)
  arrows(0, usr[3], 0, usr[4], length = 0.1, angle = 25)
  text(usr[2] - 0.2, 0.1, "x", adj = c(1, 0))
  text(-0.1, usr[4], "y", adj = c(1, 1))
  abline(h = 5, lty = 2, lwd = 0)
  arrows(-0.8, 2.1, -0.8, 0, length = 0.1, angle = 25)
  arrows(-0.8, 2.9, -0.8, 5, length = 0.1, angle = 25)
  text(-0.8, 2.5, expression(phi[1]), adj = c(0.5, 0.5))
  abline(h = 1, lty = 2, lwd = 0)
  arrows(-0.3, 0.25, -0.3, 0, length = 0.07, angle = 25)
  arrows(-0.3, 0.75, -0.3, 1, length = 0.07, angle = 25)
  text(-0.3, 0.5, expression(phi[2]), adj = c(0.5, 0.5))
  segments(2, 0, 2, 3.3, lty = 2, lwd = 0.75)
  text(2, 3.3, expression(phi[3]), adj = c(0.5, 0))
  segments(3, 1+4/(1+exp(-1)) - 0.025, 3, 2.5, lty = 2, lwd = 0.75)
  arrows(2.3, 2.7, 2.0, 2.7, length = 0.08, angle = 25)
  arrows(2.7, 2.7, 3.0, 2.7, length = 0.08, angle = 25)
  text(2.5, 2.7, expression(phi[4]), adj = c(0.5, 0.5))
dev.off()

png(file="g557.png", width=600, height=600)
  # Copi� sur le manuel
  xx <- seq(-0.5, 5, len = 101)
  yy <- 5 / ( 1 + exp((2-xx)))
  par(mar = c(0, 0, 3.5, 0))
  plot(xx, yy, type = "l", axes = FALSE, ylim = c(0,6), xlim = c(-1, 5),
       xlab = "", ylab = "", lwd = 2,
       main = "Parameters in the SSlogis model")
  usr <- par("usr")
  arrows(usr[1], 0, usr[2], 0, length = 0.1, angle = 25)
  arrows(0, usr[3], 0, usr[4], length = 0.1, angle = 25)
  text(usr[2] - 0.2, 0.1, "x", adj = c(1, 0))
  text(-0.1, usr[4], "y", adj = c(1, 1))
  abline(h = 5, lty = 2, lwd = 0)
  arrows(-0.8, 2.1, -0.8, 0, length = 0.1, angle = 25)
  arrows(-0.8, 2.9, -0.8, 5, length = 0.1, angle = 25)
  text(-0.8, 2.5, expression(phi[1]), adj = c(0.5, 0.5))
  segments(2, 0, 2, 4.0, lty = 2, lwd = 0.75)
  text(2, 4.0, expression(phi[2]), adj = c(0.5, 0))
  segments(3, 5/(1+exp(-1)) + 0.025, 3, 4.0, lty = 2, lwd = 0.75)
  arrows(2.3, 3.8, 2.0, 3.8, length = 0.08, angle = 25)
  arrows(2.7, 3.8, 3.0, 3.8, length = 0.08, angle = 25)
  text(2.5, 3.8, expression(phi[3]), adj = c(0.5, 0.5))
dev.off()

png(file="g558.png", width=600, height=600)
  # Copi� sur le manuel
  xx <- seq(0, 5, len = 101)
  yy <- 5 * xx/(1+xx)
  par(mar = c(0, 0, 3.5, 0))
  plot(xx, yy, type = "l", axes = FALSE, ylim = c(0,6), xlim = c(-1, 5),
       xlab = "", ylab = "", lwd = 2,
       main = "Parameters in the SSmicmen model")
  usr <- par("usr")
  arrows(usr[1], 0, usr[2], 0, length = 0.1, angle = 25)
  arrows(0, usr[3], 0, usr[4], length = 0.1, angle = 25)
  text(usr[2] - 0.2, 0.1, "x", adj = c(1, 0))
  text(-0.1, usr[4], "y", adj = c(1, 1))
  abline(h = 5, lty = 2, lwd = 0)
  arrows(-0.8, 2.1, -0.8, 0, length = 0.1, angle = 25)
  arrows(-0.8, 2.9, -0.8, 5, length = 0.1, angle = 25)
  text(-0.8, 2.5, expression(phi[1]), adj = c(0.5, 0.5))
  segments(1, 0, 1, 2.7, lty = 2, lwd = 0.75)
  text(1, 2.7, expression(phi[2]), adj = c(0.5, 0))
dev.off()

png(file="g559.png", width=600, height=600)
  library(nlme)
  data(Orthodont)
  fm1 <- lme(distance ~ age, Orthodont, random = ~ age | Subject)
  # standardized residuals versus fitted values by gender
  plot(fm1, resid(., type = "p") ~ fitted(.) | Sex, abline = 0)
dev.off()

png(file="g560.png", width=600, height=600)
  # box-plots of residuals by Subject
  plot(fm1, Subject ~ resid(.))
dev.off()

png(file="g561.png", width=600, height=600)
  # observed versus fitted values by Subject
  plot(fm1, distance ~ fitted(.) | Subject, abline = c(0,1))
dev.off()

png(file="g562.png", width=600, height=600)
  # library(lqs)   # now part of MASS
  n <- 100
  x <- rnorm(n)
  y <- 1 - 2*x + rnorm(n)
  y[ sample(1:n, floor(n/4)) ] <- 7
  plot(y~x)
  abline(1,-2,lty=3)
  r1 <- lm(y~x)
  r2 <- lqs(y~x, method='lts')
  r3 <- lqs(y~x, method='lqs')
  r4 <- lqs(y~x, method='lms')
  r5 <- lqs(y~x, method='S')
  abline(r1, col='red')
  abline(r2, col='green')
  abline(r3, col='blue')
  abline(r4, col='orange')
  abline(r5, col='purple')
  legend( par("usr")[1], par("usr")[3], yjust=0,
          c("R�gression lin�aire", "lts (r�gression �lagu�e)",
          "lqs", "lms", "S"),
          lty=1, lwd=1,
          col=c("red", "green", "blue", "orange", "purple") )
  title("Moindres carr�s �lagu�s et variantes")
dev.off()

png(file="g563.png", width=600, height=600)
  # Exemple
  x <- rnorm(20)
  y <- 1 - x + rnorm(20)
  x <- c(x,10)
  y <- c(y,1)
  plot(y~x)
  abline(lm(y~x), col='blue')
  title(main="R�gression classique")
dev.off()

png(file="g564.png", width=600, height=600)
  # How bad usual regression is
  plot(lm(y~x), which=4, 
       main="Distances de Cook pour la r�gression classique")
dev.off()

png(file="g565.png", width=600, height=600)
  plot(y~x)
  for (i in 1:length(x))
    abline(lm(y~x, subset= (1:length(x))!=i ), col='red')
  title(main="R�gression classique apr�s avoir enlev� un point")
dev.off()

png(file="g566.png", width=600, height=600)
  # line (in the eda library)
  library(eda)
  plot(y~x)
  abline(1,-1, lty=3)
  abline(lm(y~x))
  abline(coef(line(x,y)), col='red')
  title(main='Regression avec "line", dans la biblioth�que "eda"')
dev.off()

png(file="g567.png", width=600, height=600)
  # R�gression �lagu�e
  #library(lqs)
  plot(y~x)
  abline(1,-1, lty=3)
  abline(lm(y~x))
  abline(lqs(y~x), col='red')
  title(main='Moindres carr�s �lagu�s (lqs)')
dev.off()

png(file="g568.png", width=600, height=600)
  # glm (d'apr�s le manuel, il s'agit bien des IWLS,
  # mais on obtient exactement le m�me r�sultat...)
  plot(y~x)
  abline(1,-1, lty=3)
  abline(lm(y~x))
  abline(glm(y~x), col='red')
  title(main='R�gression avec "glm"')
dev.off()

png(file="g569.png", width=600, height=600)
  x <- runif(20)
  y <- 1-2*x+.1*rnorm(20)
  res <- lm(y~x)
  plot(y~x)
  new <- data.frame( x=seq(0,1,length=21) )
  p <- predict(res, new)
  points( p ~ new$x, type='l' )
  p <- predict(res, new, interval='confidence')
  points( p[,2] ~ new$x, type='l', col="green" )
  points( p[,3] ~ new$x, type='l', col="green" )
  p <- predict(res, new, interval='prediction')
  points( p[,2] ~ new$x, type='l', col="red" )
  points( p[,3] ~ new$x, type='l', col="red" )
  title(main="Bandes de confiance et de pr�diction")
  legend( par("usr")[1], par("usr")[3], yjust=0,
          c("Bande de confiance", "Bande de pr�diction"),
          lwd=1, lty=1, col=c("green", "red") )
dev.off()

png(file="g570.png", width=600, height=600)
  plot(y~x, xlim=c(-1,2), ylim=c(-3,3))
  new <- data.frame( x=seq(-2,3,length=200) )
  p <- predict(res, new)
  points( p ~ new$x, type='l' )
  p <- predict(res, new, interval='confidence')
  points( p[,2] ~ new$x, type='l', col="green" )
  points( p[,3] ~ new$x, type='l', col="green" )
  p <- predict(res, new, interval='prediction')
  points( p[,2] ~ new$x, type='l', col="red" )
  points( p[,3] ~ new$x, type='l', col="red" )
  title(main="Bandes de confiance et de pr�diction")
  legend( par("usr")[1], par("usr")[3], yjust=0,
          c("Bande de confiance", "Bande de pr�diction"),
          lwd=1, lty=1, col=c("green", "red") )
dev.off()

png(file="g571.png", width=600, height=600)
  plot(y~x, xlim=c(-5,6), ylim=c(-11,11))
  new <- data.frame( x=seq(-5,6,length=200) )
  p <- predict(res, new)
  points( p ~ new$x, type='l' )
  p <- predict(res, new, interval='confidence')
  points( p[,2] ~ new$x, type='l', col="green" )
  points( p[,3] ~ new$x, type='l', col="green" )
  p <- predict(res, new, interval='prediction')
  points( p[,2] ~ new$x, type='l', col="red" )
  points( p[,3] ~ new$x, type='l', col="red" )
  title(main="Bandes de confiance et de pr�diction")
  legend( par("usr")[1], par("usr")[3], yjust=0,
          c("Bande de confiance", "Bande de pr�diction"),
          lwd=1, lty=1, col=c("green", "red") )
dev.off()

png(file="g572.png", width=600, height=600)
  N <- 100
  n <- 20
  x <- runif(N, min=-1, max=1)
  y <- 1 - 2*x + rnorm(N, sd=abs(x))
  res <- lm(y~x)
  plot(y~x)
  x0 <- seq(-1,1,length=n)
  new <- data.frame( x=x0 )
  p <- predict(res, new)
  points( p ~ x0, type='l' )
  p <- predict(res, new, interval='prediction')
  segments( x0, p[,2], x0, p[,3], col='red')
  p <- predict(res, new, interval='confidence')
  segments( x0, p[,2], x0, p[,3], col='green', lwd=3 )
dev.off()

png(file="g573.png", width=600, height=600)
  mySegments <- function(a,b,c,d,...) {
    u <- par('usr')
    e <- (u[2]-u[1])/100
    segments(a,b,c,d,...)
    segments(a+e,b,a-e,b,...)
    segments(c+e,d,c-e,d,...)
  }
  plot(y~x)
  p <- predict(res, new)
  points( p ~ x0, type='l' )
  p <- predict(res, new, interval='prediction')
  mySegments( x0, p[,2], x0, p[,3], col='red')
  p <- predict(res, new, interval='confidence')
  mySegments( x0, p[,2], x0, p[,3], col='green', lwd=3 )
dev.off()

png(file="g574.png", width=600, height=600)
  library(ellipse)
  my.confidence.region <- function (g, a=2, b=3) {
    e <- ellipse(g,c(a,b))
    plot(e,
         type="l",
         xlim=c( min(c(0,e[,1])), max(c(0,e[,1])) ),
         ylim=c( min(c(0,e[,2])), max(c(0,e[,2])) ),
        )
    x <- g$coef[a]
    y <- g$coef[b]
    points(x,y,pch=18)
    cf <- summary(g)$coefficients
    ia <- cf[a,2]*qt(.975,g$df.residual)
    ib <- cf[b,2]*qt(.975,g$df.residual)
    abline(v=c(x+ia,x-ia),lty=2)
    abline(h=c(y+ib,y-ib),lty=2)
    points(0,0)
    abline(v=0,lty="F848")
    abline(h=0,lty="F848")
  }

  n <- 20
  x1 <- rnorm(n)
  x2 <- rnorm(n)
  x3 <- rnorm(n)
  y <- x1+x2+x3+rnorm(n)
  g <- lm(y~x1+x2+x3)
  my.confidence.region(g)
dev.off()

png(file="g575.png", width=600, height=600)
  n <- 20
  x <- rnorm(n)
  x1 <- x+.2*rnorm(n)
  x2 <- x+.2*rnorm(n)
  y <- x1+x2+rnorm(n)
  g <- lm(y~x1+x2)
  my.confidence.region(g)
dev.off()

png(file="g576.png", width=600, height=600)
  my.confidence.region <- function (g, a=2, b=3, which=0, col='pink') {
    e <- ellipse(g,c(a,b))
    x <- g$coef[a]
    y <- g$coef[b]
    cf <- summary(g)$coefficients
    ia <- cf[a,2]*qt(.975,g$df.residual)
    ib <- cf[b,2]*qt(.975,g$df.residual)
    xmin <- min(c(0,e[,1]))
    xmax <- max(c(0,e[,1]))
    ymin <- min(c(0,e[,2]))
    ymax <- max(c(0,e[,2]))
    plot(e,
         type="l",
         xlim=c(xmin,xmax),
         ylim=c(ymin,ymax),
        )
    if(which==1){ polygon(e,col=col) }
    else if(which==2){ rect(x-ia,par('usr')[3],x+ia,par('usr')[4],col=col,border=col) }
    else if(which==3){ rect(par('usr')[1],y-ib,par('usr')[2],y+ib,col=col,border=col) }
    lines(e)
    points(x,y,pch=18)
    abline(v=c(x+ia,x-ia),lty=2)
    abline(h=c(y+ib,y-ib),lty=2)
    points(0,0)
    abline(v=0,lty="F848")
    abline(h=0,lty="F848")
  }
  my.confidence.region(g, which=1)
dev.off()

png(file="g577.png", width=600, height=600)
  my.confidence.region(g, which=2)
dev.off()

png(file="g578.png", width=600, height=600)
  my.confidence.region(g, which=3)
dev.off()

png(file="g579.png", width=600, height=600)
  n <- 20000
  x <- runif(n)
  y <- 4 - 8*x + rnorm(n)
  plot(y~x, pch='.')
  abline(lm(y~x), col='red')
  arrows( .1, -6, .1, 6, code=3, lwd=3, col='blue' )
  arrows( .9, -3.2-2, .9, -3.2+2, code=3, lwd=3, col='blue' )
  text( .1, 6, "TSS", adj=c(0,0), cex=2, col='blue' )  
  text( .9, -3.2+2, "RSS", adj=c(1,0), cex=2, col='blue' )  
dev.off()

png(file="g580.png", width=600, height=600)
  n <- 100
  x1 <- rnorm(n)
  x2 <- rnorm(n)
  x3 <- x1^2+rnorm(n)
  x4 <- 1/(1+x2^2)+.2*rnorm(n)
  y <- 1+x1-x2+x3-x4+.1*rnorm(n)
  pairs(cbind(x1,x2,x3,x4,y))  
dev.off()

png(file="g581.png", width=600, height=200)
  r <- lm(y~x1+x2+x3+x4)  
  boxplot(r$res, horizontal=T)
dev.off()

png(file="g582.png", width=600, height=600)
  hist(r$res)
dev.off()

png(file="g583.png", width=600, height=600)
  plot(r$res, main='R�sidus')
dev.off()

png(file="g584.png", width=600, height=600)
  plot(rstandard(r), main='R�sidus standardis�s')
dev.off()

png(file="g585.png", width=600, height=600)
  plot(rstudent(r), main="R�sidus studentis�s")
dev.off()

png(file="g586.png", width=600, height=600)
  plot(r$res ~ r$fitted.values, main="R�sidus et valeurs pr�dites")    
  abline(h=0, lty=3)
dev.off()

png(file="g587.png", width=600, height=600)
  op <- par(mfrow=c(2,2))
  plot(r$res ~ x1)    
  abline(h=0, lty=3)
  plot(r$res ~ x2)    
  abline(h=0, lty=3)
  plot(r$res ~ x3)    
  abline(h=0, lty=3)
  plot(r$res ~ x4)    
  abline(h=0, lty=3)
  par(op)
dev.off()

png(file="g588.png", width=600, height=600)
  n <- 100
  x1 <- rnorm(n)
  x2 <- 1:n
  y <- rnorm(1)
  for (i in 2:n) {
    y <- c(y, y[i-1] + rnorm(1))
  }
  y <- x1 + y
  r <- lm(y~x1+x2) # Ou simplement : lm(y~x1)
  op <- par(mfrow=c(2,1))
  plot( r$res ~ x1 )
  plot( r$res ~ x2 )
  par(op)
dev.off()

png(file="g589.png", width=600, height=600)
  n <- 100
  x <- rnorm(n)
  y <- 1-x+rnorm(n)
  r <- lm(y~x)
  plot(r$res ~ y)    
  abline(h=0, lty=3)
  abline(lm(r$res~y),col='red')
  title(main='Not a good idea...')
dev.off()

png(file="g590.png", width=600, height=600)
  partial.regression.plot <- function (y, x, n, ...) {
    m <- as.matrix(x[,-n])
    y1 <- lm(y ~ m)$res
    x1 <- lm(x[,n] ~ m)$res
    plot( y1 ~ x1, ... )
    abline(lm(y1~x1), col='red')
  }

  n <- 100
  x1 <- rnorm(n)
  x2 <- rnorm(n)
  x3 <- x1+x2+rnorm(n)
  x <- cbind(x1,x2,x3)
  y <- x1+x2+x3+rnorm(n)
  op <- par(mfrow=c(2,2))
  partial.regression.plot(y, x, 1)
  partial.regression.plot(y, x, 2)
  partial.regression.plot(y, x, 3)
  par(op)
dev.off()

png(file="g591.png", width=600, height=600)
  library(car)
  av.plots(lm(y~x1+x2+x3),ask=F)
dev.off()

png(file="g592.png", width=600, height=600)
  my.partial.residual.plot <- function (y, x, i, ...) {
    r <- lm(y~x)
    xi <- x[,i]
    # Y, auquel on a retir� l'effet des X_j
    yi <- r$residuals + r$coefficients[i] * x[,i]
    plot( yi ~ xi, ... )  
  }
  n <- 100
  x1 <- rnorm(n)
  x2 <- rnorm(n)
  x3 <- x1+x2+rnorm(n)
  x <- cbind(x1,x2,x3)
  y <- x1+x2+x3+rnorm(n)
  op <- par(mfrow=c(2,2))
  my.partial.residual.plot(y, x, 1)
  my.partial.residual.plot(y, x, 2)
  my.partial.residual.plot(y, x, 3)
  par(op)
dev.off()

png(file="g593.png", width=600, height=600)
  data(crabs)
  n <- length(crabs$RW)
  r <- lm(FL~RW, data=crabs)
  op <- par(mfrow=c(2,2))
  plot(r)
  par(op)
dev.off()

png(file="g594.png", width=600, height=600)
  data(LifeCycleSavings)
  plot(LifeCycleSavings)
dev.off()

png(file="g595.png", width=600, height=600)
  op <- par(mfrow = c(2, 2), oma = c(0, 0, 2, 0))
  plot(lm.SR <- lm(sr ~ pop15 + pop75 + dpi + ddpi, data = LifeCycleSavings))
  par(op)
dev.off()

png(file="g596.png", width=600, height=600)
  ## 4 plots on 1 page; allow room for printing model formula in outer margin:
  op <- par(mfrow = c(2, 2), oma = c(0, 0, 2, 0))
  #plot(lm.SR)
  #plot(lm.SR, id.n = NULL)               # no id's
  #plot(lm.SR, id.n = 5, labels.id = NULL)# 5 id numbers
  plot(lm.SR, panel = panel.smooth)
  ## Gives a smoother curve
  #plot(lm.SR, panel = function(x,y) panel.smooth(x, y, span = 1))
  par(op)
dev.off()

png(file="g597.png", width=600, height=600)
  n <- 10
  x <- seq(0,1,length=n)
  y <- 1-2*x+.3*rnorm(n)
  plot(spline(x, y, n = 10*n), col = 'red', type='l', lwd=3)
  points(y~x, pch=16, lwd=3, cex=2)
  abline(lm(y~x))
  title(main='Overfit')
dev.off()

png(file="g598.png", width=600, height=600)
  x <- runif(100, -1, 1)
  y <- 1-x+x^2+.3*rnorm(100)
  plot(y~x)
  abline(lm(y~x), col='red')
dev.off()

png(file="g599.png", width=600, height=600)
  plot(y~x)
  lines(smooth.spline(x,y), col='red', lwd=2)
  title(main="Relation non lin�aire mise en �vidence par des splines")
dev.off()

png(file="g600.png", width=600, height=600)
  plot(y~x)
  lines(lowess(x,y), col='red', lwd=2)
  title(main='Relation non lin�aire mise en �vidence par "lowess"')
dev.off()

png(file="g601.png", width=600, height=600)
  plot(y~x)
  xx <- seq(min(x),max(x),length=100)
  yy <- predict( loess(y~x), data.frame(x=xx) )
  lines(xx,yy, col='red', lwd=3)
  title(main='Relation non lin�aire mise en �vidence par "loess"')
dev.off()

png(file="g602.png", width=600, height=600)
  r <- lm(y~x)
  plot(r$residuals ~ r$fitted.values,
        xlab='valeurs pr�dites', ylab='r�sidus',
        main='r�sidus en fonction des valeurs pr�dites')
  lines(lowess(r$fitted.values, r$residuals), col='red', lwd=2)
  abline(h=0, lty=3)
dev.off()

png(file="g603.png", width=600, height=600)
  plot(r$residuals ~ x,
        xlab='x', ylab='r�sidus',
        main='r�sidus en fonction de la variable pr�dictive')
  lines(lowess(x, r$residuals), col='red', lwd=2)
  abline(h=0, lty=3)
dev.off()

png(file="g604.png", width=600, height=600)
  n <- 20
  done.outer <- F
  while (!done.outer) {
    done <- F
    while(!done) {
      x <- rnorm(n)
      done <- max(x)>4.5
    }
    y <- 1 - 2*x + x*rnorm(n)
    r <- lm(y~x)
    done.outer <- max(cooks.distance(r))>5
  }
  plot(y~x)
  abline(1,-2,lty=2)
  abline(lm(y~x),col='red',lwd=3)
  lm(y~x)$coef
dev.off()

png(file="g605.png", width=600, height=200)
  boxplot(x, horizontal=T)
dev.off()

png(file="g606.png", width=600, height=200)
  stripchart(x, method='jitter')
dev.off()

png(file="g607.png", width=600, height=600)
  hist(x, col='light blue', probability=T)
  lines(density(x), col='red', lwd=3)
dev.off()

png(file="g608.png", width=600, height=200)
  boxplot(y, horizontal=T)
dev.off()

png(file="g609.png", width=600, height=200)
  stripchart(y, method='jitter')
dev.off()

png(file="g610.png", width=600, height=600)
  hist(y, col='light blue', probability=T)
  lines(density(y), col='red', lwd=3)
dev.off()

png(file="g611.png", width=600, height=600)
  plot(hat(x), type='h', lwd=5)
dev.off()

png(file="g612.png", width=600, height=600)
  plot(dffits(r),type='h',lwd=3)
dev.off()

png(file="g613.png", width=600, height=600)
  plot(dfbetas(r)[,1],type='h',lwd=3)
dev.off()

png(file="g614.png", width=600, height=600)
  plot(dfbetas(r)[,2],type='h',lwd=3)
dev.off()

png(file="g615.png", width=600, height=600)
  n <- 200
  x1 <- rnorm(n)
  x2 <- rnorm(n)
  yy <- x1 - x2 + rnorm(n)
  yy[1] <- 10
  r <- lm(yy~x1+x2)
  pairs(dfbetas(r))
dev.off()

png(file="g616.png", width=600, height=600)
  cd <- cooks.distance(r)
  plot(cd,type='h',lwd=3)
dev.off()

png(file="g617.png", width=600, height=600)
  n <- 100
  xx <- rnorm(n)
  yy <- 1 - 2 * x + rnorm(n)
  rr <- lm(yy~xx)
  cd <- cooks.distance(rr)
  plot(cd,type='h',lwd=3)
dev.off()

png(file="g618.png", width=600, height=200)
  boxplot(cd, horizontal=T)
dev.off()

png(file="g619.png", width=600, height=200)
  stripchart(cd, method='jitter')
dev.off()

png(file="g620.png", width=600, height=600)
  hist(cd, probability=T, breaks=20, col='light blue')
dev.off()

png(file="g621.png", width=600, height=600)
  plot(density(cd), type='l', col='red', lwd=3)
dev.off()

png(file="g622.png", width=600, height=600)
  qqnorm(cd)
  qqline(cd, col='red')
dev.off()

png(file="g623.png", width=600, height=600)
  half.qqnorm <- function (x) {
    n <- length(x)
    qqplot(qnorm((1+ppoints(n))/2), x)
  }
  half.qqnorm(cd)
dev.off()

png(file="g624.png", width=600, height=600)
  m <- max(cooks.distance(r))
  plot(y~x, cex=1+5*cooks.distance(r)/m)
dev.off()

png(file="g625.png", width=600, height=600)
  cd <- cooks.distance(r)
  # rescaled Cook's distance
  rcd <- (99/4) * cd*(cd+1)^2
  rcd[rcd>100] <- 100
  plot(r$res~r$fitted.values, cex=1+.05*rcd)
  abline(h=0,lty=3)
dev.off()

png(file="g626.png", width=600, height=600)
  m <- max(cd)
  plot(r$res, 
       cex=1+5*cd/m,
       col=heat.colors(100)[ceiling(70*cd/m)],
       pch=16,
      )
  points(r$res, cex=1+5*cd/m)
  abline(h=0,lty=3)
dev.off()

png(file="g627.png", width=600, height=600)
  plot(r$res, 
       cex=1+.05*rcd,
       col=heat.colors(100)[ceiling(rcd)],
       pch=16,
      )
  points(r$res, cex=1+.05*rcd)
  abline(h=0,lty=3)
dev.off()

png(file="g628.png", width=600, height=600)
  n <- 100
  x <- rnorm(n)
  y <- 1 - 2*x + rnorm(n)
  r <- lm(y~x)
  cd <- cooks.distance(r)
  m <- max(cd)
  plot(r$res ~ r$fitted.values,
       cex=1+5*cd/m,
       col=heat.colors(100)[ceiling(70*cd/m)],
       pch=16,
      )
  points(r$res ~ r$fitted.values, cex=1+5*cd/m)
  abline(h=0,lty=3)
dev.off()

png(file="g629.png", width=600, height=600)
  op <- par(fg='white', bg='black', 
            col='white', col.axis='white', 
            col.lab='white', col.main='white', 
            col.sub='white')
  plot(r$res ~ r$fitted.values,
       cex=1+5*cd/m,
       col=heat.colors(100)[ceiling(100*cd/m)],
       pch=16,
      )
  abline(h=0,lty=3)
  par(op)
dev.off()

png(file="g630.png", width=600, height=600)
  # Avec la distance de Cook
  x <- rnorm(20)
  y <- 1 + x + rnorm(20)
  x <- c(x,10)
  y <- c(y,1)
  r <- lm(y~x)
  d <- cooks.distance(r)
  d <- (99/4)*d*(d+1)^2 + 1
  d[d>100] <- 100
  d[d<20] <- 20
  d <- d/20
  plot( y~x, cex=d )
  abline(r)
  abline(coef(line(x,y)), col='red')
  abline(lm(y[1:20]~x[1:20]),col='blue')
dev.off()

png(file="g631.png", width=600, height=600)
  n <- 200
  s <- .2
  x <- runif(n)
  y1 <- 1 - 2 * x + s*rnorm(n)
  y2 <- 2 * x - 1 + s*rnorm(n)
  y <- ifelse( sample(c(T,F),n,replace=T,prob=c(.25,.75)), y1, y2 )
  plot(y~x)
  abline(1,-2,lty=3)
  abline(-1,2,lty=3)
dev.off()

png(file="g632.png", width=600, height=200)
  x <- runif(100)
  y <- 1 - 2*x + .3*exp(rnorm(100)-1)
  r <- lm(y~x)
  boxplot(r$residuals, horizontal=T)
dev.off()

png(file="g633.png", width=600, height=600)
  hist(r$residuals, breaks=20, probability=T, col='light blue')
  lines(density(r$residuals), col='red', lwd=3)
  f <- function(x) {
    dnorm(x,
          mean=mean(r$residuals),
          sd=sd(r$residuals),
    )
  }
  curve(f, add=T, col="red", lwd=3, lty=2)
dev.off()

png(file="g634.png", width=600, height=600)
  qqnorm(r$residuals)
  qqline(r$residuals, col='red')
dev.off()

png(file="g635.png", width=600, height=600)
  rcauchy.with.hole <- function (n) { 
    x <- rcauchy(n)
    x[x>0] <- 10+x[x>0]
    x[x<0] <- -10+x[x<0]
    x
  }
  n <- 20
  x <- rcauchy(n)
  y <- 1 - 2*x + .5*rcauchy.with.hole(n)
  plot(y~x)
  abline(1,-2)
  r <- lm(y~x)
  abline(r, col='red')
dev.off()

png(file="g636.png", width=600, height=600)
  op <- par(mfrow=c(2,2))
  hist(r$residuals, breaks=20, probability=T, col='light blue')
  lines(density(r$residuals), col='red', lwd=3)
  f <- function(x) {
    dnorm(x,
          mean=mean(r$residuals),
          sd=sd(r$residuals),
    )
  }
  curve(f, add=T, col="red", lwd=3, lty=2)
  qqnorm(r$residuals)
  qqline(r$residuals, col='red')
  plot(r$residuals ~ r$fitted.values)
  plot(r$residuals ~ x)
  par(op)
dev.off()

png(file="g637.png", width=600, height=600)
  done <- F
  while(!done) {
    # On choisit une situation o� l'intervalle de pr�diction n'est pas trop grand,
    # de sorte qu'il soit sur le dessin
    n <- 5
    x <- rcauchy(n)
    y <- 1 - 2*x + .5*rcauchy.with.hole(n)
    r <- lm(y~x)
    n <- 100000
    xp <- sort(runif(n,-50,50))
    yp <- predict(r, data.frame(x=xp), interval="prediction")
    done <- ( yp[round(n/2),2] > -75 & yp[round(n/2),3] < 75 )
  }
  yr <- 1 - 2*xp + .5*rcauchy.with.hole(n)
  plot(yp[,1]~xp, type='l',
       xlim=c(-50,50), ylim=c(-100,100))
  points(yr~xp, pch='.')
  lines(xp, yp[,2], col='blue')  
  lines(xp, yp[,3], col='blue')
  abline(r, col='red')
  points(y~x, col='orange', pch=16, cex=1.5)
  points(y~x, cex=1.5)
dev.off()

png(file="g638.png", width=600, height=600)
  done <- F
  while(!done) {
    # On choisit une situation encore pire, dans laquelle le signe du
    # coefficient directeur de la droite de r�gression n'est pas le bon
    n <- 5
    x <- rcauchy(n)
    y <- 1 - 2*x + .5*rcauchy.with.hole(n)
    r <- lm(y~x)
    n <- 100000
    xp <- sort(runif(n,-50,50))
    yp <- predict(r, data.frame(x=xp), interval="prediction")
    print(r$coef[2])
    done <- ( yp[round(n/2),2] > -75 & yp[round(n/2),3] < 75 & r$coef[2]>0)
  }
  yr <- 1 - 2*xp + .5*rcauchy.with.hole(n)
  plot(yp[,1]~xp, type='l',
       xlim=c(-50,50), ylim=c(-100,100))
  points(yr~xp, pch='.')
  lines(xp, yp[,2], col='blue')  
  lines(xp, yp[,3], col='blue')
  abline(r, col='red')
  points(y~x, col='orange', pch=16, cex=1.5)
  points(y~x, cex=1.5)
dev.off()

png(file="g639.png", width=600, height=600)
  done <- F
  while (!done) {
    n <- 5
    x <- rcauchy(n)
    y <- 1 - 2*x + .5*rcauchy.with.hole(n)
    r <- lm(y~x)
    done <- T
  }
  n <- 10000
  xp <- sort(runif(n,-2,2))
  yp <- predict(r, data.frame(x=xp), interval="prediction")
  yr <- 1 - 2*xp + .5*rcauchy.with.hole(n)
  plot(c(xp,x), c(yp[,1],y), pch='.',
       xlim=c(-2,2), ylim=c(-50,50) )
  lines(yp[,1]~xp)
  abline(r, col='red')
  lines(xp, yp[,2], col='blue')  
  lines(xp, yp[,3], col='blue')
  points(yr~xp, pch='.')
  points(y~x, col='orange', pch=16)
  points(y~x)
dev.off()

png(file="g640.png", width=600, height=600)
  done <- F
  essais <- 0
  while (!done) {
    n <- 5
    x <- rcauchy(n)
    y <- 1 - 2*x + .5*rcauchy.with.hole(n)
    r <- lm(y~x)
    yp <- predict(r, data.frame(x=2), interval='prediction')
    done <- yp[3]<0
    essais <- essais+1
  }
  print(essais) # Autour de 20 ou 30
  n <- 10000
  xp <- sort(runif(n,-2,2))
  yp <- predict(r, data.frame(x=xp), interval="prediction")
  yr <- 1 - 2*xp + .5*rcauchy.with.hole(n)
  plot(c(xp,x), c(yp[,1],y), pch='.',
       xlim=c(-2,2), ylim=c(-50,50) )
  lines(yp[,1]~xp)
  points(yr~xp, pch='.')
  abline(r, col='red')
  lines(xp, yp[,2], col='blue')  
  lines(xp, yp[,3], col='blue')
  points(y~x, col='orange', pch=16)
  points(y~x)
dev.off()

png(file="g641.png", width=600, height=600)
  done <- F
  e <- NULL
  for (i in 1:100) {
    essais <- 0
    done <- F
    while (!done) {
      n <- 5
      x <- rcauchy(n)
      y <- 1 - 2*x + .5*rcauchy.with.hole(n)
      r <- lm(y~x)
      yp <- predict(r, data.frame(x=2), interval='prediction')
      done <- yp[3]<0
      essais <- essais+1
    }
    e <- append(e,essais)
  }
  hist(e, probability=T, col='light blue')
  lines(density(e), col='red', lwd=3)
  abline(v=median(e), lty=2, col='red', lwd=3)
dev.off()

png(file="g642.png", width=600, height=600)
  x <- runif(100)
  y <- 1 - 2*x + .3*x*rnorm(100)
  plot(y~x)
  r <- lm(y~x)
  abline(r, col='red')
  title(main="H�t�rosc�dasticit�")
dev.off()

png(file="g643.png", width=600, height=600)
  plot(r$residuals ~ r$fitted.values)
dev.off()

png(file="g644.png", width=600, height=600)
  plot(abs(r$residuals) ~ r$fitted.values)
  lines(lowess(r$fitted.values, abs(r$residuals)), col='red')
dev.off()

png(file="g645.png", width=600, height=600)
  plot(abs(r$residuals) ~ x)
  lines(lowess(x, abs(r$residuals)), col='red')
dev.off()

png(file="g646.png", width=600, height=600)
  data(crabs)
  plot(FL~RW, data=crabs)
dev.off()

png(file="g647.png", width=600, height=600)
  r <- lm(FL~RW, data=crabs)
  plot(r, which=1)
dev.off()

png(file="g648.png", width=600, height=600)
  plot(r, which=3, panel = panel.smooth)
dev.off()

png(file="g649.png", width=600, height=600)
  library(car)
  spread.level.plot(r)
dev.off()

png(file="g650.png", width=600, height=600)
  x <- runif(100)
  y <- 1 - 2*x + .3*x*rnorm(100)
  r <- lm(y~x)
  n <- 10000
  xp <- sort(runif(n,))
  yp <- predict(r, data.frame(x=xp), interval="prediction")
  yr <- 1 - 2*xp + .3*xp*rnorm(n)

  plot(c(xp,x), c(yp[,1],y), pch='.')
  lines(yp[,1]~xp)
  abline(r, col='red')
  lines(xp, yp[,2], col='blue')  
  lines(xp, yp[,3], col='blue')
  points(yr~xp, pch='.')
  points(y~x, col='orange', pch=16)
  points(y~x)
  title(main="Effet de l'h�t�rosc�dasticit� sur les intervalles de pr�diction")
dev.off()

png(file="g651.png", width=600, height=600)
  n <- 100
  x <- runif(n)
  y <- 1 - 2*x + x*rnorm(n)
  plot(y~x)
  r <- lm(y~x)
  abline(r, col='red')
  title(main="R�gression lin�aire classique")
dev.off()

png(file="g652.png", width=600, height=600)
  plot(abs(r$res) ~ x)
  r2 <- lm( abs(r$res) ~ x )
  abline(r2, col="red")
  title(main="H�t�rosc�dasticit� des r�sidus")
dev.off()

png(file="g653.png", width=600, height=600)
  # On fait l'hypoth�se que l'�cart-type des r�sidus
  # est de la forme a*x
  a <- lm( I(r$res^2) ~ I(x^2) - 1 )$coefficients
  w <- (a*x)^-2
  r3 <- lm( y ~ x, weights=w )
  plot(y~x)
  abline(1,-2, lty=3)
  abline(lm(y~x), lty=3, lwd=3)
  abline(lm(y~x, weights=w), col='red') 
  legend( par("usr")[1], par("usr")[3], yjust=0,
          c("mod�le r�el", "moindres carr�s", "moindres carr�s pond�r�s"),
          lwd=c(1,3,1),
          lty=c(3,3,1),
          col=c(par("fg"), par("fg"), 'red') )
  title("Moindres carr�s pond�r�s et h�t�rosc�dasticit�")
dev.off()

png(file="g654.png", width=600, height=600)
  # Les intervalles de pr�diction
  N <- 10000
  xx <- runif(N,min=0,max=2)
  yy <- 1 - 2*xx + xx*rnorm(N)
  plot(y~x, xlim=c(0,2), ylim=c(-3,2))
  points(yy~xx, pch='.')
  abline(1,-2, col='red')
  xp <- seq(0,3,length=100)
  yp1 <- predict(r, new=data.frame(x=xp), interval='prediction')
  lines( xp, yp1[,2], col='red', lwd=3 )
  lines( xp, yp1[,3], col='red', lwd=3 )
  yp3 <- predict(r3, new=data.frame(x=xp), interval='prediction')
  lines( xp, yp3[,2], col='blue', lwd=3 )
  lines( xp, yp3[,3], col='blue', lwd=3 )
  legend( par("usr")[1], par("usr")[3], yjust=0,
          c("moindres carr�s", "moindres carr�s pond�r�s"),
          lwd=3, lty=1,
          col=c('red', 'blue') )
  title(main="Bande de pr�diction")
dev.off()

png(file="g655.png", width=600, height=600)
  my.acf.plot <- function (x, n=10, ...) {
    y <- rep(NA,n)
    l <- length(x)
    for (i in 1:n) {
      y[i] <- cor( x[1:(l-i)], x[(i+1):l] )
    }
    plot(y, type='h', ylim=c(-1,1),...)
  }
  n <- 100
  x <- runif(n)
  b <- .1*rnorm(n+1)
  y <- 1-2*x+b[1:n]
  my.acf.plot(lm(y~x)$res, lwd=10)
  abline(h=0, lty=2)
dev.off()

png(file="g656.png", width=600, height=600)
  z <- 1-2*x+.5*(b[1:n]+b[1+1:n])
  my.acf.plot(lm(z~x)$res, lwd=10)
  abline(h=0, lty=2)
dev.off()

png(file="g657.png", width=600, height=600)
  n <- 500
  x <- runif(n)
  b <- rep(NA,n)
  b[1] <- 0
  for (i in 2:n) {
    b[i] <- b[i-1] + .1*rnorm(1)
  }
  y <- 1-2*x+b[1:n]
  my.acf.plot(lm(y~x)$res, n=100)
  abline(h=0, lty=2)
  title(main='Exemple hautement autocorr�l�')
dev.off()

png(file="g658.png", width=600, height=600)
  r <- lm(y~x)
  plot(r$res ~ r$fitted.values)
  title(main="R�sidus de l'exemple hautement autocorr�l�")
dev.off()

png(file="g659.png", width=600, height=600)
  r <- lm(y~x)
  plot(r$res)
  title(main="R�sidus de l'exemple hautement autocorr�l�")
dev.off()

png(file="g660.png", width=600, height=600)
  n <- 500
  x <- runif(n)
  b <- rep(NA,n)
  b[1] <- 0
  for (i in 2:n) {
    b[i] <- b[i-1] + .1*rnorm(1)
  }
  y <- 1-2*x+b[1:n]
  r <- lm(y~x)$res
  plot( r[1:(n-1)], r[2:n],
        xlab='i-i�me r�sidu', 
        ylab='(i+1)-i�me r�sidu' )
dev.off()

png(file="g661.png", width=600, height=600)
  n <- 500
  x <- runif(n)
  b <- rep(NA,n)
  b[1] <- 0
  b[2] <- 0
  for (i in 3:n) {
    b[i] <- b[i-2] + .1*rnorm(1)
  }
  y <- 1-2*x+b[1:n]
  r <- lm(y~x)$res
  plot(data.frame(x=r[3:n-2], y=r[3:n-1], z=r[3:n]))
dev.off()

png(file="g662.png", width=600, height=600)
  plot(r)
dev.off()

png(file="g663.png", width=600, height=600)
  data(randu)
  plot(randu)
  # On ne voit rien...
dev.off()

png(file="g664.png", width=600, height=600)
  m <- matrix( c(0.0491788982891203, -0.998585856299176, 0.0201921658647648,  
                 0.983046639705112,  0.0448184901961194, -0.177793720645666, 
                 -0.176637312387723,  -0.028593540105802, -0.983860594462783),
               nr=3, nc=3)
  plot( t( m %*% t(randu) )[,1:2] )
dev.off()

png(file="g665.png", width=600, height=600)
  data(EuStockMarkets)
  plot(EuStockMarkets)
dev.off()

png(file="g666.png", width=600, height=600)
  x <- EuStockMarkets[,1]
  y <- EuStockMarkets[,2]
  r <- lm(y~x)
  plot(y~x)
  abline(r, col='red', lwd=3)
dev.off()

png(file="g667.png", width=600, height=600)
  plot(r, which=1)
dev.off()

png(file="g668.png", width=600, height=600)
  plot(r, which=3)
dev.off()

png(file="g669.png", width=600, height=600)
  plot(r, which=4)
dev.off()

png(file="g670.png", width=600, height=600)
  r <- r$res
  hist(r, probability=T, col='light blue')
  lines(density(r), col='red', lwd=3)
dev.off()

png(file="g671.png", width=600, height=600)
  plot(r)
dev.off()

png(file="g672.png", width=600, height=600)
  acf(r)
dev.off()

png(file="g673.png", width=600, height=600)
  pacf(r)
dev.off()

png(file="g674.png", width=600, height=600)
  r <- as.vector(r)
  x <- r[1:(length(r)-1)]
  y <- r[2:length(r)]
  plot(x,y, xlab='x[i]', ylab='x[i+1]')
dev.off()

png(file="g675.png", width=600, height=600)
  n <- 100
  x <- rnorm(n)
  e <- vector()
  e <- append(e, rnorm(1))
  for (i in 2:n) {
    e <- append(e, .6 * e[i-1] + rnorm(1) )
  }
  y <- 1 - 2*x + e
  i <- 1:n
  plot(y~x)
dev.off()

png(file="g676.png", width=600, height=600)
  r <- lm(y~x)$residuals
  plot(r)
dev.off()

png(file="g677.png", width=600, height=600)
  library(nlme)
  plot(y~x)
  abline(lm(y~x))
  abline(gls(y~x, correlation = corAR1(form= ~i)), col='red')
dev.off()

png(file="g678.png", width=600, height=600)
  n <- 1000
  x <- rnorm(n)
  e <- vector()
  e <- append(e, rnorm(1))
  for (i in 2:n) {
    e <- append(e, 1 * e[i-1] + rnorm(1) )
  }
  y <- 1 - 2*x + e
  i <- 1:n
  plot(lm(y~x)$residuals)
dev.off()

png(file="g679.png", width=600, height=600)
  plot(y~x)
  abline(lm(y~x))
  abline(gls(y~x, correlation = corAR1(form= ~i)), col='red')
  abline(1,-2, lty=2)
dev.off()

png(file="g680.png", width=600, height=600)
  check.multicolinearity <- function (M) {
    a <- NULL
    n <- dim(M)[2]
    for (i in 1:n) {
      m <- as.matrix(M[, 1:n!=i])
      y <- M[,i]
      a <- append(a, summary(lm(y~m))$adj.r.squared)
    }
    names(a) <- names(M)
    print(round(a,digits=2))
    invisible(a)
  }
  data(freeny)
  names(freeny) <- paste(
    names(freeny), 
    " (",
    round(check.multicolinearity(freeny), digits=2),
    ")",
    sep='')
  pairs(freeny,
    upper.panel=panel.smooth,
    lower.panel=panel.smooth)
dev.off()

png(file="g681.png", width=600, height=600)
  n <- 100
  v <- .1
  x <- rnorm(n)
  x1 <- x + v*rnorm(n)
  x2 <- rnorm(n)
  x3 <- x + v*rnorm(n)
  y <- x1+x2-x3 + rnorm(n)
  m <- summary(lm(y~x1+x2+x3), correlation=T)$correlation
  plot(col(m), row(m), cex=10*abs(m),
       xlim=c(0, dim(m)[2]+1), 
       ylim=c(0, dim(m)[1]+1),
       main="Matrice de corr�lation des coefficients d'une r�gression")
dev.off()

png(file="g682.png", width=600, height=600)
  n <- 100
  x <- runif(n)
  z <- ifelse(x>.5,1,0)
  y <- 2*z -x + .1*rnorm(n)
  plot( y~x, col=c('red','blue')[1+z] )
dev.off()

png(file="g683.png", width=600, height=600)
  n <- 20
  x <- rnorm(n)
  y <- 1 - 2*x - .1*x^2 + rnorm(n)
  #summary(lm(y~poly(x,10)))
  plot(y~x, xlim=c(-20,20), ylim=c(-30,30))
  r <- lm(y~x)
  abline(r, col='red')
  xx <- seq(-20,20,length=100)
  p <- predict(r, data.frame(x=xx), interval='prediction')
  lines(xx,p[,2],col='blue')
  lines(xx,p[,3],col='blue')
  title(main="Augmentation de l'intervalle de pr�diction")
dev.off()

png(file="g684.png", width=600, height=600)
  plot(y~x, xlim=c(-20,20), ylim=c(-30,30))
  r <- lm(y~x)
  abline(r, col='red')
  xx <- seq(-20,20,length=100)
  yy <- 1 - 2*xx - .1*xx^2 + rnorm(n)
  p <- predict(r, data.frame(x=xx), interval='prediction')
  points(yy~xx)
  lines(xx,p[,2],col='blue')
  lines(xx,p[,3],col='blue')
  title(main="Probl�me d'extropolation : �a n'�tait pas lin�aire...")
dev.off()

png(file="g685.png", width=600, height=600)
  data(cars)
  y <- cars$dist
  x <- cars$speed
  o <- x<quantile(x,.25)
  x1 <- x[o]
  y1 <- y[o]
  r <- lm(y1~x1)
  xx <- seq(min(x),max(x),length=100)
  p <- predict(r, data.frame(x1=xx), interval='prediction')
  plot(y~x)
  abline(r, col='red')
  lines(xx,p[,2],col='blue')
  lines(xx,p[,3],col='blue')
dev.off()

png(file="g686.png", width=600, height=600)
  n <- 100
  e <- .5
  x0 <- rnorm(n)
  x <- x0 + e*rnorm(n)
  y <- 1 - 2*x0 + e*rnorm(n)
  plot(y~x)
  points(y~x0, col='red')
  abline(lm(y~x))
  abline(lm(y~x0),col='red')
dev.off()

png(file="g687.png", width=600, height=600)
  n <- 100
  x <- abs(rnorm(n)) ^ runif(1,min=0,max=2)
  kk <- seq(.01,5,by=.01)
  N <- length(kk)
  pv <- rep(NA, N)
  for (i in 1:N) {
    pv[i] <- shapiro.test( x^kk[i] )$p.value
  }
  plot( pv ~ kk, type='l', xlab='exposant', ylab='p-valeur' )
  seuil <- .05
  abline( v = kk[ range( (1:N)[pv>seuil] ) ], lty=3 )  
  abline( v = kk[pv==max(pv)], lty=3 )
  abline( h = seuil, lty=3 )
  title(main="Test de Shapiro")
dev.off()

png(file="g688.png", width=600, height=600)
  x <- exp( rnorm(100) )
  y <- 1 + 2*x + .3*rnorm(100)
  y <- y^1.3
  library(MASS)
  boxcox(y~x, plotit=T)
dev.off()

png(file="g689.png", width=600, height=600)
  bc <- boxcox(y ~ x, plotit=F)
  a <- bc$x[ order(bc$y, decreasing=T)[1] ]
  op <- par( mfcol=c(1,2) )
  plot( y~x )
  plot( y^a ~ x )
  par(op)
dev.off()

png(file="g690.png", width=600, height=600)
  data(trees)
  plot(trees)
dev.off()

png(file="g691.png", width=600, height=600)
  boxcox(Volume ~ Girth, data = trees)
dev.off()

png(file="g692.png", width=600, height=600)
  boxcox(Volume ~ log(Height) + log(Girth), data = trees )
dev.off()

png(file="g693.png", width=600, height=600)
  n <- 100
  v <- .1
  x1 <- rlnorm(n)
  x2 <- rlnorm(n)
  x3 <- rlnorm(n)
  x4 <- x1 + x2 + x3 + v*rlnorm(n)
  m1 <- cbind(x1,x2,x3,x4)
  pairs(m1, main="Aucune valeur manquante")
dev.off()

png(file="g694.png", width=600, height=600)
  remove.higher.values <- function (x) {
    n <- length(x)
    ifelse( rbinom(n,1,(x-min(x))/(max(x)+1))==1 , NA, x)
  }
  x1 <- remove.higher.values(x1)
  x2 <- remove.higher.values(x2)
  x3 <- remove.higher.values(x3)
  x4 <- remove.higher.values(x4)
  m2 <- cbind(x1,x2,x3,x4)
  pairs(m2, main="Quelques valeurs manquantes")
dev.off()

png(file="g695.png", width=600, height=600)
  op <- par(mfrow=c(2,2))
  r <- naclus(data.frame(m2))
  naplot(r)
  par(op)
dev.off()

png(file="g696.png", width=600, height=600)
  op <- par(mfrow=c(2,2))
  for(m in c("ward","complete","median")) {
    plot(naclus(data.frame(m2), method=m))
    title(m)
  }
  plot(naclus(data.frame(m2)))
  title("Default")
  par(op)
dev.off()

png(file="g697.png", width=600, height=600)
  library(Hmisc)
  op <- par(mfrow=c(2,2))
  w <- transcan(~x1+x2+x3+x4, imputed=T, transformed=T, trantab=T, impcat='tree',
                data=data.frame(x1,x2,x3,x4), pl=TRUE)
  par(op)
dev.off()

png(file="g698.png", width=600, height=600)
  library(acepack)
  TWOPI <- 8*atan(1)
  x <- runif(200,0,TWOPI)
  y <- exp(sin(x)+rnorm(200)/2)
  a <- ace(x,y)
  op <- par(mfrow=c(3,1))
  plot(a$y,a$ty)  # view the response transformation
  plot(a$x,a$tx)  # view the carrier transformation
  plot(a$tx,a$ty) # examine the linearity of the fitted model
  par(op)
dev.off()

png(file="g699.png", width=600, height=600)
  library(acepack)
  TWOPI <- 8*atan(1)
  x <- runif(200,0,TWOPI)
  y <- exp(sin(x)+rnorm(200)/2)
  a <- avas(x,y)
  op <- par(mfrow=c(3,1))
  plot(a$y,a$ty)  # view the response transformation
  plot(a$x,a$tx)  # view the carrier transformation
  plot(a$tx,a$ty) # examine the linearity of the fitted model
  par(op)
dev.off()

png(file="g700.png", width=600, height=600)
  pi.monte.carlo.plot <- function (n=10000, pch='.', ...) {
    x <- runif(n)
    y <- runif(n)
    interieur <- x^2 + y^2 <= 1
    p <- 4*sum(interieur)/n
    xc <- seq(0,1,length=200)
    yc <- sqrt(1-xc^2)
    plot( xc, yc, type='l' )
    lines( c(0,1,1,0,0), c(0,0,1,1,0) )
    abline(h=0, lty=3)
    abline(v=0, lty=3)
    points(x[interieur], y[interieur], col='red', pch=pch, ...)
    points(x[!interieur], y[!interieur], pch=pch, ...)
    title(main=paste("Simulation de Mont� Carlo : pi=",p,sep=''))
  }
  pi.monte.carlo.plot(100, pch='+', cex=3)
dev.off()

png(file="g701.png", width=600, height=600)
  pi.monte.carlo.plot()
dev.off()

png(file="g702.png", width=600, height=600)
  n <- 10
  N <- 1000
  r <- matrix(NA, nr=N, nc=6)
  for (i in 1:N) {
    x <- ifelse( runif(n)>1/6, rnorm(n,1,2), rnorm(n,-1,1) )
    r[i,] <- c( mean(x), quantile(x) )
  }
  colnames(r) <- c("mean", "0% (min)", "25%", "50% (median)", "75%", "100% (max)")
  rr <- apply(r,2,density)
  # R�cup�rer les valeurs min et max de x et y...
  xlim <- range( sapply(rr,function(a){range(a$x)}) )
  ylim <- range( sapply(rr,function(a){range(a$y)}) )
  plot(NA, xlim=xlim, ylim=ylim, ylab='density')
  for (i in 1:6) {
    lines(rr[[i]], col=i)
  }
  legend(par('usr')[2], par('usr')[4], xjust=1, yjust=1,
         c('moyenne', "min", "1er quartile", "m�diane", "3e quartile", "max"),
         lwd=1, lty=1,
         col=1:6 )
dev.off()

png(file="g703.png", width=600, height=600)
  op <- par(mfrow=c(2,3))
  for (i in 1:6) {
    qqnorm(r[,i], main=colnames(r)[i])
    qqline(r[,i], col='red')
    text( par("usr")[1], par("usr")[4], adj=c(-.2,2),
          round(shapiro.test(r[,i])$p.value, digits=4) )
  }
  par(op)
dev.off()

png(file="g704.png", width=600, height=600)
  my.simulation <- function (get.sample, statistic, R) {
    res <- statistic(get.sample())
    r <- matrix(NA, nr=R, nc=length(res))
    r[1,] <- res
    for (i in 2:R) {
      r[i,] <- statistic(get.sample())
    }
    list(t=r, t0=apply(r,2,mean))
  }

  r <- my.simulation(
    function () { 
      n <- 200
      x1 <- rnorm(n)
      x2 <- rnorm(n)
      y <-  1 - x1 + 2 * x2 + rnorm(n)
     data.frame(y,x1,x2)
    },
    function (d) {
      lm(y~x1+x2, data=d)$coef
    },
    R=999
  )

  matdensityplot <- function (r, ylab='density', ...) {
    rr <- apply(r,2,density)
    n <- length(rr)
    # R�cup�rer les valeurs min et max de x et y...
    xlim <- range( sapply(rr,function(a){range(a$x)}) )
    ylim <- range( sapply(rr,function(a){range(a$y)}) )
    plot(NA, xlim=xlim, ylim=ylim, ylab=ylab, ...)
    for (i in 1:n) {
      lines(rr[[i]], col=i)
    }
  }

  matdensityplot(r$t)
dev.off()

png(file="g705.png", width=600, height=600)
  q <- runif(1,0,10)
  m1 <- runif(1,0,10)
  m2 <- q*m1
  r <- my.simulation(
    function () { 
      n1 <- 200
      n2 <- 100
      x1 <- m1*rlnorm(n1)
      x2 <- m2*rlnorm(n2)
      data.frame( x=c(x1,x2), c=factor(c(rep(1,n1),rep(2,n2))))
    },
    function (d) { 
      a <- tapply(d[,1],d[,2],mean) 
      a[2]/a[1]
    }, 
    R=999
  )
  hist(r$t, probability=T, col='light blue',
       main="Distribution du quotient de deux moyennes")
  lines(density(r$t), col='red', lwd=3)
  abline(v=c(q,r$t0), lty=3, lwd=3, col=c('blue','red'))
  legend( par("usr")[2], par("usr")[4], xjust=1, yjust=1,
          c("Moyenne th�orique", "Moyenne exp�rimentale"),
          lwd=1, lty=3, col=c('blue','red') )
dev.off()

png(file="g706.png", width=600, height=600)
  # Intervalle de confiance � 5% de l'exemple pr�c�dent
  hist(r$t, probability=T, col='light blue',
       main="Distribution du quotient de deux moyennes")
  qt <- quantile(r$t, c(.025,.975))
  d <- density(r$t)
  o <- d$x>qt[1] & d$x<qt[2]
  lines(d$x[o], d$y[o], col='red', lwd=3)
  lines(d, col='red')
  abline(v=c(q,r$t0), lty=3, lwd=3, col=c('blue','red'))
  legend( par("usr")[2], par("usr")[4], xjust=1, yjust=1,
          c("Moyenne th�orique", "Moyenne exp�rimentale",
            "Intervalle de confiance � 5%"),
          lwd=c(1,1,3), lty=c(3,3,1), col=c('blue','red', 'red') )
dev.off()

png(file="g707.png", width=600, height=600)
  # On a deux �chantillons, de tailles diff�rentes, et on cherche le
  # quotient de leurs moyennes
  n1 <- 200
  n2 <- 100
  q <- runif(1,0,10)
  m1 <- runif(1,0,10)
  m2 <- q*m1
  x1 <- m1*rlnorm(n1)
  x2 <- m2*rlnorm(n2)
  d <- data.frame( x=c(x1,x2), c=factor(c(rep(1,n1),rep(2,n2))))
  R <- 999
  r <- boot(d, 
            function (d,i) { 
              a <- tapply(d[,1][i],d[,2][i],mean) 
              a[2]/a[1]
            }, 
            R=R)
  hist(r$t, probability=T, col='light blue',
       main="Distribution du quotient de deux moyennes")
  qt <- quantile(r$t, c(.025,.975))
  d <- density(r$t)
  o <- d$x>qt[1] & d$x<qt[2]
  lines(d$x[o], d$y[o], col='red', lwd=3)
  lines(d, col='red')
  abline(v=c(q,r$t0), lty=3, lwd=3, col=c('blue','red'))
  legend( par("usr")[2], par("usr")[4], xjust=1, yjust=1,
          c("Moyenne th�orique", "Moyenne exp�rimentale",
            "Intervalle de confiance � 5%"),
          lwd=c(1,1,3), lty=c(3,3,1), col=c('blue','red', 'red') )
dev.off()

png(file="g708.png", width=600, height=600)
  # Les variables � pr�dire sont les premi�res du data.frame
  my.simulation.predict <- function (
    get.training.sample,
    get.test.sample=get.training.sample,
    get.model,
    get.predictions=predict,
    R=999) {
    r <- matrix(NA, nr=R, nc=3)
    colnames(r) <- c("biais", "variance", "erreur quadratique")
    for (i in 1:R) {
      d.train <- get.training.sample()
      d.test <-  get.test.sample()
      m <- get.model(d.train)
      p <- get.predictions(m, d.test)
      if(is.vector(p)){ p <- data.frame(p) }
      d.test <- d.test[,1:(dim(p)[2])]
      b <- apply(d.test-p, 2, mean)
      v <- apply(d.test-p, 2, var)
      e <- apply((d.test-p)^2, 2, mean)
      r[i,] <- c(b,v,e)
    }
    list(t=r, t0=apply(r,2,mean))
  }

  get.sample <- function () {
    n <- 200
    x1 <- rnorm(n)
    x2 <- rnorm(n)
    y <- sin(x1) + cos(x2) - x1*x2 + rnorm(n)
    data.frame(y,x1,x2)
  }
  r <- my.simulation.predict(
    get.sample,
    get.model = function (d) {
      lm(y~x1+x2,data=d)
    }
  )
  hist(r$t[,1], probability=T, col='light blue', 
       main="Biais d'une r�gression lin�aire")
  lines(density(r$t), col='red', lwd=3)
  abline(v=r$t0[1], lty=3)
dev.off()

png(file="g709.png", width=600, height=600)
  library(MASS)
  get.sample <- function () {
    n <- 20
    x <- rnorm(n)
    x1 <- x + .2*rnorm(n)
    x2 <- x + .2*rnorm(n)
    x3 <- x + .2*rnorm(n)
    x4 <- x + .2*rnorm(n)
    y <- x + (x1+x2+x3+x4)/4 + rnorm(n)
    data.frame(y,x1,x2,x3,x4)
  }
  get.model <- function (d) {
    r <- lm.ridge(y~., data=d)
  }
  get.predictions <- function (r,d) {
    m <- t(as.matrix(r$coef/r$scales))
    inter <- r$ym - m %*% r$xm
    drop(inter) + as.matrix(d[,-1]) %*% drop(m)
  }

  lambda <- c(0,.001,.002,.005,.01,.02,.05,.1,.2,.5,1,2,5,10,20,50,100)
  n <- length(lambda)
  res <- rep(NA,n)
  for (i in 1:n) {  
    res[i] <- my.simulation.predict(
      get.sample,
      get.model = function (d) {
        lm.ridge(y~., data=d, lambda=lambda[i])
      },
      get.predictions = get.predictions,
      R=99
    )$t0[3]
  }
  plot(res~lambda, type='l', log='x')
  abline(h=res[1], lty=3)
  i <- (1:n)[ res == min(res) ]
  x <- lambda[i]
  y <- res[i]
  points(x,y,col='red',pch=15)
  title(main="D�termination du param�tre d'une ridge regression par boostrap")
dev.off()

png(file="g710.png", width=600, height=600)
  library(MASS)
  get.sample <- function () {
    n <- 20
    x <- rnorm(n)
    x1 <- x + .2*rnorm(n)
    x2 <- x + .2*rnorm(n)
    x3 <- x + .2*rnorm(n)
    x4 <- x + .2*rnorm(n)
    y <- 1+x1+2*x2+x3+2*x4 + rnorm(n)
    data.frame(y,x1,x2,x3,x4)
  }
  get.model <- function (d) {
    r <- lm.ridge(y~., data=d)
  }
  get.predictions <- function (r,d) {
    m <- t(as.matrix(r$coef/r$scales))
    inter <- r$ym - m %*% r$xm
    drop(inter) + as.matrix(d[,-1]) %*% drop(m)
  }

  lambda <- c(0,.001,.002,.005,.01,.02,.05,.1,.2,.5,1,2,5,10,20,50,100)
  lambda <- exp(seq(-7,7,length=100))
  n <- length(lambda)
  res <- rep(NA,n)
  for (i in 1:n) {  
    res[i] <- my.simulation.predict(
      get.sample,
      get.model = function (d) {
        lm.ridge(y~., data=d, lambda=lambda[i])
      },
      get.predictions = get.predictions,
      R=20
    )$t0[1]
  }
  plot(res~lambda, type='l', log='x')
  abline(h=0,lty=3)
  title("Biais des pr�dictions de la ridge regression")
dev.off()

png(file="g711.png", width=600, height=600)
  get.sample <- function () {
    n <- 20
    x <- rnorm(n)
    x1 <- x + .2*rnorm(n)
    x2 <- x + .2*rnorm(n)
    x3 <- x + .2*rnorm(n)
    x4 <- x + .2*rnorm(n)
    y <- 1+2*x1+3*x2+4*x3+5*x4 + rnorm(n)
    data.frame(y,x1,x2,x3,x4)
  }
  s <- function(d,l) {
    r <- lm.ridge(y~., data=d, lambda=l)
    m <- t(as.matrix(r$coef/r$scales))
    inter <- r$ym - m %*% r$xm
    c(inter,m)
  }
  lambda <- exp(seq(-7,7,length=100))
  n <- length(lambda)
  res <- matrix(NA,nr=n,nc=5)
  for (i in 1:n) {
    res[i,] <- my.simulation(
      get.sample,
      function (d) { s(d,lambda[i]) },
      R=20
    )$t0
  }
  matplot(lambda,res,type='l',lty=1,log='x')
  abline(h=1:5,lty=3,col=1:5)
  title("Biais des coefficients de la ridge regression")
dev.off()

png(file="g712.png", width=600, height=600)
  get.sample <- function (a,b) {
    n <- 20
    x <- rnorm(n)
    x1 <- x + .2* rnorm(n)
    x2 <- x + .2* rnorm(n)
    y <- a*x1 + b*x2 + rnorm(n)
    data.frame(y,x1,x2)
  }
  get.parameters <- function (d) {
    y <- d[,1]
    x <- d[,-1]
    p <- princomp(x)
    r <- lm(y ~ p$scores[,1] -1)
    drop(p$loadings %*% c(r$coef,0))
  }
  N <- 5
  a.min <- 0
  a.max <- 10
  res <- matrix(NA,nr=N,nc=N)
  a <- seq(a.min,a.max,length=N)
  b <- seq(a.min,a.max,length=N)
  for (i in 1:N) {
    for(j in 1:N) {
      res[i,j] <- my.simulation(
        function () { get.sample(a[i],b[j]) },
        get.parameters,
        R=20
      )$t0[1] - a[i]
    }
  }

  persp(res)
dev.off()

png(file="g713.png", width=600, height=600)
  image(a,b,res,col=topo.colors(255))
  text( matrix(a,nr=N,nc=N),
        matrix(b,nr=N,nc=N, byrow=T),
        round(res) )
dev.off()

png(file="g714.png", width=600, height=600)
  get.parameters <- function (d) {
    y <- d[,1]
    x <- d[,-1]
    p <- princomp(x)
    r <- lm(y ~ p$scores[,1] -1)
    res <- drop(p$loadings %*% c(r$coef,0))
    a <- res[1]
    b <- res[2]
    c( a - (b-a)/2, b - (a-b)/2 )
  }
  N <- 5
  a.min <- 0
  a.max <- 10
  res <- matrix(NA,nr=N,nc=N)
  a <- seq(a.min,a.max,length=N)
  b <- seq(a.min,a.max,length=N)
  for (i in 1:N) {
    for(j in 1:N) {
      res[i,j] <- my.simulation(
        function () { get.sample(a[i],b[j]) },
        get.parameters,
        R=20
      )$t0[1] - a[i]
    }
  }
  persp(res)
dev.off()

png(file="g715.png", width=600, height=600)
  image(a,b,res,col=topo.colors(255))
  text( matrix(a,nr=N,nc=N),
        matrix(b,nr=N,nc=N, byrow=T),
        round(res) )
dev.off()

png(file="g716.png", width=600, height=600)
  get.parameters <- function (d) {
    y <- d[,1]
    x <- d[,-1]
    p <- princomp(x)
    r <- lm(y ~ p$scores[,1] -1)
    drop(p$loadings %*% c(r$coef,0))
  }
  N <- 5
  a.min <- 0
  a.max <- 10
  res <- matrix(NA,nr=N,nc=N)
  res.a <- matrix(NA,nr=N,nc=N)
  res.b <- matrix(NA,nr=N,nc=N)
  a <- seq(a.min,a.max,length=N)
  b <- seq(a.min,a.max,length=N)
  for (i in 1:N) {
    for(j in 1:N) {
      r <- my.simulation(
        function () { get.sample(a[i],b[j]) },
        get.parameters,
        R=20
      )$t0
      res.a[i,j] <- r[1]
      res.b[i,j] <- r[2]
      res[i,j] <- r[1] - a[i]
    }
  }
  plot(res.a, res.b, type='n')
  text(res.a, res.b, round(res))
dev.off()

png(file="g717.png", width=600, height=600)
  plot(as.vector(res) ~ as.vector(res.a-res.b))
dev.off()

png(file="g718.png", width=600, height=600)
  my.simulation.cross.validation <- function (
    s, # sample
    k, # number of observations to fit the the model
    get.model,
    get.predictions=predict,
    R = 999 )
  {
    n <- dim(s)[1]
    r <- matrix(NA, nr=R, nc=3)
    colnames(r) <- c("biais", "variance", "erreur quadratique")
    for (i in 1:R) {
      j <- sample(1:n, k)
      d.train <- s[j,]
      d.test <-  s[-j,]
      m <- get.model(d.train)
      p <- get.predictions(m, d.test)
      if(is.vector(p)){ p <- data.frame(p) }
      d.test <- d.test[,1:(dim(p)[2])]
      b <- apply(d.test-p, 2, mean)
      v <- apply(d.test-p, 2, var)
      e <- apply((d.test-p)^2, 2, mean)
      r[i,] <- c(b,v,e)
    }
    list(t=r, t0=apply(r,2,mean))
  }

  n <- 200
  x1 <- rnorm(n)
  x2 <- rnorm(n)
  x3 <- rnorm(n)
  y <- 2 - x1 - x2 - x3 + rnorm(n)
  s <- data.frame(y,x1,x2,x3)
  r <- my.simulation.cross.validation(s, 150, function(s){lm(y~.,data=s)}, R=99)
  hist( r$t[,3], probability=T, col='light blue', 
        main="Estimation de l'erreur quadratique moyenne par validation crois�e" )
  lines(density(r$t[,3]),col='red',lwd=3)
  abline(v=mean(r$t[,3]),lty=2,lwd=3,col='red')
dev.off()

png(file="g719.png", width=600, height=600)
  my.simulation.jackknife <- function (
    s,
    get.model,
    get.predictions=predict,
    R=999)  
  {
    n <- dim(s)[1]
    if(R<n) {
      j <- sample(1:n, R)
    } else {
      R <- n
      j <- 1:n
    }
    p <- get.predictions(get.model(s), s)
    if( is.vector(p) ) {
      p <- as.data.frame(p)
    }
    r <- matrix(NA, nr=R, nc=dim(s)[2]+dim(p)[2])
    colnames(r) <- c(colnames(s), colnames(p))
    for (i in j) {
      d.train <- s[-i,]
      d.test <-  s[i,]
      m <- get.model(d.train)
      p <- get.predictions(m, d.test)
      r[i,] <- as.matrix(cbind(s[i,], p))
    }
    r
  }

  n <- 200
  x1 <- rnorm(n)
  x2 <- rnorm(n)
  x3 <- rnorm(n)
  y <- 2 - x1 - x2 - x3 + rnorm(n)
  s <- data.frame(y,x1,x2,x3)
  r <- my.simulation.jackknife(s, function(s){lm(y~.,data=s)})
  hist( r[,5]-r[,1], col='light blue' )
dev.off()

png(file="g720.png", width=600, height=600)
  my.simulation.bootstrap <- function (
    s,
    get.model,
    get.predictions=predict,
    R = 999 )
  {
    n <- dim(s)[1]
    r <- matrix(NA, nr=R, nc=3)
    colnames(r) <- c("biais", "variance", "erreur quadratique")
    for (i in 1:R) {
      j <- sample(1:n, n, replace=T)
      d.train <- s[j,]
      d.test <-  s
      m <- get.model(d.train)
      p <- get.predictions(m, d.test)
      if(is.vector(p)){ p <- data.frame(p) }
      d.test <- d.test[,1:(dim(p)[2])]
      b <- apply(d.test-p, 2, mean)
      v <- apply(d.test-p, 2, var)
      e <- apply((d.test-p)^2, 2, mean)
      r[i,] <- c(b,v,e)
    }
    list(t=r, t0=apply(r,2,mean))
  }

  n <- 200
  x1 <- rnorm(n)
  x2 <- rnorm(n)
  x3 <- rnorm(n)
  y <- 2 - x1 - x2 - x3 + rnorm(n)
  s <- data.frame(y,x1,x2,x3)
  r <- my.simulation.bootstrap(s, function(s){lm(y~.,data=s)}, R=99)
  hist( r$t[,3], col='light blue', 
        main="Estimation de l'erreur quadratique moyenne par bootstrap" )
  lines(density(r$t[,3]),col='red',lwd=3)
  abline(v=mean(r$t[,3]),lty=2,lwd=3,col='red')
dev.off()

png(file="g721.png", width=600, height=600)
  library(boot)
  n <- 200
  x <- rlnorm(n)
  r <- boot(x, function(s,i){mean(s[i])}, R=99)
  hist(r$t, probability=T, col='light blue')
  lines(density(r$t),col='red',lwd=3)
  abline(v=mean(r$t),lty=2,lwd=3,col='red')
  title("Estimation par bootstrap de la distribution de la moyenne d'un �chantillon")
dev.off()

png(file="g722.png", width=600, height=600)
  n <- 200
  x1 <- rnorm(n)
  x2 <- rnorm(n)
  x3 <- rnorm(n)
  y <- -2 - x1 +0* x2 + x3 + rnorm(n)
  s <- data.frame(y,x1,x2,x3)
  r <- boot(s, function(s,i){lm(y~.,data=s[i,])$coef}, R=99)
  plot(NA,xlim=range(r$t), ylim=c(0,6.5))
  for (i in 1:4) {
    lines(density(r$t[,i]), lwd=2, col=i)
  }
dev.off()

png(file="g723.png", width=600, height=600)
  n <- 200
  x1 <- rnorm(n)
  x2 <- rnorm(n)
  x3 <- rnorm(n)
  y <- 1+x1+x2+x3+rnorm(n)
  d <- data.frame(y,x1,x2,x3)
  r <- boot(d, 
            function (d,i) {
              r <- lm(y~.,data=d[i,])
              p <- predict(r, d[-i,])
              mean((p-d[,1][-i])^2)
            },
            R=99)
  hist(r$t,probability=T,col='light blue',
       main="R�partition de l'erreur quadratique moyenne")
  lines(density(r$t),lwd=3,col='red')
  abline(v=mean(r$t),lty=3)
dev.off()

png(file="g724.png", width=600, height=600)
  get.sample <- function (n=50) { rnorm(n) }
  get.statistic <- function (x) { mean(x) }
  # Tra�ons la densit� de l'estimateur
  R <- 200
  x <- rep(NA,R)
  for (i in 1:R) {
    x[i] <- get.statistic(get.sample())
  }
  plot(density(x), ylim=c(0,4), lty=1,lwd=3,col='red',
       main="Pertinence du bootstrap")
  # Tra�ons quelques estimations de cette densit� obtenus par le bootstrap
  for (i in 1:5) {
    x <- get.sample()
    r <- boot(x, function(s,i){mean(s[i])}, R=R)
    lines(density(r$t))
  }
  curve(dnorm(x,sd=1/sqrt(50)),add=T, lty=2,lwd=3,col='blue')
  legend(par('usr')[2], par('usr')[4], xjust=1, yjust=1,
         c('bootstrap param�trique', 'bootstraps non param�triques',
           "Courbe th�orique"),
         lwd=c(3,1,2),
         lty=c(1,1,2),
         col=c("red", par("fg"), "blue"))
dev.off()

png(file="g725.png", width=600, height=600)
  n <- 50
  x <- rnorm(n)
  r <- boot(x, function(s,i){max(s[i])}, R=999)
  hist(r$t, probability=T, col='light blue',
       main="Une statistique pour laquelle le bootstrap n'est pas tr�s pertinent...")
  lines(density(r$t,bw=.05), col='red', lwd=3)
dev.off()

png(file="g726.png", width=600, height=600)
  n <- 20
  N <- 100
  r <- matrix(NA,nr=N,nc=2)
  for (i in 1:N) {
    x <- rnorm(n)
    r[i,] <- boot.ci(boot(x,function(x,i){mean(x[i])},R=99))$basic[c(4,5)]
  }
  plot(NA,xlim=c(-1.5,1.5), ylim=c(0,2),
       main="R�partition des bornes des intervalles de confiance donn�s par le bootstrap")
  lines(density(r[,1]), lwd=3, col='red')
  lines(density(r[,2]), lwd=3, col='blue')
  abline(v=0,lty=3)
dev.off()

png(file="g727.png", width=600, height=600)
  n <- 200
  x1 <- rnorm(n)
  x2 <- rnorm(n)
  x3 <- rnorm(n)
  y <- 1+x1+x2+x3+rnorm(n)
  d <- data.frame(y,x1,x2,x3)
  r1 <- boot(d, function (d,i) {
               r <- lm(y~.,data=d[i,])
               p <- predict(r, d)
               mean(p-d[,1])
             },
             R=99)$t
  r2 <- boot(d, function (d,i) {
               r <- lm(y~.,data=d[i,])
               p <- predict(r, d[-i,])
               mean(p-d[,1][-i])
             },
             R=99)$t
  r3 <- .368*r1 + .632*r2
  hist(r1,probability=T,col='light blue',
       main="Estimations du biais : bootstrap, oobb, .632")
  lines(density(r1),lwd=3,col='red')
  lines(density(r2),lwd=3,col='green')
  lines(density(r3),lwd=3,col='blue')
  legend(par('usr')[2], par('usr')[4], xjust=1, yjust=1,
         c("bootstrap classique", "bootstrap hors-du-sac", "boootstrap .632"),
         lwd=3,
         col=c("red", "green", "blue")
        )
dev.off()

png(file="g728.png", width=600, height=600)
  library(boot)
  my.max <- function (x, i) { max(x[i]) }
  r <- boot(faithful$eruptions, my.max, R=100)
  plot(r)
dev.off()

png(file="g729.png", width=600, height=600)
  jack.after.boot(r)
dev.off()

png(file="g730.png", width=600, height=600)
  get.sample <- function (n=50) {
    x <- rnorm(n)
    y <- 1-x+rnorm(n)
    data.frame(x,y)
  }
  s <- get.sample()

  R <- 100
  n <- dim(s)[1]
  x <- s$x
  y <- s$y
  res <- rep(NA,R)
  res.oob <- rep(NA,R)
  for (k in 1:R) {
    i <- sample(n,n,replace=T)
    xx <- x[i]    
    yy <- y[i]
    r <- lm(yy~xx)
    ip <- rep(T,n)
    ip[i] <- F
    xp <- x[ip]
    yp <- predict(r,data.frame(xx=xp))
    try( res.oob[k] <- sd(yp - s$y[ip]) )
    res[k] <- sd( yy - predict(r) )
  }
  plot(density(res), main="Basic and out-of-the-box bootstrap")
  lines(density(res.oob),lty=2)
  abline(v=1,lty=3)
  legend( par("usr")[2], par("usr")[4], xjust=1, yjust=1,
          c("Basic bootstrap", "Out-of-the-box bootstrap"),
          lwd=1, lty=c(1,2) )
dev.off()

png(file="g731.png", width=600, height=600)
  echantillon.multicolineaire <- function (n=100) {
    x0 <- rep(1,n)
    x1 <- x0 + .1*rnorm(n)
    x2 <- x0 + .1*rnorm(n)
    x3 <- x0 + .1*rnorm(n)
    y <- x0 + x1 + x2 + x3 + rnorm(n)
    x <- cbind(x0,x1,x2,x3)
    m <- cbind(y,x)
    m
  }
  m <- echantillon.multicolineaire()
  f <- function (m, k) { 
    x <- m[,-1]
    y <- m[,1]
    n <- dim(x)[2]
    solve( t(x) %*% x + k*diag(rep(1,n)), t(x) %*% y )
  }
  N <- 200
  variance <- rep(NA, N)
  biais <- rep(NA, N)
  exact <- f(m,0)
  k <- exp(seq(.01,4, length=N))-1
  for (j in 1:N) {
    g <- function (m, i) { f(m[i,], k[j]) }
    s <- boot(m, g, R=1000)
    variance[j] <- max(var(s$t))
    biais[j] <- max(exact - apply(s$t,2,mean))
  }
  plot(variance ~ k, log='x', type='l')
  par(new=T)
  plot(biais ~ k, type='l', log='x', col='red', xlab='', ylab='', axes=F)
  axis(4, col="red")
  legend( par("usr")[2], par("usr")[4], yjust=1, xjust=0,
          c("variance", "optimisme"),
          lwd=1, lty=1,
          col=c(par('fg'), 'red') )
dev.off()

png(file="g732.png", width=600, height=600)
  my.bootstrap <- function (data, estimator, size, ...) {
    values <- NULL
    n <- dim(data)[1]
    for (i in 1:size) {
      bootstrap.sample <- data[ sample(1:n, n, replace=T), ]
      values <- rbind(values, t(estimator(bootstrap.sample, ...)))
    }
    values
  }

  n <- 100
  x0 <- rep(1,n)
  x1 <- x0 + .1*rnorm(n)
  x2 <- x0 + .1*rnorm(n)
  x3 <- x0 + .1*rnorm(n)
  y <- x0 + x1 + x2 + x3 + rnorm(n)
  x <- cbind(x0,x1,x2,x3)
  f <- function (m, k) { 
    x <- m[,-1]
    y <- m[,1]
    n <- dim(x)[2]
    solve( t(x) %*% x + k*diag(rep(1,n)), t(x) %*% y )
  }
  N <- 200
  variance <- rep(NA, N)
  biais <- rep(NA, N)
  k <- exp(seq(0,6, length=N))-1
  for (i in 1:N) {
    s <- my.bootstrap(cbind(y,x), f, 100, k[i])
    variance[i] <- max(apply(s, 2, var))
    biais[i] <- max(abs( s - 
      matrix( as.vector(f(cbind(y,x),0)), nr=dim(s)[1], nc=dim(s)[2], byrow=T )
    ))
  }
  plot(variance ~ k, log='x', type='l')
  par(new=T)
  plot(biais ~ k, type='l', log='x', col='red', xlab='', ylab='', axes=F)
  axis(4)
dev.off()

png(file="g733.png", width=600, height=600)
  s <- my.bootstrap(cbind(y,x), f, 100, 10)
  b <- apply(s, 2, mean)
  b0 <- as.vector(f(cbind(y,x),0))

  # Un autre �chantillon de la m�me population
  # A FAIRE : mettre �a dans une fonction
  n <- 100
  x0 <- rep(1,n)
  x1 <- x0 + .1*rnorm(n)
  x2 <- x0 + .1*rnorm(n)
  x3 <- x0 + .1*rnorm(n)
  y <- x0 + x1 + x2 + x3 + rnorm(n)
  x <- cbind(x0,x1,x2,x3)

  a1 <- x %*% b  
  a2 <- x %*% b0
  boxplot( c(as.vector(a1), as.vector(a2)) ~ 
           gl(2,n,2*n, c("ridge", "classic")),
           horizontal=T )
  title(main="Residues of a ridge regression")
dev.off()

png(file="g734.png", width=600, height=600)
  n <- 50
  k <- 10 
  N <- 50
  get.sample <- function (n) {
    x <- runif(n)
    y <- sin(2*pi*x)+.3*rnorm(n)
    m <- data.frame(x=x, y=y)
    m
  }
  error <- rep(NA,k)
  for (i in 1:k) {
    e <- rep(NA,N)
    for (j in 1:N) {
      training.sample <- get.sample(n)
      x <- training.sample$x
      y <- training.sample$y
      r <- lm(y~poly(x,i))
      test.sample <- get.sample(1000)
      e[j] <- mean( (predict(r, data.frame(x=test.sample$x)) - test.sample$y)^2 )
    }
    error[i] <- mean(e)
  }
  plot(error, type='l', log='y',
       xlab="Complexit� du mod�le",
       ylab="Erreur")
dev.off()

png(file="g735.png", width=600, height=600)
  a <- 2
  curve(dnorm(x-a), xlim=c(-3,5), ylim=c(0,.5))
  abline(v=0, lty=3, col='red')
  abline(v=a, lty=3, col='blue')
  arrows(0,.45,a,.45, code=3, col='green')
  arrows(a-pnorm(1), dnorm(pnorm(1)), a+pnorm(1), dnorm(pnorm(1)), code=3, col='red')
  legend(par('usr')[2], par('usr')[4], xjust=1,
         c("vraie valeur", "esp�rance de l'estimateur", "biais", "variance"),
         lwd=1, lty=c(3,3,1,1),
         col=c('red', 'blue', 'green', 'red') )
  title(main="Biais et variance d'un estimateur biais�")
dev.off()

png(file="g736.png", width=600, height=600)
  n <- 100
  k <- 5
  x <- matrix(rnorm(n*k),nc=k)
  y <- x[,1] + x[,2] - sqrt(abs(x[,3]*x[,4]))
  y <- y-median(y)
  y <- factor(y>0)
  pairs(x, col=as.numeric(y)+1)
dev.off()

png(file="g737.png", width=600, height=600)
  library(nlme)
  n <- 20
  m <- 15
  d <- as.data.frame(matrix(rnorm(n*m),nr=n,nc=m))
  # i <- sample(1:m, 3)
  i <- 1:3
  d <- data.frame(y=apply(d[,i],1,sum)+rnorm(n), d)
  k <- m
  res <- matrix(nr=k, nc=5)
  for (j in 1:k) {
    r <- lm(d$y ~ as.matrix(d[,2:(j+1)]))
    res[j,] <- c( logLik(r), AIC(r), BIC(r), summary(r)$r.squared, summary(r)$adj.r.squared )
  }
  colnames(res) <- c('logLik', 'AIC', 'BIC', "R squared", "adjusted R squared")
  res <- t( t(res) - apply(res,2,mean) )
  res <- t( t(res) / apply(res,2,sd) )
  matplot(0:(k-1), res, type='l', 
          col=c(par('fg'),'blue','green', 'orange', 'red'), lty=1,
          xlab="Nombre de variables")
  legend(par('usr')[2], par('usr')[3], xjust=1, yjust=0,
         c('log-vraissemblance', 'AIC', 'BIC', 
           "coefficient de d�termination", "coefficient de d�termination ajust�" ),
         lwd=1, lty=1,
         col=c(par('fg'), 'blue', 'green', "orange", "red") )
  abline(v=3, lty=3)
dev.off()

png(file="g738.png", width=600, height=600)
  get.sample <- function () {
    # Nombre d'observations
    n <- 20 
    # Nombre de variables
    m <- 10
    # Num�ro des variables qui interviennent vraiment
    k <- sample(1:m, 5)
    print(k)    
    # Coefficients
    b <- rnorm(m); b <- round(sign(b)+b); b[-k] <- 0
    x <- matrix(nr=n, nc=m, rnorm(n*m))
    y <- x %*% b + rnorm(n)
    data.frame(y=y, x)
  }

  my.variable.selection <- function (y,x, p=.05) {
    nvar <- dim(x)[2]
    nobs <- dim(x)[1]
    v <- rep(FALSE, nvar)
    p.values <- matrix(NA, nr=nvar, nc=nvar)
    res1 <- list()
    res2 <- list()
    done <- FALSE
    while (!done) {
      print(paste("It�ration", sum(v)))
      done <- TRUE
      # On cherche si l'une des p-valeurs est inf�rieure � p
      pmax <- 1
      imax <- NA
      for (i in 1:nvar) {
        if(!v[i]){
          # Calcul de la p-valeur
          m <- cbind(x[,v], x[,i])
          m <- as.matrix(m)
          pv <- 1
          try( pv <- summary(lm(y~m))$coefficients[ dim(m)[2]+1, 4 ] )
          if( is.nan(pv) ) pv <- 1
          if (pv<pmax) {
            pmax <- pv
            imax <- i
          }
          p.values[i,sum(v)+1] <- pv
        }
      }
      if (pmax<p) {
        print(paste("Adding variable", imax, "with p-value", pmax))
        m1 <- as.matrix(x[,v])
        res1[[ length(res1)+1 ]] <- NULL
        try( res1[[ length(res1)+1 ]] <- data.frame(res=lm(y~m1)$res,xi=x[,imax]) )
        v[imax] <- TRUE
        done <- FALSE
        m2 <- as.matrix(cbind(x[,v], x[,imax]))
        res2[[ length(res2)+1 ]] <- data.frame(res=lm(y~m2)$res,xi=x[,imax])
      }
    }
    list(variables=v, p.values=p.values[,1:sum(v)], res1=res1, res2=res2)
  }

  d <- get.sample()
  y <- d$y
  x <- d[,-1]
  res <- my.variable.selection(y,x)

  k <- ceiling(length(res$res1)/3)
  op <- par(mfrow=c(k,3))
  for (i in 1:length(res$res1)) {
    r1 <- res$res1[[i]]
    r2 <- res$res2[[i]]
    plot(r1[,1] ~ r1[,2], ylab="res", xlab=names(r1)[2])
    points(r2[,1] ~ r2[,2],  col='red')
  }
  par(op)
dev.off()

png(file="g739.png", width=600, height=600)
  matplot(t(res$p.values), type='l', lty=1, lwd=1+2*res$variables)
  abline(h=.05, lty=3)
dev.off()

png(file="g740.png", width=600, height=600)
  library(ade4)
  data(microsatt)
  x <- microsatt$tab   # 18 observations, 112 variables, beaucoup de z�ros
  y <- x[,3]
  x <- x[,-3]
  yn <- y/sqrt(sum(y*y))
  xn <- t(t(x)/sqrt(apply(x*x, 2, sum)))
  plot( sort(as.vector(t(yn) %*% xn)), type='h')
dev.off()

png(file="g741.png", width=600, height=600)
  library(leaps)
  library(car)
  get.sample <- function () {
    # Nombre d'observations
    n <- 20 
    # Nombre de variables
    m <- 10
    # Num�ro des variables qui interviennent vraiment
    k <- sample(1:m, 5)
    print(k)    
    # Coefficients
    b <- rnorm(m); b <- round(sign(b)+b); b[-k] <- 0
    x <- matrix(nr=n, nc=m, rnorm(n*m))
    y <- x %*% b + rnorm(n)
    list(y=y, x=x, k=k, b=b)
  }
  d <- get.sample()
  x <- d$x
  y <- d$y
  k <- d$k
  b <- d$b
  subsets(regsubsets(x,y), statistic='bic', legend=F)
  title(main=paste(sort(k),collapse=', '))
dev.off()

png(file="g742.png", width=600, height=600)
  n <- 200
  x <- rnorm(n)
  y <- rnorm(n)
  u <- sqrt(x^2+y^2)
  u <- ifelse( u<.5*mean(u), 1, 2)
  plot(y~x, col=u, pch=15)
dev.off()

png(file="g743.png", width=600, height=600)
  library(e1071)
  u <- factor(u)
  r <- svm(u~x+y)
  {
    # La fonction plot.svm appelle browser() : pourquoi ???
    # Et apr�s, �a plante...
    # (e1071 version 1.3-16, 1.3-16)
    browser <- function () {}
    try(  plot(r, data.frame(x,y,u), y~x)  )
  }
dev.off()

png(file="g744.png", width=600, height=600)
  n <- 200
  x <- runif(n, -1,1)
  y <- runif(n, -1,1)
  u <- abs(x-y)
  u <- ifelse( u<.5*mean(u), 1, 2)
  plot(y~x, col=u, pch=15)
dev.off()

png(file="g745.png", width=600, height=600)
  u <- factor(u)
  r <- svm(u~x+y)
  { 
    browser <- function () {} 
    try(  plot(r, data.frame(x,y,u), y~x)  )
  }
dev.off()

png(file="g746.png", width=600, height=600)
  n <- 200
  x1 <- runif(n,-3,3)
  x2 <- runif(n,-3,3)
  x3 <- runif(n,-3,3)
  f1 <- sin; f2 <- cos; f3 <- abs;
  y <- f1(x1) + f2(x2) + f3(x3) + rnorm(n)
  pairs(cbind(y,x1,x2,x3)) # on ne voit pas grand-chose...
dev.off()

png(file="g747.png", width=600, height=600)
  library(mgcv)
  r <- gam(y~s(x1)+s(x2)+s(x3))
  x <- seq(-3,3,length=200)
  z <- rep(0,200)
  m.theorique <- cbind(f1(x),f2(x),f3(x))
  m.experimentale <- cbind( 
    predict(r, data.frame(x1=x,x2=z,x3=z)),
    predict(r, data.frame(x1=z,x2=x,x3=z)),
    predict(r, data.frame(x1=z,x2=z,x3=x))
  )
  matplot(m.theorique, type='l', lty=1)
  matplot(m.experimentale, type='l', lty=2, add=T)
dev.off()

png(file="g748.png", width=600, height=600)
  zero.mean <- function (m) {
    t(t(m)-apply(m,2,mean))
  }
  matplot(zero.mean(m.theorique), type='l', lty=1)
  matplot(zero.mean(m.experimentale), type='l', lty=2, add=T)
  title(main="GAM")
  legend(par('usr')[2], par('usr')[3], xjust=1, yjust=0,
         c('courbes th�oriques', 'courbes exp�rimentales'),
         lty=c(1,2))
dev.off()

png(file="g749.png", width=600, height=600)
  op <- par(mfrow=c(2,2))
  for (i in 1:3) {
    plot(r, select=i)
    lines(zero.mean(m.theorique)[,i]~x, lwd=3, lty=3, col='red')
  }
  par(op)
dev.off()

png(file="g750.png", width=600, height=600)
  res <- residuals(r)
  op <- par(mfrow=c(2,2))
  plot(res)
  plot(res~predict(r))
  hist(res, col='light blue', probability=T)
  lines(density(res), col='red', lwd=3)
  rug(res)
  qqnorm(res)
  qqline(res)
  par(op)
dev.off()

png(file="g751.png", width=600, height=600)
  op <- par(mfrow=c(2,2))
  plot(res ~ x1)
  plot(res ~ x2)
  plot(res ~ x3)
  par(op)
dev.off()

png(file="g752.png", width=600, height=600)
  library(rpart)
  data(kyphosis)
  r <- rpart(Kyphosis ~ ., data=kyphosis)
  plot(r)
  text(r)
dev.off()

png(file="g753.png", width=600, height=600)
  library(randomForest)
  library(mlbench)
  library(mva)
  data(Vowel)
  r <- randomForest(Class~., data=Vowel, importance=T) # Trois minutes...
  m <- r$confusion
  # On a une matrice de confusion alors qu'on veut une matrice de
  # distances. On essaye donc de tripatouiller un peu la matrice pour
  # se ramener � quelque chose qui ressemble � des distances -- il y a
  # peut-�tre de meilleures mani�re de proc�der...
  m <- m[,-dim(m)[2]]
  m <- m+t(m)-diag(diag(m))
  n <- dim(m)[1]
  m <- m/( matrix(diag(m),nr=n,nc=n) + matrix(diag(m),nr=n,nc=n, byrow=T) )
  m <- 1-m
  diag(m) <- 0
  # On peut le dessiner (il faudrait aussi regarder en dimensions sup�rieures)
  mds <- cmdscale(m,2)
  plot(mds, type='n')
  text(mds, colnames(m))
  rm(Vowel)
dev.off()

png(file="g754.png", width=600, height=600)
  op <- par(mfrow = c(2,2))
  m <- r$importance
  n <- dim(m)[1]
  for (i in 1:4) {
    plot(m[,i],
         type = "h", lwd=3, col='blue', axes=F,
         ylab='', xlab='Variables',
         main = colnames(r$importance)[i] )
    axis(2)
    axis(1, at=1:n, labels=rownames(m))
    # Je mets les deux valeurs les plus �lev�es en rouge
    a <- order(m[,i], decreasing=T)
    m2 <- m[,i]
    m2[ -a[1:2] ] <- NA
    lines(m2, type='h', lwd=5, col='red')
  }
  par(op)
dev.off()

png(file="g755.png", width=600, height=600)
  library(mda)
  library(mlbench)
  data(BostonHousing)
  x <- BostonHousing
  x[,4] <- as.numeric(x[,4])
  pairs(x)
dev.off()

png(file="g756.png", width=600, height=600)
  op <- par(mfrow=c(4,4))
  for (i in 1:14) {
    hist(x[,i],probability=T,col='light blue', main=paste(i,names(x)[i]))
    lines(density(x[,i]),col='red',lwd=3)
    rug(jitter(x[,i]))
  }
    hist(log(x[,1]),probability=T,col='light blue', main="log(x1)")
    lines(density(log(x[,1])),col='red',lwd=3)
    rug(jitter(log(x[,1])))
  par(op)
dev.off()

png(file="g757.png", width=600, height=600)
  op <- par(mfrow=c(4,4))
  for (i in 1:14) {
    qqnorm(x[,i], main=paste(i,names(x)[i]))
    qqline(x[,i], col='red')
  }
    qqnorm(log(x[,1]), main="log(x1)")
    qqline(log(x[,1]), col='red')
  par(op)
dev.off()

png(file="g758.png", width=600, height=600)
  x[,1] <- log(x[,1])
  n <- dim(x)[1]
  k <- sample(1:n, 100)
  d1 <- x[k,]
  d2 <- x[-k,]
  r <- mars(d1[,-1],d1[,1])
  p <- predict(r, d2[,-1])
  res <- d2[,1] - p

  op <- par(mfrow=c(4,4))
  plot(res)
  plot(res~p)
  for (i in 2:14) {
    plot(res~d2[,i])
  }  
  par(op)
dev.off()

png(file="g759.png", width=600, height=600)
  op <- par(mfrow=c(2,2))
  qqnorm(r$fitted.values, main="fitted values")
  qqline(r$fitted.values)
  hist(r$fitted.values,probability=T,col='light blue', main='fitted values')
  lines(density(r$fitted.values),col='red',lwd=3)
  rug(jitter(r$fitted.values))
  qqnorm(res, main="residues")
  qqline(res)
  hist(res,probability=T,col='light blue', main='residues')
  lines(density(res),col='red',lwd=3)
  rug(jitter(res))
  par(op)
dev.off()

png(file="g760.png", width=600, height=800)
  m <- read.table("faraway")
  op <- par(mfrow=(c(6,1)))
  for (i in 1:6) {
    boxplot(m[,i], horizontal=T, main=names(m)[i])
  }
  par(op)
dev.off()

png(file="g761.png", width=600, height=800)
  m <- read.table("faraway")
  op <- par(mfrow=(c(3,2)))
  for (i in 1:6) {
    hist(m[,i], col='light blue', probability=T, xlab=names(m)[i])
    lines(density(m[,i]), col='red', lwd=2)
  }
  par(op)
dev.off()

png(file="g762.png", width=600, height=800)
  m <- read.table("faraway")
  op <- par(mfrow=(c(3,2)))
  for (i in 1:6) {
    qqnorm(m[,i], main=names(m)[i])
    qqline(m[,i], col='red')
  }
  par(op)
dev.off()

png(file="g763.png", width=600, height=300)
  n <- 200
  x <- sample(0:1, n, replace=T)
  y <- 2*(x==0) +rnorm(n)
  plot( y ~ factor(x), horizontal=T, xlab='y', ylab='x' )
dev.off()

png(file="g764.png", width=600, height=600)
  plot(density(y[x==0]), lwd=3, xlim=c(-3,5), ylim=c(0,.5), col='blue')
  lines(density(y[x==1]), lwd=3, col='red')
dev.off()

png(file="g765.png", width=600, height=600)
  plot(y~x)
  abline(lm(y~x), col='red')
dev.off()

png(file="g766.png", width=600, height=600)
  n <- 200
  x1 <- sample(0:1, n, replace=T)
  x2 <- rnorm(n)
  y <- 1 - 2*(x1==0) + x2 +rnorm(n)
  plot( y ~ x2, col=c(par('fg'), 'red')[1+x1] )
  rc <- lm(y~x1+x2)$coef
  abline(rc[1],rc[3])
  abline(rc[1]+rc[2],rc[3], col='red')
dev.off()

png(file="g767.png", width=600, height=600)
  n <- 200
  x1 <- sample(0:1, n, replace=T)
  x2 <- rnorm(n)
  y <- 1 + x2 - (x1==1)*(2+3*x2) + rnorm(n)
  plot( y ~ x2, col=c(par('fg'), 'red')[1+x1] )
  # Sans interaction (en pointill�s)
  rc <- lm(y~x1+x2)$coef
  abline(rc[1],rc[3], lty=3)
  abline(rc[1]+rc[2],rc[3], col='red', lty=3)
  # avec
  rc <- lm(y~x1+x2+x1:x2)$coef
  abline(rc[1],rc[3])
  abline(rc[1]+rc[2],rc[3]+rc[4], col='red')
dev.off()

png(file="g768.png", width=600, height=400)
  n <- 200
  x <- sample(0:3, n, replace=T)
  y <- 2*(x==0) + 5*(x==2) -2*(x==3) +rnorm(n)
  plot( y ~ factor(x), horizontal=T, xlab='y', ylab='x' )
dev.off()

png(file="g769.png", width=600, height=600)
  n <- 1000
  x1 <- sample(1:4, n, replace=T)
  x2 <- runif(n, min=-1, max=1)
  y <- (x1==1) * (2 - 2*x2) +
       (x1==2) * (1 + x2) +
       (x1==3) * (-.5 + .5*x2) +
       (x1==4) * (-1) +
       rnorm(n)
  cols <- c(par('fg'), 'red', 'blue', 'orange')
  plot( y~x2, col=cols[x1] )
  x1 <- factor(x1)
  r <- lm(y~x1*x2)
  xx <- seq( min(x2), max(x2), length=100 )
  for (i in levels(x1)) {
    yy <- predict(r, data.frame(x1=rep(i, length(xx)), x2=xx))
    lines(xx,yy, col=cols[as.numeric(i)], lwd=3)
  }
dev.off()

png(file="g770.png", width=600, height=300)
  n <- 1000
  l <- 0:1
  v <- .5
  x1 <- factor( sample(l, n, replace=T), levels=l )
  x2 <- factor( sample(l, n, replace=T), levels=l )
  y <- ifelse( x1==0, 
         ifelse( x2==0, 1+v*rnorm(n),   v*rnorm(n) ),
         ifelse( x2==0, v*rnorm(n),   1+v*rnorm(n) )
       )
  boxplot( y ~ x1, horizontal=T )  
dev.off()

png(file="g771.png", width=600, height=300)
  boxplot( y ~ x2, horizontal=T )  
dev.off()

png(file="g772.png", width=600, height=300)
  boxplot( y ~ x2, horizontal=T )  
dev.off()

png(file="g773.png", width=600, height=600)
  plot( as.numeric(x1)-1+.2*rnorm(n), y, 
        col=c("red","blue")[as.numeric(x2)], 
        xlab="x1 (jittered)" )
dev.off()

png(file="g774.png", width=600, height=600)
  N <- 10
  a <- rnorm(N)
  b <- rnorm(N)
  c <- rnorm(N)
  d <- rnorm(N)
  df <- data.frame( y=c(a,b,c,d), x=factor(c(rep(1,N),rep(2,N),rep(3,N),rep(4,N))) )
  plot( y ~ x, data=df )
dev.off()

png(file="g775.png", width=600, height=600)
  plot(density(df$y,bw=1), xlim=c(-6,6), ylim=c(0,.5), type='l')
  points(density(a,bw=1), type='l', col='red')
  points(density(b,bw=1), type='l', col='green')
  points(density(c,bw=1), type='l', col='blue')
  points(density(d,bw=1), type='l', col='orange')
dev.off()

png(file="g776.png", width=600, height=600)
  curve( dnorm(x-2), from=-6, to=6, col='red' )
  curve( dnorm(x+2), add=T, col='green')
  curve( dnorm(x+2+.2), add=T, col='blue')
  curve( dnorm(x+2-.3), add=T, col='orange')
  x <- c(2, -2, -2.2, -1.7)
  segments( x, c(0,0,0,0), x, rep(dnorm(0),4), col=c('red', 'green', 'blue', 'orange') )
dev.off()

png(file="g777.png", width=600, height=600)
  s <- 3
  curve( dnorm(x-2, sd=s), from=-6, to=6, col='red' )
  curve( dnorm(x+2, sd=s), add=T, col='green')
  curve( dnorm(x+2+.2, sd=s), add=T, col='blue')
  curve( dnorm(x+2-.3, sd=s), add=T, col='orange')
  x <- c(2, -2, -2.2, -1.7)
  segments( x, c(0,0,0,0), x, rep(dnorm(0, sd=s),4), 
            col=c('red', 'green', 'blue', 'orange') )
dev.off()

png(file="g778.png", width=600, height=600)
  curve( df(x, 2, 2), from=0, to=4, ylim=c(0,1) )
  curve( df(x, 2, 10), add=T, col='red' )
  curve( df(x, 4, 2),  add=T, col='green' )
  curve( df(x, 4, 6),  add=T, col='green' )
  curve( df(x, 4, 10), add=T, col='green' )
  curve( df(x, 4, 20), add=T, col='green' )
  curve( df(x, 6, 2),  add=T, col='blue' )
  curve( df(x, 6, 6),  add=T, col='blue' )
  curve( df(x, 6, 10), add=T, col='blue' )
  curve( df(x, 6, 20), add=T, col='blue' )
dev.off()

png(file="g779.png", width=600, height=600)
  n <- 30
  x <- sample(LETTERS[1:3],n,replace=T, p=c(3,2,1)/6)
  x <- factor(x)
  y <- rnorm(n)  
  plot(y~x, col='pink')
dev.off()

png(file="g780.png", width=600, height=600)
  n <- 100
  x1 <- sample(LETTERS[1:3],n,replace=T,p=c(3,2,1)/6)
  x1 <- factor(x1)
  x2 <- sample(LETTERS[1:2],n,replace=T,p=c(3,1)/4)
  x2 <- factor(x2)
  y <- rnorm(n)
  i <- which(x1=='A' & x2=='B')
  y[i] <- rnorm(length(i),.5)
  library(lattice)
  bwplot(~y|x1*x2, layout=c(1,6))
dev.off()

png(file="g781.png", width=600, height=600)
  x1 <- gl(2,2,4,c(0,1))
  x2 <- gl(2,1,4,c(0,1))
  n <- function (x) {
    as.numeric(as.vector(x))
  }
  y1 <- n(x1) + n(x2)
  interaction.plot(x1,x2,y1, main="Pas d'interaction")
dev.off()

png(file="g782.png", width=600, height=600)
  y2 <- n(x1) + n(x2) - 2*n(x1)*n(x2)
  interaction.plot(x1,x2,y2, main="Interaction")
dev.off()

png(file="g783.png", width=600, height=600)
  n <- 2000    # Nombre d'exp�riences
  k <- 20     # Nombre d'individus
  l <- 4      # Nombre de groupes
  kl <- sample(1:l, k, replace=T)  # Groupe des individus
  x1 <- sample(1:k, n, replace=T)  
  x2 <- kl[x1]
  A <- rnorm(1,sd=4)
  B <- rnorm(k,sd=4)
  C <- rnorm(l,sd=4)
  y <- A + B[x1] + C[x2] + rnorm(n)
  x1 <- factor(x1)
  x2 <- factor(x2)
  op <- par(mfrow=c(1,2))
  plot(y~x1, col='pink')
  plot(y~x2, col='pink')
  par(op)
dev.off()

png(file="g784.png", width=600, height=600)
  # If the data were real, we wouldn't know kl.
  # One may recover it that way.
  kl <- tapply(x2, x1, function (x) { a <- table(x); names(a)[which(a==max(a))[1]] } )
  kl <- factor(kl, levels=levels(x2))
  plot(y~x1, col=rainbow(l)[kl])
dev.off()

png(file="g785.png", width=600, height=600)
  x1 <- factor(x1, levels=order(kl))
  kl <- sort(kl)
  plot(y~x1, col=rainbow(l)[kl])
dev.off()

png(file="g786.png", width=600, height=600)
  n <- 1000
  k <- 9
  sujet <- factor(sample(1:k,n,replace=T), levels=1:k)
  a <- rnorm(k,sd=4)
  b <- rnorm(1)
  x <- rnorm(n)
  y <- a[sujet] + b * x + rnorm(n)
  plot(y~x)
  abline(lm(y~x))
dev.off()

png(file="g787.png", width=600, height=600)
  col <- rainbow(k)
  plot(y~x)
  for (i in 1:k) {
    points(y[sujet==i] ~ x[sujet==i], col=col[i])
    abline( lm(y~x, subset=sujet==i), col=col[i] )
  }
dev.off()

png(file="g788.png", width=600, height=600)
  library(lattice)
  xyplot(y~x|sujet)
dev.off()

png(file="g789.png", width=600, height=600)
  n <- 30
  k <- 10
  sujet <- gl(k,n/k,n)
  x <- gl(n/k,1,n)
  y <- rnorm(k)
  y <- rnorm(n, y[sujet])
  y[ x==2 ] <- y[ x==2 ] + 1

  # On ne voit rien
  plot(y~x, col='pink')
dev.off()

png(file="g790.png", width=600, height=600)
  interaction.plot(x,sujet,y)
dev.off()

png(file="g791.png", width=600, height=600)
  n <- 50
  k <- 10
  sujet <- gl(k,n/k,n)
  groupe <- sample(1:3, k, replace=T)[sujet]
  groupe <- factor(groupe)
  x <- gl(n/k,1,n)
  y <- rnorm(n)
  y[x==1] <- y[x==1] + 1
  plot(y~x, col='pink')
dev.off()

png(file="g792.png", width=600, height=600)
  n <- 10
  sujet <- gl(n,2)
  traitement <- gl(2,1,2*n, 0:1)
  duree <- ifelse( traitement==1, rpois(2*n,2), rpois(2*n,3) )
  sans <- duree[2*(1:n)-1]
  avec <- duree[2*(1:n)]
  plot(sans+rnorm(n), avec+rnorm(n))
  abline(0,1)
dev.off()

png(file="g793.png", width=600, height=600)
  # Il y a 12 villes
  n.villes <- 12

  # La superficie des villes (plus raisonnablement, le logarithme de
  # leur superficie) sont des variables al�atoires ind�pendantes,
  # normales, de moyenne 5 et d'�cart-type 1.
  superficie.moyenne <- 5
  superficie.sd <- 1
  superficie <- rnorm(n.villes, superficie.moyenne, superficie.sd)

  a <- rnorm(n.villes)
  b <- rnorm(n.villes)

  # Il y a 200 individus, 20 dans chaque ville
  n.individus <- 20
  ville <- rep(1:n.villes, each=n.individus)

  # L'�ge des individus sont des variables al�atoires ind�pendantes,
  # normales, de moyenne 40, d'�cart-type 10.
  # On aurait pu choisir une loi diff�rente pour chacune des villes
  # (soit de mani�re purement al�atoire, soit en tenant compte de leur
  # superficie).
  age <- rnorm(n.villes*n.individus, 40, 10)

  # Le salaire (la variable qu'on cherche � expliquer) est une
  # fonction affine de l'�ge, mais les coefficients d�pendent de la
  # ville.
  # Ici, ces coefficients sont pris au hasard, mais on aurait pu les
  # faire d�pendre de la superficie de la ville. 
  # Ici, ces coefficients sont ind�pendants -- c'est rarement le cas.
  a <- rnorm(n.villes, 20000, sd=2000)
  b <- rnorm(n.villes, sd=20)
  salaire <- 200*superficie[ville] + a[ville] + b[ville]*age + rnorm(n.villes*n.individus, sd=200)

  plot(salaire ~ age, col=rainbow(n.villes)[ville], pch=16)
dev.off()

png(file="g794.png", width=600, height=600)
  library(lattice)
  xyplot(salaire ~ age | ville)
dev.off()

png(file="g795.png", width=600, height=600)
  a <- rnorm(n.villes, 20000, sd=2000)
  b <- rep(rnorm(1, sd=20), n.villes)
  salaire <- 200*superficie[ville] + a[ville] + b[ville]*age + rnorm(n.villes*n.individus, sd=200)
  xyplot(salaire ~ age | ville)
dev.off()

png(file="g796.png", width=600, height=600)
  a <- rep( rnorm(1, 20000, sd=2000), n.villes )
  b <- rnorm(n.villes, sd=20)
  salaire <- 200*superficie[ville] + a[ville] + b[ville]*age + rnorm(n.villes*n.individus, sd=200)
  xyplot(salaire ~ age | ville)
dev.off()

png(file="g797.png", width=600, height=600)
  a <- rep( rnorm(1, 20000, sd=2000), n.villes )
  b <- rep(rnorm(1, sd=20), n.villes)
  salaire <- 200*superficie[ville] + a[ville] + b[ville]*age + rnorm(n.villes*n.individus, sd=200)
  xyplot(salaire ~ age | ville)
dev.off()

png(file="g798.png", width=600, height=600)
  n.villes <- 12
  superficie <- rnorm(n.villes, 5, 1)
  a <- rnorm(n.villes)
  b <- rnorm(n.villes)
  n.individus <- 20
  ville <- rep(1:n.villes, each=n.individus)
  age <- rnorm(n.villes*n.individus, 40, 10)
  a <- rnorm(n.villes, 20000, sd=2000)
  b <- rep(rnorm(1, sd=20), n.villes)
  salaire <- 200*superficie[ville] + a[ville] + b[ville]*age + rnorm(n.villes*n.individus, sd=200)
  xyplot(salaire ~ age | ville)
dev.off()

png(file="g799.png", width=600, height=600)
  library(nlme)
  d <- data.frame(salaire, age, ville, superficie=superficie[ville])
  r <- lmList(salaire ~ age | ville, data=d)
  plot(intervals(r))
dev.off()

png(file="g800.png", width=600, height=600)
  N <- 1000
  n <- 20   # Taille des �chantillons
  k <- 4    # Nombre d'�chantillons
  res <- matrix(NA, nr=N, nc=2)
  for (a in 1:N) {
    x <- factor(rep(1:k,1,each=n))
    y <- rnorm(k*n)  
    res[a,1] <- summary(aov(y~x))[[1]][1,5]
    p <- 1
    for (i in 1:(k-1)) {
      for (j in (i+1):k) {
      p <- min(c( p, t.test(y[x==i],y[x==j])$p.value ))
      }
    }
    res[a,2] <- p
  }
  plot(res, xlab="p-valeur (anova)", ylab="p-valeur (tests de Student multiples)")
dev.off()

png(file="g801.png", width=600, height=600)
  plot(sort(res[,1]), main="p-valeurs (anova)")
  abline(0,1/N, col='red')
dev.off()

png(file="g802.png", width=600, height=600)
  plot(sort(res[,2]), main="p-valeurs (tests de Student multiples)")
  abline(0,1/N, col='red')
dev.off()

png(file="g803.png", width=600, height=600)
  plot(sort(k*(k-1)/2*res[,2]), ylim=c(0,1), main="p-valeurs (Bonferronni)")
  abline(0,1/N, col='red')
dev.off()

png(file="g804.png", width=600, height=600)
  plot(sort(1-(1-res[,2])^(k*(k-1)/2)), main="p-valeurs (correction de ???)")
  abline(0,1/N, col='red')
dev.off()

png(file="g805.png", width=600, height=600)
  # Tr�s, tr�s long...
  N <- 1000
  n <- 20   # Taille des �chantillons
  k <- 20   # Nombre d'�chantillons
  res <- matrix(NA, nr=N, nc=2)
  for (a in 1:N) {
    x <- factor(rep(1:k,1,each=n))
    y <- rnorm(k*n)  
    res[a,1] <- summary(aov(y~x))[[1]][1,5]
    p <- 1
    for (i in 1:(k-1)) {
      for (j in (i+1):k) {
      p <- min(c( p, t.test(y[x==i],y[x==j])$p.value ))
      }
    }
    res[a,2] <- p
  }

  op <- par(mfrow=c(2,2))
  plot(res, xlab="p-valeur (anova)", ylab="p-valeur (tests de Student multiples)")

  # plot(sort(res[,1]), main="p-valeurs (anova)")
  # abline(0,1/N, col='red')

  plot(sort(res[,2]), ylim=c(0,1), main="p-valeurs (tests de Student multiples)")
  abline(0,1/N, col='red')
  abline(h=.05, lty=3)

  plot(sort(k*(k-1)/2*res[,2]), ylim=c(0,1), main="p-valeurs (Bonferronni)")
  abline(0,1/N, col='red')
  abline(h=.05, lty=3)

  plot(sort(1-(1-res[,2])^(k*(k-1)/2)), main="p-valeurs (correction de ???)")
  abline(0,1/N, col='red')
  abline(h=.05, lty=3)
  par(op)
dev.off()

png(file="g806.png", width=600, height=600)
  library(nlme)
  data(Orthodont)
  formula(Orthodont)
  plot(Orthodont)
dev.off()

png(file="g807.png", width=600, height=600)
  plot(Orthodont, outer=T)
dev.off()

png(file="g808.png", width=600, height=600)
  data(Machines)
  bwplot(score~Machine|Worker, data=Machines)
dev.off()

png(file="g809.png", width=600, height=600)
  data(CO2)
  plot(CO2)
dev.off()

png(file="g810.png", width=600, height=600)
  plot(CO2, outer=T)
dev.off()

png(file="g811.png", width=600, height=600)
  data(InsectSprays)
  y <- InsectSprays$count
  x <- InsectSprays$spray
  boxplot(y~x, col='pink')
dev.off()

png(file="g812.png", width=600, height=600)
  library(lattice)
  histogram(~ y | x)
dev.off()

png(file="g813.png", width=600, height=600)
  qqmath(~ y | x)
  # A FAIRE : ajouter qqmathline
dev.off()

png(file="g814.png", width=600, height=600)
  n <- length(levels(x))
  res <- matrix(NA, nr=n, nc=n)
  rownames(res) <- levels(x)
  colnames(res) <- levels(x)
  for (i in 2:n) {
    for (j in 1:(i-1)) {
      res[i,j] <- t.test( y[ x == levels(x)[i] ], y[ x == levels(x)[j] ] )$p.value
    }
  }
  #res <- res * n*(n-1)/2; res <- ifelse(res>1,1,res)
  res <- 1 - (1-res)^n
  image(res, col=topo.colors(255))  # A FAIRE : peu lisible
                                    # Ecrire une fonction qui dessine des matrices 
                                    # de distance, de corr�lation, de p-valeurs.
                                    # Avec le nom des lignes/colonnes, avec une l�gende
                                    # pour les couleurs
  round(res,3)
dev.off()

png(file="g815.png", width=600, height=600)
  d <- 1-res
  d <- ifelse(is.na(d), t(d), d)
  diag(d) <- 0
  p <- isoMDS(d)$points
  plot(p, pch=16)
  text(p, levels(x), pos=c(1,2,1,1,1,3))
dev.off()

png(file="g816.png", width=600, height=600)
  n <- 10
  N <- 10
  s <- .3
  m1 <- rnorm(n, c(0,0))
  a <- rnorm(2*N*n, m1, sd=s)
  m2 <- rnorm(n, c(1,1))
  b <- rnorm(2*N*n, m2, sd=s)
  x1 <- c( a[2*(1:(N*n))], b[2*(1:(N*n))] )
  x2 <- c( a[2*(1:(N*n))-1], b[2*(1:(N*n))-1] )
  y <- c(rep(0,N*n), rep(1,N*n))
  plot( x1, x2, col=c('red','blue')[1+y] )
dev.off()

png(file="g817.png", width=600, height=600)
  plot( x1, x2, col=c('red','blue')[1+y] )
  r <- lm(y~x1+x2)
  abline( (.5-coef(r)[1])/coef(r)[3], -coef(r)[2]/coef(r)[3] )
dev.off()

png(file="g818.png", width=600, height=600)
  # J'ai besoin d'une fonction pour tracer des c�niques
  conic.plot <- function (a,b,c,d,e,f, xlim=c(-2,2), ylim=c(-2,2), n=20, ...) {
    x0 <- seq(xlim[1], xlim[2], length=n)
    y0 <- seq(ylim[1], ylim[2], length=n)
    x <- matrix( x0, nr=n, nc=n )
    y <- matrix( y0, nr=n, nc=n, byrow=T )
    z <- a*x^2 + b*x*y + c*y^2 + d*x + e*y + f
    contour(x0,y0,z, nlevels=1, levels=0, drawlabels=F, ...)
  }
  r <- lm(y~x1+x2+I(x1^2)+I(x1*x2)+I(x2^2))$coef
  plot( x1, x2, col=c('red','blue')[1+y] )
  conic.plot(r[4], r[5], r[6], r[2], r[3], r[1]-.5, 
             xlim=par('usr')[1:2], ylim=par('usr')[3:4], add=T)
dev.off()

png(file="g819.png", width=600, height=600)
  M <- 100
  d <- function (a,b, N=10) {
    mean( y[ order( (x1-a)^2 + (x2-b)^2 )[1:N] ] )
  }
  myOuter <- function (x,y,f) {
    r <- matrix(nrow=length(x), ncol=length(y))
    for (i in 1:length(x)) {
      for (j in 1:length(y)) {
        r[i,j] <- f(x[i],y[j])
      }
    }
    r
  }
  cx1 <- seq(from=min(x1), to=max(x1), length=M)
  cx2 <- seq(from=min(x2), to=max(x2), length=M)
  plot( x1, x2, col=c('red','blue')[1+y] )
  contour(cx1, cx2, myOuter(cx1,cx2,d), levels=.5, add=T)
dev.off()

png(file="g820.png", width=600, height=600)
  n <- 20
  N <- 10
  s <- .1
  m1 <- rnorm(n, c(0,0))
  a <- rnorm(2*N*n, m1, sd=s)
  m2 <- rnorm(n, c(0,0))
  b <- rnorm(2*N*n, m2, sd=s)
  x1 <- c( a[2*(1:(N*n))], b[2*(1:(N*n))] )
  x2 <- c( a[2*(1:(N*n))-1], b[2*(1:(N*n))-1] )
  y <- c(rep(0,N*n), rep(1,N*n))
  plot( x1, x2, col=c('red','blue')[1+y] )
  M <- 100
  cx1 <- seq(from=min(x1), to=max(x1), length=M)
  cx2 <- seq(from=min(x2), to=max(x2), length=M)
  #text(outer(cx1,rep(1,length(cx2))),
  #     outer(rep(1,length(cx1)), cx2),
  #     as.character(myOuter(cx1,cx2,d)))
  contour(cx1, cx2, myOuter(cx1,cx2,d), levels=.5, add=T)
  # On colorie les diff�rentes zones
  points(matrix(cx1, nr=M, nc=M),
         matrix(cx2, nr=M, nc=M, byrow=T),
         pch='.',
         col=c("red", "blue")[ as.numeric( myOuter(cx1,cx2,d) >.5 )+1])
dev.off()

png(file="g821.png", width=600, height=600)
  pastel <- .9
  plot( x1, x2, col=c('red','blue')[1+y] )
  points(matrix(cx1, nr=M, nc=M),
         matrix(cx2, nr=M, nc=M, byrow=T),
         pch=16,
         col=c(rgb(1,pastel,pastel), rgb(pastel,pastel,1))
             [ as.numeric( myOuter(cx1,cx2,d) >.5 )+1])
  points(x1, x2, col=c('red','blue')[1+y] )
  contour(cx1, cx2, myOuter(cx1,cx2,d), levels=.5, add=T)
dev.off()

png(file="g822.png", width=600, height=600)
  plot( x1, x2, col=c('red','blue')[1+y] )
  v <- c(3,10,50)
  for (i in 1:length(v)) {
    contour(cx1, cx2, 
            myOuter(cx1,cx2, function(a,b){d(a,b,v[i])}), 
            levels=.5, add=T, drawlabels=F, col=i+1)
  }
  legend(min(x1),max(x2),as.character(v),col=1+(1:length(v)), lty=1)
dev.off()

png(file="g823.png", width=600, height=600)
  get.model <- function (n=10, m=2, s=.1) {
    list( n=n, m=m, x=runif(n), y=runif(n), z=sample(1:m,n,replace=T), s=s )
  }
  get.sample <- function (model, n=200) {
    i <- sample( 1:model$n, n, replace=T )
    data.frame( x=rnorm(n, model$x[i], model$s),
                y=rnorm(n, model$y[i], model$s),
                z=model$z[i] )
  }
  nearest.neighbour.predict <- function (x, y, d, k=10) {
    o <- order( (d$x-x)^2 + (d$y-y)^2 )[1:k]
    s <- apply(outer(d[o,]$z, 1:max(d$z), '=='), 2, sum)
    order(s, decreasing=T)[1]
  }
  m <- get.model()
  d <- get.sample(m)
  N <- 1000
  d.test <- get.sample(m,N)
  n <- 50
  r <- rep(0, n)
  # Tr�s lent
  for (k in 1:n) {
    for(i in 1:N) {
      r[k] <- r[k] + 
        (nearest.neighbour.predict(d.test$x[i], d.test$y[i], d, k) != d.test$z[i] )
    }
  }
  plot(r/N, ylim=c(0,1), type='l', xlab="Taux d'erreurs")
  abline(h=c(0,.5,1), lty=3)
  rm(d.test)
dev.off()

png(file="g824.png", width=600, height=600)
  m <- get.model()
  d <- get.sample(m, 20)
  N <- 1000
  d.test <- get.sample(m,N)
  n <- 50
  r <- rep(0, n)
  # Tr�s lent
  for (k in 1:n) {
    for(i in 1:N) {
      r[k] <- r[k] + 
        (nearest.neighbour.predict(d.test$x[i], d.test$y[i], d, k) != d.test$z[i] )
    }
  }
  plot(r/N, ylim=c(0,1), type='l', xlab="Taux d'erreurs")
  abline(h=c(0,.5,1), lty=3)
  rm(d.test)
dev.off()

png(file="g825.png", width=600, height=600)
  nearest.neighbour.plot <- function (d, k=10, model=NULL) {
    col <- rainbow(max(d$z))
    plot( d$x, d$y, col=col )
    cx <- seq(min(d$x), max(d$x), length=100)
    cy <- seq(min(d$y), max(d$y), length=100)
    pastel <- .8
    colp <- round(pastel*255 + (1-pastel)*col2rgb(col))
    colp <- rgb(colp[1,], colp[2,], colp[3,], max=255)
    points(matrix(cx,nr=100,nc=100),
           matrix(cy,nr=100,nc=100,byrow=T),
           col = colp[ 
             myOuter(cx,cy, function(a,b){
               nearest.neighbour.predict(a,b,d,k)
             })
           ],
           pch=16
          )
    points( d$x, d$y, col=col )
    if(!is.null(model)){
      points(model$x,model$y,pch='+',cex=3,lwd=3,col=col[model$z])
    }
  }
  m <- get.model(n=10, m=4)
  d <- get.sample(m)
  nearest.neighbour.plot(d, model=m)
dev.off()

png(file="g826.png", width=600, height=600)
  library(MASS)
  n <- 100
  k <- 5
  x1 <- runif(k,-5,5) + rnorm(k*n)
  x2 <- runif(k,-5,5) + rnorm(k*n)
  x3 <- runif(k,-5,5) + rnorm(k*n)
  x4 <- runif(k,-5,5) + rnorm(k*n)
  x5 <- runif(k,-5,5) + rnorm(k*n)
  y <- factor(rep(1:5,n))
  plot(lda(y~x1+x2+x3+x4+x5))
dev.off()

png(file="g827.png", width=600, height=600)
  n <- 100
  x <- c(rnorm(n), 1+rnorm(n))
  y <- c(rep(0,n), rep(1,n))
  plot(y~x)
  abline(lm(y~x), col='red')
dev.off()

png(file="g828.png", width=600, height=600)
  x <- seq(0,1, length=100)
  x <- x[2:(length(x)-1)]
  logit <- function (t) {
    log( t / (1-t) )
  }
  plot(logit(x) ~ x, type='l')
dev.off()

png(file="g829.png", width=600, height=600)
  curve(logit(x), col='blue', add=F)
  curve(qnorm(x), col='red', add=T)
  a <- par("usr")
  legend( a[1], a[4], c("logit","probit"), col=c("blue","red"), lty=1)
dev.off()

png(file="g830.png", width=600, height=600)
  curve(logit(x), col='blue', add=F)
  curve(qnorm(x), col='red', add=T)
  curve(log(-log(1-x)), col='green', add=T)
  abline(h=0, lty=3)
  abline(v=0, lty=3)
  a <- par("usr")
  legend( a[1], a[4], 
          c("logit","probit", "log-log"), 
          col=c("blue","red","green"), 
          lty=1)
dev.off()

png(file="g831.png", width=600, height=600)
  ilogit <- function (l) {
    exp(l) / ( 1 + exp(l) )
  }
  fakelogit <- function (l) {
    ifelse(l>.5, 1e6, -1e6)
  }
  n <- 100
  x <- c(rnorm(n), 1+rnorm(n))
  y <- c(rep(0,n), rep(1,n))
  yy <- fakelogit(y)
  xp <- seq(min(x),max(x),length=200)
  yp <- ilogit(predict(lm(yy~x), data.frame(x=xp)))
  yp[is.na(yp)] <- 1
  plot(y~x)
  lines(xp,yp, col='red', lwd=3)
dev.off()

png(file="g832.png", width=600, height=600)
  n <- 100
  x <- c(rnorm(n), 1+rnorm(n))
  y <- c(rep(0,n), rep(1,n))
  f <- function (a) {
    -sum(log(ilogit(a[1]+a[2]*x[y==1]))) - sum(log(1-ilogit(a[1]+a[2]*x[y==0])))
  }
  r <- optim(c(0,1),f)
  a <- r$par[1]
  b <- r$par[2]
  plot(y~x)
  curve( dnorm(x,1,1)*.5/(dnorm(x,1,1)*.5+dnorm(x,0,1)*(1-.5)), add=T, col='red')
  curve( ilogit(a+b*x), add=T )
  legend( .95*par('usr')[1]+.05*par('usr')[2],
          .9,
          c('courbe th�orique', 'MLE'),
          col=c('red', par('fg')),
          lty=1, lwd=1)
  title(main="R�gression logistique � la main")
dev.off()

png(file="g833.png", width=600, height=600)
  #
  # ATTENTION !!!
  # Surtout ne pas oublier l'argument "family" -- sinon, on fait une r�gression lin�aire...
  #
  r <- glm(y~x, family=binomial)
  plot(y~x)
  abline(lm(y~x),col='red',lty=2)
  xx <- seq(min(x), max(x), length=100)
  yy <- predict(r, data.frame(x=xx), type='response')
  lines(xx,yy, col='blue', lwd=5, lty=2)
  lines(xx, ilogit(r$coef[1]+xx*r$coef[2]))
  legend( .95*par('usr')[1]+.05*par('usr')[2],
          .9,
          c('r�gression lin�aire', 
            "pr�diction � l'aide de la commande predict",
            "pr�diction � l'aide des coefficients"),
          col=c('red', 'blue', par('fg')),
          lty=c(2,2,1), lwd=c(1,5,1))
  title(main="R�gression logistique avec la commande glm")
dev.off()

png(file="g834.png", width=600, height=600)
  n <- 100
  x <- c(rnorm(n), 1+rnorm(n))
  y <- c(rep(0,n), rep(1,n))
  plot(y~x)
  # pr�diction brutale
  m1 <- mean(x[y==0])
  m2 <- mean(x[y==1])
  m <- mean(c(m1,m2))
  if(m1<m2) a <- 0
  if(m1>m2) a <- 1
  if(m1==m2) a <- .5
  lines( c(min(x),m,m,max(x)),
         c(a,a,1-a,1-a),
         col='blue')  
  # r�gression lin�aire
  abline(lm(y~x), col='red')
  # r�gression logistique
  xp <- seq(min(x),max(x),length=200)
  r <- glm(y~x, family=binomial)
  yp <- predict(r, data.frame(x=xp), type='response')
  lines(xp,yp, col='orange') 
  # Courbe th�orique
  curve( dnorm(x,1,1)*.5/(dnorm(x,1,1)*.5+dnorm(x,0,1)*(1-.5)), add=T, lty=3, lwd=3)
  legend( .95*par('usr')[1]+.05*par('usr')[2],
          .9, #par('usr')[4],
          c('pr�diction brutale', "r�gression lin�aire", "r�gression logistique",
            "courbe th�orique"),
          col=c('blue','red','orange', par('fg')),
          lty=c(1,1,1,3),lwd=c(1,1,1,3))
  title(main="Comparaison des r�gressions lin�aire et logistique")
dev.off()

png(file="g835.png", width=600, height=600)
  n <- 100
  x <- c(rnorm(n), 1+rnorm(n))
  y <- c(rep(0,n), rep(1,n))
  r <- glm(y~x, family=binomial)
  plot(r, which=1)
dev.off()

png(file="g836.png", width=600, height=600)
  n <- 1000
  a <- -2
  b <- 1
  x <- runif(n, -4, 5)
  y <- exp(a*x+b + rnorm(n))
  y <- y/(1+y)
  y <- rbinom(n,1,y)
  plot(y~x)
dev.off()

png(file="g837.png", width=600, height=600)
  boxplot(x~y, horizontal=T)
dev.off()

png(file="g838.png", width=600, height=600)
  op <- par(mfrow=c(2,1))
  hist(x[y==1], probability=T, col='light blue')
  lines(density(x[y==1]),col='red',lwd=3)
  hist(x[y==0], probability=T, col='light blue')
  lines(density(x[y==0]),col='red',lwd=3)
  par(op)
dev.off()

png(file="g839.png", width=600, height=600)
  rt <- glm(y~x, family=binomial)
  plot(rt, which=1)
dev.off()

png(file="g840.png", width=600, height=600)
  plot(rt, which=2)
dev.off()

png(file="g841.png", width=600, height=600)
  hist(rt$residuals, breaks=seq(min(rt$residuals),max(rt$residuals)+1,by=.5),
       xlim=c(-10,10),
       probability=T, col='light blue')
  points(density(rt$residuals, bw=.5), type='l', lwd=3, col='red')
dev.off()

png(file="g842.png", width=600, height=600)
  plot(rt, which=3)
dev.off()

png(file="g843.png", width=600, height=600)
  plot(rt, which=4)
dev.off()

png(file="g844.png", width=600, height=600)
  # C'est sens� ne pas �tre la m�me que dans le cas lin�aire : l�, c'est la m�me...
  plot(hat(x), type='h')
dev.off()

png(file="g845.png", width=600, height=600)
  plot(rt, which=4)
dev.off()

png(file="g846.png", width=600, height=600)
  n <- 1000
  y <- factor(sample(0:1,n,replace=T))
  x <- rnorm(n)
  r <- glm(y~x,family=binomial)
  op <- par(mfrow=c(2,2))
  plot(r,ask=F)
  par(op)
dev.off()

png(file="g847.png", width=600, height=600)
  library(Design)
  r <- lrm(y~x,y=T,x=T)
  P <- resid(r,"gof")['P']
  resid(r,"partial",pl=T)
  title(signif(P))
dev.off()

png(file="g848.png", width=600, height=600)
  n <- 1000
  x <- rnorm(n)
  a <- 1
  b <- -2
  p <- exp(a+b*x)/(1+exp(a+b*x))
  y <- factor(ifelse( runif(n)<p, 1, 0 ), levels=0:1)
  r <- glm(y~x,family=binomial)
  op <- par(mfrow=c(2,2))
  plot(r,ask=F)
  par(op)
dev.off()

png(file="g849.png", width=600, height=600)
  r <- lrm(y~x,y=T,x=T)
  P <- resid(r,"gof")['P']
  resid(r,"partial",pl=T)
  title(signif(P))
dev.off()

png(file="g850.png", width=600, height=600)
  n <- 1000
  x <- rnorm(n)
  a <- 1
  b <- -2
  p <- exp(a+b*x)/(1+exp(a+b*x))
  y <- ifelse( runif(n)<p, 1, 0 )
  i <- runif(n)<.1
  y <- ifelse(i, 1-y, y)
  y <- factor(y, levels=0:1)
  col=c(par('fg'),'red')[1+as.numeric(i)]
  r <- glm(y~x,family=binomial)
  op <- par(mfrow=c(2,2))
  plot(r,ask=F, col=col)
  par(op)
dev.off()

png(file="g851.png", width=600, height=600)
  r <- lrm(y~x,y=T,x=T)
  P <- resid(r,"gof")['P']
  resid(r,"partial",pl=T)
  title(signif(P))
dev.off()

png(file="g852.png", width=600, height=600)
  n <- 1000
  x <- rnorm(n)
  a <- 1
  b <- -2
  p <- exp(a+b*x)/(1+exp(a+b*x))
  y <- ifelse( runif(n)<p, 1, 0 )
  i <- runif(n)<.5 & abs(x)>1
  y <- ifelse(i, 1-y, y)
  y <- factor(y, levels=0:1)
  col=c(par('fg'),'red')[1+as.numeric(i)]
  r <- glm(y~x,family=binomial)
  op <- par(mfrow=c(2,2))
  plot(r,ask=F, col=col)
  par(op)
dev.off()

png(file="g853.png", width=600, height=600)
  r <- lrm(y~x,y=T,x=T)
  P <- resid(r,"gof")['P']
  resid(r,"partial",pl=T)
  title(signif(P))
dev.off()

png(file="g854.png", width=600, height=600)
  n <- 1000
  x1 <- rnorm(n)
  x2 <- rnorm(n)
  a <- 1
  b <- -2
  p <- exp(a+b*x1)/(1+exp(a+b*x1))
  y <- factor(ifelse( runif(n)<p, 1, 0 ), levels=0:1)
  r <- glm(y~x1+x2,family=binomial)
  op <- par(mfrow=c(2,2))
  plot(r,ask=F)
  par(op)
dev.off()

png(file="g855.png", width=600, height=600)
  r <- lrm(y~x,y=T,x=T)
  P <- resid(r,"gof")['P']
  resid(r,"partial",pl=T)
  title(signif(P))
dev.off()

png(file="g856.png", width=600, height=600)
  n <- 1000
  x <- rnorm(n)
  a <- 1
  b1 <- -1
  b2 <- -2
  p <- 1/(1+exp(-(a+b1*x+b2*x^2)))
  y <- factor(ifelse( runif(n)<p, 1, 0 ), levels=0:1)
  r <- glm(y~x,family=binomial)
  op <- par(mfrow=c(2,2))
  plot(r,ask=F)
  par(op)
dev.off()

png(file="g857.png", width=600, height=600)
  r <- lrm(y~x,y=T,x=T)
  P <- resid(r,"gof")['P']
  resid(r,"partial",pl=T)
  title(signif(P))
dev.off()

png(file="g858.png", width=600, height=600)
  # NON
  n <- 100
  x <- c( rnorm(n), 1+rnorm(n), 2.5+rnorm(n) )
  y <- factor(c( rep(0,n), rep(1,n), rep(2,n) ))
  r <- glm(y~x, family=binomial)
  plot(as.numeric(y)-1~x)
  xp <- seq(-5,5,length=200)
  yp <- predict(r,data.frame(x=xp), type='response')
  lines(xp,yp)
dev.off()

png(file="g859.png", width=600, height=600)
  n <- 100
  x <- c( rnorm(n), 10+rnorm(n), 25+rnorm(n), -7 + rnorm(n) )
  y <- factor(c( rep(0,n), rep(1,n), rep(2,n), rep(3,n) ))
  y1 <- factor(c( rep(0,n), rep(0,n), rep(1,n), rep(1,n) ))
  y2 <- factor(c( rep(0,n), rep(1,n), rep(0,n), rep(1,n) ))
  r1 <- glm(y1~x, family=binomial)
  r2 <- glm(y2~x, family=binomial)
  xp <- seq(-50,50,length=500)
  y1p <- predict(r1,data.frame(x=xp), type='response')
  y2p <- predict(r2,data.frame(x=xp), type='response')

  plot(as.numeric(y)-1~x)
  lines(xp,y1p+2*y2p)
  lines(xp,y1p, col='red')
  lines(xp,y2p, col='blue')
dev.off()

png(file="g860.png", width=600, height=600)
  plot(as.numeric(y1)-1~x)
  lines(xp,y1p, col='red')
dev.off()

png(file="g861.png", width=600, height=600)
  n <- 100
  x <- c( rnorm(n), 10+rnorm(n), 25+rnorm(n), -7 + rnorm(n) )
  y <- factor(c( rep(0,n), rep(1,n), rep(2,n), rep(3,n) ))
  y1 <- factor(c( rep(0,n), rep(1,n), rep(1,n), rep(1,n) ))
  y2 <- factor(c( rep(0,n), rep(0,n), rep(1,n), rep(1,n) ))
  y3 <- factor(c( rep(0,n), rep(0,n), rep(0,n), rep(1,n) ))
  r1 <- glm(y1~x, family=binomial)
  r2 <- glm(y2~x, family=binomial)
  r3 <- glm(y3~x, family=binomial)
  xp <- seq(-50,50,length=500)
  y1p <- predict(r1,data.frame(x=xp), type='response')
  y2p <- predict(r2,data.frame(x=xp), type='response')
  y3p <- predict(r3,data.frame(x=xp), type='response')

  plot(as.numeric(y)-1~x)
  lines(xp,y1p+y2p+y3p)
dev.off()

png(file="g862.png", width=600, height=600)
  plot(as.numeric(y1)-1~x)
  lines(xp,y1p, col='red')
dev.off()

png(file="g863.png", width=600, height=600)
  n <- 100
  x <- c( -7+rnorm(n), rnorm(n), 10+rnorm(n), 25+rnorm(n))
  y <- factor(c( rep(0,n), rep(1,n), rep(2,n), rep(3,n) ))
  y1 <- factor(c( rep(0,n), rep(1,n), rep(1,n), rep(1,n) ))
  y2 <- factor(c( rep(0,n), rep(0,n), rep(1,n), rep(1,n) ))
  y3 <- factor(c( rep(0,n), rep(0,n), rep(0,n), rep(1,n) ))
  r1 <- glm(y1~x, family=binomial)
  r2 <- glm(y2~x, family=binomial)
  r3 <- glm(y3~x, family=binomial)
  xp <- seq(-50,50,length=500)
  y1p <- predict(r1,data.frame(x=xp), type='response')
  y2p <- predict(r2,data.frame(x=xp), type='response')
  y3p <- predict(r3,data.frame(x=xp), type='response')

  plot(as.numeric(y)-1~x)
  lines(xp,y1p+y2p+y3p)
dev.off()

png(file="g864.png", width=600, height=600)
  n <- 100
  x <- c( -.7+rnorm(n), rnorm(n), 1+rnorm(n), 2.5+rnorm(n))
  y <- factor(c( rep(0,n), rep(1,n), rep(2,n), rep(3,n) ))
  y1 <- factor(c( rep(0,n), rep(1,n), rep(1,n), rep(1,n) ))
  y2 <- factor(c( rep(0,n), rep(0,n), rep(1,n), rep(1,n) ))
  y3 <- factor(c( rep(0,n), rep(0,n), rep(0,n), rep(1,n) ))
  r1 <- glm(y1~x, family=binomial)
  r2 <- glm(y2~x, family=binomial)
  r3 <- glm(y3~x, family=binomial)
  xp <- seq(-5,5,length=500)
  y1p <- predict(r1,data.frame(x=xp), type='response')
  y2p <- predict(r2,data.frame(x=xp), type='response')
  y3p <- predict(r3,data.frame(x=xp), type='response')

  plot(as.numeric(y)-1~x)
  lines(xp,y1p+y2p+y3p)
  lines(xp,round(y1p+y2p+y3p, digits=0), col='red')
dev.off()

png(file="g865.png", width=600, height=600)
  n <- 100
  x <- c( -.7+rnorm(n), rnorm(n), 1+rnorm(n), 2.5+rnorm(n))
  y <- factor(c( rep(0,n), rep(1,n), rep(2,n), rep(3,n) ))
  ordinal.regression.one <- function (y,x) {
    xp <- seq(min(x),max(x), length=100)
    yi <- matrix(nc=length(levels(y)), nr=length(y))
    ri <- list();
    ypi <- matrix(nc=length(levels(y)), nr=100)
    for (i in 1:length(levels(y))) {
      yi[,i] <- as.numeric(y) >= i
      ri[[i]] <- glm(yi[,i] ~ x, family=binomial)
      ypi[,i] <- predict(ri[[i]], data.frame(x=xp), type='response')
    }
    plot(as.numeric(y) ~ x)
    lines(xp, apply(ypi,1,sum), col='red', lwd=3)
  }
  ordinal.regression.one(y,x)
dev.off()

png(file="g866.png", width=600, height=600)
  n <- 100
  v <- .2
  x <- c( -.7+v*rnorm(n), v*rnorm(n), 1+v*rnorm(n), 2.5+v*rnorm(n))
  y <- factor(c( rep(0,n), rep(1,n), rep(2,n), rep(3,n) ))
  ordinal.regression.one(y,x)
dev.off()

png(file="g867.png", width=600, height=600)
  n <- 100
  x <- c( -.7+rnorm(n), rnorm(n), 1+rnorm(n), 2.5+rnorm(n))
  y <- factor(c( rep(0,n), rep(1,n), rep(2,n), rep(3,n) ))
  ordinal.regression.two <- function (y,x) {
    xp <- seq(min(x),max(x), length=100)
    yi <- list();
    ri <- list();
    ypi <- matrix(nc=length(levels(y)), nr=100)
    for (i in 1:length(levels(y))) {
      ya <- as.numeric(y)
      o <- ya >= i
      ya <- ya[o]
      xa <- x[o]
      yi[[i]] <- ya == i
      ri[[i]] <- glm(yi[[i]] ~ xa, family=binomial)
      ypi[,i] <- predict(ri[[i]], data.frame(xa=xp), type='response')
    }

    # Le dessin est un peu plus compliqu� � faire que tout-�-l'heure...
    plot(as.numeric(y) ~ x)
    p <- matrix(0, nc=length(levels(y)), nr=100)
    for (i in 1:length(levels(y))) {
      p[,i] = ypi[,i] * (1 - apply(p,1,sum))
    }
    for (i in 1:length(levels(y))) {
      p[,i] = p[,i]*i
    }
    lines(xp, apply(p,1,sum), col='red', lwd=3)
  }
  ordinal.regression.two(y,x)
dev.off()

png(file="g868.png", width=600, height=600)
  n <- 100
  v <- .1
  x <- c( -.7+v*rnorm(n), v*rnorm(n), 1+v*rnorm(n), 2.5+v*rnorm(n))
  y <- factor(c( rep(0,n), rep(1,n), rep(2,n), rep(3,n) ))
  ordinal.regression.two(y,x)
dev.off()

png(file="g869.png", width=600, height=600)
  op <- par(mfrow=c(3,1))
  n <- 20
  lambda <- rep(2,n)
  x <- seq(0,2,length=n)
  plot(lambda ~ x, type='l', main=expression(lambda))
  plot(lambda*x ~ x, type='l', main=expression(Lambda))
  plot(exp(-lambda*x) ~ x, type='l', main="S")
  par(op)
dev.off()

png(file="g870.png", width=600, height=600)
  op <- par(mfrow=c(3,1))
  n <- 20
  alpha <- 1
  g <- rep(2,n)
  x <- seq(0,2,length=n)
  plot(g * alpha * x^(g-1) ~ x, type='l', main=expression(lambda (gamma==2)))
  plot(alpha * x^g ~ x, type='l', main=expression(Lambda))
  plot(exp(-alpha*x^g) ~ x, type='l', main="S")
  par(op)
dev.off()

png(file="g871.png", width=600, height=600)
  op <- par(mfrow=c(3,1))
  n <- 20
  alpha <- 1
  g <- rep(.5,n)
  x <- seq(0,2,length=n)
  plot(g * alpha * x^(g-1) ~ x, type='l', main=expression(lambda (gamma==.5)))
  plot(alpha * x^g ~ x, type='l', main=expression(Lambda))
  plot(exp(-alpha*x^g) ~ x, type='l', main="S")
  par(op)
dev.off()

png(file="g872.png", width=600, height=600)
  op <- par(mfrow=c(3,1))
  n <- 200
  x <- seq(0,5,length=n)
  plot(1-plnorm(x) ~ x, type='l', main="S")
  L <- function (x) { -log(1-plnorm(x)) }
  plot(L(x) ~ x, type='l', main=expression(Lambda))
  h <- .001
  plot( (L(x+h)-L(x))/h ~ x, type='l', main=expression(lambda))
  par(op)
dev.off()

png(file="g873.png", width=600, height=600)
  set.seed(87638)
  library(survival)
  n <- 200
  x <- rweibull(n,.5)
  y <- rexp(n,1/mean(x))
  s <- Surv(ifelse(x<y,x,y), x<=y)
  plot(s) # peu informatif
dev.off()

png(file="g874.png", width=600, height=600)
  plot(survfit(s))
  lines(survfit(s, type='fleming-harrington'), col='red')
  r <- survfit(s)
  lines( 1-pweibull( r$time, .5 ) ~ r$time, lty=3, lwd=3, col='blue' )
  legend( par("usr")[2], par("usr")[4], yjust=1, xjust=1,
          c("Kaplan-Meier", "Fleming-Harrington", "Fonction de survie th�orique"),
          lwd=c(1,1,3), lty=c(1,1,3),
          col=c(par("fg"), 'red', 'blue'))
  title(main="Fonction de survie (estimation de Kaplan-Meier)")
dev.off()

png(file="g875.png", width=600, height=600)
  op <- par(mfrow=c(3,1))
  r <- survfit(s)
  plot(r$surv ~ r$time, type='l', main="S")
  curve( 1-pweibull(x,.5,1), col='red', lty=2, add=T )
  plot(-log(r$surv) ~ r$time, type='l', main=expression(Lambda))
  curve( -log(1-pweibull(x,.5,1)), col='red', lty=2, add=T )
  # Avant de d�river, on commence par lisser Lambda
  a <- -log(r$surv)
  b <- r$time
  library(modreg)
  l <- loess(a~b)
  bb <- seq(min(b),max(b),length=200)
  aa <- predict(l, data.frame(b=bb))
  plot( diff(aa) ~ bb[-1], type='l', main=expression(lambda) )
  aa <- -log(1-pweibull(bb,.5,1))
  lines( diff(aa) ~ bb[-1], col='red', lty=2 )
  par(op)
dev.off()

png(file="g876.png", width=600, height=600)
  plot(r, fun="log", main="log-survival curve")
dev.off()

png(file="g877.png", width=600, height=600)
  plot(r, fun="event", main="cumulative events: f(y)=1-y")
dev.off()

png(file="g878.png", width=600, height=600)
  plot(r, fun="cumhaz", main="cumulative hazard: f(y)=-log(y)=Lambda")
dev.off()

png(file="g879.png", width=600, height=600)
  try(
    plot(r, fun="cloglog", main="complementary log-log plot")
  )
  # f(y)=log(-log(y)), log-scale on the x-axis
dev.off()

png(file="g880.png", width=600, height=600)
  n <- 200
  x1 <- rweibull(n,.5)
  x2 <- rweibull(n,1.2)
  f <- factor( sample(1:2, n, replace=T), levels=1:2 )
  x <- ifelse(f==1,x1,x2)
  y <- rexp(n,1/mean(x))
  s <- Surv(ifelse(x<y,x,y), x<=y)
  plot(s, col=as.numeric(f))
dev.off()

png(file="g881.png", width=600, height=600)
  plot( density(s[,1][ s[,2] == 1 & f == 1]), lwd=3,
        main="Analyse de la survie, un facteur" )
  lines( density(s[,1][ s[,2] == 0 & f == 1]), lty=2, lwd=3 )
  lines( density(s[,1][ s[,2] == 1 & f == 2]), col='red', lwd=3 )
  lines( density(s[,1][ s[,2] == 0 & f == 2]), lty=2, col='red', lwd=3 )
  legend( par("usr")[2], par("usr")[4], yjust=1, xjust=1,
          c("non censored, f = 1", "censored, f = 1",
            "non censored, f = 2", "censored, f = 2"),
          lty=c(1,2,1,2),
          lwd=1,
          col=c(par('fg'), par('fg'), 'red', 'red') )
dev.off()

png(file="g882.png", width=600, height=600)
  plot(survfit(s ~ f), col=as.numeric(levels(f)))
dev.off()

png(file="g883.png", width=600, height=600)
  data(lung)
  x <- Surv(lung$time, lung$status)
  plot(x)
dev.off()

png(file="g884.png", width=600, height=600)
  plot(survfit(x))
dev.off()

png(file="g885.png", width=600, height=600)
  data(lung)
  x <- Surv(lung$time, lung$status)
  f <- function (p,t) { dweibull(t,p[1],p[2]) }
  S <- function (p,t) { 1-pweibull(t,p[1],p[2]) }
  ll <- function (p) {
    time <- x[,1]
    status <- x[,2]
    censored <- 0
    dead <- 1
    # cat(p); cat("\n"); str(time); cat("\n");
    -2*( sum(log(f(p,time[status==dead]))) + sum(log(S(p,time[status==censored]))) )
  }

  # Quelques estimations du second param�tre
  m <- 1     # Ne marche pas
  m <- 100
  s <- survfit(x)
  m <- mean(s$time)
  m <- max(s$time[s$surv>.5])

  r <- optim( c(1,m), ll )

  # Dessinons la log-vraissemblance
  myOuter <- function (x,y,f) {
    r <- matrix(nrow=length(x), ncol=length(y))
    for (i in 1:length(x)) {
      for (j in 1:length(y)) {
        r[i,j] <- f(x[i],y[j])
      }
    }
    r
  }
  lll <- function (u,v) { 
    r <- ll(c(u,v)) 
    if(r==Inf) r <- NA
    r
  }
  a <- seq(1,1.6,length=50)
  b <- seq(100,700,length=50)
  ab <- myOuter(a,b,lll)
  persp(a,b,ab)
dev.off()

png(file="g886.png", width=600, height=600)
  op <- par(mfrow=c(3,3))
  for (i in seq(0,360,length=10)[-10]) {
    persp(a,b,ab,theta=i)
  }
  par(op)
dev.off()

png(file="g887.png", width=600, height=600)
  image(a,b,ab)
  points(r$par[1],r$par[2],lwd=3,cex=3)
dev.off()

png(file="g888.png", width=600, height=600)
  n <- 255
  image(a,b,ab, col=topo.colors(n), breaks=quantile(ab,(0:n)/n, na.rm=T))
  points(r$par[1],r$par[2],lwd=3,cex=3)
dev.off()

png(file="g889.png", width=600, height=600)
  image(a,b,ab, col=topo.colors(n), breaks=quantile(ab,((0:n)/n)^2,na.rm=T))
  points(r$par[1],r$par[2],lwd=3,cex=3)
dev.off()

png(file="g890.png", width=600, height=600)
  plot(survfit(x))
  curve( 1-pweibull(x,r$par[1],r$par[2]), add=T, col='red', lwd=3, lty=2 )
dev.off()

png(file="g891.png", width=600, height=600)
  ph.mle.weibull <- function (x) {
    f <- function (p,t) { dweibull(t,p[1],p[2]) }
    S <- function (p,t) { 1-pweibull(t,p[1],p[2]) }
    m <- mean(survfit(x)$time)
    ph.mle.optim(x,f,S,c(1,m))
  }
  ph.mle.exp <- function (x) {
    f <- function (p,t) { dexp(t,p) }
    S <- function (p,t) { 1-pexp(t,p) }
    m <- mean(survfit(x)$time)
    ph.mle.optim(x,f,S,1/m)
  }
  ph.mle.gamma <- function (x) {
    f <- function (p,t) { dgamma(t,p[1],p[2]) }
    S <- function (p,t) { 1-pgamma(t,p[1],p[2]) }
    m <- mean(survfit(x)$time)
    ph.mle.optim(x,f,S,c(1,1/m))
  }
  ph.mle.optim <- function (x,f,S,m) {
    ll <- function (p) {
      time <- x[,1]
      status <- x[,2]
      censored <- 0
      dead <- 1
      -2*( sum(log(f(p,time[status==dead]))) + sum(log(S(p,time[status==censored]))) )
    }
    optim(m,ll)
  }
  eda.surv <- function (x) {
    r <- survfit(x)
    plot(r)
    a1 <- ph.mle.exp(x)$par
    lines( 1-pexp(r$time,a1) ~ r$time, col='red' )
    a2 <- ph.mle.weibull(x)$par
    lines( 1-pweibull(r$time,a2[1],a2[2]) ~ r$time, col='green' )
    a3 <- ph.mle.gamma(x)$par
    lines( 1-pgamma(r$time,a3[1],a3[2]) ~ r$time, col='blue' )
    legend( par("usr")[2], par("usr")[4], yjust=1, xjust=1,
            c(paste("Exponentielle(", signif(a1,2), ")", sep=''), 
              paste("Weibull(", signif(a2[1],2), ", ", signif(a2[2],2), ")", sep=''), 
              paste("Gamma(", signif(a3[1],2), ", ", signif(a3[2],2), ")", sep='')
            ),
            lwd=1, lty=1,
            col=c('red', 'green', 'blue'))
    title(main="Parametric estimation of PH models")
  }

  data(lung)
  x <- Surv(lung$time, lung$status)
  eda.surv(x)
dev.off()

png(file="g892.png", width=600, height=600)
  x <- Surv(lung$time, lung$status)
  r <- survfit(x)
  a1 <- ph.mle.exp(x)$par
  t1 = 1-pexp(r$time,a1)
  a2 <- ph.mle.weibull(x)$par
  t2 <- 1-pweibull(r$time,a2[1],a2[2])
  a3 <- ph.mle.gamma(x)$par
  t3 <- 1-pgamma(r$time,a3[1],a3[2])
  plot( t1 ~ r$surv, col='red', xlab='sample', ylab='model')
  points( t2 ~ r$surv, col='green')
  points( t3 ~ r$surv, col='blue' )
  abline(0,1)
  legend( par("usr")[1], par("usr")[4], yjust=1, xjust=0,
          c(paste("Exponentielle(", signif(a1,2), ")", sep=''), 
            paste("Weibull(", signif(a2[1],2), ", ", signif(a2[2],2), ")", sep=''), 
            paste("Gamma(", signif(a3[1],2), ", ", signif(a3[2],2), ")", sep='')
          ),
          lwd=1, lty=1,
          col=c('red', 'green', 'blue'))
  title(main="Parametric estimation of PH models")
dev.off()

png(file="g893.png", width=600, height=600)
  plot( t1 - r$surv ~ t1, col='red', xlab='predicted values', ylab='residuals')
  points( t2 - r$surv ~ t2, col='green')
  points( t3 - r$surv ~ t3, col='blue' )
  abline(h=0, lty=3)
  legend( par("usr")[2], par("usr")[4], yjust=1, xjust=1,
          c(paste("Exponentielle(", signif(a1,2), ")", sep=''), 
            paste("Weibull(", signif(a2[1],2), ", ", signif(a2[2],2), ")", sep=''), 
            paste("Gamma(", signif(a3[1],2), ", ", signif(a3[2],2), ")", sep='')
          ),
          lwd=1, lty=1,
          col=c('red', 'green', 'blue'))
  title(main="Parametric estimation of PH models")  
dev.off()

png(file="g894.png", width=600, height=600)
  plot( abs(t1 - r$surv) ~ t1, col='red', 
        xlab='predicted values', ylab=expression( abs(residuals) ))
  points( abs(t2 - r$surv) ~ t2, col='green')
  points( abs(t3 - r$surv) ~ t3, col='blue' )
  abline(h=0, lty=3)
  legend( par("usr")[2], par("usr")[4], yjust=1, xjust=1,
          c(paste("Exponentielle(", signif(a1,2), ")", sep=''), 
            paste("Weibull(", signif(a2[1],2), ", ", signif(a2[2],2), ")", sep=''), 
            paste("Gamma(", signif(a3[1],2), ", ", signif(a3[2],2), ")", sep='')
          ),
          lwd=1, lty=1,
          col=c('red', 'green', 'blue'))
  title(main="Parametric estimation of PH models")  
dev.off()

png(file="g895.png", width=600, height=200)
  library(ts)
  data(LakeHuron)
  x <- LakeHuron
  plot(x)
dev.off()

png(file="g896.png", width=600, height=600)
  data(sunspots)
  x <- window(sunspots, start=1750, end=1800)
  plot(x)
  plot(x, type='p')
  k <- 20
  lines(filter(x, rep(1/k,k)), col='red', lwd=3)
dev.off()

png(file="g897.png", width=600, height=300)
  data(UKgas)
  plot.band <- function (x, ...) {
    plot(x, ...)
    a <- time(x)
    i1 <- floor(min(a))
    i2 <- ceiling(max(a))
    y1 <- par('usr')[3]
    y2 <- par('usr')[4]
    if( par("ylog") ){
      y1 <- 10^y1
      y2 <- 10^y2
    }
    for (i in seq(from=i1, to=i2-1, by=2)) {
      polygon( c(i,i+1,i+1,i), c(y1,y1,y2,y2), col='grey', border=NA )
    }
    par(new=T)
    plot(x, ...)
  }
  plot.band(UKgas, log='y')
dev.off()

png(file="g898.png", width=600, height=300)
  data(LakeHuron)
  x <- LakeHuron
  op <- par(mfrow=c(1,2))
  hist(x)
  qqnorm(x)
  qqline(x, col='red')
  par(op)
dev.off()

png(file="g899.png", width=600, height=200)
  boxplot(x, horizontal=T)
dev.off()

png(file="g900.png", width=600, height=300)
  plot(x)
dev.off()

png(file="g901.png", width=600, height=600)
  n <- length(x)
  k <- 5
  m <- matrix(nr=n+k-1, nc=k)
  for (i in 1:k) {
    m[,i] <- c(rep(NA,i-1), x, rep(NA, k-i))
  }
  pairs(m, lower.panel = panel.smooth,
        upper.panel = function (x,y) {
          panel.smooth(x,y)
          par(usr = c(0, 1, 0, 1))
          a <- cor(x,y, use='pairwise.complete.obs')
          text(.1,.9, 
               adj=c(0,1),
               round(a, digits=2),
               col='blue',
               cex=2*a)
        })
dev.off()

png(file="g902.png", width=600, height=600)
  op <- par(mfrow=c(3,1))
  acf(x)
  pacf(x)
  spectrum(x)
  par(op)
dev.off()

png(file="g903.png", width=600, height=600)
  op <- par(mfrow=c(3,3))

  n <- 100
  k <- 5
  N <- k*n
  x <- (1:N)/n
  y1 <- rnorm(N)
  plot(ts(y1))

  y2 <- cumsum(rnorm(N))
  plot(ts(y2))

  y3 <- cumsum(rnorm(N))+rnorm(N)
  plot(ts(y3))

  y4 <- cumsum(cumsum(rnorm(N)))
  plot(ts(y4))

  y5 <- cumsum(cumsum(rnorm(N))+rnorm(N))+rnorm(N)
  plot(ts(y5))

  # With a trend
  y6 <- 1 - x + cumsum(rnorm(N)) + .2 * rnorm(N)
  plot(ts(y6))

  y7 <- 1 - x - .2*x^2 + cumsum(rnorm(N)) + .2 * rnorm(N)
  plot(ts(y7))

  # With a seasonnal component
  y8 <- .3 + .5*cos(2*pi*x) - 1.2*sin(2*pi*x) +
        .6*cos(2*2*pi*x) + .2*sin(2*2*pi*x) +
        -.5*cos(3*2*pi*x) + .8*sin(3*2*pi*x)
  plot(ts(y8+ .2*rnorm(N)))
  lines(y8, type='l', lty=3, lwd=3, col='red')

  y9 <- y8 + cumsum(rnorm(N)) + .2*rnorm(N)
  plot(ts(y9))
  par(op)
dev.off()

png(file="g904.png", width=600, height=600)
  my.acf <- function (x, lag.max = ceiling(5*log(length(x)))) {
    m <- matrix( 
      c( NA, 
         rep( c(rep(NA, lag.max-1), x),
              lag.max ),
         rep(NA,, lag.max-1)
       ),
      byrow=T,
      nr=lag.max)
    x0 <- m[1,]
    apply(m,1,cor, x0, use="complete")
  }
  n <- 200
  x <- rnorm(n)
  plot(my.acf(x), type='h')
  abline(h=0)
dev.off()

png(file="g905.png", width=600, height=600)
  op <- par(mfrow=c(2,1))
  acf(x, main="fonction d'autocorr�lation d'un bruit blanc")
  x <- LakeHuron
  acf(x, main="fonction d'autocorr�lation d'une s�rie temporelle")
  par(op)
dev.off()

png(file="g906.png", width=600, height=600)
  op <- par(mfrow=c(3,3))
  for (y in sample(list(y1,y2,y3,y4,y5,y6,y7,y8,y9))) {
    acf(y)
  }
  par(op)
dev.off()

png(file="g907.png", width=600, height=300)
  op <- par()
  layout( matrix(c(1,2),nr=1,nc=2), widths=c(3,1) )
  n <- 100
  x <- ts(rnorm(n))
  plot(x)
  abline(h=0, lty=3)
  title(main="Bruit iid normal")
  hist(x, main='')
  par(op)
dev.off()

png(file="g908.png", width=600, height=300)
  op <- par()
  layout( matrix(c(1,2),nr=1,nc=2), widths=c(3,1) )
  n <- 100
  x <- ts(runif(n,-1,1))
  plot(x)
  abline(h=0, lty=3)
  title(main="Bruit iid non normal")
  hist(x, main='')
  par(op)
dev.off()

png(file="g909.png", width=600, height=300)
  plot(ts(rnorm(100)^3))
  abline(h=0, lty=3)
  title(main="Bruit iid non normal")
dev.off()

png(file="g910.png", width=600, height=300)
  n <- 100
  x <- rep(0,n)
  z <- rnorm(n)
  for (i in 2:n) {
    x[i] <- z[i] * sqrt( 1 + .5 * x[i-1]^2 )
  }
  plot(ts(x))
  abline(h=0, lty=3)
  title("Bruit non iid")
dev.off()

png(file="g911.png", width=600, height=300)
  n <- 100
  x <- rep(.7, n)
  for (i in 2:n) {
    x[i] <- 4 * x[i-1] * ( 1 - x[i-1] )
  }
  x <- x - mean(x)
  plot(ts(x))
  abline(h=0, lty=3) 
  title(main="Une suite d�terministe")
dev.off()

png(file="g912.png", width=600, height=600)
  n <- 1000
  tn <- cumsum(rexp(n))
  # Une fonction, de classe C^infini, d�finie comme une somme de 
  # densit�s gaussiennes.
  f <- function (x) { 
    # si x est un seul nombre : sum(dnorm(x-tn))
    apply( dnorm( outer(x,rep(1,length(tn))) - outer(rep(1,length(x)),tn) ),
           1,
           sum )
  }
  op <- par(mfrow=c(2,1))
  curve( f(x), xlim=c(1,500),
         n=1000,
         main="De loin, �a a l'air al�atoire..." )
  curve( f(x), xlim=c(1,10),
         n=1000,
         main="...mais pas de pr�s (c'est une fonction C^infini)" )
  par(op)
dev.off()

png(file="g913.png", width=600, height=600)
  z <- rnorm(200)
  op <- par(mfrow=c(2,1))
  plot(ts(z))
  acf(z)
  par(op)
dev.off()

png(file="g914.png", width=600, height=600)
  data(co2)
  x <- diff(co2)
  y <- diff(x,lag=12)
  op <- par(mfrow=c(2,1))
  plot(ts(y))
  acf(y)
  par(op)
dev.off()

png(file="g915.png", width=600, height=600)
  op <- par(mfrow=c(2,1))
  plot.box.ljung <- function (z, k=15, main="p-valeur du test de Ljung-Box") {
    p <- rep(NA, k)
    for (i in 1:k) {
      p[i] <- Box.test(z, i, type = "Ljung-Box")$p.value
    }
    plot(p, type='h', ylim=c(0,1), lwd=3, main=main)
    abline(h=c(0,.05),lty=3)
  }
  plot.box.ljung(z, main="Donn�es al�atoires")
  plot.box.ljung(y, main="diff(diff(co2),lag=12)")
  par(op)
dev.off()

png(file="g916.png", width=600, height=600)
  op <- par(mfrow=c(2,1))
  library(lmtest)
  plot(LakeHuron, main="Lake Huron")
  acf(LakeHuron, main=paste("p =", signif(dwtest(LakeHuron~1)$p.value)))
  par(op)
dev.off()

png(file="g917.png", width=600, height=600)
  n <- 200
  x <- rnorm(n)
  op <- par(mfrow=c(2,1))
  x <- ts(x)
  plot(x, main="Bruit blanc")
  acf(x, main=paste("p =", signif(dwtest(x~1)$p.value)))
  par(op)
dev.off()

png(file="g918.png", width=600, height=600)
  n <- 200
  x <- rnorm(n)
  op <- par(mfrow=c(2,1))
  y <- filter(x,.8,method="recursive")
  plot(y, main="AR(1)")
  acf(y, main=paste("p =", signif(dwtest(y~1)$p.value)))
  par(op)
dev.off()

png(file="g919.png", width=600, height=600)
  n <- 200
  x <- rnorm(n)
  y <- filter(x, c(0,1), method="recursive")
  op <- par(mfrow=c(3,1))
  plot(y, main=paste("p =",dwtest(y~1)$p.value))
  acf(y)
  pacf(y)
  par(op)
dev.off()

png(file="g920.png", width=600, height=600)
  op <- par(mfcol=c(2,2))
  hist(z)
  qqnorm(z)
  qqline(z,col='red')
  hist(y)
  qqnorm(y)
  qqline(y, col='red')
  par(op)
dev.off()

png(file="g921.png", width=600, height=600)
  data(co2)
  r <- arima(co2, order = c(0, 1, 1), seasonal = list(order = c(0, 1, 1), period = 12))
  tsdiag(r)
dev.off()

png(file="g922.png", width=600, height=300)
  data(co2)
  plot(co2)
dev.off()

png(file="g923.png", width=600, height=300)
  y <- as.vector(co2)
  x <- as.vector(time(co2))
  r <- lm( y ~ poly(x,1) + cos(2*pi*x) + sin(2*pi*x) )
  plot(y~x, type='l')
  lines(predict(r)~x, lty=3, col='red', lwd=3)
dev.off()

png(file="g924.png", width=600, height=600)
  plot( y-predict(r) )
dev.off()

png(file="g925.png", width=600, height=300)
  r <- lm( y ~ poly(x,2) + cos(2*pi*x) + sin(2*pi*x) )
  plot(y~x, type='l')
  lines(predict(r)~x, lty=3, col='red', lwd=3)
dev.off()

png(file="g926.png", width=600, height=600)
  plot( y-predict(r) )
dev.off()

png(file="g927.png", width=600, height=300)
  r <- lm( y ~ poly(x,2) + cos(2*pi*x) + sin(2*pi*x) 
                         + cos(4*pi*x) + sin(4*pi*x) )
  plot(y~x, type='l')
  lines(predict(r)~x, lty=3, col='red', lwd=3)
dev.off()

png(file="g928.png", width=600, height=600)
  plot( y-predict(r), type='l' )
dev.off()

png(file="g929.png", width=600, height=600)
  op <- par(mfrow=c(2,1))
  acf(y - predict(lm( y ~ poly(x,2) + cos(2*pi*x) + sin(2*pi*x) )))
  acf(y - predict(lm( y ~ poly(x,2) + cos(2*pi*x) 
                          + sin(2*pi*x) + cos(4*pi*x) + sin(4*pi*x) )))
  par(op)
dev.off()

png(file="g930.png", width=600, height=600)
  m <- tapply(co2, gl(12,1,length(co2)), mean)
  m <- rep(m, ceiling(length(co2)/12)) [1:length(co2)]
  m <- ts(m, start=start(co2), frequency=frequency(co2))
  op <- par(mfrow=c(3,1))
  plot(co2)
  plot(m)
  plot(co2-m)
  r <- lm(co2-m ~ poly(as.vector(time(m)),2))
  lines(predict(r) ~ as.vector(time(m)), col='red')
  par(op)
dev.off()

png(file="g931.png", width=600, height=800)
  op <- par(mfrow=c(4,1))
  plot(r$res)
  acf(r$res)
  pacf(r$res)
  spectrum(r$res, col=par('fg'))
  abline(v=1:6, lty=3)
  par(op)
dev.off()

png(file="g932.png", width=600, height=600)
  k <- 12  
  m <- matrix( as.vector(diag(k)), nr=length(co2), nc=k, byrow=T)
  m <- cbind(m, poly(as.vector(time(co2)),2))
  r <- lm(co2~m-1)
  summary(r)
  b <- r$coef
  y1 <- m[,1:k] %*% b[1:k]
  y1 <- ts(y1, start=start(co2), frequency=frequency(co2))
  y2 <- m[,k+1:2] %*% b[k+1:2]
  y2 <- ts(y2, start=start(co2), frequency=frequency(co2))
  res <- co2 - y1 - y2
  op <- par(mfrow=c(3,1))
  plot(co2)
  lines(y2+mean(b[1:k]) ~ as.vector(time(co2)), col='red')
  plot(y1)
  plot(res)
  par(op)
dev.off()

png(file="g933.png", width=600, height=600)
  op <- par(mfrow=c(3,1))
  acf(res)
  pacf(res)
  spectrum(res, col=par('fg'))
  abline(v=1:10, lty=3)
  par(op)
dev.off()

png(file="g934.png", width=600, height=300)
  x <- co2
  n <- length(x)
  k <- 12
  m <- matrix( c(x, rep(NA,k)), nr=n+k-1, nc=k )
  y <- apply(m, 1, mean, na.rm=T)
  y <- y[1:n + round(k/2)]
  y <- ts(y, start=start(x), frequency=frequency(x))
  y <- y[round(k/4):(n-round(k/4))]
  yt <- time(x)[ round(k/4):(n-round(k/4)) ]
  plot(x)
  lines(y~yt, col='red')
dev.off()

png(file="g935.png", width=600, height=300)
  x <- co2
  plot(x)
  k <- 12
  lines( filter(x, rep(1/k,k)), col='red')
dev.off()

png(file="g936.png", width=600, height=800)
  lissage.exponentiel <- function (x, a) {
    m <- x
    for (i in 2:n) {
      # D�finition du lissage exponentiel :
      m[i] <- a * x[i] + (1-a)*m[i-1]
    }
    m <- ts(m, start=start(x), frequency=frequency(x))
    m
  }
  plot.lissage.exponentiel <- function (x, a=.9) {
    plot(lissage.exponentiel(x,a))
    par(usr=c(0,1,0,1))
    text(.02,.9, a, adj=c(0,1), cex=3)
  }
  op <- par(mfrow=c(4,1))
  plot(x, main="Lissages exponentiels")
  plot.lissage.exponentiel(x)
  plot.lissage.exponentiel(x,.1)
  plot.lissage.exponentiel(x,.02)
  par(op)
dev.off()

png(file="g937.png", width=600, height=800)
  r <- x - lissage.exponentiel(x,.02)
  op <- par(mfrow=c(4,1))
  plot(r, main="R�sidus du lissage exponentiel")
  acf(r)
  pacf(r)
  spectrum(r)
  abline(v=1:10,lty=3)
  par(op)
dev.off()

png(file="g938.png", width=600, height=600)
  x <- co2
  m <- HoltWinters(x, alpha=.1, beta=0, gamma=0)
  p <- predict(m, n.ahead=240, prediction.interval=T)
  plot(m, predicted.values=p)
dev.off()

png(file="g939.png", width=600, height=600)
  data(LakeHuron)
  x <- LakeHuron
  avant <- window(x, end=1935)
  apres <- window(x, start=1935)
  a <- .2
  b <- 0
  g <- 0
  mod�le <- HoltWinters(avant, alpha=a, beta=b, gamma=g)
  pr�visions <- predict(mod�le, n.ahead=37, prediction.interval=T)
  plot(mod�le, predicted.values=pr�visions)
  lines(apres)
dev.off()

png(file="g940.png", width=600, height=600)
  data(LakeHuron)
  x <- LakeHuron
  avant <- window(x, end=1935)
  apres <- window(x, start=1935)
  a <- .2
  b <- .2
  g <- 0
  mod�le <- HoltWinters(avant, alpha=a, beta=b, gamma=g)
  pr�visions <- predict(mod�le, n.ahead=37, prediction.interval=T)
  plot(mod�le, predicted.values=pr�visions)
  lines(apres)
dev.off()

png(file="g941.png", width=600, height=600)
  data(LakeHuron)
  x <- LakeHuron
  op <- par(mfrow=c(2,2))
  avant <- window(x, end=1935)
  apres <- window(x, start=1935)
  a <- .2
  b <- .5
  g <- 0
  for (b in c(.02, .04, .1, .5)) {
    mod�le <- HoltWinters(avant, alpha=a, beta=b, gamma=g)
    pr�visions <- predict(mod�le, n.ahead=37, prediction.interval=T)
    par(mar=c(0,0,0,0))
    plot(mod�le, predicted.values=pr�visions, axes=F, xlab='', ylab='', main='')
    box()
   text( (4*par('usr')[1]+par('usr')[2])/5,
          (par('usr')[3]+5*par('usr')[4])/6,
          paste("b�ta =",b),
          cex=3, col='blue' )
    lines(apres)
  }
  par(op)
dev.off()

png(file="g942.png", width=600, height=600)
  n <- 200
  plot(ts(cumsum(rnorm(n)) + rnorm(n)))
dev.off()

png(file="g943.png", width=600, height=600)
  op <- par(mfrow=c(2,1))
  plot(ts(cumsum(rnorm(n, sd=1))+rnorm(n,sd=.1)))
  plot(ts(cumsum(rnorm(n, sd=.1))+rnorm(n,sd=1)))
  par(op)
dev.off()

png(file="g944.png", width=600, height=600)
  n <- 200
  plot(ts( cumsum( cumsum(rnorm(n))+rnorm(n) ) + rnorm(n) ))
dev.off()

png(file="g945.png", width=600, height=600)
  n <- 200
  op <- par(mfrow=c(3,1))
  plot(ts( cumsum( cumsum(rnorm(n,sd=1))+rnorm(n,sd=1) ) + rnorm(n,sd=.1) ))
  plot(ts( cumsum( cumsum(rnorm(n,sd=1))+rnorm(n,sd=.1) ) + rnorm(n,sd=1) ))
  plot(ts( cumsum( cumsum(rnorm(n,sd=.1))+rnorm(n,sd=1) ) + rnorm(n,sd=1) ))
  par(op)
dev.off()

png(file="g946.png", width=600, height=600)
  # je ne sais pas le faire sans boucle...
  structural.model <- function (n=200, sd1=1, sd2=1, sd3=1, sd4=1, sd5=200) {
    sd1 <- 1
    sd2 <- 2
    sd3 <- 3
    sd4 <- 4
    mu <- rep(rnorm(1),n)
    nu <- rep(rnorm(1),n)
    g <- rep(rnorm(1,sd=sd5),n)
    x <- mu + g + rnorm(1,sd=sd1)
    for (i in 2:n) {
      if (i>3) {    
        g[i] <- -(g[i-1]+g[i-2]+g[i-3]) + rnorm(1,sd=sd4)
      } else {
        g[i] <- rnorm(1,sd=sd5)
      }
      nu[i] <- nu[i-1] + rnorm(1,sd=sd3)
      mu[i] <- mu[i-1] + nu[i-1] + rnorm(1,sd=sd2)
      x[i] <- mu[i] + g[i] + rnorm(1,sd=sd1)
    }
    ts(x)
  }
  n <- 200
  op <- par(mfrow=c(3,1))
  plot(structural.model(n))
  plot(structural.model(n))
  plot(structural.model(n))
  par(op)
dev.off()

png(file="g947.png", width=600, height=600)
  n <- 200
  op <- par(mfrow=c(3,1))
  plot(structural.model(n,sd4=0))
  plot(structural.model(n,sd4=0))
  plot(structural.model(n,sd4=0))
  par(op)
dev.off()

png(file="g948.png", width=600, height=300)
  data(AirPassengers)
  plot(AirPassengers)
dev.off()

png(file="g949.png", width=600, height=300)
  plot(log(AirPassengers))
dev.off()

png(file="g950.png", width=600, height=600)
  x <- log(AirPassengers)
  r <- StructTS(x)
  plot(x)
  f <- apply(fitted(r), 1, sum)
  f <- ts(f, frequency=frequency(x), start=start(x))
  lines(f, col='red', lty=3, lwd=3)
dev.off()

png(file="g951.png", width=600, height=600)
  matplot( (StructTS(x-min(x)))$fitted, type='l')
dev.off()

png(file="g952.png", width=600, height=600)
  l <- 1956
  x <- log(AirPassengers)
  x1 <- window(x, end=l)
  x2 <- window(x, start=l)
  r <- StructTS(x1)
  plot(x)
  f <- apply(fitted(r), 1, sum)
  f <- ts(f, frequency=frequency(x), start=start(x))
  lines(f, col='red')
  p <- predict(r, n.ahead=100)
  lines(p$pred, col='red')
  lines(p$pred + qnorm(.025) * p$se, col='red', lty=2)
  lines(p$pred + qnorm(.975) * p$se, col='red', lty=2)
  title(main="Pr�dictions avec un mod�le structurel")
dev.off()

png(file="g953.png", width=600, height=600)
  # Une fonction pour regarder une s�rie temporelle
  eda.ts <- function (x, bands=FALSE) {
    # Calcul des p-valeurs du test de Ljung-Box
    # (on le les affiche que si leur examen est n�cessaire, i.e., 
    # si on peut penser que c'est du bruit blanc)
    p.min <- .05
    k <- 15
    p <- rep(NA, k)
    for (i in 1:k) {
      p[i] <- Box.test(x, i, type = "Ljung-Box")$p.value
    }
    if( max(p)>p.min ) {
      op <- par(mfrow=c(5,1))
    } else {
      op <- par(mfrow=c(4,1))
    }
    if(!is.ts(x))
      x <- ts(x)
    plot(x)
    if(bands) {
      a <- time(x)
      i1 <- floor(min(a))
      i2 <- ceiling(max(a))
      y1 <- par('usr')[3]
      y2 <- par('usr')[4]
      if( par("ylog") ){
        y1 <- 10^y1
        y2 <- 10^y2
      }
      for (i in seq(from=i1, to=i2-1, by=2)) {
        polygon( c(i,i+1,i+1,i), c(y1,y1,y2,y2), col='grey', border=NA )
      }
      lines(x)
    }
    acf(x)
    pacf(x)
    spectrum(x, col=par('fg')) 
    if( max(p)>p.min ) {
      main <- "p-valeur du test de Ljung-Box"
      plot(p, type='h', ylim=c(0,1), lwd=3, main=main)
      abline(h=c(0,.05),lty=3)
    }
    par(op)
  }

  data(co2)
  eda.ts(co2, bands=T)
dev.off()

png(file="g954.png", width=600, height=300)
  spectrum(co2)
  abline(v=1:10, lty=3)
dev.off()

png(file="g955.png", width=600, height=300)
  data(sunspots)
  plot(sunspots)
dev.off()

png(file="g956.png", width=600, height=300)
  spectrum(sunspots)
dev.off()

png(file="g957.png", width=600, height=300)
  spectrum(sunspots, spans=10)
dev.off()

png(file="g958.png", width=600, height=300)
  spectrum(sunspots, spans=10, xlim=c(0,1))
  abline(v=1:3/11, lty=3) # une seule harmonique
dev.off()

png(file="g959.png", width=600, height=300)
  library(car)
  box.cox.powers(3+sunspots)
  y <- box.cox(sunspots,.3)
  spectrum(y, spans=10, xlim=c(0,1))
  abline(v=1:3/11, lty=3) # une seule harmonique
dev.off()

png(file="g960.png", width=600, height=300)
  x <- as.vector(time(y))
  y <- as.vector(y)
  r1 <- lm( y ~ sin(2*pi*x/11) + cos(2*pi*x/11) )
  r2 <- lm( y ~ sin(2*pi*x/11) + cos(2*pi*x/11) 
                + sin(2* 2*pi*x/11) + cos(2* 2*pi*x/11) 
                + sin(3* 2*pi*x/11) + cos(3* 2*pi*x/11) 
                + sin(4* 2*pi*x/11) + cos(4* 2*pi*x/11) 
          )
  plot(y~x, type='l')
  lines(predict(r1)~x, col='red')
  lines(predict(r2)~x, col='green', lty=3, lwd=3)
dev.off()

png(file="g961.png", width=600, height=600)
  z <- y - predict(r1)
  op <- par(mfrows=c(2,2))
  hist(z)
  qqnorm(z)
  acf(z)
  pacf(z)
  par(op)
dev.off()

png(file="g962.png", width=600, height=600)
  n <- 8
  x <- 1:n/n*2*pi
  k <- 0
  y <- cbind(  rep(1,n),
               1 + exp(1i *x),
               1 + exp(1i *x) + exp(-1i),
               1 + exp(1i *x) + exp(-1i) + exp(2i),
               1 + exp(1i *x) + exp(-1i) + exp(2i) + exp(-2i)
              )
  z <- mvfft(y)  
  op <- par(mfrow=c(2,1))
  barplot(Re(t(z)), beside=T, col=rainbow(dim(y)[2]))
  barplot(Im(t(z)), beside=T, col=rainbow(dim(y)[2]))
  par(op)
dev.off()

png(file="g963.png", width=600, height=600)
  n <- 8
  x <- 1:n/n*2*pi
  k <- 0
  y <- cbind(  rep(1,n),
               1 + cos(x),
               1 + cos(x) + sin(x),
               1 + cos(x) + sin(x) + cos(2*x),
               1 + cos(x) + sin(x) + cos(2*x) + sin(2*x)
              )
  z <- mvfft(y)  
  op <- par(mfrow=c(2,1))
  barplot(Re(t(z)), beside=T, col=rainbow(dim(y)[2]), main="Partie r�elle de la FFT")
  barplot(Im(t(z)), beside=T, col=rainbow(dim(y)[2]), main="Partie imaginaire de la FFT")
  par(op)
dev.off()

png(file="g964.png", width=600, height=600)
  x <- rep(0,256)
  x[129:256] <- 1
  op <- par(mfrow=c(2,1))
  plot(x, type='l')
  plot(Mod(fft(x)[1: ceiling((length(x)+1)/2) ]), type='l')
  par(op)
dev.off()

png(file="g965.png", width=600, height=600)
  x <- rep(0,256)
  x[33:64] <- 1
  x[64+33:64] <- 1
  x[128+33:64] <- 1
  x[128+64+33:64] <- 1
  op <- par(mfrow=c(2,1))
  plot(x, type='l')
  plot(Mod(fft(x)[1: ceiling((length(x)+1)/2) ]), type='l')
  par(op)
dev.off()

png(file="g966.png", width=600, height=600)
  x <- rep( 1:32/32, 8 )
  op <- par(mfrow=c(2,1))
  plot(x, type='l')
  plot(Mod(fft(x)[1: ceiling((length(x)+1)/2) ]), type='l')
  par(op)
dev.off()

png(file="g967.png", width=600, height=600)
  x <- 1:256/256
  op <- par(mfrow=c(2,1))
  plot(x, type='l')
  plot(Mod(fft(x)[1: ceiling((length(x)+1)/2) ]), type='l')
  par(op)
dev.off()

png(file="g968.png", width=600, height=600)
  x <- abs(1:256-128)
  op <- par(mfrow=c(2,1))
  plot(x, type='l')
  plot(Mod(fft(x)[1: ceiling((length(x)+1)/2) ]), type='l')
  par(op)
dev.off()

png(file="g969.png", width=600, height=600)
  x <- 1:256/256
  x <- sin(2*pi*x) + cos(3*pi*x) + sin(4*pi*x+pi/3)
  op <- par(mfrow=c(2,1))
  plot(x, type='l')
  plot(Mod(fft(x)[1: ceiling((length(x)+1)/2) ]), type='l')
  par(op)
dev.off()

png(file="g970.png", width=600, height=600)
  x <- 1:256/256
  x <- sin(16*pi*x)
  op <- par(mfrow=c(2,1))
  plot(x, type='l')
  plot(Mod(fft(x)[1: ceiling((length(x)+1)/2) ]), type='l')
  par(op)
dev.off()

png(file="g971.png", width=600, height=600)
  x <- 1:256/256
  x <- sin(16*pi*x) + .3*cos(56*pi*x)
  op <- par(mfrow=c(2,1))
  plot(x, type='l')
  plot(Mod(fft(x)[1: ceiling((length(x)+1)/2) ]), type='l')
  par(op)
dev.off()

png(file="g972.png", width=600, height=600)
  n <- 1000
  x <- cumsum(rnorm(n))+rnorm(n)
  y <- fft(x)
  y[20:(length(y)-19)] <- 0
  y <- Re(fft(y, inverse=T)/length(y))
  op <- par(mfrow=c(3,1))
  plot(x, type='l')
  lines(y, col='red', lwd=3)
  plot(Mod(fft(x)[1: ceiling((length(x)+1)/2) ]), type='l')
  plot(Mod(fft(y)[1: ceiling((length(y)+1)/2) ]), type='l')
  par(op)
dev.off()

png(file="g973.png", width=600, height=600)
  n <- 1000
  x <- cumsum(rnorm(n))+rnorm(n)
  plot(x, type='l')
  for (i in 1:10) {
    y <- fft(x)
    y[(1+i):(length(y)-i)] <- 0
    y <- Re(fft(y, inverse=T)/length(y))
    lines(y, col=rainbow(10)[i])
  }
dev.off()

png(file="g974.png", width=600, height=600)
  n <- 1000
  x <- c(129:256,1:128)/256
  y <- fft(x)
  y[20:(length(y)-19)] <- 0
  y <- Re(fft(y, inverse=T)/length(y))
  plot(x, type='l', ylim=c(-.2,1.2))
  lines(y, col='red', lwd=3)
dev.off()

png(file="g975.png", width=600, height=600)
  x <- co2
  y <- fft(x)
  y[20:(length(y)-19)] <- 0
  y <- Re(fft(y, inverse=T)/length(y))
  plot(x, type='l')
  lines(y, col='red', lwd=3)
dev.off()

png(file="g976.png", width=600, height=600)
  p <- predict(lm(co2~time(co2)))
  x <- co2 - p
  y <- fft(x)
  y[20:(length(y)-19)] <- 0
  y <- Re(fft(y, inverse=T)/length(y))
  plot(x+p, type='l')
  lines(y+p, col='red', lwd=3)
  lines(x-y+mean(x+p), col='green', lwd=3)
dev.off()

png(file="g977.png", width=600, height=600)
  x <- co2
  y <- fft(x)
  k <- 20
  n <- length(y)
  y[1:(k+1)] <- 0
  y[(n-k):n] <- 0
  y <- Re(fft(y, inverse=T)/length(y))
  plot(x, type='l')
  lines(y+mean(x), col='red', lwd=3)
dev.off()

png(file="g978.png", width=600, height=600)
  library(sound)
  x <- loadSample("sample.wav")
  plot(x)
dev.off()

png(file="g979.png", width=600, height=600)
  n <- length(x$sound)
  n <- round(n/3)
  y <- x$sound[ n:(n+2000) ]
  n <- length(y)
  op <- par(mfrow=c(2,1))
  plot(y, type='l')
  #plot(Mod(fft(y)[1: ceiling((length(y)+1)/2) ]), type='l')
  plot(Mod(fft(y)[1:100]), type='l')
dev.off()

png(file="g980.png", width=600, height=600)
  op <- par(mfrow=c(2,1))
  x <- ts(rnorm(200))
  plot(x, main="vaiid normales")
  acf(x)
  par(op)
dev.off()

png(file="g981.png", width=600, height=600)
  op <- par(mfrow=c(2,1))
  data(BJsales)
  plot(BJsales)
  acf(BJsales)
  par(op)
dev.off()

png(file="g982.png", width=600, height=600)
  f <- 24
  x <- seq(0,10, by=1/f)
  y <- sin(2*pi*x)
  y <- ts(y, start=0, frequency=f)
  op <- par(mfrow=c(4,1))
  plot(y)
  acf(y)
  pacf(y)
  spectrum(y)
  par(op)
dev.off()

png(file="g983.png", width=600, height=600)
  f <- 24
  x <- seq(0,10, by=1/f)
  y <- x + sin(2*pi*x) + rnorm(10*f)
  y <- ts(y, start=0, frequency=f)
  op <- par(mfrow=c(4,1))
  plot(y)
  acf(y)
  pacf(y)
  spectrum(y)
  par(op)
dev.off()

png(file="g984.png", width=600, height=600)
  n <- 200  
  x <- rnorm(n)
  y <- ( x[2:n] + x[2:n-1] ) / 2
  op <- par(mfrow=c(3,1))
  plot(ts(x), main="buit blanc")
  plot(ts(y), main="MA(1)")
  acf(y)
  par(op)
dev.off()

png(file="g985.png", width=600, height=600)
  n <- 200  
  x <- rnorm(n)
  y <- ( x[1:(n-3)] + x[2:(n-2)] + x[3:(n-1)] + x[4:n] )/4
  op <- par(mfrow=c(3,1))
  plot(ts(x), main="bruit blanc")
  plot(ts(y), main="MA(3)")
  acf(y)
  par(op)
dev.off()

png(file="g986.png", width=600, height=600)
  n <- 200  
  x <- rnorm(n)
  y <- x[2:n] - x[1:(n-1)]
  op <- par(mfrow=c(3,1))
  plot(ts(x), main="bruit blanc")
  plot(ts(y), main="MA(1)")
  acf(y)
  par(op)
dev.off()

png(file="g987.png", width=600, height=600)
  n <- 200  
  x <- rnorm(n)
  y <- x[3:n] - 2 * x[2:(n-1)] + x[1:(n-2)]
  op <- par(mfrow=c(3,1))
  plot(ts(x), main="bruit blanc")
  plot(ts(y), main="MA(2)")
  acf(y)
  par(op)
dev.off()

png(file="g988.png", width=600, height=600)
  n <- 200  
  x <- rnorm(n)
  y <- filter(x, c(1,-2,1))
  op <- par(mfrow=c(3,1))
  plot(ts(x), main="bruit blanc")
  plot(ts(y), main="MA(2)")
  acf(y, na.action=na.pass)
  par(op)
dev.off()

png(file="g989.png", width=600, height=600)
  n <- 200
  x <- rnorm(n)
  y <- cumsum(x)
  op <- par(mfrow=c(3,1))
  plot(ts(x))
  plot(ts(y), main="AR(1)")
  acf(y)
  par(op)  
dev.off()

png(file="g990.png", width=600, height=600)
  n <- 200
  a <- .7
  x <- rep(0,n)
  for (i in 2:n) {
    x[i] <- a*x[i-1] + rnorm(1)
  }
  y <- x[-1]
  x <- x[-n]
  r <- lm( y ~ x -1)
  plot(y~x)
  abline(r, col='red')
  abline(0, .7, lty=2)
dev.off()

png(file="g991.png", width=600, height=600)
  n <- 200
  x <- rep(0,n)
  for (i in 4:n) {
    x[i] <- .3*x[i-1] -.7*x[i-2] + .5*x[i-3] + rnorm(1)
  }
  op <- par(mfrow=c(3,1))
  plot(ts(x), main="AR(3)")
  acf(x)
  pacf(x)
  par(op)
dev.off()

png(file="g992.png", width=600, height=600)
  n <- 200
  x <- arima.sim(list(ar=c(.3,-.7,.5)), n)
  op <- par(mfrow=c(3,1))
  plot(ts(x), main="AR(3)")
  acf(x)
  pacf(x)
  par(op)
dev.off()

png(file="g993.png", width=600, height=600)
  n <- 200
  x <- seq(0,2,length=n)
  tendance <- ts(sin(x))
  plot(tendance, ylim=c(-.5,1.5), lty=2, lwd=3, col='red', ylab='')
  r <- arima.sim(list(ar = c(0.5,-.3), ma = c(.7,.1)), n, sd=.1 )
  lines(tendance+r)
dev.off()

png(file="g994.png", width=600, height=600)
  n <- 200
  k <- 10
  x <- 1:n
  r <- matrix(nr=n,nc=k)
  for (i in 1:k) {
    r[,i] <- cumsum(rnorm(n))
  }
  matplot(x,r,type='l',lty=1,col=par('fg'))
  abline(h=0,lty=3)
dev.off()

png(file="g995.png", width=600, height=600)
  n <- 200
  ma <- 2
  mai <- 1/ma
  op <- par(mfrow=c(4,1))
  x <- arima.sim(list(ma=ma),n)
  plot(x)
  acf(x)
  lines(0:n, ARMAacf(ma=ma, lag.max=n), lty=2, lwd=3, col='red')
  x <- arima.sim(list(ma=mai),n)
  plot(x)
  acf(x)
  lines(0:n, ARMAacf(ma=mai, lag.max=n), lty=2, lwd=3, col='red')
  par(op)
dev.off()

png(file="g996.png", width=600, height=600)
  sym.poly <- function (z,k) {
    # Somme des produits de k �l�ments distincts du vecteur z
    if (k==0) {
      r <- 1
    } else if (k==1) {
      r <- sum(z)
    } else {
      r <- 0
      for (i in 1:length(z)) {
        r <- r + z[i]*sym.poly(z[-i],k-1)
      }
      r <- r/k   # chaque terme a �t� compt� k fois...
    }
    r
  }
  sym.poly( c(1,2,3), 1 )   #  6
  sym.poly( c(1,2,3), 2 )   # 11
  sym.poly( c(1,2,3), 3 )   #  6

  roots.to.poly <- function (z) {
    n <- length(z)
    p <- rep(1,n)
    for (k in 1:n) {
      p[n-k+1] <- (-1)^k * sym.poly(z,k)
    }
    p <- c(p,1)
    p
  }
  roots.to.poly(c(1,2))   # 2 -3 1
  round(Re(  polyroot( roots.to.poly(c(1,2,3)) )  ), digits=1)

  # Apr�s ce l�ger interlude, on peut enfin inverser construire
  # un processus MA et son inverse
  n <- 200
  k <- 3
  ma <- runif(k,-1,1)
  # On calcule les racines
  z <- polyroot(c(1,-ma))
  # On les inverse
  zi <- 1/z
  # On reconstruit le polyn�me
  p <- roots.to.poly(zi)
  # Le r�sultat doit �tre r�el, mais � cause des erreurs d'arrondi il ne l'est pas
  p <- Re(p)
  # On veut que le terme constant �gale 1
  p <- p/p[1]
  mai <- -p[-1]

  op <- par(mfrow=c(4,1))
  x <- arima.sim(list(ma=ma),n)
  plot(x)
  acf(x)
  lines(0:n, ARMAacf(ma=ma, lag.max=n), lty=2, lwd=3, col='red')
  x <- arima.sim(list(ma=mai),n)
  plot(x)
  acf(x)
  lines(0:n, ARMAacf(ma=mai, lag.max=n), lty=2, lwd=3, col='red')
  par(op)
dev.off()

png(file="g997.png", width=600, height=600)
  data(Nile)
  op <- par(mfrow=c(2,1))
  plot(Nile, main="Il n'y a pas de tendance")
  acf(Nile)
  par(op)
dev.off()

png(file="g998.png", width=600, height=600)
  data(BJsales)
  op <- par(mfrow=c(3,1))
  plot(BJsales, main="il y a une tendance")
  acf(BJsales)
  acf(BJsales, main="Elle disparait si on d�rive")
  par(op)
dev.off()

png(file="g999.png", width=600, height=600)
  n <- 2000
  x <- arima.sim(model=list(ar=c(.3,.6), ma=c(.8,-.5,.2), order=c(2,1,3)), n)
  x <- ts(x)
  op <- par(mfrow=c(3,1))
  plot(x, main="D�river une fois suffit")
  acf(x)
  acf(diff(x))
  par(op)
dev.off()

png(file="g1000.png", width=600, height=800)
  n <- 10000
  x <- arima.sim(model=list(ar=c(.3,.6), ma=c(.8,-.5,.2), order=c(2,2,3)), n)
  x <- ts(x)
  op <- par(mfrow=c(4,1))
  plot(x, main="D�river deux fois fois suffit")
  acf(x)
  acf(diff(x))
  acf(diff(x,differences=2))
  par(op)
dev.off()

png(file="g1001.png", width=600, height=600)
  acf.exp <- function (x, lag.max=NULL, lag.max.reg=lag.max, ...) {
    a <- acf(x, lag.max=lag.max.reg, plot=F)
    b <- acf(x, lag.max=lag.max, ...)
    r <- lm( log(a$acf) ~ a$lag -1)
    lines( exp( b$lag * r$coef[1] ) ~ b$lag, lty=2 )
  }
  op <- par(mfrow=c(2,1))
  data(BJsales)
  acf.exp(BJsales)
  acf.exp(BJsales, lag.max=40)
  par(op)
dev.off()

png(file="g1002.png", width=600, height=600)
  data(Nile)
  acf.exp(Nile, lag.max.reg=10)
dev.off()

png(file="g1003.png", width=600, height=800)
  x <- diff(co2, lag=12)
  op <- par(mfrow=c(4,1))
  plot(x)
  acf(x)
  pacf(x)
  spectrum(x, col=par('fg'))
  par(op)
dev.off()

png(file="g1004.png", width=600, height=800)
  y <- diff(x)
  op <- par(mfrow=c(4,1))
  plot(y)
  acf(y)
  pacf(y)
  spectrum(y, col=par('fg'))
  par(op)
dev.off()

png(file="g1005.png", width=600, height=600)
  n <- 200
  x <- arima.sim(list(order=c(2,1,2), ar=c(.5,-.8), ma=c(.9,.6)), n)
  op <- par(mfrow=c(3,1))
  acf(x, main="Il faudra d�river une fois")
  acf(diff(x))
  acf(diff(x, differences=2))
  par(op)
dev.off()

png(file="g1006.png", width=600, height=600)
  n <- 200
  x <- arima.sim(list(order=c(2,2,2), ar=c(.5,-.8), ma=c(.9,.6)), n)
  op <- par(mfrow=c(3,1))
  acf(x, main="Il faudra d�river deux fois")
  acf(diff(x))
  acf(diff(x, differences=2))
  par(op)
dev.off()

png(file="g1007.png", width=600, height=600)
  #data(sunspot, package=ts)    # moved into stats
  data(sunspot)
  op <- par(mfrow=c(4,1))
  plot(sunspot.month)
  acf(sunspot.month)
  plot(diff(sunspot.month))
  acf(diff(sunspot.month))
  par(op) 
dev.off()

png(file="g1008.png", width=600, height=600)
  data(JohnsonJohnson)
  x <- log(JohnsonJohnson)
  op <- par(mfrow=c(4,1))
  plot(x)
  acf(x)
  plot(diff(x))
  acf(diff(x))
  par(op) 
dev.off()

png(file="g1009.png", width=600, height=600)
  data(BJsales)
  x <- BJsales
  op <- par(mfrow=c(6,1))
  plot(x)
  acf(x)
  plot(diff(x))
  acf(diff(x))
  plot(diff(x, difference=2))
  acf(diff(x, difference=2))
  par(op) 
dev.off()

png(file="g1010.png", width=600, height=600)
  data(austres)
  x <- austres
  op <- par(mfrow=c(6,1))
  plot(x)
  acf(x)
  plot(diff(x))
  acf(diff(x))
  plot(diff(x, difference=2))
  acf(diff(x, difference=2))
  par(op) 
dev.off()

png(file="g1011.png", width=600, height=600)
  # Dans l'exemple pr�c�dent, il y avait clairement une tendance
  # lin�aire : extrayons-la.
  data(austres)
  x <- lm(austres ~ time(austres))$res
  op <- par(mfrow=c(6,1))
  plot(x)
  acf(x)
  plot(diff(x))
  acf(diff(x))
  plot(diff(x, difference=2))
  acf(diff(x, difference=2))
  par(op) 
dev.off()

png(file="g1012.png", width=600, height=600)
  my.sarima.sim <- function (n=20, period=12, model, seasonal) {    
    x <- arima.sim( model, n*period )
    x <- x[1:(n*period)]
    for (i in 1:period) {
      xx <- arima.sim( seasonal, n )
      xx <- xx[1:n]
      x[i + period * 0:(n-1)] <- x[i + period * 0:(n-1)] + xx
    }
    x <- ts(x, frequency=period)
    x
  }
  op <- par(mfrow=c(3,1))
  x <- my.sarima.sim(20, 12, 
                    list(ar=.6, ma=.3, order=c(1,0,1)),
                    list(ar=c(.5), ma=c(1,2), order=c(1,0,2))
                   )
  eda.ts(x, bands=T)
dev.off()

png(file="g1013.png", width=600, height=600)
  x <- my.sarima.sim(20, 12, 
                    list(ar=c(.5,-.3), ma=c(-.8,.5,-.3), order=c(2,1,3)),
                    list(ar=c(.5), ma=c(1,2), order=c(1,0,2))
                   )
  eda.ts(x, bands=T)
dev.off()

png(file="g1014.png", width=600, height=600)
  x <- my.sarima.sim(20, 12, 
                    list(ar=c(.5,-.3), ma=c(-.8,.5,-.3), order=c(2,1,3)),
                    list(ar=c(.5), ma=c(1,2), order=c(1,1,2))
                   )
  eda.ts(x, bands=T)
dev.off()

png(file="g1015.png", width=600, height=600)
  x <- co2
  eda.ts(x)
dev.off()

png(file="g1016.png", width=600, height=600)
  eda.ts(diff(x))
dev.off()

png(file="g1017.png", width=600, height=600)
  eda.ts(diff(diff(x),lag=12))
dev.off()

png(file="g1018.png", width=600, height=600)
  r3 <- arima(co2, order = c(1, 1, 1), seasonal = list(order = c(0, 1, 1), period = 12))
  eda.ts(r3$res)
dev.off()

png(file="g1019.png", width=600, height=600)
  x1 <- window(co2,end=1990)
  r <- arima(x1, order = c(1, 1, 1), seasonal = list(order = c(0, 1, 1), period = 12))
  plot(co2)
  p <- predict(r, n.ahead=100)
  lines(p$pred, col='red')
  lines(p$pred+qnorm(.025)*p$se, col='red', lty=3)
  lines(p$pred+qnorm(.975)*p$se, col='red', lty=3)
dev.off()

png(file="g1020.png", width=600, height=600)
  # Par contre, je ne sais pas quoi penser de ce graphique
  # (on dirait du bruit int�gr�) :
  eda.ts(co2-p$pred)
dev.off()

png(file="g1021.png", width=600, height=600)
  r <- arima(co2, order = c(1, 1, 1), seasonal = list(order = c(0, 1, 1), period = 12))
  p <- predict(r, n.ahead=150)
  plot(co2, xlim=c(1959,2010), ylim=range(c(co2,p$pred)))
  lines(p$pred, col='red')
  lines(p$pred+qnorm(.025)*p$se, col='red', lty=3)
  lines(p$pred+qnorm(.975)*p$se, col='red', lty=3)
dev.off()

png(file="g1022.png", width=600, height=600)
  op <- par(mfrow=c(4,2))
  n <- 200
  for (i in 1:4) {
    x <- NULL
    while(is.null(x)) {
      model <- list(ar=rnorm(1))
      try( x <- arima.sim(model, n) )
    }
    acf(x, main=paste("ARMA(1,0)","AR:",round(model$ar,digits=1)))
    points(0:50, ARMAacf(ar=model$ar, lag.max=50), col='red')
    pacf(x)
    points(1:50, ARMAacf(ar=model$ar, lag.max=50, pacf=T), col='red')
  } 
  par(op)  
dev.off()

png(file="g1023.png", width=600, height=600)
  op <- par(mfrow=c(4,2))
  n <- 200
  for (i in 1:4) {
    x <- NULL
    while(is.null(x)) {
      model <- list(ar=rnorm(2))
      try( x <- arima.sim(model, n) )
    }
    acf(x, 
        main=paste("ARMA(2,0)","AR:",
                   round(model$ar[1],digits=1),
                   round(model$ar[2],digits=1)
                   ))
    points(0:50, ARMAacf(ar=model$ar, lag.max=50), col='red')
    pacf(x)
    points(1:50, ARMAacf(ar=model$ar, lag.max=50, pacf=T), col='red')
  } 
  par(op)  
dev.off()

png(file="g1024.png", width=600, height=600)
  op <- par(mfrow=c(4,2))
  n <- 200
  for (i in 1:4) {
    x <- NULL
    while(is.null(x)) {
      model <- list(ma=rnorm(1))
      try( x <- arima.sim(model, n) )
    }
    acf(x, main=paste("ARMA(0,1)","MA:",round(model$ma,digits=1)))
    points(0:50, ARMAacf(ma=model$ma, lag.max=50), col='red')
    pacf(x)
    points(1:50, ARMAacf(ma=model$ma, lag.max=50, pacf=T), col='red')
  } 
  par(op)  
dev.off()

png(file="g1025.png", width=600, height=600)
  op <- par(mfrow=c(4,2))
  n <- 200
  for (i in 1:4) {
    x <- NULL
    while(is.null(x)) {
      model <- list(ma=rnorm(2))
      try( x <- arima.sim(model, n) )
    }
    acf(x, main=paste("ARMA(0,2)","MA:",
                   round(model$ma[1],digits=1),
                   round(model$ma[2],digits=1)
                   ))
    points(0:50, ARMAacf(ma=model$ma, lag.max=50), col='red')
    pacf(x)
    points(1:50, ARMAacf(ma=model$ma, lag.max=50, pacf=T), col='red')
  } 
  par(op)  
dev.off()

png(file="g1026.png", width=600, height=600)
  op <- par(mfrow=c(4,2))
  n <- 200
  for (i in 1:4) {
    x <- NULL
    while(is.null(x)) {
      model <- list(ma=rnorm(1),ar=rnorm(1))
      try( x <- arima.sim(model, n) )
    }
    acf(x, main=paste("ARMA(1,1)",
                   "AR:", round(model$ar,digits=1),
                   "AR:", round(model$ma,digits=1)
                   ))
    points(0:50, ARMAacf(ar=model$ar, ma=model$ma, lag.max=50), col='red')
    pacf(x)
    points(1:50, ARMAacf(ar=model$ar, ma=model$ma, lag.max=50, pacf=T), col='red')
  } 
  par(op)  
dev.off()

png(file="g1027.png", width=600, height=600)
  r <- arima(co2, order=c(0,1,1), list(order=c(0,1,1), period=12 ) ) 
  eda.ts(r$res)
dev.off()

png(file="g1028.png", width=600, height=600)
  x1 <- window(co2,end=1990)
  r <- arima(x1, order = c(0, 1, 1), seasonal = list(order = c(0, 1, 1), period = 12))
  plot(co2)
  p <- predict(r, n.ahead=100)
  lines(p$pred, col='red')
  lines(p$pred+qnorm(.025)*p$se, col='red', lty=3)
  lines(p$pred+qnorm(.975)*p$se, col='red', lty=3)
dev.off()

png(file="g1029.png", width=600, height=600)
  eda.ts(co2-p$pred)
dev.off()

png(file="g1030.png", width=600, height=600)
  r <- arima(co2, order = c(0, 1, 1), seasonal = list(order = c(0, 1, 1), period = 12))
  p <- predict(r, n.ahead=150)
  plot(co2, xlim=c(1959,2010), ylim=range(c(co2,p$pred)))
  lines(p$pred, col='red')
  lines(p$pred+qnorm(.025)*p$se, col='red', lty=3)
  lines(p$pred+qnorm(.975)*p$se, col='red', lty=3)
dev.off()

png(file="g1031.png", width=600, height=600)
  r1 <- arima(co2, order = c(0, 1, 1), seasonal = list(order = c(0, 1, 1), period = 12))
  r2 <- arima(co2, order = c(1, 1, 1), seasonal = list(order = c(0, 1, 1), period = 12))
  p1 <- predict(r1, n.ahead=150)
  p2 <- predict(r2, n.ahead=150)
  plot(co2, xlim=c(1959,2010), ylim=range(c(co2,p$pred)))
  lines(p1$pred, col='red')
  lines(p2$pred, col='green', lty=3, lwd=4)
dev.off()

png(file="g1032.png", width=600, height=600)
  data(AirPassengers)
  x <- AirPassengers
  plot(x)
dev.off()

png(file="g1033.png", width=600, height=600)
  plot(x)
  abline(lm(x~time(x)), col='red')
dev.off()

png(file="g1034.png", width=600, height=600)
  plot(lm(x~time(x))$res)
dev.off()

png(file="g1035.png", width=600, height=600)
  plot(diff(x))
dev.off()

png(file="g1036.png", width=600, height=600)
  x <- log(x)
  plot(x)
  abline(lm(x~time(x)),col='red')
dev.off()

png(file="g1037.png", width=600, height=600)
  plot(lm(x~time(x))$res)
dev.off()

png(file="g1038.png", width=600, height=600)
  plot(diff(x))
dev.off()

png(file="g1039.png", width=600, height=600)
  op <- par(mfrow=c(3,1))
  plot(diff(x,1,2))
  plot(diff(x,1,3))
  plot(diff(x,1,4))
  par(op)
dev.off()

png(file="g1040.png", width=600, height=600)
  op <- par(mfrow=c(3,1))
  plot(x)
  abline(h=0, v=1950:1962, lty=3)
  y <- diff(x)
  plot(y)
  abline(h=0, v=1950:1962, lty=3)
  plot(diff(y, 12,1))
  abline(h=0, v=1950:1962, lty=3)
  par(op)
dev.off()

png(file="g1041.png", width=600, height=600)
  op <- par(mfrow=c(3,1))
  plot(x)
  abline(lm(x~time(x)), col='red', lty=2)
  abline(h=0, v=1950:1962, lty=3)
  y <- x - predict(lm(x~time(x)))
  plot(y)
  abline(h=0, v=1950:1962, lty=3)
  plot(diff(y, 12,1))
  abline(h=0, v=1950:1962, lty=3)
  par(op)
dev.off()

png(file="g1042.png", width=600, height=600)
  z <- diff(y,12,1)
  op <- par(mfrow=c(3,1))
  plot(z)
  abline(h=0,lty=3)
  plot(diff(z))
  abline(h=0,lty=3)
  plot(diff(z,1,2))
  abline(h=0,lty=3)
  par(op)  
dev.off()

png(file="g1043.png", width=600, height=600)
  k <- 3
  n <- 2*k
  op <- par(mfrow=c(k,2))
  zz <- z
  for(i in 1:n) {
    acf(zz, main=i-1)
    zz <- diff(zz)
  }
  par(op)
dev.off()

png(file="g1044.png", width=600, height=600)
  n <- 20
  a <- rep(NA,n)
  zz <- z
  for(i in 1:n) {
    a[i] <- acf(zz, plot=F)$acf[2]
    zz <- diff(zz)
  }
  plot(a,type='h')
  abline(h=0,lty=3)
dev.off()

png(file="g1045.png", width=600, height=600)
  op <- par(mfrow=c(2,2))
  n <- 20
  for (k in 1:4) {
    zz <- rnorm(100)
    for (l in 1:k) {
      zz <- cumsum(zz)+rnorm(100)
    }
    a <- rep(NA,n)
    for(i in 1:n) {
      a[i] <- acf(zz, plot=F)$acf[2]
      zz <- diff(zz)
    }
    plot(a,type='h', main=paste("Il faut d�river",k,"fois"))
    abline(h=c(0,.5,-.5),lty=3)
  }
  par(op)
dev.off()

png(file="g1046.png", width=600, height=900)
  data(sunspots)
  op <- par(mfrow=c(5,1))
  for (i in 10+1:5) {
    plot(diff(sunspots,i))
  }
  par(op)
dev.off()

png(file="g1047.png", width=600, height=600)
  nombre.de.suites <- function (x) {
    1+sum(abs(diff(as.numeric(x))))
  }
  test.du.nombre.de.suites <- function (x, R=999) {
    if( is.numeric(x) )
      x <- factor(sign(x), levels=c(-1,1))
    if( is.logical(x) )
      x <- factor(x, levels=c(FALSE,TRUE))
    if(!is.factor(x))
      stop("x should be a factor")

    # Test non param�trique, bas� sur le
    # r��chantillonage
    n <- length(x)
    res <- rep(NA, R)
    for (i in 1:R) {
      res[i] <- nombre.de.suites(
        x[sample(1:n,n,replace=F)]
      )
    }
    t0 <- nombre.de.suites(x)
    n1 <- 1+sum(t0<=res)
    n2 <- 1+sum(t0>=res)
    p <- min( n1/R, n2/R )*2
    p <- min(1,p) # On peut avoir des probl�mes
                  # si plus de la moiti� des
                  # valeurs sont identiques...
    # Test param�trique, bas� sur une formule
    # trouv�e sur Internet...  On admet que Z
    # suit � peu pr�s une loi normale (on peut
    # v�rifier, par des simulations, que c'est
    # compl�tement faux avec des �v�nements assez
    # rares -- comme les mutations qui nous
    # int�ressent).
    n1 <- sum(x==levels(x)[1])
    n2 <- sum(x==levels(x)[2])
    r <- nombre.de.suites(x)
    mr <- 2*n1*n2/(n1+n2) + 1
    sr <- sqrt( 2*n1*n2*(2*n1*n2-n1-n2)/
            (n1+n2)^2/(n1+n2-1) )
    z <- (r-mr)/sr
    pp <- 2*min(pnorm(z), 1-pnorm(z))

    r <- list(t0=t0, t=res, R=R,
              p.value.boot=p,
              n1=n1, n2=n2, r=r, mr=mr, sr=sr, z=z,
              p.value.formula=pp)
    class(r) <- "nstest"
    r
  }

  print.nstest <- function (d) {
    cat("Test du nombre de suites\n");
    cat("  NS = ")
    cat(d$t0)
    cat("\n  p-valeur (")
    cat(d$R)
    cat(" r��chantillonages) = ")
    cat(round(d$p.value.boot,digits=3))
    cat("\n")
    cat("  p-valeur th�orique = ")
    cat(d$p.value.formula)
    cat("\n")
  }

  plot.statistic <- function (t0, t, ...) {
    xlim <- range(c(t,t0))
    hist(t, col='light blue', xlim=xlim, ...)
    points(t0, par("usr")[4]*.8,
           type='h', col='red', lwd=5)
    text(t0, par("usr")[4]*.85, signif(t0,3))
  }

  plot.nstest <- function (
      d, main="Test du nombre de suites",
      ylab="effectif", ...
    ) {
    plot.statistic(d$t0, d$t, main=main,
                   xlab=paste("Nombre de suites, p =",signif(d$p.value.boot,3)), 
                   ...)
  }

  # Exemple
  data(EuStockMarkets)
  x <- EuStockMarkets[,1]
  x <- diff(log(x))
  i <- abs(x)>median(abs(x))
  plot(test.du.nombre.de.suites(i))
dev.off()

png(file="g1048.png", width=600, height=600)
  op <- par(mfrow=c(2,2))
  for (k in 1:4) {
    x <- EuStockMarkets[,k]
    x <- diff(log(x))
    i <- abs(x)>median(abs(x))
    plot(test.du.nombre.de.suites(i))
  }
  par(op)
dev.off()

png(file="g1049.png", width=600, height=600)
  sde.sim <- function (t, f, ...) {
    n <- length(t)
    S <- rep(NA,n)
    S[1] <- 1
    for (i in 2:n) {
      S[i] <- S[i-1] + f(S[i-1], t[i]-t[i-1], sqrt(t[i]-t[i-1])*rnorm(1), ...)
    }
    S
  } 
  a <- 0
  b <- 10
  N <- 1000
  x <- sde.sim(seq(a,b,length=N),
               function (S,dt,dX,m=1,s=1) { m * S * dt + s * S * dX })
  x <- ts(x, start=a, end=b, freq=(N-1)/(b-a))
  op <- par(mfrow=c(4,1))
  plot(x)
  plot(log(x))
  plot(diff(log(x)))
  acf(diff(log(x)))
  par(op)
dev.off()

png(file="g1050.png", width=600, height=600)
  N <- 1000
  a <- 0
  b <- 3

  op <- par(mfrow=c(3,1))
  for (i in 1:3) {
    x <- sde.sim(seq(a,b,length=N),
                 function (S,dt,dX,m=1,s=1) { s * dX })
    x <- ts(x, start=a, end=b, freq=(N-1)/(b-a))
    plot(x, main="Marche al�atoire")
  }
  par(op)
dev.off()

png(file="g1051.png", width=600, height=600)
  op <- par(mfrow=c(3,1))
  for (i in 1:3) {
    x <- sde.sim(seq(a,b,length=N),
                 function (S,dt,dX,m=1,s=1) { m * dt + s * dX })
    x <- ts(x, start=a, end=b, freq=(N-1)/(b-a))
    plot(x, main="Marche al�atoire avec d�rive")
  }
  par(op)
dev.off()

png(file="g1052.png", width=600, height=600)
  op <- par(mfrow=c(3,1))
  for (i in 1:3) {
    x <- sde.sim(seq(a,b,length=N),
                 function (S,dt,dX,m=1,s=1) { m * S * dt + s * S * dX })
    x <- ts(x, start=a, end=b, freq=(N-1)/(b-a))
    plot(x, main="Marche al�atoire lognormale")
  }
  par(op)
dev.off()

png(file="g1053.png", width=600, height=600)
  b <- 10
  op <- par(mfrow=c(3,1))
  for (i in 1:3) {
    x <- sde.sim(seq(a,b,length=N),
                 function (S,dt,dX,m=3,s=1,n=3) { (n - m*S) * dt + s * dX })
    x <- ts(x, start=a, end=b, freq=(N-1)/(b-a))
    plot(x, main="Mean-reverting random walk")
    abline(h=1,lty=3)
  }
  par(op)
dev.off()

png(file="g1054.png", width=600, height=600)
  op <- par(mfrow=c(3,1))
  for (i in 1:3) {
    x <- sde.sim(seq(a,b,length=N),
                 function (S,dt,dX,m=3,s=1,n=3) { (n - m*S) * dt + s * sqrt(S) * dX })
    x <- ts(x, start=a, end=b, freq=(N-1)/(b-a))
    plot(x, main="Mean-reverting random walk")
    abline(h=1,lty=3)
  }
  par(op)
dev.off()

png(file="g1055.png", width=600, height=600)
  op <- par(mfrow=c(2,1))
    x <- sde.sim(seq(a,b,length=N),
                 function (S,dt,dX,m=1,s=1) { m * S * dt + s * S * dX })
    x <- ts(x, start=a, end=b, freq=(N-1)/(b-a))
    plot(x, main="Marche al�atoire lognormale")
    return <- diff(x) / x[ -length(x) ]
    y <- return^2
    plot(y)
    lines(predict(loess(y~time(y))) ~ as.vector(time(y)), col='red', lwd=3)
  par(op)
dev.off()

png(file="g1056.png", width=600, height=600)
  n <- 200
  a <- c(1,.2,.8,.5)

  a0 <- a[1]
  a <- a[-1]
  k <- length(a)
  u <- rep(NA,n)
  u[1:k] <- a0 * rnorm(k)
  for (i in (k+1):n) {
    u[i] <- sqrt( a0 + sum(a * u[(i-1):(i-k) ]^2 )) * rnorm(1)
  }
  u <- ts(u)
  eda.ts(u)
dev.off()

png(file="g1057.png", width=600, height=600)
  h <- rnorm(1000)^2
  x <- filter(h, rep(1,50))
  x <- x[!is.na(x)]
  eda.ts(x)
dev.off()

png(file="g1058.png", width=600, height=600)
  y <- rnorm(length(x),0,sqrt(x))
  eda.ts(y)
dev.off()

png(file="g1059.png", width=600, height=600)
  h <- c(rep(1,100), rep(2,100))
  y <- ts(rnorm(length(h), 0, sd=h))
  eda.ts(y)
dev.off()

png(file="g1060.png", width=600, height=600)
  plot(abs(y))
  lines(predict(loess(abs(y)~time(y))), col='red', lwd=3)
  k <- 20
  lines(filter(abs(y), rep(1/k,k)), col='blue', lwd=3, lty=2)
dev.off()

png(file="g1061.png", width=600, height=600)
  plot.ma <- function (x, k=20, ...) {
    plot(abs(x), ...)
    a <- time(x)
    b <- predict(loess(abs(x) ~ a))
    lines(b ~ as.vector(a), col='red', lwd=3)
    k <- 20
    lines(filter(abs(x), rep(1/k,k)), col='blue', lwd=3)
  }
  plot.ma(u)  
dev.off()

png(file="g1062.png", width=600, height=600)
  n <- 1000
  op <- par(mfrow=c(4,1))
  plot.ma(ts(rnorm(n)))
  plot.ma(arima.sim(list(ar = c(.8,.1)), n))
  plot.ma(arima.sim(list(ma = c(.8,.1)), n))
  plot.ma(arima.sim(list(ma = c(.8,.4,.1), ar = c(.8,.1)), n))
  par(op)
dev.off()

png(file="g1063.png", width=600, height=600)
  op <- par(mfrow=c(1,4))
  data(EuStockMarkets)
  for (a in 1:4) {
    x <- EuStockMarkets[,a]
    x <- diff(log(x))

    n <- length(x)
    s <- rep(NA, n+1)
    s[ which(x>0) + 1 ] <- "+"
    s[ which(x<0) + 1 ] <- "-"
    i <- which( !is.na(s) )
    s <- factor(s[i])
    x <- x[i]
    boxplot(log(abs(x))~s, col='light blue')
  }
  par(op)
dev.off()

png(file="g1064.png", width=600, height=600)
  data(EuStockMarkets)
  x <- EuStockMarkets[,1]
  op <- par(mfrow=c(3,1))
  plot(x, main="Un indice boursier")
  y <- diff(log(x))
  plot(abs(y), main="volatilit�")
  k <- 30
  z <- filter(abs(y),rep(1,k)/k)
  plot(z, ylim=c(0,max(z,na.rm=T)), col='red', type='l', 
       main="volatilit� liss�e (30 jours)")
  par(op)
dev.off()

png(file="g1065.png", width=600, height=600)
  n <- 200
  v <- function (t) { .1*(.5 + sin(t/50)^2) }
  x <- 1:n
  y <- rnorm(n) * v(x)
  y <- ts(y)
  op <- par(mfrow=c(3,1))
  plot(ts(cumsum(y)), main="Une simulation")
  plot(abs(y), main="volatilit�")
  plot(v(x)~x, 
       ylim=c(0,.3),
       type='l', lty=2, main="volatilit� liss�e")
  k <- c(5,10,20,50)
  col <- rainbow(length(k))
  for (i in 1:length(k)) {
    z <- filter(abs(y),rep(1,k[i])/k[i])
    lines(z, col=col[i])
  }
  par(op)
dev.off()

png(file="g1066.png", width=600, height=600)
  library(tseries)
  x <- EuStockMarkets[,1]
  y <- diff(x)/x
  r <- garch(y)
  # plot(r)   La fonction plot ne marche qu'en interactif...
  op <- par(mfrow=c(2,1))
  plot(y, main = r$series, ylab = "Series")
  plot(r$residuals, main = "Residuals", ylab = "Series")
dev.off()

png(file="g1067.png", width=600, height=600)
  hist(y, main = paste("Histogram of", r$series), xlab = "Series")
  hist(r$residuals, main = "Histogram of Residuals", xlab = "Series")
dev.off()

png(file="g1068.png", width=600, height=600)
  qqnorm(y, main = paste("Q-Q Plot of", r$series), xlab = "Normal Quantiles")
  qqnorm(r$residuals, main = "Q-Q Plot of Residuals", xlab = "Normal Quantiles")
dev.off()

png(file="g1069.png", width=600, height=600)
  acf(y^2, main = paste("ACF of Squared", r$series))
  acf(r$residuals^2, main = "ACF of Squared Residuals", na.action = na.remove)
  par(op)
dev.off()

png(file="g1070.png", width=600, height=600)
  data(EuStockMarkets)
  x <- EuStockMarkets[,1]
  y <- EuStockMarkets[,2]
  acf(ts.union(x,y),lag.max=100)
dev.off()

png(file="g1071.png", width=600, height=600)
  x <- diff(x)
  y <- diff(y)
  acf(ts.union(x,y),lag.max=100)
dev.off()

png(file="g1072.png", width=600, height=600)
  n <- 2000
  x <- 1:n
  y <- sin(x/10) + cos(pi*x/20) + rnorm(n)
  op <- par(mfrow=c(4,1))
  plot(ts(y))
  acf(y)
  pacf(y)
  spectrum(y, col=par('fg'))
  abline(v=c(1/40,1/20/pi), lty=3)
  par(op)
dev.off()

png(file="g1073.png", width=600, height=800)
  see.ts <- function (name, ma=NULL, ar=NULL, d=0, n=2000) {
    order=c(length(ar), d, length(ma))
    x <- arima.sim(list(ma=ma, ar=ar, order=order), n)
    op <- par(mfrow=c(4,1))
    plot(x, main=name)
    acf(x)
    pacf(x)
    spectrum(x, spans=10, col=par('fg'))
    par(op)
  }
  n <- 200
  see.ts("MA(1) theta_1=.9", .9)
dev.off()

png(file="g1074.png", width=600, height=800)
  see.ts("MA(1) theta_1=.5", .5)
dev.off()

png(file="g1075.png", width=600, height=800)
  see.ts("MA(1) theta_1=.1", .1)
dev.off()

png(file="g1076.png", width=600, height=800)
  see.ts("MA(1) theta_1=-.9", -.9)
dev.off()

png(file="g1077.png", width=600, height=800)
  see.ts("AR(1) phi_1=.9", 0, .9)
dev.off()

png(file="g1078.png", width=600, height=800)
  see.ts("AR(1) phi_1=.8", 0, .9)
dev.off()

png(file="g1079.png", width=600, height=800)
  see.ts("AR(1) phi_1=.5", 0, .5)
dev.off()

png(file="g1080.png", width=600, height=800)
  see.ts("AR(1) phi_1=.1", 0, .1)
dev.off()

png(file="g1081.png", width=600, height=800)
  see.ts("AR(1) phi_1=-.9", 0, -.9)
dev.off()

png(file="g1082.png", width=600, height=800)
  see.ts("AR(1) phi_1=-.8", 0, -.8)
dev.off()

png(file="g1083.png", width=600, height=800)
  see.ts("ARMA(1,1) theta_1=.9 phi_1=.9", .9, .9)
dev.off()

png(file="g1084.png", width=600, height=800)
  see.ts("ARMA(1,1) theta_1=.9 phi_1=-.9", .9, -.9)
dev.off()

png(file="g1085.png", width=600, height=800)
  see.ts("ARMA(1,1) theta_1=-.9 phi_1=.9", -.9, .9)
dev.off()

png(file="g1086.png", width=600, height=800)
  see.ts("ARMA(1,1) theta_1=-.9 phi_1=-.9", -.9, -.9)
dev.off()

png(file="g1087.png", width=600, height=600)
  op <- par(mfrow=c(4,1))
  data(AirPassengers)
  plot(AirPassengers)
  acf(AirPassengers)
  pacf(AirPassengers)
  spectrum(AirPassengers);
  par(op)
dev.off()

png(file="g1088.png", width=600, height=600)
  op <- par(mfrow=c(4,1))
  data(austres)
  plot(austres)
  acf(austres)
  pacf(austres)
  spectrum(austres);
  par(op)
dev.off()

png(file="g1089.png", width=600, height=600)
  op <- par(mfrow=c(4,1))
  data(beavers)
  plot(ts(beaver1$temp))
  acf(beaver1$temp)
  pacf(beaver1$temp)
  spectrum(beaver1$temp);
  par(op)
dev.off()

png(file="g1090.png", width=600, height=600)
  op <- par(mfrow=c(4,1))
  data(BJsales)
  plot(BJsales)
  acf(BJsales)
  pacf(BJsales)
  spectrum(BJsales);
  par(op)
dev.off()

png(file="g1091.png", width=600, height=600)
  op <- par(mfrow=c(4,1))
  data(EuStockMarkets)
  plot(EuStockMarkets[,1])
  acf(EuStockMarkets[,1])
  pacf(EuStockMarkets[,1])
  spectrum(EuStockMarkets[,1]);
  par(op)
dev.off()

png(file="g1092.png", width=600, height=600)
  op <- par(mfrow=c(4,1))
  data(JohnsonJohnson)
  plot(JohnsonJohnson)
  acf(JohnsonJohnson)
  pacf(JohnsonJohnson)
  spectrum(JohnsonJohnson);
  par(op)
dev.off()

png(file="g1093.png", width=600, height=600)
  op <- par(mfrow=c(4,1))
  data(LakeHuron)
  plot(LakeHuron)
  acf(LakeHuron)
  pacf(LakeHuron)
  spectrum(LakeHuron);
  par(op)
dev.off()

png(file="g1094.png", width=600, height=600)
  op <- par(mfrow=c(4,1))
  data(lh)
  plot(lh)
  acf(lh)
  pacf(lh)
  spectrum(lh);
  par(op)
dev.off()

png(file="g1095.png", width=600, height=600)
  op <- par(mfrow=c(4,1))
  data(lynx)
  plot(lynx)
  acf(lynx)
  pacf(lynx)
  spectrum(lynx);
  par(op)
dev.off()

png(file="g1096.png", width=600, height=600)
  op <- par(mfrow=c(4,1))
  data(Nile)
  plot(Nile)
  acf(Nile)
  pacf(Nile)
  spectrum(Nile);
  par(op)
dev.off()

png(file="g1097.png", width=600, height=600)
  op <- par(mfrow=c(4,1))
  data(nottem)
  plot(nottem)
  acf(nottem)
  pacf(nottem)
  spectrum(nottem);
  par(op)
dev.off()

png(file="g1098.png", width=600, height=600)
  op <- par(mfrow=c(4,1))
  #data(sunspot, package=ts) # Il y en a aussi dans "boot"...
  data(sunspot)
  plot(sunspot.month)
  acf(sunspot.month)
  pacf(sunspot.month)
  spectrum(sunspot.month);
  par(op)
dev.off()

png(file="g1099.png", width=600, height=600)
  op <- par(mfrow=c(4,1))
  data(treering)
  plot(treering)
  acf(treering)
  pacf(treering)
  spectrum(treering);
  par(op)
dev.off()

png(file="g1100.png", width=600, height=600)
  op <- par(mfrow=c(4,1))
  data(UKDriverDeaths)
  plot(UKDriverDeaths)
  acf(UKDriverDeaths)
  pacf(UKDriverDeaths)
  spectrum(UKDriverDeaths);
  par(op)
dev.off()

png(file="g1101.png", width=600, height=600)
  op <- par(mfrow=c(4,1))
  data(UKLungDeaths)
  plot(ldeaths)
  acf(ldeaths)
  pacf(ldeaths)
  spectrum(ldeaths);
  par(op)
dev.off()

png(file="g1102.png", width=600, height=600)
  op <- par(mfrow=c(4,1))
  data(UKgas)
  plot(UKgas)
  acf(UKgas)
  pacf(UKgas)
  spectrum(UKgas);
  par(op)
dev.off()

png(file="g1103.png", width=600, height=600)
  op <- par(mfrow=c(4,1))
  data(USAccDeaths)
  plot(USAccDeaths)
  acf(USAccDeaths)
  pacf(USAccDeaths)
  spectrum(USAccDeaths);
  par(op)
dev.off()

png(file="g1104.png", width=600, height=600)
  op <- par(mfrow=c(4,1))
  data(WWWusage)
  plot(WWWusage)
  acf(WWWusage)
  pacf(WWWusage)
  spectrum(WWWusage);
  par(op)
dev.off()

png(file="g1105.png", width=600, height=600)
  library(Rgraphviz)
  data(graphExamples)
  op <- par(mfrow=c(3,3))
  set.seed(2)
  for (i in 1:9) {
    try(   plot(randomGraph(LETTERS[1:10], 1, .3))   )
  }
  par(op)
dev.off()

png(file="g1106.png", width=600, height=600)
  op <- par(mfrow=c(3,3))
  for (i in 1:9) {
    try(   plot(randomGraph(LETTERS[1:10], 1, .5))   )
  }
  par(op)
dev.off()

png(file="g1107.png", width=600, height=600)
  op <- par(mfrow=c(3,3))
  for (i in 1:9) {
    try(   plot(randomGraph(LETTERS[1:10], 1, .8))   )
  }
  par(op)
dev.off()

png(file="g1108.png", width=600, height=600)
  op <- par(mfrow=c(2,2))
  for (a in 1:4) {

    n <- 10
    V <- LETTERS[1:n]
    m <- matrix(sample(0:1,n*n,replace=T,prob=c(.8,.2)), nr=n, nc=n, dimnames=list(V,V))
    m <- m + t(m)
    m <- 1 - (m-1)*(m-2)/2
    m <- m - diag(diag(m))

    e <- vector("list", length=n)
    names(e) <- V
    for (i in 1:n) {
      e[[i]] <- list( edges = which(m[i,]==1) )  # Les num�ros des sommets, pas leurs noms
    } 
    g <- new("graphNEL", nodes=V, edgeL=e)
    plot(g)

  }
  par(op)
dev.off()

png(file="g1109.png", width=600, height=600)
  my.gibbs <- function (x0=c(0,0), N=20, r=.5, plot.it=T) {
    res <- matrix(NA, nr=N, nc=2)
    res[1,] <- c(0,0)
    for (i in seq(2,N-1,by=2)) {
      x1 <- res[i-1,1]
      x2 <- res[i-1,2]
      res[i,2] <- x2
      # Normalement, on devrait prendre un nouveau point n'importe comment
      # et l'accepter ou le rejeter -- pour simplifier, j'en prend directement
      # un suivant la probabilit� marginale. 
      x1 <- rnorm(1, r*x2, sd=sqrt(1-r^2))
      res[i,1] <- x1
      res[i+1,1] <- x1
      x2 <- rnorm(1, r*x1, sd=sqrt(1-r^2))
      res[i+1,2] <- x2
    }
    if (plot.it) {
      plot(res, type='l', xlab="x1", ylab="x2", main="Gibbs sampler")
      points(res, pch=16)
      invisible(res)
    } else {
      res
    }
  }
  my.gibbs()
dev.off()

png(file="g1110.png", width=600, height=600)
  my.gibbs(N=1000)
dev.off()

png(file="g1111.png", width=600, height=600)
  r <- my.gibbs(N=40,plot.it=F)[2*(1:20),]
  plot(r, type='l', xlab="x1", ylab="x2",
       main="Trajectoire d'une simulation de M�tropolis (presque)")
  points(r, pch=16)
dev.off()

png(file="g1112.png", width=600, height=600)
  r <- my.gibbs(N=2000,plot.it=F)[2*(1:1000),]
  plot(r, type='l', xlab="x1", ylab="x2",
       main="Trajectoire d'une simulation de M�tropolis (presque)")
  points(r, pch=16)
dev.off()

png(file="g1113.png", width=600, height=600)
  N <- 200
  K <- 5
  res <- matrix(NA, nr=N, nc=K)
  for (i in 1:K) {
    r <- my.gibbs(x0=runif(2,-1,1), N=N, plot.it=F)
    res[,i] <- apply(r,1,cumsum)[1,] / 1:N
  }
  matplot(res, type='l', lty=1,
          ylab="Estimateur", xlab="Longueur de la simulation",
          main="Gibbs sampler")
dev.off()

png(file="g1114.png", width=600, height=600)
  library(ts)
  MH <- function (N = 1000, 
                  voisin = function (x) { rnorm(1,x,1) },
                  p = dnorm,                 # Distribution de probabilit� � simuler
                  q = function (x,y) { 1 }   # Correction de Hastings
                 ) {
    res <- rep(NA,N)
    x <- 0
    for (i in 1:N) {
      y <- voisin(x)
      u <- runif(1)
      if ( u < q(x,y)/q(y,x) * p(y)/p(x) ) {
        x <- y
      }
      res[i] <- x
    }
    ts(res)
  }

  x1 <- ts(rnorm(1000))
  x2 <- MH()
  x3 <- MH(voisin = function (x) { rnorm(1,x,.01) })
  x4 <- MH(voisin = function (x) { rnorm(1,x,50) })

  op <- par(mfrow=c(4,1))
  plot(x1, main="Hasard")
  plot(x2, main="MCMC")
  plot(x3, main="MCMC, voisins trop proches")
  plot(x4, main="MCMC, voisins trop lointains")
  par(op)
dev.off()

png(file="g1115.png", width=600, height=600)
  op <- par(mfrow=c(2,2))
  qqnorm(x1, main="Hasard"); qqline(x1); 
  qqnorm(x2, main="MCMC"); qqline(x2); 
  qqnorm(x3, main="MCMC, voisins trop proches"); qqline(x3); 
  qqnorm(x4, main="MCMC, voisins trop lointains"); qqline(x4)
  par(op)
dev.off()

png(file="g1116.png", width=600, height=600)
  op <- par(mfrow=c(2,2))
  hist(x1, col='light blue', probability=T, main="Hasard")
  curve(dnorm(x),col='red',lwd=3, add=T)
  hist(x2, col='light blue', probability=T, main="MCMC")
  curve(dnorm(x),col='red',lwd=3, add=T)
  hist(x3, col='light blue', probability=T, main="MCMC, voisins trop proches")
  curve(dnorm(x),col='red',lwd=3, add=T)
  hist(x4, col='light blue', probability=T, main="MCMC, voisins trop lointains")
  curve(dnorm(x),col='red',lwd=3, add=T)
  par(op)
dev.off()

png(file="g1117.png", width=600, height=600)
  op <- par(mfrow=c(4,1))
  acf(x1, main="Hasard")
  acf(x2, main="MCMC")
  acf(x3, main="MCMC, voisins trop proches")
  acf(x4, main="MCMC, voisins trop lointains")
  par(op)
dev.off()

png(file="g1118.png", width=600, height=600)
  op <- par(mfrow=c(4,1))
  pacf(x1, main="Hasard")
  pacf(x2, main="MCMC")
  pacf(x3, main="MCMC, voisins trop proches")
  pacf(x4, main="MCMC, voisins trop lointains")
  par(op)
dev.off()

png(file="g1119.png", width=600, height=600)
  N <- 3000
  x <- MH(N=N)
  plot(x[2:N]~x[2:N-1],xlab='x(i)',ylab='x(i+1)')
  abline(0,1,col='red')
dev.off()

png(file="g1120.png", width=600, height=600)
  N <- 100000
  x <- MH(N=N)
  x <- x[100:length(x)]  # burn-in
  x <- x[seq(1,length(x),by=50)]
  N <- length(x)
  plot(x[2:N]~x[2:N-1],xlab='x(i)',ylab='x(i+1)')
  abline(0,1,col='red')
dev.off()

png(file="g1121.png", width=600, height=600)
  op <- par(mfrow=c(4,1))
  plot(ts(x))
  acf(x)
  pacf(x)
  spectrum(x)
  par(op)
dev.off()

png(file="g1122.png", width=600, height=600)
  x <- seq(0,1, length=100)
  x <- x[2:(length(x)-1)]
  logit <- function (t) {
    log( t / (1-t) )
  }
  plot(logit(x) ~ x, type='l')
dev.off()

png(file="g1123.png", width=600, height=600)
  curve(logit(x), col='blue', add=F)
  curve(qnorm(x), col='red', add=T)
  a <- par("usr")
  legend( a[1], a[4], c("logit","probit"), col=c("blue","red"), lty=1)
dev.off()

png(file="g1124.png", width=600, height=600)
  N <- 10000
  f <- NULL
  c <- NULL
  for (i in 1:N) {
    x <- sample( c(rep(0,3),rep(1,7)), 10, replace=T )
    y <- sample( c(0,1), 10, replace=T )
    x <- factor(x, levels=c(0,1))
    y <- factor(y, levels=c(0,1))
    t <- table(x,y)
    f <- append(f, fisher.test(t)$p.value)
    c <- append(c, chisq.test(t)$p.value)
  }
  plot(sort(f), type='l')
  points(sort(c), type='l', col='red')
dev.off()

png(file="g1125.png", width=600, height=600)
  x <- sample( c(rep(0,3),rep(1,7)), 10, replace=T )
  y <- sample( c(0,1), 10, replace=T )
  x <- factor(x, levels=c(0,1))
  y <- factor(y, levels=c(0,1))
  pValeur <- function (x,y, N=1000) {
    x <- factor(x)
    y <- factor(y)
    s <- numeric(N)
    for (i in 1:N) {
      xx <- sample( x, length(x), replace=T )
      yy <- sample( y, length(y), replace=T )
      s[i] <- as.numeric(chisq.test(table(xx,yy))$statistic)
    }
    t <- table(x,y)
    p <- sum( chisq.test(t)$statistic > s )/length(s)
    if( p>.5 ) p <- 1-p
    p
  }
  t <- table(x,y)
  c( ChiSq = chisq.test(t)$p.value, Fisher = fisher.test(t)$p.value, MonteCarlo = pValeur(x,y) )

  #Repr�sentons maintenant nos trois p-valeurs sur un m�me graphique.

  N <- 100
  f <- NULL
  c <- NULL
  s <- NULL
  for (i in 1:N) {
    x <- sample( c(rep(0,3),rep(1,7)), 10, replace=T )
    y <- sample( c(0,1), 10, replace=T )
    x <- factor(x, levels=c(0,1))
    y <- factor(y, levels=c(0,1))
    t <- table(x,y)
    f <- append(f, fisher.test(t)$p.value)
    c <- append(c, chisq.test(t)$p.value)
    s <- append(s, pValeur(x,y,100))
  }
  plot(sort(f), type='l')
  points(sort(c), type='l', col='green')
  points(sort(s), type='l', col='red')
  
  # J'ai de TR�S gros doutes sur la pertinence de mes calculs...
  # A FAIRE
dev.off()

png(file="g1126.png", width=600, height=600)
  n <- 100
  x1 <- rnorm(n)
  x2 <- rnorm(n)
  x3 <- rnorm(n)
  y <- x1 - x2*x2 + 2*x3 + rnorm(n)
  pairs(cbind(y,x1,x2))
dev.off()

png(file="g1127.png", width=600, height=600)
  y3  <- lm(y~x3)$residuals
  x13 <- lm(x1~x3)$residuals
  x23 <- lm(x2~x3)$residuals
  plot( y3 ~ x13,
        xlab="x1 sans les effets lin�aires de x3",
        ylab="y sans les effets lin�aires de x3" )
dev.off()

png(file="g1128.png", width=600, height=600)
  library(lattice)
  bwplot( ~ y3 | equal.count(x13), layout=c(1,6) )    
dev.off()

png(file="g1129.png", width=1200, height=600)
  bwplot( ~ y3 | equal.count(x13) + equal.count(x23) )    
dev.off()

png(file="g1130.png", width=600, height=600)
  n <- 1000
  x <- runif(n)
  x <- x>.5
  x <- cumsum(x)/(1:n)
  plot(x, ylim=c(0,1), type="l")
dev.off()

png(file="g1131.png", width=600, height=600)
  plot(x, ylim=c(0,1), type="l", log="x")
dev.off()

png(file="g1132.png", width=600, height=600)
  N <- 10
  n <- 20
  x <- rnorm(n*N)
  y <- rep(1:n, N)
  boxplot(x ~ y)
dev.off()

png(file="g1133.png", width=600, height=600)
  par( mfrow = c(4,5) )
  for (i in 1:n) {
    hist(x[ y==i ])
  }
dev.off()

png(file="g1134.png", width=600, height=600)
  N <- 100
  n <- 20
  x <- rnorm(n*N)
  y <- rep(1:n, N)
  boxplot(x ~ y)
dev.off()

png(file="g1135.png", width=600, height=600)
  par( mfrow = c(4,5) )
  for (i in 1:n) {
    hist(x[ y==i ])
  }
dev.off()

png(file="g1136.png", width=600, height=600)
  N <- 3
  n <- 20
  x <- rnorm(n*N)
  y <- rep(1:n, N)
  m <- matrix(x, nrow=N, byrow=T)
  c <- apply(m,2,min)>0 | apply(m,2,max)<0
  boxplot(x ~ y, col=c(0,6)[1+c])
dev.off()

png(file="g1137.png", width=600, height=600)
  x <- rnorm(10+100+1000+10000+100000)
  y <- c( rep(5,10), rep(4,100), rep(3,1000), rep(2,10000), rep(1,100000))
  boxplot(x~y, horizontal=T, axes=F)
  axis(1)
  axis(2, 1:5, c(10,100,1000,10000,100000) )
dev.off()

png(file="g1138.png", width=600, height=600)
  x <- 1:9
  y <- log(1+1/x)/log(10)
  plot(y~x, type="h")
dev.off()

png(file="g1139.png", width=600, height=600)
  a <- read.table("Cours.txt")
  a <- a[a>0]
  a <- as.vector(a)
  a <- floor(a*10^-floor(log(a)/log(10)))
  hist(a, probability=T)
  points((x+.5), y, type='h', col='red', lwd=3)
  chisq.test(table(factor(a)), p=y) # p-value = 0.06
dev.off()

png(file="g1140.png", width=600, height=600)
  a <- read.table("Volume.txt")
  a <- a[a>0]
  a <- as.vector(a)
  a <- floor(a*10^-floor(log(a)/log(10)))
  hist(a, probability=T)
  points((x+.5), y, type='h', col='red', lwd=3)
  chisq.test(table(factor(a)), p=y) # p-value = 0.85
dev.off()

png(file="g1141.png", width=600, height=600)
  plot(sort(runif(100)))
  for (i in 1:1000) {
    lines( sort(runif(100)) )
  }
dev.off()

png(file="g1142.png", width=600, height=600)
  n <- 1000
  m <- 200
  a <- matrix( runif(n*m), c(n,m) )
  b <- apply(a, 1, sort)
  c <- apply(b, 1, range)
  plot( c[1,], type="l" )
  lines( c[2,] )

  n <- 10
  m <- 200
  a <- matrix( runif(n*m), c(n,m) )
  b <- apply(a, 1, sort)
  c <- apply(b, 1, range)
  lines( c[1,] )
  lines( c[2,] )
dev.off()
