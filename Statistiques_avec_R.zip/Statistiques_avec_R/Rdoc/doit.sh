#! /bin/sh
(
  echo '<html><head><title>Exemples tir�s de la documentation de R</title></head><body>'
  ls *.png | perl -p -e 's#^(.+)_([0-9]+)(.*)#<tt>$1</tt><center><img src="$1_$2$3"></center><hr>#'
  echo '</body>'
) > index.html

