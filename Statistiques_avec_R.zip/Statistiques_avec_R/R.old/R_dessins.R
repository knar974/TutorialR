a = c(1,4,9,6,8,6,3,4,6,4,5,9,0,1,7,3,4)
postscript()

# 1
barplot(table(a))

# 2 
pie(table(a))

# 3
hist(a)

# 4
hist(a, probability=TRUE)

# 5
hist(a)
rug(jitter(a))

# 6
hist(a, breaks=10)

# 7
hist(a, breaks=c(0,3,5,7,max(a)))

# 8
boxplot(a)

# 9
tmp = hist(a)
lines( c(min(tmp$breaks),tmp$mids,max(tmp$breaks)),
           c(0,tmp$counts,0), 
           type="l")

# 10
hist(a, probability=TRUE)
points(density(a),type='l')
points(density(a,bw=.1),type='l')

# 11
data(package='MASS')
library("MASS")
data(biopsy)
barplot(table(biopsy$class, biopsy$V7), beside=TRUE)

# 12
barplot(table(biopsy$V7, biopsy$class))

# 13
boxplot( biopsy$V7 [biopsy$class == 'benign'], 
         biopsy$V7 [biopsy$class == 'malignant'])

# 14
boxplot( biopsy$V7 ~ biopsy$class )

# 15
data(crabs)
boxplot( crabs$RW, crabs$CW)

# 16
boxplot( as.data.frame(scale(data.frame( crabs$RW, crabs$CW ))))

# 17
stripchart(crabs$RW[1:20])

# 18
stripchart(data.frame(crabs$RW, crabs$CW))
# 19
stripchart(crabs)

# 20
plot(crabs$CL, crabs$CW)

# 21
plot(crabs$CL, crabs$CW)
abline(lm( crabs$CL ~ crabs$CW ))

# 22
lm.res = lm(crabs$CL ~ crabs$CW)
  hist(residuals(lm.res))

# 23
plot(lm.res$fitted.values, lm.res$residuals)
abline(0,0)

# 24
qqnorm(a); qqline(a)
# 25
qqnorm(crabs$CL); qqline(crabs$CL)
# 26
x = rnorm(100); qqnorm(x); qqline(x)
# 27
x = runif(100); qqnorm(x); qqline(x)

# 28
lm.res = lm(crabs$CL ~ crabs$CW)
qqnorm(residuals(lm.res)); qqline(residuals(lm.res))

# 29
x = rnorm(1000)
y = exp(x)
qqnorm(y); qqline(y)

# 30
y = x[x>0]
qqnorm(y); qqline(y)

# 31
y = rexp(1000)
qqnorm(y); qqline(y)


