  


  doit <- function (d) {
    name <- as.character(substitute(d))
    cat(paste("Processing", name, "\n"))
    if (!exists(name)) {
      cat(paste("  Skipping (does not exist!)", name, "\n"))
    } else if (is.vector(d)) {
      doit2(d, name)
    } else if (is.data.frame(d)) {
      for (x in names(d)) {
        cat(paste("Processing", name, "/", x, "\n"))
        doit2(d[[x]], paste(name,"/",x))
      }
    } else
      cat(paste("  Skipping (unknown reason)", substitute(d), "\n"))
  }

  doit2 <- function (x,n) {
    if( is.factor(x) ) 
      really.do.it(x,n)
    else
      cat("    Skipping (non factor)\n")
  }

  really.do.it <- function (x,name) {
    x <- x[!is.na(x)]
    n <- length(levels(x))
    if( n>20 ) {
      dotchart(table(x), main=name)
      cat(paste("      OK ", n, sep=''))
    }
  }

  source("ALL.R", echo=F)
