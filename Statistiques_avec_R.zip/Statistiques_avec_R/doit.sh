#!/bin/zsh

rm -f *__TMP__*
perl doit.pl [0-9][0-9]*.txt

R --vanilla --no-save < g.R

echo '<html><head><title>Statistiques avec R</title>
    <style type="text/css">
BODY {
  background-color: #FFFFFF;
  color: #000000;
}
H1 {
  background-color: #ffdb43;
  color: #000000;
  padding: 20pt;
  margin-left:  20%;
  margin-right: 20%;
  text-align: center;
}
P.intro {
  margin-left: 10%;
  margin-right: 10%;
}
P {
  margin-left: 15%;
  margin-right: 15%;
}
    </style>
    <meta http-equiv="Content-Style-Type" content="text/css">
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head><body>' > all.html
echo "<p align='center'><img alt="Statistiques avec R" height=400 width=800 src="titre.png"></p>
<P class='intro'>Mise en garde<br>
Voici les notes que j'ai prises en d�couvrant, apprenant et utilisant
le logiciel de statistiques R. N�anmoins, je ne revendique aucune
autorit� dans ce domaine : j'esp�re que ces notes vous seront utiles,
mais elles peuvent toujours comporter des erreurs.
</P>
" >> all.html

echo '<p>' >> all.html
n=1
for i in [0-9]*.new__TMP__.txt
do
  j=`echo $i | perl -p -e 's/\.new__TMP__\.txt$//'`
  echo " ----" Processing $j
  echo $n'. <a href="'$j'.html">' >> all.html
  head -1 $i >> all.html
  echo '</a><br>' >> all.html
  ( txt2xml --toc $i | xml2html > $j.html ) || exit 1
  n=$(( n+1 ))
done
echo '</p>' >> all.html
echo '<p align ="RIGHT"><font color="#c8c8c8"><a href="http://www.math.jussieu.fr/~zoonek/" style="text-decoration: none">Vincent Zoonekynd</a><br>
<a href="mailto:zoonek@math.jussieu.fr" style="text-decoration: none">&lt;zoonek@math.jussieu.fr></a><br>
latest modification on '`date`'
</font></p>' >> all.html
echo '</body></html>' >> all.html

perl -p -i -e 's/(href="[0-9][0-9]).*?"/$1.html"/' all.html [0-9][0-9]_*.html
perl rename.pl 's/_.*.html/.html/' [0-9][0-9]_*.html

