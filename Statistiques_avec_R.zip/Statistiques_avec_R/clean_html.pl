#! perl -w
use strict;

die "usage: $1 file.html" unless $ARGV[0];
open(HTML,$ARGV[0]) || die "Cannot open $ARGV[0] for reading: $!";
my $tout = join('',<HTML>);
close HTML;

my $new = "";
while( $tout =~ s/^(.*?)SRC\=\"([^"]*)\"//si ){ #"
  my $avant = $1;
  my $file = $2;
  print STDERR "Looking for the size of $file\n";
  open(SIZE, "file $file /dev/null|") || 
    warn "Cannot run `file $file /dev/null': $!";
#    warn "Cannot run `convert -verbose $file /dev/null': $!";
  my $tmp = join('',<SIZE>);
  close SIZE;
  my($width,$height)=(10,10);
  if($tmp =~ m/([0-9]+) x ([0-9]+)/){
    $width = $1;
    $height = $2;
  }
  print STDERR " width: $width height: $height\n";
  $new .= "$avant WIDTH=$width HEIGHT=$height SRC=\"$file\" ";
}
$new .= $tout;

open(HTML, ">$ARGV[0]") || die "Cannot open $ARGV[0] for writing: $!";
print HTML $new;
close HTML;


