#!/bin/zsh

rm -f *__TMP__*
perl doit_tex.pl [0-9]*.txt

R --vanilla --no-save < g.R

echo '\documentclass{book}
\usepackage[left=2cm,right=2cm,top=2cm,bottom=2cm,nofoot]{geometry}
\usepackage{graphicx}
\usepackage[latin1]{inputenc}
\usepackage[T1]{fontenc}
\usepackage[frenchb]{babel}
\parindent=0pt
\usepackage{verbatim}
\makeatletter
  \let\old@vst\verbatim@startline
  \def\verbatim@startline{\hspace{1cm}\old@vst}
  \def\verbatim@font{\normalfont\ttfamily
                     \footnotesize
                     \hyphenchar\font\m@ne
                     \let\do\do@noligs
                     \verbatim@nolig@list}
\makeatother
\begin{document}
\title{Statistiques avec R}
\author{Vincent \textsc{Zoonekynd} <zoonek@math.jussieu.fr}
\maketitle

\chapter{Mise en garde}'"
Voici les notes que j'ai prises en d�couvrant, apprenant et utilisant
le logiciel de statistiques R. N�anmoins, je ne revendique aucune
autorit� dans ce domaine : j'esp�re que ces notes vous seront utiles,
mais elles peuvent toujours comporter des erreurs.

" > all.tex

for i in [0-9]*.new__TMP__.txt
do
  j=`echo $i | perl -p -e 's/\.new__TMP__\.txt$//'`
  ( txt2xml $i | perl xml2tex >> all.tex ) || exit 1
  n=$(( n+1 ))
done

echo '\tableofcontents
\end{document}' >> all.tex

pdflatex all.tex
