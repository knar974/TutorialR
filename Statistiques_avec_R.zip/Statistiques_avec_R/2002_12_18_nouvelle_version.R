# load me with:
#   source("...")

options(digits=3)
new.classe <- function (eleves) { 
  c =  list(
    list(nom="Minimum", fonction=function(x,...){min(x,na.rm=T)}),
    list(nom="M�diane", fonction=function(x,...){median(x,na.rm=T)}),
    list(nom="Maximum", fonction=function(x,...){max(x,na.rm=T)}),
    list(nom="Moyenne", fonction=function(x,...){mean(x,na.rm=T)}),
    list(nom="Ecart-type", fonction=function(x,...){sd(x,na.rm=T)})
  )
  a = list(eleves=eleves,
           column.functions = c
          ) 
  attr(a, "class") <- c("classe")
  a
}
new.trimestre <- function (classe) { 
  df <- data.frame(nom = classe[["eleves"]], row.names = classe[["eleves"]])
  df <- df[,FALSE]
  a <- classe
  a[["notes"]] <- df
  a[["devoirs"]] <- list()
  attr(a, "class") <- c("trimestre", "classe", "list")
  a
}
add.new.mark <- function (trimestre, nom, coefficient) {
  trimestre[["devoirs"]][[nom]] <- coefficient
  trimestre
}
edit.trimestre <- function (trimestre) {
  trimestre$notes <- edit(trimestre$notes)
  trimestre
}
print.trimestre <- function (trimestre) {
  print.trimestre.text(trimestre)
  print.trimestre.graphics(trimestre)
}
print.trimestre.text <- function (trimestre) {
  a <- trimestre[["notes"]]
  Moyenne <- apply(a, 1, trimestre$moyenne)
  a <- cbind(a,Moyenne)
  v <- NULL
  n <- NULL
  for (i in trimestre[["column.function"]]){
    vv <- apply(a, 2, i$fonction)
    if( is.null(v) ){
      v <- vv 
      n <- c(i$nom)
    } else {
      v <- rbind(v,vv)
      n <- append(n, i$nom)
    }
  }
  attr(v, "dimnames")[[1]] <- n
  v <- data.frame(v)
  a <- rbind(a,v)
  print(a)
}
print.trimestre.graphics <- function (trimestre) {
  x <- trimestre$notes
  x <- t(t(x) - apply(x, 2, mean, na.rm=T))
  x[ is.na(x) ] <- 0
  op <- par(ask=T)
  plot(princomp(x), main="Scree plot")
  biplot(princomp(x), main="Principal Components")
  plot(hclust(dist(x)))
  n <- 2
  cl <- kmeans(x, n, 20)
  plot(x, col = cl$cluster, main="K-means")
  points(cl$centers, col = 1:n, pch = 8)
  par(las=1)
  boxplot(data.frame(x), horizontal=T, main="Marks per test")
  boxplot(data.frame(t(x)), horizontal=T, main="Marks per pupil")
  boxplot(data.frame(t( apply(-x,2,rank) )), horizontal=T, main="Marks per pupil (Pearson's rank)")
  par(op)
}
S4 <- new.classe(c("aaa", "bbb", "ccc", "ddd"))
S4T1 <- new.trimestre(S4)
print.default(S4T1)
S4T1 <- add.new.mark(S4T1, "DM1", 2)
S4T1 <- add.new.mark(S4T1, "DM2", 2)
print.default(S4T1)
S4T1$notes <- data.frame(S4T1$notes, DM1 = c(19, 11, 12, 9))
S4T1$notes <- data.frame(S4T1$notes, DM2 = c(18,6,14,11))
#S4T1 <- edit(S4T1)
S4T1$moyenne <- function(x) { mean(c(x["DM1"], x["DM1"], x["DM2"])) }
print.default(S4T1)
print(S4T1)
