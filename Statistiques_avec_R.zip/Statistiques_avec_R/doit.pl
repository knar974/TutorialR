#! perl -w
use strict;

use constant TEXT => 1;
use constant GRAPH => 2;
my $state = TEXT;

my $n = 0;

open(G, '>', 'g.R') || die "Cannot open g.R for writing: $!";
print G "library(MASS)\n";
print G "#library(mva)\n";
print G "library(cluster)\n";
print G "#library(ts)\n";

foreach my $file (@ARGV) {
    open(F, '<', $file) || die "Cannot open $file for reading: $!";
    my $new_file = $file;
    $new_file =~ s/\.txt$/.new__TMP__.txt/;
    open(W, '>', $new_file) || die "Cannot open $new_file for writing: $!";
    while(<F>) {
	if( $state == TEXT ) {
	    if( m/^\s\s\%G/ ){
		$state = GRAPH;
		$n++;
		my ($width, $height) = (600,600);
		if( m/^\s\s\%G\s*([0-9]+)\s+([0-9]+)/ ){
		    $width = $1;
		    $height = $2;
		}
		print G "\npng(file=\"g$n.png\", width=$width, height=$height)\n";
	    } else {
		print W $_;
	    }
	} else {
	    if( m/^\s\s\%--/ ){
		$state = TEXT;
		print G "dev.off()\n";
		print W "\n= g$n.png\n";
	    } else {
		print G $_;
		print W $_;
	    }
	}
    }
    close W;
    close F;
}
	
close(G);    
